"""Regenerate fixed-order revision illustrations from supplied numerical arrays."""
from PIL import Image,ImageDraw
import numpy as np
from release_runtime import EVIDENCE as E,read

def run(dest):
 dest.mkdir(parents=True,exist_ok=True);meta=read(E/'qmnist_confirmation_20261105/focal_stimuli.json');ids=[next(r['case'] for r in meta if r['task']=='occlusion' and r['level']==12 and r['truth']==c) for c in range(10)]
 with np.load(E/'qmnist_confirmation_20261105/focal_stimuli.npz',allow_pickle=False) as z:images=[z['input'][ids],z['clean'][ids]]
 for mode in ['none','pixel_retrieval','reference_decoding','full']:
  with np.load(E/'qmnist_retrieval_controls_20261105'/f'model71001_{mode}.npz',allow_pickle=False) as z:images.append(z['images'][ids])
 canvas=Image.new('RGB',(745,945),'white');draw=ImageDraw.Draw(canvas)
 for i,label in enumerate(['Input','Clean target','No feedback','Pixel reference','Decoded ref.','Full']):draw.text((85+i*110,10),label,fill='black')
 for row in range(10):
  draw.text((5,60+row*90),f'Category {row}',fill='black')
  for col,ims in enumerate(images):canvas.paste(Image.fromarray((np.clip(ims[row],0,1)*255).astype('uint8')).resize((72,72)),(85+col*110,40+row*90))
 canvas.save(dest/'focal_baseline_examples.png')
 # Recompute numerical bar data directly from case records.
 rows=read(E/'independent_image_evaluation_20261106/focal_results.json');modes=['none','fixed','full'];values=[]
 for mode in modes:
  rr=[r for r in rows if r['mode']==mode and r['task']=='mixture'];values.append(np.mean([r['mlp_full_agreement'] for r in rr]))
 canvas=Image.new('RGB',(700,320),'white');draw=ImageDraw.Draw(canvas);draw.text((15,12),'Independent-classifier agreement with the common full-model winner',fill='black')
 for i,(mode,value) in enumerate(zip(modes,values)):
  y=60+i*75;draw.text((10,y+10),mode,fill='black');draw.rectangle((85,y,85+value*500,y+35),fill=['#777777','#0072b2','#d55e00'][i]);draw.text((590,y+10),f'{value:.1%}',fill='black')
 draw.text((85,295),'Three models, 45 image pairs; all mixture proportions retained.',fill='black');canvas.save(dest/'independent_agreement.png')
 return dict(figures=['focal_baseline_examples.png','independent_agreement.png'])
