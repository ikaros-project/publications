"""Recompute the principal revision contrasts from per-case records, with original bootstrap rules."""
import numpy as np
from release_runtime import EVIDENCE as E,read

def close(a,b):
 if a is None or b is None:assert a is None and b is None;return
 np.testing.assert_allclose(a,b,atol=1e-12,rtol=1e-12)
def run():
 import qmnist_confirmation_common as q
 q.protocol=lambda:read(E/'qmnist_confirmation_20261105/protocol.json')
 import summarize_qmnist_confirmation as confirm
 import summarize_qmnist_retrieval_controls as retrieval
 import analyze_independent_image_evaluator as independent
 import analyze_spatial_pathway_ablation as ablation
 out={};checks=0
 d=E/'qmnist_confirmation_20261105';fr=read(d/'focal_results.json');sr=read(d/'spatial_results.json');expected=read(d/'summary.json')['summaries'];rr=[]
 for v in expected:
  spatial=v['task'] in ['completion','category_search'];got=confirm.stats(sr if spatial else fr,v['task'],v['level'],v['metric'],spatial)
  for k in ['off','on','difference','ci95']:close(got[k],v[k])
  rr.append(got);checks+=1
 out['confirmation']=rr
 d=E/'qmnist_retrieval_controls_20261105';rows=read(d/'results.json')['rows'];expected=read(d/'summary.json')['paired'];rr=[]
 for v in expected:
  got=retrieval.contrast(rows,v['task'],v['level'],v['metric'],v['control']);close(got['full_minus_control'],v['full_minus_control']);close(got['ci95'],v['ci95']);rr.append(got);checks+=1
 out['retrieval_controls']=rr
 d=E/'independent_image_evaluation_20261106';summary=read(d/'summary.json');fr=read(d/'focal_results.json');sr=read(d/'spatial_results.json');rr=[]
 for family,rows in [('focal',fr),('spatial',sr)]:
  for v in summary[family]:
   field='task' if family=='focal' else 'group';group=[r for r in rows if r[field]==v[field] and (v['level']=='all' or r['level']==v['level'])];full=[r for r in group if r['mode']=='full'];control={(r['seed'],r['case'],r.get('target')):r for r in group if r['mode']==v['mode']};got=independent.stats(full,v['metric'],control)
   for k in ['mean','control','difference','ci95']:close(got[k],v['full_minus_condition'][k])
   rr.append({k:v[k] for k in [field,'level','mode','metric']}|{'paired':got});checks+=1
 out['independent_evaluation']=rr
 d=E/'spatial_pathway_ablation_20261106';rows=read(d/'enriched_results.json');baseline={(r['seed'],r['case']):r for r in rows if r['mode']=='full'};rr=[]
 for v in read(d/'summary.json')['tasks']:
  group=[r for r in rows if r['task']==v['task'] and r['mode']==v['mode']]
  for metric,expected in v['paired_difference_from_full'].items():
   if expected is None:continue
   got=ablation.interval(group,metric,baseline);close(got['mean'],expected['mean']);close(got['ci95'],expected['ci95']);rr.append(dict(task=v['task'],mode=v['mode'],metric=metric,paired=got));checks+=1
 out['pathway_ablation']=rr
 d=E/'final_stability_20261105';rows=read(d/'spatial_results.json');focal=read(d/'focal_results.json');out['stability']={stage:dict(n=len(a),nonsettled=sum(not r['settled'] for r in a)) for stage in ['parameter','fresh','endpoint','release','diagnostic'] for a in [[r for r in rows if r['stage']==stage]]};out['stability']['focal']=dict(n=len(focal),nonsettled=sum(not r['settled'] for r in focal))
 assert out['stability']['parameter']['nonsettled']==28 and out['stability']['fresh']['nonsettled']==6 and out['stability']['endpoint']['nonsettled']==0
 out['validation']=dict(paired_statistics_checked=checks,all_match=True,method='Original crossed bootstrap functions applied to supplied per-case records. No model inference required.')
 return out
