"""Winner-only competitive patch learning; no topology, labels or upper feedback."""
from pathlib import Path
import numpy as np


def patches(image, kernel=7):
    return np.lib.stride_tricks.sliding_window_view(image, (kernel, kernel)).reshape(-1, kernel*kernel)


def reconstruct(selected):
    kernel = int(round(np.sqrt(selected.shape[-1])))
    side = 33-kernel
    selected = selected.reshape(side, side, kernel, kernel)
    result = np.zeros((32, 32), dtype=np.float32)
    counts = np.zeros((32, 32), dtype=np.float32)
    for dy in range(kernel):
        for dx in range(kernel):
            result[dy:dy+side, dx:dx+side] += selected[:, :, dy, dx]
            counts[dy:dy+side, dx:dx+side] += 1
    return result / counts


class Codebook:
    def __init__(self, prototypes, usage=None, updates=0):
        self.prototypes = np.asarray(prototypes, dtype=np.float32).copy()
        self.code_count, area = self.prototypes.shape
        self.kernel = int(round(np.sqrt(area)))
        assert self.kernel*self.kernel == area and 1 <= self.kernel <= 32
        self.side = 33-self.kernel
        self.positions = self.side*self.side
        self.usage = np.zeros(self.code_count, dtype=np.int64) if usage is None else usage.copy()
        self.updates = updates

    def process(self, image, train, rate, temperature=0):
        x = patches(image, self.kernel)
        distance = np.sum(x*x, axis=1)[:,None] + np.sum(self.prototypes**2, axis=1)[None,:] - 2*x@self.prototypes.T
        winners = np.argmin(distance, axis=1)
        if temperature > 0:
            # Stable softmax of negative mean-squared pixel distances.
            logits = -(distance-distance.min(axis=1,keepdims=True))/(self.kernel*self.kernel*temperature)
            weights = np.exp(logits)
            weights /= weights.sum(axis=1,keepdims=True)
            activity = weights.T
            reconstruction = reconstruct(weights@self.prototypes)
        else:
            activity = np.zeros((self.code_count,self.positions), dtype=np.float32)
            activity[winners, np.arange(self.positions)] = 1
            reconstruction = reconstruct(self.prototypes[winners])
        # All patches compete against the same pre-update codebook. Each winning
        # prototype moves once per image toward the mean of its assigned patches.
        if train:
            counts = np.bincount(winners, minlength=self.code_count)
            for k in np.flatnonzero(counts):
                self.prototypes[k] += rate * (x[winners == k].mean(axis=0) - self.prototypes[k])
            self.usage += counts
            self.updates += 1
        return activity.reshape(self.code_count,self.side,self.side), reconstruction


def init(ctx):
    global model, save_filename
    save_filename = str(ctx.parameters['save_file'])
    with np.load(str(ctx.parameters['load_file'])) as saved:
        model = Codebook(saved['prototypes'], saved['usage'], int(saved['updates']))


def tick(ctx):
    image = np.asarray(ctx.inputs['INPUT'], dtype=np.float32).reshape(32,32)
    value = np.asarray(ctx.parameters['train']).reshape(-1)[0]
    training = str(value).lower() in ('1','1.0','true','yes')
    rate = float(np.asarray(ctx.parameters['learning_rate']).reshape(-1)[0])
    temperature = float(np.asarray(ctx.parameters['temperature']).reshape(-1)[0])
    activity, reconstruction = model.process(image, training, rate, temperature)
    ctx.outputs['ACTIVITY'][:] = activity
    ctx.outputs['OUTPUT'][:] = reconstruction
    ctx.outputs['LOSS'][:] = np.mean((reconstruction-image)**2)
    ctx.outputs['RECONSTRUCTION_ABSOLUTE_ERROR'][:] = np.mean(np.abs(reconstruction-image))
    ctx.outputs['KL_LOSS'][:] = 0


def shutdown(ctx):
    filename = save_filename
    if filename:
        path = Path(filename)
        temporary = path.with_suffix('.tmp')
        with temporary.open('wb') as handle:
            np.savez(handle, prototypes=model.prototypes, usage=model.usage, updates=model.updates)
        temporary.replace(path)
