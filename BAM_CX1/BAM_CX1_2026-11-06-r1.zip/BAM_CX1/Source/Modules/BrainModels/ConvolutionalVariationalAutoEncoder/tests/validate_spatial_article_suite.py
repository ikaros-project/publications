"""Validate the final suite and reused evidence without rerunning inference."""
import json,hashlib,argparse
from pathlib import Path
from dataclasses import asdict
import numpy as np
from run_spatial_article_suite import ROOT as DATA,POP,BASE,CONFIRM,ABSENT,r,init
from summarize_spatial_article_suite import ROOT,PREFIX,read
from spatial_content_feedback import render_scene

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--partial',action='store_true');args=ap.parse_args()
    stats_path=ROOT/(PREFIX+('_partial' if args.partial else '_statistics')+'.json')
    protocol=json.loads((DATA/'protocol.json').read_text());jobs=json.loads((DATA/'jobs.json').read_text());meta=json.loads((DATA/'stimuli.json').read_text());stats=json.loads(stats_path.read_text())
    if not args.partial:assert stats['complete']
    analyzed={r['job'] for r in stats['rows']}
    here=Path(__file__).parent;checked={}
    for label,folder in [('suite',DATA),('overlap',POP),('search',CONFIRM),('blank',ABSENT)]:
        old=json.loads((folder/'protocol.json').read_text());checked[label]={name:digest(here/name)==sha for name,sha in old['source_sha256'].items()};assert all(checked[label].values())
    assert protocol['parameters']==asdict(r.PAR)
    init();assert r.FRONT.hashes==protocol['checkpoint_hashes']
    prior=json.loads((CONFIRM/'validation.json').read_text());assert prior['checkpoint_hashes']==protocol['checkpoint_hashes'];assert prior['frozen_parameters']==protocol['parameters']
    with np.load(DATA/'stimuli.npz') as z:
        assert z['input'].shape[1:]==(32,320) and z['clean'].shape==z['input'].shape and z['mask'].shape==z['input'].shape
        assert np.isfinite(z['input']).all() and z['input'].min()>=0 and z['input'].max()<=1
        for m in meta:
            if m['group']=='imagery':assert not z['input'][m['case']].any()
            if m['group']=='duplicates':np.testing.assert_array_equal(z['input'][m['case'],:,64:96],z['input'][m['case'],:,224:256])
    counts={g:sum(j['group']==g for j in jobs) for g in protocol['counts']};assert counts==protocol['counts'] and len(jobs)==1093
    parity=[];experimental=0
    for job in jobs:
        if args.partial and job['job'] not in analyzed:continue
        folder=DATA/f"trial{job['job']:04d}";row=json.loads((folder/'result.json').read_text());assert row['weights_unchanged'];a=read(folder)
        assert a['final_render'].shape==(32,320) and a['final_probability'].shape==(351,10) and a['spatial_trace'].shape==(600,351)
        assert row['settled']==bool(a['changes'][-100:].max()<5e-6)
        np.testing.assert_array_equal(a['final_render'],render_scene(a['final_field_predictions'],320))
        np.testing.assert_allclose(a['final_probability'].sum(1),1,atol=1e-5)
        for key in ['condition','case','group','target','spatial_position','category_cue','feedback']:assert row[key]==job[key]
        if job['group']=='parity':
            old=POP/'focused_population'/'case00_combined_category_A' if job['condition']=='overlap' else CONFIRM/'present'/'case00_combined_category_A'
            with np.load(old/'arrays.npz') as z:
                for key in z.files:np.testing.assert_array_equal(a[key],z[key],err_msg=key)
            parity.append(job['condition'])
        else:experimental+=1
    reused=0
    for rec in stats['overlap']['rows']:
        if rec['mode']!='feedback':continue
        folder=POP/'focused_population'/f"case{rec['source_case']:02d}_combined_category_{rec['cue']}";assert json.loads((folder/'result.json').read_text())['weights_unchanged'];read(folder);reused+=1
    for j in json.loads((CONFIRM/'jobs.json').read_text()):
        if j['condition']=='parity':continue
        folder=CONFIRM/j['condition']/f"case{j['case']:02d}_combined_category_{j['cue']}";read(folder);assert json.loads((folder/'diagnostic_result.json').read_text())['weights_unchanged'];reused+=1
    blanks=[]
    for j in json.loads((ABSENT/'jobs.json').read_text()):
        if j['condition']!='blank':continue
        folder=ABSENT/'blank'/f"case{j['case']:02d}_combined_category_{j['cue']}";a=read(folder);blanks.append(a['final_render']);assert not a['spatial_trace'].any();assert json.loads((folder/'diagnostic_result.json').read_text())['weights_unchanged'];reused+=1
    assert len(blanks)==10 and all(np.array_equal(a,blanks[0]) for a in blanks)
    assert reused==90 and experimental==sum(r['group']!='parity' for r in stats['rows']) and set(parity)=={'overlap','search'} and r.FRONT.unchanged()
    if not args.partial:assert experimental==1091
    out=dict(all_required_checks_passed=bool(stats['complete'] and experimental==1091),validated_completed_subset=True,source_hashes_match=checked,checkpoint_hashes=protocol['checkpoint_hashes'],parameters=protocol['parameters'],maximum_feedback=.65,new_experimental_trials=experimental,reused_experimental_trials=reused,reproduction_trials=2,experimental_total=experimental+reused,all_saved_arrays_finite=True,weights_frozen=True,exact_reproduction=parity,all600_updates=True,all_cases32x320=True,all351_fields=True,uniform_rendering_exact=True,probabilities_normalized=True,settling_recomputed=True,blank_category_only_identical=True,stimuli_sha256=digest(DATA/'stimuli.npz'),analysis_sha256=digest(here/'summarize_spatial_article_suite.py'),statistics_sha256=digest(stats_path),note='Numerical/provenance validation. Figure and final manuscript visual inspection are recorded separately after rendering.')
    (ROOT/(PREFIX+('_validation_partial' if args.partial else '_validation')+'.json')).write_text(json.dumps(out,indent=2)+'\n');print('VALIDATED',experimental,'new and',reused,'reused experimental trials')
if __name__=='__main__':main()
