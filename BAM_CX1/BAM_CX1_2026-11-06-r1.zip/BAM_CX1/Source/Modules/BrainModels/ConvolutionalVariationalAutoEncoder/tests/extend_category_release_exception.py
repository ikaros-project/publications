"""Post hoc extension of the sole unsettled primary release case; no tuning."""
import json,hashlib
import numpy as np
import category_release_seed_worker as w
n=w.n;OUT=n.CAMPAIGN/'category_release_ten_seeds';SRC=OUT/'seed71009';seed=71009;j=60
folder=n.CAMPAIGN/'hierarchy_s71009';rd=n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit/grouped_softmax_s71009.npz';dp=n.CAMPAIGN/'local_linear_patch_decoder_ten_seeds/seed71009/local_decoder.npz'
paths=[folder/'model.state',rd,dp];hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
state=json.loads(paths[0].read_text())['items']
def weight(key):
 a=state['CVAE_TwoLayer.Upper.'+key];return np.array(a['value'],np.float32).reshape(a['shape'])
enc=weight('DIRECT_MEAN_WEIGHTS');eb=weight('DIRECT_MEAN_BIAS');dec=weight('DIRECT_DECODER_WEIGHTS');db=weight('DIRECT_DECODER_BIAS');del state
with np.load(rd) as z:rw=z['weights'];rb=z['bias']
with np.load(dp) as z:d=z['decoder'].astype(np.float32)
with np.load(SRC/'setup.npz') as z:
 p=z['release_lower_activity'][j:j+1].copy();ids=z['reference_ids'];chosen=z['chosen_reference_slots'][j].copy();release_pr=z['release_readout'][j:j+1].copy()
# Use the original 80-reference decoder batch before selecting competing references.
from argparse import Namespace
train,test,labels,tl=w.e.prepare_data(Namespace(train_count=60000,test_count=10000))
codes,_,_=w.e.read_codes(folder/'train_codes.csv',train,labels,128)
def decode(z):
 v=(z@dec+db).reshape(-1,64,676);v-=v.max(1,keepdims=True);return v-np.log(np.exp(v).sum(1,keepdims=True))
def render(q):return np.clip(w.local.overlap(np.exp(q).transpose(0,2,1)@d),0,1)
refs=np.exp(decode(codes[ids].astype(np.float32).reshape(80,128))).reshape(10,8,64,676)[np.arange(10),chosen]
with np.load(SRC/'released.npz') as saved:
 original_acts=saved['activities'][:,j].copy();original_prs=saved['probabilities'][:,j].copy();original_changes=saved['changes'][:,j].copy();original_final_image=saved['images'][-1,j].copy()
a=np.eye(10,dtype=np.float32)[[7]];pr=release_pr.copy();q=decode(p.reshape(1,-1)@enc+eb);initial_image=render(q);acts=[a[0].copy()];prs=[pr[0].copy()];changes=[];images=[];times=[]
for step in range(1,10001):
 an=original_acts[step:step+1] if step<=1000 else .8*a+.2*np.maximum(pr/pr.max(1,keepdims=True)-1.5*(a.sum(1,keepdims=True)-a),0)
 ww=an/an.sum(1,keepdims=True);Q=np.zeros_like(p)
 for c in range(10):Q+=ww[:,c,None,None]*refs[c]
 pn=.8*p+.2*Q;changes.append([float(abs(pn-p).max()),float(abs(an-a).max())]);p=pn;a=an;z=p.reshape(1,-1)@enc+eb;q=decode(z);pr=n.softmax(z@rw+rb).reshape(1,10,20).sum(2);acts.append(a[0].copy());prs.append(pr[0].copy())
 if step==1000:
  reconstruction_error=float(abs(render(q)[0]-original_final_image).max());readout_error=float(abs(pr[0]-original_prs[-1]).max());assert reconstruction_error<3e-5 and readout_error<3e-5
  pr=original_prs[-1:].copy();prs[-1]=pr[0].copy()
 if step in [1000,2000,4000,6000,8000] or (step>=9800 and step%5==0):images.append(render(q)[0]);times.append(step)
 if step%2000==0:print('exception replay',step,'/10000',flush=True)
acts=np.array(acts);prs=np.array(prs);changes=np.array(changes);images=np.array(images)
with np.load(SRC/'released.npz') as z:
 parity=float(abs(acts[:1001]-z['activities'][:,j]).max());assert parity<3e-5;np.testing.assert_array_equal(acts[:1001].argmax(1),z['activities'][:,j].argmax(1))
windows=[]
for start,end in [(800,1000),(4800,5000),(9800,10000)]:
 v=acts[start:end+1,7];peaks=np.flatnonzero((v[1:-1]>v[:-2])&(v[1:-1]>=v[2:]))+1
 windows.append(dict(start=start,end=end,category7_min=float(v.min()),category7_max=float(v.max()),peak_intervals=np.diff(peaks).tolist(),max_update=float(changes[start:end].max())))
result=dict(seed=seed,category=7,reference_slot=4,steps=10000,post_hoc=True,primary_endpoint=1000,settled_last10=bool(changes[-10:].max()<1e-5),late_winner_switches=int((np.diff(acts[-1000:].argmax(1))!=0).sum()),winner=int(acts[-1].argmax()),windows=windows,replay_activity_error=parity,reconstructed_endpoint_pixel_error=reconstruction_error,reconstructed_endpoint_readout_error=readout_error,continuation="Reconstructed p at1000 from saved release p and saved competition weights, verified image/readout; resumed autonomous dynamics to10000. Single-case BLAS may introduce floating-point phase shifts after1000.",weights_unchanged=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]==hashes)
assert result['weights_unchanged']
(OUT/'exception_extension.json').write_text(json.dumps(result,indent=2)+'\n');np.savez_compressed(OUT/'exception_extension.npz',activities=acts,probabilities=prs,changes=changes,images=images,image_iterations=times,release_image=initial_image)
w.f.gallery(OUT/'exception_late_images.png','Unsettled case: category 7, seed71009; late images after release',[[images[times.index(t)] for t in [9800,9805,9810,9815,9820,9825]]],['late activity'],[str(t) for t in [9800,9805,9810,9815,9820,9825]])
print(json.dumps(result,indent=2),flush=True)
