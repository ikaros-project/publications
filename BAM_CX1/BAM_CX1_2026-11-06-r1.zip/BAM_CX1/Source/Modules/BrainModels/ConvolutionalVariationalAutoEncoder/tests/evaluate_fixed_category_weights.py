"""Reviewer 1 comment 2: fix the feedback mixture after first category update."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
os.environ.setdefault('VECLIB_MAXIMUM_THREADS','2')
import json,time,csv
from pathlib import Path
import numpy as np
import evaluate_reference_bank_sensitivity as base
from evaluate_reference_bank_sensitivity import decode,render,probs
OUT=base.C/'fixed_category_weights_20261105'
MODES=['none','fixed','full']
def dump(name,value):base.dump(OUT/name,value)
def status(stage):dump('status.json',dict(stage=stage));print(stage,flush=True)
def simulate(m,ids,mode):
 feedback=mode!='none'
 fixed_weights=None
 """Exact affine-state reduction in real arithmetic; checked against stored full-state runs.
 p_t = s_t*b + sum_c h_tc*q_ref,c, s_t+sum_c h_tc=1.
 Thus z_t=s_t*z0+sum_c h_tc*encode(q_ref,c). No changing reference addresses.
 """
 rc=m['codes'][ids].astype(np.float32);rp=decode(m,rc.reshape(-1,128)).reshape(10,ids.shape[1],64,676)
 rz=rp.reshape(-1,64*676)@m['enc']+m['eb'];rz=rz.reshape(10,ids.shape[1],128)
 chosen=((m['z0'][:,None,None]-rc[None])**2).sum(3).argmin(2)
 chosen_z=np.stack([rz[c,chosen[:,c]] for c in range(10)],axis=1)
 pr=probs(m,m['z0']);a=pr/pr.max(1,keepdims=True);N=len(a)
 h=np.zeros((N,10),np.float64);s=1.;act=[a.copy()];coeff=[h.copy()];ss=[s];lastchanges=[]
 for step in range(1,501):
  an=.8*a+.2*np.maximum(pr/pr.max(1,keepdims=True)-1.5*(a.sum(1,keepdims=True)-a),0)
  weights=an/an.sum(1,keepdims=True)
  if step==1:fixed_weights=weights.copy()
  drive=fixed_weights if mode=='fixed' else weights
  hn=.8*h+.1*drive if feedback else h
  sn=.8*s+.1 if feedback else s
  if step>490:
   dc=hn-h;dp=np.empty(N)
   # Compute actual local-code change, not merely a latent-space proxy.
   for j in range(N):
    change=(sn-s)*m['b'][j].astype(np.float64)
    for c in range(10):change+=dc[j,c]*rp[c,chosen[j,c]]
    dp[j]=np.abs(change).max()
   lastchanges.append(np.maximum(dp,np.abs(an-a).max(1)))
  a=an;h=hn;s=sn
  z=s*m['z0']+np.einsum('nc,ncd->nd',h,chosen_z)
  if feedback:pr=probs(m,z)
  act.append(a.copy());coeff.append(h.copy());ss.append(s)
 im=render(m,z);act=np.array(act);ch=np.array(lastchanges)
 assert np.isfinite(im).all() and np.isfinite(act).all()
 assert np.max(np.abs(s+h.sum(1)-1))<2e-6
 return dict(first_weights=fixed_weights,final_weights=weights,images=im,acts=act,changes=ch,chosen=chosen,ids=ids,coeff=np.array(coeff),base_coeff=np.array(ss))

def main():
 OUT.mkdir(exist_ok=True);status('loading frozen model')
 m=base.load()
 refs=json.loads((base.C/'category_feedback_diagnostic/reference_indices.json').read_text())['71001']
 ids=np.array([refs[str(c)] for c in range(10)])
 protocol=dict(model_seed=71001,modes=MODES,reference_count_per_category=8,reference_ids=ids.tolist(),steps=500,alpha=.2,inhibition=1.5,feedback_fraction=.5,stimuli='Same 220 mixtures and 160 occlusion inputs used in the bank sensitivity study, including intact controls.',fixed_control='Compute normalized category weights after the first competition update from initial sensory evidence and hold that feedback mixture constant for all 500 updates. Continue to re-encode sensory state and update category activity, but do not feed revised category weights back into the mixture.',full='Ordinary recurrent update with evolving normalized category weights.',none='Keep local code state equal to initial sensory encoding while category competition continues.',reference_selection='Nearest exemplar per category chosen from original input, held fixed in all conditions.',scope='One frozen network and reused 3/8 stimuli. Descriptive paired comparisons, not independent confirmation or variation across trained models. No spatial tests.',implementation='Affine coefficient reduction of fixed-reference local state; same equations as prior parity-validated runner.',checkpoint_sha256=m['hashes'],script_sha256=base.sha(Path(__file__)),dependency_sha256=base.sha(Path(base.__file__)))
 pp=OUT/'protocol.json'
 if pp.exists():assert json.loads(pp.read_text())==protocol
 else:dump('protocol.json',protocol)
 results={};arrays={};checks={}
 for mode in MODES:
  status('running '+mode);start=time.monotonic();a=simulate(m,ids,mode)
  rows=base.score(m,a,0,8)
  for row in rows:row['mode']=mode;row.pop('bank');row.pop('size')
  if mode=='full':
   checks['full_activity_error']=float(abs(a['acts']-m['known_acts']).max());checks['full_image_error']=float(abs(a['images']-m['known_images']).max())
   assert checks['full_activity_error']<3e-5 and checks['full_image_error']<3e-5
   assert np.array_equal(a['acts'].argmax(2),m['known_acts'].argmax(2))
   assert all(x['pixel_prediction']==y['pixel_prediction'] for x,y in zip(rows,m['mixrows']+m['ocrows']))
  if mode=='none':
   om=json.loads((base.original.OUT/'seed71001_results.json').read_text())['cases']
   oo=json.loads((base.C/'relaxation_occlusion_ten_seeds/seed71001/results.json').read_text())['cases']
   old=[r for r in om if r['method']=='none']+[r for r in oo if r['method']=='none']
   assert all(x['pixel_prediction']==y['pixel_prediction'] and x['final_winner']==y['final_winner'] for x,y in zip(rows,old))
   checks['no_feedback_labels_match']=True
  if mode=='fixed':
   expected=.5*(1-.8**500)*a['first_weights'];checks['fixed_closed_form_coefficient_error']=float(abs(a['coeff'][-1]-expected).max())
   assert checks['fixed_closed_form_coefficient_error']<1e-7
   np.testing.assert_allclose(a['base_coeff'][-1],.5+.5*.8**500,atol=1e-14)
  results[mode]=dict(cases=rows,summary=base.summary(rows),seconds=time.monotonic()-start)
  arrays[mode]=a
  np.savez_compressed(OUT/(mode+'.npz'),images=a['images'],activities=a['acts'],last10changes=a['changes'],first_weights=a['first_weights'],final_weights=a['final_weights'],chosen_reference_slots=a['chosen'],reference_ids=ids)
  dump(mode+'.json',results[mode])
 np.testing.assert_array_equal(arrays['fixed']['first_weights'],arrays['full']['first_weights'])
 np.testing.assert_array_equal(arrays['fixed']['chosen'],arrays['full']['chosen'])
 np.testing.assert_array_equal(arrays['fixed']['acts'][1],arrays['full']['acts'][1])
 checks['matched_first_update_and_reference_choices']=True
 assert {str(p.relative_to(base.C)):base.sha(p) for p in m['paths']}==m['hashes']
 comparisons=[]
 for j in range(380):
  f=results['fixed']['cases'][j];r=results['full']['cases'][j]
  comparisons.append(dict(case_index=j,task=f['task'],category_differs=f['final_winner']!=r['final_winner'],pixel_label_differs=f['pixel_prediction']!=r['pixel_prediction'],image_mse=float(((arrays['fixed']['images'][j]-arrays['full']['images'][j])**2).mean()),delta_image_agreement=int(r['image_winner_agreement'])-int(f['image_winner_agreement']),delta_hidden_mse=r.get('hidden_mse')-f.get('hidden_mse') if f.get('hidden_mse') is not None else None))
 dump('results.json',dict(protocol=protocol,conditions=results,checks=checks,paired_full_minus_fixed=comparisons,weights_unchanged=True))
 with (OUT/'summary.csv').open('w') as out:
  summary=[dict(mode=mode,**a) for mode in MODES for a in results[mode]['summary']];w=csv.DictWriter(out,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
 with (OUT/'per_case.csv').open('w') as out:
  rows=[r for v in results.values() for r in v['cases']];w=csv.DictWriter(out,fieldnames=sorted(set(k for r in rows for k in r)));w.writeheader();w.writerows(rows)
 from PIL import Image,ImageDraw,ImageFont
 selected=[37,300,340];canvas=Image.new('RGB',(1120,630),'white');draw=ImageDraw.Draw(canvas);font=ImageFont.load_default(size=18)
 for j,label in enumerate(['Input','No feedback','Fixed weights','Full recurrence']):draw.text((240+215*j,15),label,fill='black',font=font)
 for i,idx in enumerate(selected):
  y=55+i*185;draw.text((10,y+55),['Prior mixture example','12-pixel deletion','16-pixel deletion'][i],fill='black',font=font)
  for j,im in enumerate([m['x'][idx]]+[arrays[k]['images'][idx] for k in MODES]):canvas.paste(Image.fromarray(np.uint8(np.clip(im,0,1)*255)).resize((160,160),Image.Resampling.NEAREST),(240+215*j,y))
 canvas.save(OUT/'fixed_weights_examples.png')
 lines=['# Fixed category-weight feedback control','','## Protocol','','Original eight-reference bank, one frozen network, 220 existing mixtures and 160 occlusion inputs. All conditions run 500 updates with alpha 0.2, inhibition 1.5 and feedback fraction 0.5 when enabled. In the fixed control, normalized category weights are computed after the first category update and retained for feedback. Category activity itself continues to evolve. All reference selections remain fixed.','','These are descriptive comparisons on reused 3/8 stimuli. No learning, spatial extension or independent confirmation was performed.','','## Results','','| Task | Condition | Image/winner agreement | Category accuracy | Winner changes | Hidden MSE | Visible MSE |','| --- | --- | ---: | ---: | ---: | ---: | ---: |']
 for task,level in [('mixture','all'),('mixture','equal')]+[('occlusion',x) for x in [0,8,12,16]]:
  for mode in MODES:
   a=next(a for a in results[mode]['summary'] if a['task']==task and a['level']==level)
   fmt=lambda v:'—' if v is None else f'{v:.6f}'
   acc='—' if a['category_correct'] is None else f"{a['category_correct']:.2%}"
   lines.append(f"| {task} {level} | {mode} | {a['image_winner_agreement']:.2%} | {acc} | {round(a['changed_winner']*a['n'])}/{a['n']} | {fmt(a['hidden_mse'])} | {fmt(a['visible_mse'])} |")
 lines+=['','## Verification','',json.dumps(checks,indent=2),'','All frozen model hashes remain unchanged. Full-model category trajectories and final pixel-classifier labels match the original results. The no-feedback labels match the saved baseline. The fixed-control coefficients match the analytical fixed-mixture solution.','','## Interpretation boundary','','This isolates the contribution of recurrent category weighting. Completion retained by the fixed control is achievable without updating feedback category weights. It does not isolate learned representations from direct pixel-space retrieval, or prove independence from reference selection. Image/winner agreement is distinct from correctness.','','Examples use the existing mixture case 37 and the first source image at two occlusion sizes, chosen without inspecting the new outcomes. See results.json for paired per-case differences and unsettled endpoints.']
 report='\n'.join(lines)+'\n';(OUT/'REPORT.md').write_text(report)
 (Path(__file__).resolve().parents[5]/'Manuscript/fixed_category_weights_source_notes.md').write_text(report)
 status('complete');print(report,flush=True)
if __name__=='__main__':main()
