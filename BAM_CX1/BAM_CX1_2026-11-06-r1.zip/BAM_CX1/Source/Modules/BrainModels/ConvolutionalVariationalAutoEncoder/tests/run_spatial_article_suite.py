"""Six article questions, one frozen spatial/content configuration; resumable."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import argparse,concurrent.futures,hashlib,json,time,fcntl
from pathlib import Path
from dataclasses import asdict
import numpy as np
import run_spatial_overlap_pilot as r
from run_spatial_population_feedback import PopulationFeedback,ROOT as POP,BASE
from run_spatial_final_confirmation import ROOT as CONFIRM
from run_spatial_absent_category import ROOT as ABSENT
from neural_spatial_rate_model import Circuit,windows
from spatial_content_feedback import render_scene
from evaluate_spatial_single_stimulus import CAMPAIGN
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
ROOT=CONFIRM.parent/'article_fixed_model_suite'
SNAP=[0,8,32,128,300,600]

def init():r.init()

def prepare():
    ROOT.mkdir(exist_ok=True)
    if (ROOT/'protocol.json').exists():return
    raw=r.r.e.full.read_idx_images(r.r.e.full.RAW_ROOT/'t10k-images-idx3-ubyte.gz',10000)
    labels=r.r.e.full.read_idx_labels(r.r.e.full.RAW_ROOT/'t10k-labels-idx1-ubyte.gz',10000)
    image=lambda i:r.r.e.full.center_and_pad(raw[i]).astype(np.float32)/255
    cases=[];inputs=[];clean=[];masks=[];jobs=[]
    def case(group,x,positions,categories,ids,truth=None,mask=None,**kw):
        j=len(cases);cases.append(dict(case=j,group=group,positions=positions,categories=categories,test_indices=ids,**kw));inputs.append(x);clean.append(x if truth is None else truth);masks.append(np.zeros_like(x,bool) if mask is None else mask);return j
    def job(j,name,target=None,spatial=False,category=False,feedback=True):
        m=cases[j];jobs.append(dict(job=len(jobs),case=j,group=m['group'],condition=name,target=target,spatial_position=m['positions'][target] if spatial else None,category_cue=m['categories'][target] if category else None,feedback=feedback))
    ids=json.loads((r.r.OUT/'focused_step_boundary_checks/protocol.json').read_text())['single_indices'];assert len(ids)==100
    init();focal,_=r.FRONT.infer_pixels(np.stack([image(i) for i in ids]));focalpred=dict(zip(ids,focal.argmax(1).tolist()))
    for i in ids:
        for pos in [0,16,144,272,288]:
            x=np.zeros((32,320),np.float32);x[:,pos:pos+32]=image(i)
            j=case('translation',x,[pos],[int(labels[i])],[i],focal_category=focalpred[i]);job(j,'uncued',0)
    src=CAMPAIGN/'spatial_two_objects_seed1'
    with np.load(src/'arrays.npz') as z:xx=z['scenes']
    mm=[m for m in json.loads((src/'cases.json').read_text()) if m['condition']=='none'];assert len(mm)==90
    for m in mm:
        x=xx[m['scene']];j=case('spatial_selection',x,[m['left'],m['right']],[m['left_category'],m['right_category']],[m['left_index'],m['right_index']],source_scene=m['scene'],pair=m['pair'],swap=m['swap'])
        job(j,'neutral')
        for k in [0,1]:job(j,'spatial_'+str(k),k,spatial=True)
    from run_spatial_relative_binding_expanded import ROOT as COMPLETION
    with np.load(COMPLETION/'stimuli.npz') as z:xx=z['input'];truth=z['clean'];mask=z['mask']
    for m in json.loads((COMPLETION/'stimuli.json').read_text()):
        if not m['condition'].startswith('spatial'):continue
        j=case('completion',xx[m['case']],[m['target_position'],m['distractor_position']],[m['target_category'],m['distractor_category']],m['test_indices'],truth=truth[m['case']],mask=mask[m['case']],pair=m['pair'],occlusion=m['occlusion'])
        for on in [True,False]:job(j,'feedback' if on else 'feedback_off',0,spatial=True,feedback=on)
    from run_spatial_set_size import ROOT as LOAD
    old=json.loads((LOAD/'stimuli.json').read_text())
    # Compact the previous nested layouts to the fixed320-pixel canvas. Rank preserves category ordering.
    full={(m['base'],m['mirror']):m for m in old if m['count']==8}
    for m in old:
        master=full[m['base'],m['mirror']];slots={pos:int(rank*40) for rank,pos in enumerate(sorted(master['positions']))};pp=[slots[p] for p in m['positions']];x=np.zeros((32,320),np.float32)
        for i,pos in zip(m['test_indices'],pp):x[:,pos:pos+32]=image(i)
        j=case('set_size',x,pp,m['categories'],m['test_indices'],base=m['base'],mirror=m['mirror'],count=m['count'])
        for k in [0,1]:job(j,'category_'+str(k),k,category=True)
    # Identical copies: first fixed translation exemplar per category; no outcome screening.
    for cat in range(10):
        idx=next(i for i in ids if labels[i]==cat);x=np.zeros((32,320),np.float32)
        for pos in [64,224]:x[:,pos:pos+32]=image(idx)
        j=case('duplicates',x,[64,224],[cat,cat],[idx,idx]);job(j,'category_only',0,category=True)
        for k in [0,1]:job(j,'category_spatial_'+str(k),k,spatial=True,category=True)
    with np.load(BASE/'independent'/'stimuli.npz') as z:xx=z['input']
    for m in json.loads((BASE/'independent'/'stimuli.json').read_text()):
        cats=m['categories'][:2 if m['kind']=='pair' else 1];pp=m['positions'][:len(cats)];idx=m['test_indices'][:len(cats)]
        j=case('overlap_control',xx[m['case']],pp,cats,idx,source_case=m['case'],separation=m['separation'],kind=m['kind'],pair=m['pair'])
        for k in range(len(cats)):job(j,'feedback_off_'+str(k),k,spatial=True,category=True,feedback=False)
    for cat in range(10):
        j=case('imagery',np.zeros((32,320),np.float32),[144],[cat],[],requested_category=cat)
        job(j,'category_spatial',0,spatial=True,category=True)
        if cat==0:job(j,'spatial_only',0,spatial=True)
    # Reproduce two completed final-model trials through the unified core.
    for source,oldj,k in [('overlap',0,0),('search',0,0)]:
        source_root=BASE/'independent' if source=='overlap' else CONFIRM/'present'
        mm=json.loads((source_root/'stimuli.json').read_text())[oldj]
        with np.load(source_root/'stimuli.npz') as z:x=z['input'][oldj]
        j=case('parity',x,mm['positions'],mm['categories'],mm['test_indices'],source=source,source_case=oldj)
        job(j,source,k,spatial=source=='overlap',category=True)
    np.savez_compressed(ROOT/'stimuli.npz',input=inputs,clean=clean,mask=masks);r.r.dump(ROOT/'stimuli.json',cases)
    # Verify the core early, then cover every question before the bulk translation rerun.
    jobs.sort(key=lambda j:(j['group']!='parity',j['group']=='translation',j['job']))
    r.r.dump(ROOT/'jobs.json',jobs)
    counts={g:sum(j['group']==g for j in jobs) for g in sorted(set(j['group'] for j in jobs))}
    names=['run_spatial_article_suite.py','run_spatial_population_feedback.py','run_spatial_overlap_feedback_strength.py','run_spatial_overlap_pilot.py','neural_spatial_rate_model.py','spatial_content_feedback.py','cached_spatial_content_feedback.py']
    protocol=dict(parameters=asdict(r.PAR),maximum_feedback=.65,steps=600,early_stop=False,counts=counts,new_total=len(jobs),checkpoint_hashes=r.FRONT.hashes,source_sha256={n:hashlib.sha256(Path(__file__).with_name(n).read_bytes()).hexdigest() for n in names},scope='Six article questions with one frozen seed71001 model. Reuse40 final-confirmation search trials,40 focused population overlap trials and10 category-only blank trials after hash/parameter checks. New matched controls disable only the content-feedback mixture; all other equations stay fixed.',geometry='All cases32x320,351 stride-one fields including zero extension. Translation uses the original100 images at0/16/144/272/288. Spatial selection uses all90 original two-object layouts, neutral and both spatial cues. Completion reuses20 original pairs at0/8/12 deletion, with and without content feedback. Nested2/4/8-object layouts reuse80 original images on slots0/40/.../280 with original rank order, both mirrored layouts and both category targets; a32pixel field cannot include two stimulus tiles, but sensory gain can span neighbors. These compact layouts are not identical to prior640pixel displays.',duplicates='Ten identical-image pairs, one per category, at64/224; category alone and category plus left/right spatial cue, with neutral initial state. No sequences or weak-cue tuning.',overlap='Reuse40 focused population outputs at0/8/40 and isolated controls; add40 matched content-feedback-disabled trials with the same category/spatial cues and references. Cue reversals at full overlap hold spatial cue identical.',imagery='Reuse10 blank category-only runs; add10 category+spatial cues at144 and one shared spatial-only blank control. Fixed zero sensory input and zero initial spatial activity.',scoring='Primary outcomes specified by question: category/localization and offsets; gain/feature selection under spatial cue; location and unforced local category under category cues; missing/visible/distractor reconstruction error with clean masks used only for scoring; cue-specific overlap feature contrast and matched feedback-off effects; blank-image category specificity and location. Shared mismatch is spatially weighted Eplus+Eminus, undefined without active spatial mass. All600update endpoints retained. Settling last100 max normalized change<5e-6. No tuning, extra seeds, sequences or dedicated oscillation study. Original image groups, mirrors, cues and translations are dependent observations; report denominators honestly.')
    r.r.dump(ROOT/'protocol.json',protocol);print('PREPARED',counts,flush=True)

def worker(job):
    folder=ROOT/f"trial{job['job']:04d}";folder.mkdir(exist_ok=True)
    with (folder/'run.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        if (folder/'result.json').exists():return json.loads((folder/'result.json').read_text())
        m=json.loads((ROOT/'stimuli.json').read_text())[job['case']]
        with np.load(ROOT/'stimuli.npz') as z:x=z['input'][job['case']]
        c=Circuit(x[None],r.PAR,closed=True,padding=31);local=PopulationFeedback(r.FRONT,c,job['feedback'],True)
        u=np.zeros_like(c.a);v=np.zeros_like(c.c)
        if job['spatial_position'] is not None:u[0,job['spatial_position']+31]=2
        if job['category_cue'] is not None:v[0,job['category_cue']]=2
        changes=[];ct=[];at=[];gt=[];snap={};start=time.time()
        for tick in range(601):
            prob,y=r.FRONT.evidence(local.q)
            if tick in SNAP:
                snap[f't{tick}_render']=render_scene(y,320);snap[f't{tick}_fields']=y[np.array(m['positions'])+31].copy()
            if tick==600:break
            new,dq,gate=local.propose(c);_,sensory_prediction=r.FRONT.infer_pixels(windows(c.s,31)[0])
            change=c.update(prob[None],sensory_prediction[None],u=u,v=v);local.q=new
            changes.append(max(float(change[0]),dq)/r.PAR.alpha);ct.append(c.c[0].copy());at.append(c.a[0].copy());gt.append(c.gain()[0].copy())
            if (tick+1)%100==0:r.r.dump(folder/'progress.json',dict(tick=tick+1,seconds=time.time()-start,rate=changes[-1],group=job['group']))
        assert r.FRONT.unchanged() and np.isfinite(local.q).all() and np.isfinite(y).all();np.testing.assert_allclose(local.q.sum(1),1,atol=1e-5)
        arr=dict(**snap,final_render=render_scene(y,320),final_field_predictions=y,final_probability=prob,final_sensory=c.s[0],final_binding=c.t[0],category_trace=ct,spatial_trace=at,gain_trace=gt,changes=changes,reference_slots=local.chosen,reference_ids=r.FRONT.ids,final_positive_error=c.ep[0],final_negative_error=c.em[0],final_support=c.m[0])
        if job['group']=='parity':
            src=POP/'focused_population'/'case00_combined_category_A' if m['source']=='overlap' else CONFIRM/'present'/'case00_combined_category_A'
            with np.load(src/'arrays.npz') as z:
                for key in z.files:np.testing.assert_array_equal(np.array(arr[key]),z[key],err_msg=key)
        np.savez_compressed(folder/'arrays.npz',**arr)
        mass=float(c.a.sum());loc=int(c.a[0].argmax())-31 if mass>1e-7 else None;idx=None if loc is None else loc+31
        row=dict(**job,metadata=m,spatial_mass=mass,location=loc,category=int(c.c[0].argmax()) if c.c.sum()>1e-7 else None,category_mass=float(c.c.sum()),local_category=None if idx is None else int(prob[idx].argmax()),settled=bool(max(changes[-100:])<5e-6),last100_rate=float(max(changes[-100:])),seconds=time.time()-start,weights_unchanged=True,parity_exact=job['group']=='parity')
        r.r.dump(folder/'result.json',row);print('DONE',job['job'],job['group'],job['condition'],round(row['seconds'],1),flush=True);return row

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=24);ap.add_argument('--prepare',action='store_true');args=ap.parse_args();prepare()
    if args.prepare:return
    jobs=json.loads((ROOT/'jobs.json').read_text());start=time.time();rows=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,initializer=init) as pool:
        # Mandatory parity before any new inference.
        parity=[j for j in jobs if j['group']=='parity']
        rows+=list(pool.map(worker,parity));assert all(r['parity_exact'] for r in rows)
        futures=[pool.submit(worker,j) for j in jobs if j['group']!='parity']
        for f in concurrent.futures.as_completed(futures):
            rows.append(f.result());r.r.dump(ROOT/'status.json',dict(completed=len(rows),total=len(jobs),seconds=time.time()-start,workers=args.workers,by_group={g:sum(x['group']==g for x in rows) for g in sorted(set(x['group'] for x in rows))}))
    r.r.dump(ROOT/'results.json',rows);print('ARTICLE SUITE COMPLETE',flush=True)
if __name__=='__main__':main()
