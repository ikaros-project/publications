"""Question-based analysis of the fixed-model article suite; all outcomes retained."""
import json,argparse,hashlib
from pathlib import Path
import numpy as np
from run_spatial_article_suite import ROOT as DATA,POP,BASE,CONFIRM,ABSENT
from generate_spatial_manuscript_figures import ROOT
PREFIX='spatial_article_suite'

def mean(values):
    v=[x for x in values if x is not None];return float(np.mean(v)) if v else None

def masked(a,mask):return float(a[mask].mean()) if mask.any() else None

def read(folder):
    with np.load(folder/'arrays.npz') as z:a={k:z[k] for k in z.files}
    assert all(np.isfinite(v).all() for v in a.values()) and len(a['changes'])==600
    return a

def base_metrics(a,cats,positions):
    spatial=a['spatial_trace'][-1].astype(np.float64);mass=float(spatial.sum());active=mass>1e-7;idx=int(spatial.argmax());loc=idx-31 if active else None
    weights=spatial/max(mass,1e-30);catmass=float(a['category_trace'][-1].sum());globalcat=int(a['category_trace'][-1].argmax()) if catmass>1e-7 else None
    candidates=[] if loc is None else [i for i,pos in enumerate(positions) if abs(loc-pos)<=16]
    selected=candidates[0] if len(candidates)==1 else None
    return dict(location=loc,spatial_mass=mass,category_mass=catmass,category=globalcat,local_category=int(a['final_probability'][idx].argmax()) if active else None,selected_object=selected,settled=bool(a['changes'][-100:].max()<5e-6),last100_rate=float(a['changes'][-100:].max()),last100_location_changes=int(np.count_nonzero(np.diff(a['spatial_trace'][-100:].argmax(1)))) if active else None,dominance=float(spatial.max()/mass) if active else None,basin_shares=[float(weights[abs(np.arange(-31,320)-pos)<=16].sum()) if active else None for pos in positions],shared_mismatch=float(weights@(a['final_positive_error']+a['final_negative_error'])) if active and 'final_positive_error' in a else None)

def collect(partial=False):
    protocol=json.loads((DATA/'protocol.json').read_text());jobs=json.loads((DATA/'jobs.json').read_text());meta=json.loads((DATA/'stimuli.json').read_text())
    with np.load(DATA/'stimuli.npz') as z:inputs=z['input'];clean=z['clean'];masks=z['mask']
    rows=[];ref={};figdata={}
    for job in jobs:
        folder=DATA/f"trial{job['job']:04d}"
        if not (folder/'result.json').exists():
            if partial:continue
            raise RuntimeError('Incomplete suite')
        rr=json.loads((folder/'result.json').read_text());assert rr['weights_unchanged'];a=read(folder);m=meta[job['case']];j=job['case'];x=inputs[j];truth=clean[j]
        if j in ref:np.testing.assert_array_equal(a['reference_slots'],ref[j])
        else:ref[j]=a['reference_slots']
        row=dict(**job,metadata=m,**base_metrics(a,m['categories'],m['positions']))
        k=job['target'];targetcat=None if k is None else m['categories'][k];pos=None if k is None else m['positions'][k]
        row.update(target_category=targetcat,global_correct=None if targetcat is None else row['category']==targetcat,local_correct=None if targetcat is None else row['local_category']==targetcat,located=None if pos is None else row['location'] is not None and abs(row['location']-pos)<=16,offset=None if pos is None or row['location'] is None else row['location']-pos)
        row['joint_success']=row['located'] and row['local_correct'] if pos is not None else None
        if job['group']=='translation':row['focal_correct']=m['focal_category']==targetcat
        if job['group']=='spatial_selection':
            row['sensory_feature_intensity']=[];row['gain_mean']=[];row['render_feature_intensity']=[]
            for pp in m['positions']:
                mask=truth[:,pp:pp+32]>.05
                row['sensory_feature_intensity'].append(masked(a['final_sensory'][:,pp:pp+32],mask));row['gain_mean'].append(float(a['gain_trace'][-1,pp:pp+32].mean()));row['render_feature_intensity'].append(masked(a['final_render'][:,pp:pp+32],mask))
        if job['group']=='completion':
            target=a['final_field_predictions'][pos+31];ct=truth[:,pos:pos+32];mask=masks[j,:,pos:pos+32];dp=m['positions'][1];dy=a['final_field_predictions'][dp+31];dt=truth[:,dp:dp+32]
            row.update(hidden_mse=masked((target-ct)**2,mask),visible_mse=masked((target-ct)**2,~mask),visible_foreground_mse=masked((target-ct)**2,(ct>.05)&~mask),distractor_mse=float(((dy-dt)**2).mean()),target_field_category=int(a['final_probability'][pos+31].argmax()))
        if job['group']=='imagery':
            row.update(render_mean=float(a['final_render'].mean()),render_max=float(a['final_render'].max()),cued_field_category=int(a['final_probability'][pos+31].argmax()),support_max=float(a['final_support'].max()),sensory_max=float(a['final_sensory'].max()))
        rows.append(row)
    return rows,protocol,meta

def summarize(rows,protocol):
    out=dict(scope='One frozen network and common32x320 model. Fixed600update endpoints; no parameter tuning or selected-outcome removal. Conditions sharing original images, layouts or cues are dependent.',rows=rows,protocol=protocol,complete=len(rows)==protocol['new_total'],settled=sum(r['settled'] for r in rows if r['group']!='parity'),experimental_n=sum(r['group']!='parity' for r in rows))
    tr=[r for r in rows if r['group']=='translation'];out['translation']=dict(n=len(tr),by_position=[dict(position=p,n=len(rr),correct=sum(r['global_correct'] for r in rr),located=sum(r['located'] for r in rr),settled=sum(r['settled'] for r in rr)) for p in [0,16,144,272,288] for rr in [[r for r in tr if r['metadata']['positions'][0]==p]]])
    ids=sorted(set(r['metadata']['test_indices'][0] for r in tr));complete=[[r for r in tr if r['metadata']['test_indices'][0]==i] for i in ids];complete=[v for v in complete if len(v)==5]
    out['translation'].update(complete_images=len(complete),category_consistent=sum(all(r['category'] is not None for r in rr) and len(set(r['category'] for r in rr))==1 for rr in complete),offset_consistent=sum(all(r['offset'] is not None for r in rr) and len(set(r['offset'] for r in rr))==1 for rr in complete),focal_correct=sum(rr[0]['focal_correct'] for rr in complete))
    ss=[r for r in rows if r['group']=='spatial_selection'];cu=[r for r in ss if r['target'] is not None];deltas=[]
    for r in cu:
        neutral=next((v for v in ss if v['case']==r['case'] and v['target'] is None),None)
        if neutral:
            k=r['target'];deltas.append(dict(case=r['case'],target=k,target_sensory=r['sensory_feature_intensity'][k]-neutral['sensory_feature_intensity'][k],distractor_sensory=r['sensory_feature_intensity'][1-k]-neutral['sensory_feature_intensity'][1-k],target_gain=r['gain_mean'][k],distractor_gain=r['gain_mean'][1-k]))
    out['spatial_selection']=dict(n=len(ss),cued_n=len(cu),correct=sum(r['global_correct'] for r in cu),located=sum(r['located'] for r in cu),settled=sum(r['settled'] for r in cu),neutral_n=len(ss)-len(cu),deltas=deltas,mean_target_sensory_change=mean([r['target_sensory'] for r in deltas]),mean_distractor_sensory_change=mean([r['distractor_sensory'] for r in deltas]))
    out['set_size']=[dict(count=n,trials=len(rr),located=sum(r['located'] for r in rr),local_correct=sum(r['local_correct'] for r in rr),joint=sum(r['joint_success'] for r in rr),settled=sum(r['settled'] for r in rr)) for n in [2,4,8] for rr in [[r for r in rows if r['group']=='set_size' and r['metadata']['count']==n]]]
    out['duplicates']=[dict(condition=c,n=len(rr),active=sum(r['location'] is not None for r in rr),located=sum(r['located'] for r in rr) if c!='category_only' else None,local_correct=sum(r['local_correct'] for r in rr),settled=sum(r['settled'] for r in rr),dominance_mean=mean([r['dominance'] for r in rr]),both_basins10=sum(all(v is not None and v>=.1 for v in r['basin_shares']) for r in rr)) for c in ['category_only','category_spatial_0','category_spatial_1'] for rr in [[r for r in rows if r['group']=='duplicates' and r['condition']==c]]]
    comp=[r for r in rows if r['group']=='completion'];out['completion']=[];contrasts=[]
    for size in [0,8,12]:
        for mode in ['feedback','feedback_off']:
            rr=[r for r in comp if r['metadata']['occlusion']==size and r['condition']==mode]
            out['completion'].append(dict(size=size,mode=mode,n=len(rr),correct=sum(r['global_correct'] for r in rr),active=sum(r['category_mass']>1e-7 for r in rr),located=sum(r['located'] for r in rr),settled=sum(r['settled'] for r in rr),**{key:mean([r[key] for r in rr]) for key in ['hidden_mse','visible_mse','visible_foreground_mse','distractor_mse']}))
    for a in [r for r in comp if r['feedback']]:
        b=next((r for r in comp if r['case']==a['case'] and not r['feedback']),None)
        if b:contrasts.append(dict(case=a['case'],pair=a['metadata']['pair'],size=a['metadata']['occlusion'],correct_change=int(a['global_correct'])-int(b['global_correct']),**{k:None if a[k] is None else a[k]-b[k] for k in ['hidden_mse','visible_mse','visible_foreground_mse','distractor_mse']}))
    out['completion_contrasts']=contrasts
    out['imagery']=[r for r in rows if r['group']=='imagery']
    return out

def overlap(rows):
    with np.load(BASE/'independent'/'stimuli.npz') as z:comp=z['components']
    meta=json.loads((BASE/'independent'/'stimuli.json').read_text());records=[];paired=[];contrast=[]
    from run_spatial_overlap_pilot import masks
    for r in [r for r in rows if r['group']=='overlap_control']:
        j=r['metadata']['source_case'];k=r['target'];cue='A' if k==0 else 'B';m=meta[j];mm=masks(comp[j]);own=mm[cue+'_unique'];other=mm[('B' if k==0 else 'A')+'_unique'];union=mm['union']
        aa=read(POP/'focused_population'/f'case{j:02d}_combined_category_{cue}');bb=read(DATA/f"trial{r['job']:04d}");np.testing.assert_array_equal(aa['reference_slots'],bb['reference_slots'])
        pp=[]
        for mode,a in [('feedback',aa),('feedback_off',bb)]:
            rec=dict(source_case=j,pair=m['pair'],kind=m['kind'],separation=m['separation'],cue=cue,mode=mode,requested_category=m['categories'][k],**base_metrics(a,m['categories'],m['positions']),target_intensity=masked(a['final_render'],own),loser_intensity=masked(a['final_render'],other),canvas_mse=masked((a['final_render']-comp[j,k])**2,union),target_foreground_mse=masked((a['final_render']-comp[j,k])**2,comp[j,k]>.05));records.append(rec);pp.append(rec)
        paired.append(dict(source_case=j,pair=m['pair'],kind=m['kind'],separation=m['separation'],cue=cue,gain_difference_last100=float(abs(aa['gain_trace'][-100:]-bb['gain_trace'][-100:]).max()),**{key:pp[0][key]-pp[1][key] if pp[0][key] is not None and pp[1][key] is not None else None for key in ['target_intensity','loser_intensity','canvas_mse','target_foreground_mse']}))
        if m['kind']=='pair':
            opposite='B' if cue=='A' else 'A';opp=read(POP/'focused_population'/f'case{j:02d}_combined_category_{opposite}')
            contrast.append(dict(source_case=j,pair=m['pair'],separation=m['separation'],cue=cue,gain_difference_last100=float(abs(aa['gain_trace'][-100:]-opp['gain_trace'][-100:]).max()),own_contrast=masked(aa['final_render']-opp['final_render'],own),loser_contrast=masked(aa['final_render']-opp['final_render'],other)))
    ag=[]
    for group in ['isolated',0,8,40]:
        member=lambda r:r['kind']=='isolated' if group=='isolated' else r['kind']=='pair' and r['separation']==group
        rr=[r for r in paired if member(r)];cc=[c for c in contrast if c['separation']==group]
        ag.append(dict(group=group,n=len(rr),max_feedback_gain_difference=max([r['gain_difference_last100'] for r in rr],default=None),max_cue_gain_difference=max([r['gain_difference_last100'] for r in cc],default=None),mse_by_mode={mode:mean([r['canvas_mse'] for r in records if member(r) and r['mode']==mode]) for mode in ['feedback','feedback_off']},mse_change=mean([r['canvas_mse'] for r in rr]),target_change=mean([r['target_intensity'] for r in rr]),loser_change=mean([r['loser_intensity'] for r in rr]),target_preserved_loser_reduced=sum(r['target_intensity']>=-1e-6 and r['loser_intensity'] is not None and r['loser_intensity']<-1e-6 for r in rr),mse_improved=sum(r['canvas_mse']<-1e-6 for r in rr),cue_contrast=mean([c['own_contrast'] for c in cc]),positive_cue_contrasts=sum(c['own_contrast']>1e-6 for c in cc)))
    return dict(rows=records,paired=paired,cue_contrasts=contrast,aggregates=ag,by_mode=[dict(mode=mode,n=len(rr),settled=sum(r['settled'] for r in rr),local_correct=sum(r['local_category']==r['requested_category'] for r in rr)) for mode in ['feedback','feedback_off'] for rr in [[r for r in records if r['mode']==mode]]])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--partial',action='store_true');args=ap.parse_args();rows,protocol,meta=collect(args.partial);out=summarize(rows,protocol);out['overlap']=overlap(rows)
    out['reused_search']=json.loads((ROOT/'spatial_final_confirmation_statistics.json').read_text())
    out['reused_blank']=[r for r in json.loads((ROOT/'spatial_absent_category_statistics.json').read_text())['rows'] if r['condition']=='blank']
    out['analysis_source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    dest=ROOT/(PREFIX+('_partial' if args.partial else '_statistics')+'.json');dest.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items() if k in ['complete','translation','set_size','duplicates','completion']},indent=2))
if __name__=='__main__':main()
