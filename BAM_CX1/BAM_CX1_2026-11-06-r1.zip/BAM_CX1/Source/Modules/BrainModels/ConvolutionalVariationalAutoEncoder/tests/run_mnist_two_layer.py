#!/usr/bin/env python3
"""Compare a spatial CVAE plus gated dense VAE with the direct dense baseline."""

from __future__ import annotations

import argparse
import csv
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

import numpy as np

import run_mnist_direct_vae_full as full
import run_mnist_prototype_mixture as mixture


ROOT = Path(__file__).resolve().parents[5]
DATA = ROOT / "UserData"
OUTPUT = DATA / "output" / "cvae_mnist_two_layer"


def write_model(path, dataset, output, count, seed, hierarchy, training, agent, gates=False,
                upper_beta=0.03, upper_latent_size=64, lower_kernel_size=5, lower_padding="same",
                lower_latent_maps=16):
    root = ET.Element("group", name="CVAE_TwoLayer", title="Two-layer CVAE experiment",
                      tick_duration="1", task_timeout="60", agent=agent)
    ET.SubElement(root, "module", {
        "class": "InputImage", "name": "Images", "_x": "40", "_y": "80",
        "filename": f"{dataset}/image_#####.pgm", "filecount": str(count),
        "iterations": "0", "read_once": "no",
    })
    common = dict(learning_rate="0.001", optimizer="adam", beta="0.03",
                  train="yes" if training else "no", train_interval="1",
                  dense_train_interval="1", sample="yes" if training else "no",
                  reconstruction_source="sample" if training else "mean",
                  latent_cluster_count="1", latent_cluster_weight="0",
                  latent_consistency_weight="0", latent_decorrelation_weight="0")
    if hierarchy:
        ET.SubElement(root, "module", {
            "class": "ConvolutionalVariationalAutoEncoder", "name": "Lower",
            "_x": "360", "_y": "80", **common, "random_seed": str(seed + 1000),
            "feature_stage": "convolutional", "latent_mode": "spatial",
            "kernel_size": str(lower_kernel_size), "feature_maps": "16", "padding": lower_padding,
            "latent_maps": str(lower_latent_maps), "latent_kernel_size": "1", "latent_gating": "no",
            "reconstruction_loss": "bernoulli", "output_activation": "sigmoid",
        })
    ET.SubElement(root, "module", {
        "class": "ConvolutionalVariationalAutoEncoder", "name": "Upper",
        "_x": "740", "_y": "80", **common, "random_seed": str(seed),
        "beta": format(upper_beta, ".8g"),
        "feature_stage": "direct", "latent_mode": "dense", "latent_size": str(upper_latent_size),
        "latent_gating": "yes" if gates else "no",
        "latent_gate_penalty": "0.005" if gates else "0",
        "latent_gate_warmup_updates": "0", "latent_gate_ramp_updates": "0",
        "latent_gate_freeze_update": "0",
        "reconstruction_loss": "mse" if hierarchy else "bernoulli",
        "output_activation": "linear" if hierarchy else "sigmoid",
    })
    ET.SubElement(root, "module", {
        "class": "OutputFile", "name": "Record", "_x": "1120", "_y": "80",
        "directory": str(output.parent), "filename": output.name, "format": "csv",
        "timestamp": "tick", "existing_file": "overwrite", "number_format": "full",
        "flush_interval": "100", "header": "yes",
    })

    def connect(source, target, label=None):
        attributes = dict(source=source, target=target, delay="0")
        if label:
            attributes["label"] = label
        ET.SubElement(root, "connection", attributes)

    if hierarchy:
        connect("Images.INTENSITY", "Lower.INPUT")
        # Direct mode internally flattens the complete channel-first tensor.
        # Explicit ranges give the direct encoder an owned input buffer to reshape.
        side = 32 if lower_padding == "same" else 33 - lower_kernel_size
        connect(f"Lower.LATENT_MEAN[0:{lower_latent_maps}][0:{side}][0:{side}]", "Upper.INPUT")
    else:
        connect("Images.INTENSITY[0:32][0:32]", "Upper.INPUT")
    for name in (["Lower", "Upper"] if hierarchy else ["Upper"]):
        for port, label in (("LOSS", "loss"), ("RECONSTRUCTION_ABSOLUTE_ERROR", "mae"),
                            ("KL_LOSS", "kl")):
            connect(f"{name}.{port}", "Record.INPUT", f"{name.lower()}_{label}")
    connect("Upper.ACTIVE_LATENT_COUNT", "Record.INPUT", "active")
    if not training:
        connect("Upper.GATED_LATENT_MEAN" if gates else "Upper.LATENT_MEAN", "Record.INPUT", "code")
        # Verify sample alignment using actual pixels, independently of labels.
        connect("Images.INTENSITY[12:20][12:20]", "Record.INPUT", "signature")
    ET.indent(root, space="    ")
    ET.ElementTree(root).write(path, encoding="unicode", xml_declaration=False)


def run_ikaros(args, model, log, ticks, save=None, load=None):
    command = [os.environ.get("IKAROS_EXECUTABLE", str(args.ikaros)), "-b", "-t", "1", "-u", str(DATA),
               "-s", str(ticks), "-P", str(max(1000, ticks // 10))]
    if getattr(args, "python_executable", None):
        command += ["-p", str(args.python_executable)]
    if save:
        command += ["-W", str(save)]
    if load:
        command += ["-L", str(load)]
    command.append(str(model))
    started = time.monotonic()
    # Keep Ikaros's optional remote session logger local even outside the sandbox.
    environment = os.environ.copy()
    environment.update(https_proxy="http://127.0.0.1:9", HTTPS_PROXY="http://127.0.0.1:9",
                       all_proxy="http://127.0.0.1:9", ALL_PROXY="http://127.0.0.1:9",
                       no_proxy="", NO_PROXY="")
    with log.open("w") as handle:
        process = subprocess.run(command, cwd=ROOT, env=environment,
                                 stdout=handle, stderr=subprocess.STDOUT)
    if process.returncode:
        raise RuntimeError("Ikaros failed; inspect the experiment log locally.")
    return time.monotonic() - started


def read_codes(path, images, expected_labels, latent_size=64, prepared_images=False):
    with path.open() as handle:
        names = next(csv.reader(handle))
    # Numeric storage avoids millions of Python strings on the full MNIST split.
    values = np.loadtxt(path, delimiter=",", skiprows=1, ndmin=2)
    assert len(values) == len(images), (len(values), len(images))
    assert values.shape[1] == len(names)
    def columns(prefix):
        selected = [i for i,name in enumerate(names) if name == prefix or name.startswith(prefix + ":")]
        assert selected, prefix
        return values[:,selected]
    signatures = columns("signature")
    expected = np.asarray([(image if prepared_images else full.center_and_pad(image))[12:20, 12:20].ravel() / 255.0
                           for image in images])
    assert signatures.shape == expected.shape
    assert np.allclose(signatures, expected, atol=1e-6), "Image/code sequence misaligned"
    codes = columns("code")
    assert codes.shape == (len(images), latent_size) and np.isfinite(codes).all()
    metrics = {name: float(np.mean(columns(name))) for name in
               ("upper_loss", "upper_mae", "upper_kl", "active")}
    if "lower_mae" in names:
        metrics.update({name: float(np.mean(columns(name))) for name in
                        ("lower_loss", "lower_mae", "lower_kl")})
    assert all(np.isfinite(value) for value in metrics.values())
    return codes, expected_labels, metrics


def prepare_data(args):
    full.TRAIN_COUNT, full.VALIDATION_COUNT = args.train_count, args.test_count
    full.FULL_DATA_ROOT = DATA / f"cvae_mnist_centered_32_{args.train_count}_{args.test_count}"
    full.prepare_dataset()
    archive = full.RAW_ROOT
    train_images = full.read_idx_images(archive / "train-images-idx3-ubyte.gz", args.train_count)
    test_images = full.read_idx_images(archive / "t10k-images-idx3-ubyte.gz", args.test_count)
    train_labels = full.read_idx_labels(archive / "train-labels-idx1-ubyte.gz", args.train_count)
    test_labels = full.read_idx_labels(archive / "t10k-labels-idx1-ubyte.gz", args.test_count)
    return train_images, test_images, train_labels, test_labels


def five_nearest_predictions(train, labels, test):
    """Euclidean 5-NN; vote ties favor the closest member of a tied class."""
    assert len(train) >= 5 and len(train) == len(labels)
    predictions = []
    norms = np.sum(train * train, axis=1)
    for begin in range(0, len(test), 64):
        batch = test[begin:begin + 64]
        distances = np.maximum(np.sum(batch * batch, axis=1)[:, None]
                               + norms[None, :] - 2 * batch @ train.T, 0)
        # Stable ordering resolves equal distances by training-row index.
        indices = np.argsort(distances, axis=1, kind="stable")[:, :5]
        for neighbours in labels[indices]:
            counts = np.bincount(neighbours, minlength=10)
            predictions.append(next(int(label) for label in neighbours
                                    if counts[label] == counts.max()))
    return np.asarray(predictions, dtype=np.int64)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ikaros", type=Path, required=True)
    parser.add_argument("--agent", required=True)
    parser.add_argument("--ticks", type=int, default=600000)
    parser.add_argument("--train-count", type=int, default=60000)
    parser.add_argument("--test-count", type=int, default=10000)
    parser.add_argument("--replicates", type=int, default=3)
    parser.add_argument("--seed-base", type=int, default=71000)
    parser.add_argument("--upper-beta", type=float, default=0.03,
                        help="Upper-layer KL weight; lower beta remains 0.03.")
    parser.add_argument("--upper-latent-size", type=int, default=64)
    parser.add_argument("--lower-kernel-size", type=int, choices=[3, 5, 7, 9], default=5)
    parser.add_argument("--lower-padding", choices=["same", "valid"], default="same")
    parser.add_argument("--lower-latent-maps", type=int, default=16)
    parser.add_argument("--models", nargs="+", choices=["baseline", "hierarchy"],
                        default=["baseline", "hierarchy"])
    parser.add_argument("--prototypes-per-class", type=int, default=100)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--batch-size", type=int, default=512)
    parser.add_argument("--learning-rate", type=float, default=0.01)
    parser.add_argument("--width", type=float, default=2.0)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--no-summary", action="store_true",
                        help="Write only per-run results when an external campaign runner aggregates them.")
    parser.add_argument("--classifier", choices=["knn5", "prototype"], default="knn5")
    parser.add_argument("--preprocessing", choices=["zscore", "none"], default="none",
                        help="Optional training-fitted code scaling (default: none, raw codes).")
    parser.add_argument("--evaluate-only", action="store_true",
                        help="Evaluate existing saved codes without retraining or re-extraction.")
    gating = parser.add_mutually_exclusive_group()
    gating.add_argument("--no-gates", dest="no_gates", action="store_true",
                        help="Disable upper latent gates entirely (default).")
    gating.add_argument("--gates", dest="no_gates", action="store_false",
                        help="Reproduce the earlier gated experiment.")
    parser.set_defaults(no_gates=True)
    args = parser.parse_args()
    args.ikaros = args.ikaros.resolve()
    assert args.ikaros.is_file()
    assert 0 < args.train_count <= 60000 and 0 < args.test_count <= 10000
    assert args.ticks > 0 and args.replicates > 0
    assert np.isfinite(args.upper_beta) and args.upper_beta >= 0
    assert args.upper_latent_size > 0
    assert args.lower_latent_maps > 0
    images_train, images_test, labels_train, labels_test = prepare_data(args)
    if args.classifier == "prototype":
        assert min(np.bincount(labels_train)) >= args.prototypes_per_class
    campaign = OUTPUT / f"n{args.train_count}_test{args.test_count}_ticks{args.ticks}_p{args.prototypes_per_class}_e{args.epochs}"
    if args.no_gates:
        campaign = campaign.with_name(campaign.name + "_no_gates")
    if args.upper_beta != 0.03:
        beta_tag = format(args.upper_beta, ".8g").replace(".", "p")
        campaign = campaign.with_name(campaign.name + "_upper_beta_" + beta_tag)
    if args.upper_latent_size != 64:
        campaign = campaign.with_name(campaign.name + f"_upper_latent_{args.upper_latent_size}")
    if args.lower_kernel_size != 5:
        campaign = campaign.with_name(campaign.name + f"_lower_kernel_{args.lower_kernel_size}")
    if args.lower_padding != "same":
        campaign = campaign.with_name(campaign.name + "_lower_padding_" + args.lower_padding)
    if args.lower_latent_maps != 16:
        campaign = campaign.with_name(campaign.name + f"_lower_latent_maps_{args.lower_latent_maps}")
    campaign.mkdir(parents=True, exist_ok=True)
    suffix = ("_knn5" if args.classifier == "knn5" else "")
    scaling_suffix = "_zscore" if args.preprocessing == "zscore" else ""
    suffix += scaling_suffix
    results = []
    for replicate in range(args.replicates):
        seed = args.seed_base + replicate + 1
        for kind in args.models:
            directory = campaign / f"{kind}_s{seed}"
            directory.mkdir(exist_ok=True)
            result_path = directory / f"result{suffix}.json"
            if args.resume and result_path.exists():
                results.append(json.loads(result_path.read_text()))
                continue
            hierarchy = kind == "hierarchy"
            dataset = full.FULL_DATA_ROOT.relative_to(DATA)
            output = directory.relative_to(DATA)
            if args.evaluate_only:
                previous_path = next(p for p in (result_path, directory / "result_knn5.json",
                                                directory / "result.json") if p.exists())
                previous = json.loads(previous_path.read_text())
                assert previous["ticks"] == args.ticks and previous["seed"] == seed
                assert previous["train_count"] == args.train_count and previous["test_count"] == args.test_count
                assert previous.get("latent_gating", True) == (not args.no_gates)
                assert previous.get("upper_beta", 0.03) == args.upper_beta
                assert previous.get("upper_latent_size", 64) == args.upper_latent_size
                assert previous.get("lower_kernel_size", 5) == args.lower_kernel_size
                assert previous.get("lower_padding", "same") == args.lower_padding
                assert previous.get("lower_latent_maps", 16) == args.lower_latent_maps
                duration = previous["training_seconds"]
            else:
                duration = train_and_extract(args, directory, dataset, output, seed, hierarchy)
            train, _, _ = read_codes(directory / "train_codes.csv", images_train, labels_train,
                                    latent_size=args.upper_latent_size)
            test, _, metrics = read_codes(directory / "test_codes.csv", images_test, labels_test,
                                         latent_size=args.upper_latent_size)
            if args.preprocessing == "zscore":
                mean = np.mean(train, axis=0)
                scale = np.std(train, axis=0)
                scale[scale < 1.0e-12] = 1.0
                train, test = (train - mean) / scale, (test - mean) / scale
                np.savez(directory / "preprocessing_zscore.npz", mean=mean, scale=scale)
            if args.classifier == "knn5":
                prediction = five_nearest_predictions(train, labels_train, test)
                np.save(directory / f"predictions_knn5{scaling_suffix}.npy", prediction)
                classifier_details = dict(classifier="knn5", neighbours=5, distance="euclidean",
                                          voting="uniform; ties use closest tied-class neighbour",
                                          stored_reference_vectors=len(train))
            else:
                centers, history = mixture.train_classifier(train, labels_train, test, labels_test, args, seed)
                prediction = mixture.predict(test, centers, args.prototypes_per_class, args.width ** 2)
                np.savez(directory / f"classifier{scaling_suffix}.npz", centers=centers, width=args.width,
                         prototypes_per_class=args.prototypes_per_class)
                (directory / f"classifier_history{scaling_suffix}.json").write_text(json.dumps(history, indent=2) + "\n")
                classifier_details = dict(classifier="prototype", classifier_epochs=args.epochs,
                                          prototypes_per_class=args.prototypes_per_class,
                                          classifier_width=args.width)
            result = dict(model=kind, seed=seed, ticks=args.ticks, train_count=args.train_count,
                          test_count=args.test_count, training_seconds=duration, **metrics,
                          classifier_accuracy=float(np.mean(prediction == labels_test)),
                          preprocessing=args.preprocessing, latent_gating=not args.no_gates,
                          upper_beta=args.upper_beta, lower_beta=0.03 if hierarchy else None,
                          upper_latent_size=args.upper_latent_size,
                          lower_kernel_size=args.lower_kernel_size,
                          lower_padding=args.lower_padding,
                          lower_latent_maps=args.lower_latent_maps,
                          **classifier_details)
            result_path.write_text(json.dumps(result, indent=2) + "\n")
            results.append(result)
            summary = campaign / f"results{suffix}.json"
            if not args.no_summary:
                summary.write_text(json.dumps(results, indent=2) + "\n")
            print(f"{kind}: accuracy={result['classifier_accuracy']:.2%}, active={metrics['active']:.0f}", flush=True)
    summary = campaign / f"results{suffix}.json"
    if not args.no_summary:
        summary.write_text(json.dumps(results, indent=2) + "\n")


def train_and_extract(args, directory, dataset, output, seed, hierarchy):
    write_model(directory / "train.ikg", dataset / "train", output / "metrics.csv",
                args.train_count, seed, hierarchy, True, args.agent, gates=not args.no_gates,
                upper_beta=args.upper_beta, upper_latent_size=args.upper_latent_size,
                lower_kernel_size=args.lower_kernel_size, lower_padding=args.lower_padding,
                lower_latent_maps=args.lower_latent_maps)
    for split, count in (("train", args.train_count), ("test", args.test_count)):
        write_model(directory / f"extract_{split}.ikg", dataset / split,
                    output / f"{split}_codes.csv", count, seed, hierarchy, False, args.agent,
                    gates=not args.no_gates, upper_beta=args.upper_beta,
                    upper_latent_size=args.upper_latent_size, lower_kernel_size=args.lower_kernel_size,
                    lower_padding=args.lower_padding, lower_latent_maps=args.lower_latent_maps)
    print(f"Training {'hierarchy' if hierarchy else 'baseline'}, seed {seed}, {args.ticks} updates", flush=True)
    duration = run_ikaros(args, directory / "train.ikg", directory / "training.log",
                          args.ticks, save=directory / "model.state")
    print(f"Training finished in {duration:.1f}s", flush=True)
    for split, count in (("train", args.train_count), ("test", args.test_count)):
        run_ikaros(args, directory / f"extract_{split}.ikg", directory / f"extract_{split}.log",
                   count, load=directory / "model.state")
    return duration


if __name__ == "__main__":
    main()
