"""Figures from fixed-model endpoints, with examples fixed by stimulus order."""
import json,argparse
import numpy as np
from summarize_spatial_article_suite import DATA,ROOT,PREFIX,read,POP
from generate_spatial_manuscript_figures import Figure,BLUE,ORANGE,GREEN,GRAY
from summarize_spatial_overlap_pilot import draw,finish

def legend(f,items,y,x=40,step=150):
    for i,(label,color) in enumerate(items):
        f.line(x+i*step,y+4,x+12+i*step,y+4,color,2)
        f.text(x+17+i*step,y,label,9)

def arrays(row):return read(DATA/f"trial{row['job']:04d}")
def subgroup(rows,group):return [r for r in rows if r['group']==group]
def bars(f,box,groups,series,ylabel,ylim=(0,100),yticks=(0,25,50,75,100),xlabel='Condition',fmt='.1f'):
    xy=f.axes(box,(-.5,len(groups)-.5),ylim,list(enumerate(groups)),yticks,xlabel,ylabel)
    n=len(series)
    for k,(_,values,color) in enumerate(series):
        for j,value in enumerate(values):
            if value is None:continue
            lo=j-.36+.72*k/n;hi=lo+.65/n
            x,y=xy(lo,value);xr,zero=xy(hi,0)
            f.rect(x,min(y,zero),xr-x,abs(zero-y),color)
            f.text((x+xr)/2,y-12 if value>=0 else y+3,f'{value:{fmt}}',8,align='center')
    return xy

def translation(s,rows,stim):
    rr=subgroup(rows,'translation');idx=rr[0]['metadata']['test_indices'][0]
    ex=sorted([r for r in rr if r['metadata']['test_indices'][0]==idx],key=lambda r:r['metadata']['positions'][0])
    f=Figure(PREFIX+'_translation',530);f.text(8,8,'A  One image at five positions',12,bold=True)
    f.text(448,32,'Output',9);f.text(95,32,'Original input; yellow outline = selected field',9)
    for k,r in enumerate(ex):
        y=51+43*k;f.text(8,y+10,'x = '+str(r['metadata']['positions'][0]),9)
        f.strip(stim[r['case']],85,y,350,r['location']);f.text(470,y+10,str(r['category']),12)
    f.text(8,284,'B  Categorization and localization',12,bold=True)
    bp=s['translation']['by_position']
    bars(f,(40,338,226,125),[str(r['position']) for r in bp],[('Category',[100*r['correct']/r['n'] for r in bp],BLUE),('Location',[100*r['located']/r['n'] for r in bp],ORANGE)],'Correct (%)',ylim=(0,110),xlabel='Object origin (pixels)',fmt='.0f')
    legend(f,[('Category',BLUE),('Location',ORANGE)],311,40,112)
    f.text(302,284,'C  Selected position',12,bold=True)
    xy=f.axes((336,338,190,125),(-20,310),(-40,320),[(0,'0'),(144,'144'),(288,'288')],[0,144,288],'Object origin','Selected field origin')
    f.line(*xy(0,0),*xy(288,288),GRAY,.7)
    for r in rr:
        if r['location'] is not None:f.dot(*xy(r['metadata']['positions'][0],r['location']),BLUE,1.4)
    f.text(40,515,f"{len(rr)} placements from {len(set(r['metadata']['test_indices'][0] for r in rr))} images; coincident points overlap.",9);finish(f)

def selection(s,rows,stim):
    rr=subgroup(rows,'spatial_selection');case=min(r['case'] for r in rr)
    ex=[next(r for r in rr if r['case']==case and r['condition']==c) for c in ['neutral','spatial_0','spatial_1']]
    f=Figure(PREFIX+'_selection',580);f.text(8,8,'A  Spatial cues bias selection in the same display',12,bold=True);f.text(478,25,'Category',8,align='center')
    for k,(label,im,loc,cat) in enumerate([('Input',stim[case],None,None)]+[({'neutral':'Neutral','spatial_0':'Left cue','spatial_1':'Right cue'}[r['condition']],arrays(r)['final_sensory'],r['location'],r['category']) for r in ex]):
        y=38+47*k;f.text(8,y+12,label,9);f.strip(im,90,y,360,loc);f.text(474,y+12,'-' if cat is None else str(cat),12)
    f.text(8,235,'B  Final sensory gain',12,bold=True)
    xy=f.axes((42,284,218,146),(0,319),(0,1.3),[(0,'0'),(160,'160'),(319,'319')],[0,.5,1],'Horizontal pixel coordinate','Gain')
    for r,color in zip(ex,[GRAY,BLUE,ORANGE]):f.curve(xy,np.arange(320),arrays(r)['gain_trace'][-1],color,False)
    f.line(*xy(0,1),*xy(319,1),GRAY,.7)
    legend(f,[('Neutral',GRAY),('Left cue',BLUE),('Right cue',ORANGE)],255,38,86)
    f.text(299,235,'C  Sensory changes relative to neutral',12,bold=True)
    dd=s['spatial_selection']['deltas'];vals=np.array([[r['target_sensory'],r['distractor_sensory']] for r in dd]);lo=min(-.01,float(vals.min())*1.15);hi=max(.01,float(vals.max())*1.15)
    xy=f.axes((340,284,180,146),(-.4,1.4),(lo,hi),[(0,'Selected'),(1,'Other')],[round(lo,2),0,round(hi,2)],'Object','Foreground intensity change')
    f.line(*xy(-.4,0),*xy(1.4,0),GRAY,.7)
    for k in range(2):
        for i,v in enumerate(vals[:,k]):f.dot(*xy(k+((i%13)-6)*.018,v),BLUE if k==0 else ORANGE,1.4)
        v=vals[:,k].mean();f.line(*xy(k-.23,v),*xy(k+.23,v),GREEN,2)
    q=s['spatial_selection'];f.text(40,491,f"Cued category: {q['correct']}/{q['cued_n']}; location: {q['located']}/{q['cued_n']}",11,bold=True)
    f.text(40,515,'90 layouts from 45 pairs, each with neutral and two spatial cues.',9)
    f.text(40,534,'Dots: paired changes on original foreground pixels; green lines: means.',9)
    f.text(40,553,'Example: first display in the fixed stimulus order.',9);finish(f)

def load_duplicates(s,rows,stim):
    f=Figure(PREFIX+'_load_duplicates',575);f.text(8,8,'A  Category-guided search with increasing distractor count',12,bold=True)
    q=s['set_size'];bars(f,(42,72,460,140),[str(r['count']) for r in q],[('Location',[100*r['located']/r['trials'] for r in q],BLUE),('Local category',[100*r['local_correct']/r['trials'] for r in q],ORANGE),('Joint',[100*r['joint']/r['trials'] for r in q],GREEN)],'Correct (%)',xlabel='Number of objects')
    legend(f,[('Location',BLUE),('Local category',ORANGE),('Joint success',GREEN)],39)
    f.text(42,261,'40 conditions per count; ten nested arrays, reversed orders and two category cues.',9)
    f.text(8,292,'B  Identical matching objects',12,bold=True)
    rr=subgroup(rows,'duplicates');case=min(r['case'] for r in rr);ex=[next(r for r in rr if r['case']==case and r['condition']==c) for c in ['category_only','category_spatial_0','category_spatial_1']]
    f.strip(stim[case],42,319,460)
    xy=f.axes((42,405,460,105),(-31,319),(0,1.05),[(0,'0'),(64,'64'),(144,'144'),(224,'224'),(319,'319')],[0,.5,1],'Field origin (pixels)','Spatial activity')
    for r,col in zip(ex,['#555555',BLUE,ORANGE]):f.curve(xy,np.arange(-31,320),arrays(r)['spatial_trace'][-1],col,False)
    only=arrays(ex[0])['spatial_trace'][-1]
    for i in np.flatnonzero(only>1e-7):f.dot(*xy(i-31,only[i]),'#555555',3.5)
    legend(f,[('Category only','#555555'),('Plus left cue',BLUE),('Plus right cue',ORANGE)],378);f.dot(46,382,'#555555',3)
    f.text(42,560,'Fixed example: category 0. All ten categories are included in the numerical results.',9);finish(f)

def completion(s,rows,stim,clean):
    f=Figure(PREFIX+'_completion',640);f.text(8,8,'A  Reconstruction of missing and visible target pixels',12,bold=True)
    legend(f,[('Content feedback',BLUE),('Feedback disconnected',ORANGE)],35,42,220)
    for j,(key,title) in enumerate([('hidden_mse','Missing region'),('visible_mse','Visible region')]):
        vals={mode:[next(r[key] for r in s['completion'] if r['size']==sz and r['mode']==mode) for sz in [0,8,12]] for mode in ['feedback','feedback_off']};top=max(v for vv in vals.values() for v in vv if v is not None)*1.25
        bars(f,(42+j*268,92,205,140),['0','8','12'],[('On',vals['feedback'],BLUE),('Off',vals['feedback_off'],ORANGE)],title+' MSE',ylim=(0,top),yticks=[0,round(top/2,3),round(top,3)],xlabel='Deletion width (pixels)',fmt='.3f')
    f.text(8,295,'B  All twenty targets with 12-pixel deletion',12,bold=True)
    for side in [0,270]:
        for k,label in enumerate(['Clean','Input','Off','On']):f.text(side+67+k*58,322,label,9,align='center')
    rr=[r for r in rows if r['group']=='completion' and r['metadata']['occlusion']==12 and r['feedback']];rr=sorted(rr,key=lambda r:r['metadata']['pair'])
    for i,r in enumerate(rr):
        off=next(v for v in rows if v['case']==r['case'] and not v['feedback']);pos=r['metadata']['positions'][0];y=345+(i%10)*27;side=(i//10)*270
        f.text(side+6,y+6,f"{r['target_category']}/{r['metadata']['pair']}",8)
        for k,a in enumerate([clean[r['case'],:,pos:pos+32],stim[r['case'],:,pos:pos+32],arrays(off)['final_field_predictions'][pos+31],arrays(r)['final_field_predictions'][pos+31]]):draw(f,a,side+55+k*58,y,24,24)
    f.text(8,623,'Rows: target category / pair index. Predictions shown at the known target field for scoring.',9);finish(f)

def overlap(s,rows,stim):
    f=Figure(PREFIX+'_overlap',650);f.text(8,8,'A  Cue-dependent reconstruction under overlap',12,bold=True)
    f.text(8,30,'First pair at full, partial and separated positions; identical intensity scale.',9)
    for k,label in enumerate(['Input','Cue A, off','Cue A, on','Cue B, on']):f.text(116+k*113,54,label,9,align='center')
    rr=subgroup(rows,'overlap_control')
    for i,sep in enumerate([0,8,40]):
        r=next(r for r in rr if r['metadata']['pair']==0 and r['metadata']['separation']==sep and r['target']==0);j=r['metadata']['source_case'];on=read(POP/'focused_population'/f'case{j:02d}_combined_category_A');other=read(POP/'focused_population'/f'case{j:02d}_combined_category_B');y=81+i*60
        f.text(8,y+12,f'{sep} px',10)
        for k,a in enumerate([stim[r['case']],arrays(r)['final_render'],on['final_render'],other['final_render']]):draw(f,a[:,112:208],67+k*113,y,100,100/3)
    f.text(8,280,'B  Effect on distinctive features',12,bold=True)
    qq=[r for r in s['overlap']['aggregates'] if r['group']!='isolated'];values=[r[k] for r in qq for k in ['target_change','loser_change']];lo=min(-.05,min(values)*1.4);hi=max(.05,max(values)*1.4)
    bars(f,(45,337,212,140),['0','8','40'],[('Requested',[r['target_change'] for r in qq],BLUE),('Competing',[r['loser_change'] for r in qq],ORANGE)],'Mean intensity change',ylim=(lo,hi),yticks=[round(lo,2),0,round(hi,2)],xlabel='Object offset (pixels)',fmt='.3f')
    legend(f,[('Requested',BLUE),('Competing',ORANGE)],310,40,112)
    f.text(290,280,'C  Category-cue reversal',12,bold=True)
    cc=s['overlap']['cue_contrasts'];top=max(c['own_contrast'] for c in cc)*1.2;lo=min(-.05,min(c['own_contrast'] for c in cc)*1.2)
    xy=f.axes((330,337,195,140),(-.4,2.4),(lo,top),[(0,'0'),(1,'8'),(2,'40')],[round(lo,2),0,round(top,2)],'Object offset (pixels)','Requested-feature contrast')
    f.line(*xy(-.4,0),*xy(2.4,0),GRAY,.7)
    for i,sep in enumerate([0,8,40]):
        for k,c in enumerate([c for c in cc if c['separation']==sep]):f.dot(*xy(i+(k-4.5)*.035,c['own_contrast']),GREEN,2)
    f.text(40,537,'B: feedback on minus off with cues fixed. C: own cue minus opposite cue.',9)
    f.text(40,559,'Five pairs, ten requested objects per offset. Shared pixels are excluded.',9)
    f.text(40,581,'At full overlap only the category cue changes; at other offsets both cues change.',9)
    f.text(40,603,'Positive requested-feature contrast alone does not establish object separation.',9);finish(f)

def imagery(s,rows,stim):
    f=Figure(PREFIX+'_imagery',480);f.text(8,8,'A  Blank input with a category and location cue',12,bold=True)
    rr=sorted([r for r in rows if r['group']=='imagery' and r['condition']=='category_spatial'],key=lambda r:r['category_cue'])
    for i,r in enumerate(rr):
        col=i%5;row=i//5;x=23+col*106;y=63+row*104
        f.text(x+34,y-21,f"Cue {r['category_cue']}",10,align='center');draw(f,arrays(r)['final_render'][:,128:192],x,y,78,39)
        f.text(x+39,y+46,f"Readout {r['cued_field_category']}",9,align='center')
    f.text(8,286,'B  Location cue without a category cue',12,bold=True)
    control=next(r for r in rows if r['group']=='imagery' and r['condition']=='spatial_only');draw(f,arrays(control)['final_render'][:,128:192],30,321,104,52)
    f.text(160,322,'All inputs are exactly zero; all images share the 0 to 1 scale.',9)
    f.text(160,345,'Shown: 64-column crop centered on the cued field.',9)
    f.text(160,368,'Readout is the unforced local category at the supplied location.',9)
    f.text(30,419,'Category-only blank trials have zero spatial activity and no category-specific image.',9)
    f.text(30,443,'The same feedback gate and sensory-support equations are retained in every condition.',9);finish(f)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--partial',action='store_true');args=ap.parse_args();s=json.loads((ROOT/(PREFIX+('_partial' if args.partial else '_statistics')+'.json')).read_text());rows=s['rows']
    with np.load(DATA/'stimuli.npz') as z:stim=z['input'];clean=z['clean']
    counts={g:len(subgroup(rows,g)) for g in s['protocol']['counts']};done=[]
    for g,fn in [('translation',translation),('spatial_selection',selection),('set_size',load_duplicates),('completion',completion),('overlap_control',overlap),('imagery',imagery)]:
        if counts[g]!=s['protocol']['counts'][g]:continue
        if g=='set_size' and counts['duplicates']!=30:continue
        fn(s,rows,stim,clean) if g=='completion' else fn(s,rows,stim);done.append(g)
    (ROOT/(PREFIX+'_figure_notes.json')).write_text(json.dumps(dict(completed=done,example_rule='Fixed stimulus ordering; no selection based on outcomes.',rendering='Uniform field pooling for whole-canvas reconstructions; completion uses explicitly labeled target field predictions.',counts=counts),indent=2)+'\n');print(done)
if __name__=='__main__':main()
