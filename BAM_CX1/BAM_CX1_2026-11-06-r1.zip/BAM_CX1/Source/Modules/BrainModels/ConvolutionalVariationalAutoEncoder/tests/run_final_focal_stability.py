"""Literal lower-code updates for frozen focal release perturbations."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import time,traceback,concurrent.futures
import numpy as np
import qmnist_confirmation_common as q
from run_final_stability import OUT,protocol,read

def soft(x):
 x=x-x.max(1,keepdims=True);x=np.exp(x);return x/x.sum(1,keepdims=True)
def worker(seed):
 dest=OUT/f'focal_{seed}';dest.mkdir(exist_ok=True)
 if (dest/'results.json').exists():return read(dest/'results.json')
 try:
  m,front=q.load_model(seed);start=time.time();cats=np.arange(10);p=soft(np.random.default_rng(20260921).normal(size=(1,64,676)).astype(np.float32));p=np.repeat(p,10,axis=0);target=front.rp[:,0]
  for _ in range(500):p=.8*p+.2*target
  z=front.encode(p);release_image=q.b.render(m,z);chosen=((z[:,None,None,:]-front.rc[None])**2).sum(3).argmin(2);chosen[cats,cats]=0
  variants=[(0.,0)]+[(amp,d) for amp in [.05,.1] for d in range(3)];meta=[dict(seed=seed,category=c,amplitude=amp,draw=d) for c in range(10) for amp,d in variants];index=np.repeat(cats,7)
  p=p[index].copy();a=np.eye(10,dtype=np.float32)[index];chosen=chosen[index]
  for j,row in enumerate(meta):
   amp=row['amplitude']
   if amp:
    rng=np.random.default_rng(np.random.SeedSequence([2026110513,seed,j]));noise=soft(rng.normal(size=(1,64,676)).astype(np.float32))[0];p[j]=(1-amp)*p[j]+amp*noise;r=rng.random(10).astype(np.float32);r/=r.sum();a[j]=(1-amp)*a[j]+amp*r
  pr=q.b.probs(m,front.encode(p));changes=[];activities=[a.copy()];readouts=[pr.copy()];snapshots=[]
  for t in range(1000):
   an=.8*a+.2*np.maximum(pr/pr.max(1,keepdims=True)-1.5*(a.sum(1,keepdims=True)-a),0);weights=an/an.sum(1,keepdims=True);target=np.zeros_like(p)
   for c in range(10):target+=weights[:,c,None,None]*front.rp[c,chosen[:,c]]
   pn=.8*p+.2*target;changes.append(np.maximum(abs(pn-p).max((1,2)),abs(an-a).max(1)));p=pn;a=an;z=front.encode(p);pr=q.b.probs(m,z);activities.append(a.copy());readouts.append(pr.copy())
   if t+1 in [1,10,50,100,250,500,1000]:snapshots.append(q.b.render(m,z))
   if (t+1)%100==0:q.dump(dest/'progress.json',dict(updates=t+1,total=1000,seconds=time.time()-start))
  images=q.b.render(m,z);changes=np.array(changes);activities=np.array(activities);rows=[]
  for j,row in enumerate(meta):
   base=row['category']*7;bad=np.flatnonzero(changes[:,j]>=1e-5);st=int(bad[-1]+2) if len(bad) else 1
   rows.append(dict(**row,final_category=int(a[j].argmax()),baseline_category=int(a[base].argmax()),retained_category=bool(a[j].argmax()==row['category']),same_as_unperturbed=bool(a[j].argmax()==a[base].argmax()),settled=bool(changes[-10:,j].max()<1e-5),settling_updates=st if 1000-st+1>=10 else None,last10_change=float(changes[-10:,j].max()),image_mse_unperturbed=float(np.mean((images[j]-images[base])**2)),image_mse_release=float(np.mean((images[j]-release_image[row['category']])**2)),switches=int(np.count_nonzero(np.diff(activities[:,j].argmax(1))))))
  np.savez_compressed(dest/'arrays.npz',changes=changes,activities=activities,readout=readouts,images=images,snapshot_images=snapshots,release_images=release_image,chosen=chosen)
  front.unchanged();q.dump(dest/'results.json',rows);return rows
 except Exception:q.dump(dest/'error.json',dict(error=traceback.format_exc()));raise
if __name__=='__main__':
 protocol();q.dump(OUT/'focal_implementation.json',dict(method='Literal full lower-code updates, no affine approximation',rng='SeedSequence([2026110513,model seed,category*7+variant index])',settling='Original release criterion, final10 maximum raw code/category changes<1e-5'))
 with concurrent.futures.ProcessPoolExecutor(max_workers=3) as pool:rows=sum(list(pool.map(worker,protocol()['models'])),[])
 q.dump(OUT/'focal_results.json',rows);print('Completed210 focal release runs',flush=True)
