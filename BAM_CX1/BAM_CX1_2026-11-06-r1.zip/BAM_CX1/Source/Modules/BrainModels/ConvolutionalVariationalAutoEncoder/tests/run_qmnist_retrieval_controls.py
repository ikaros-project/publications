"""Reviewer2/comment1: six matched focal controls, follow-up to QMNIST confirmation."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import json,time,datetime
from pathlib import Path
import numpy as np
import qmnist_confirmation_common as q
import evaluate_fixed_category_weights as fixed
OUT=q.C/'qmnist_retrieval_controls_20261105'
MODES=['none','pixel_retrieval','reference_decoding','single_step','fixed','full']
def status(**kw):q.dump(OUT/'status.json',kw);print(kw,flush=True)
def main():
 OUT.mkdir(exist_ok=True)
 pp=OUT/'protocol.json'
 if not pp.exists():
  p=dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Focal follow-up using previously evaluated QMNIST confirmation stimuli, not a newly preregistered independent confirmation. No spatial or no-input imagery tests.',models=q.protocol()['models'],stimuli='All1035 focal inputs/model:100clean,200occluded,600noisy,135mixtures. No new selection or tuning.',source_protocol_sha256=q.sha(q.OUT/'protocol.json'),source_stimuli_sha256=q.sha(q.OUT/'focal_stimuli.npz'),checkpoint_sha256=q.protocol()['checkpoint_sha256'],modes=MODES,definitions=dict(pixel_retrieval='Choose initial bottom-up winner c0, then nearest stored latent reference within c0. Return its original center_and_pad training pixels. No decoding or recurrent update.',reference_decoding='Same reference identity as pixel retrieval. Decode its stored latent through VAE decoder then local patch decoder. No sensory mixture or recurrence.',single_step='One original category update from sensory evidence, normalize activity across all ten categories, then one alpha0.2 relaxation toward0.5sensory+0.5weighted reference predictions. Thus actual state is0.9sensory+0.1reference mixture. Encode and decode immediately. Output category is the once-updated category population, with no second evaluation.',fixed='Original500updates but feedback category weights fixed after first category update. Category activity continues evolving.',full='Original500updates, evolving feedback weights. Reuse saved confirmation outputs after checks.',none='Original500category updates with sensory codes fixed. Reuse saved confirmation outputs.'),reference_selection='Original bank8/category per model. Nearest within each category determined from actual input initial latent and fixed. Retrieval controls use the same reference in initial winning category. No clean-source or true-label selection.',metrics='Pixel5NN recognition and own-category agreement, agreement with SAME full-model winner for every mode, agreement with same initial winner, category accuracy, clean/input/hidden/visible MSE. Equal mixtures have no category ground truth. Settling only for500update conditions.',statistics='Paired full-minus-control effects with2000 crossed bootstrap resamples of3models and source-image/pair clusters; seed2026110509. Noise repetitions and mixture fractions averaged within cluster. Report per-model results. No significance screening.',examples='First sampled12pixel-deletion image per category and first six equal-mixture pairs, first model. No outcome-based selection.',script_sha256=q.sha(Path(__file__)),total_endpoints=18630,new_endpoints=12420)
  q.dump(pp,p);(OUT/'protocol.sha256').write_text(q.sha(pp)+'\n')
 assert q.sha(pp)==(OUT/'protocol.sha256').read_text().strip()
 meta=json.loads((q.OUT/'focal_stimuli.json').read_text())
 with np.load(q.OUT/'focal_stimuli.npz') as z:x=z['input'];clean=z['clean'];mask=z['mask']
 raw=q.b.E.full.RAW_ROOT;train=q.b.E.full.read_idx_images(raw/'train-images-idx3-ubyte.gz',60000);labels=q.b.E.full.read_idx_labels(raw/'train-labels-idx1-ubyte.gz',60000)
 pixels=np.stack([q.b.E.full.center_and_pad(v) for v in train]).astype(np.float32)/255
 rows=[];checks={};started_at=time.time()
 for seed in q.protocol()['models']:
  m,front=q.load_model(seed);bottom=np.stack([m['book'].process(v,False,.01,.08)[0].reshape(64,676) for v in x]);m.update(b=bottom,z0=bottom.reshape(len(x),-1)@m['enc']+m['eb'])
  pr=q.b.probs(m,m['z0']);initial=pr.argmax(1);a0=pr/pr.max(1,keepdims=True);a1=.8*a0+.2*np.maximum(pr/pr.max(1,keepdims=True)-1.5*(a0.sum(1,keepdims=True)-a0),0);w1=a1/a1.sum(1,keepdims=True)
  rc=m['codes'][m['ids']];chosen=((m['z0'][:,None,None]-rc[None])**2).sum(3).argmin(2);retrieved_ids=m['ids'][initial,chosen[np.arange(len(x)),initial]]
  with np.load(q.OUT/f'focal_model{seed}_1.npz') as z:fullwins=z['activities'][-1].argmax(1);np.testing.assert_array_equal(chosen,z['reference_slots']);np.testing.assert_array_equal(m['ids'],z['reference_ids']);np.testing.assert_allclose(a1,z['activities'][1],atol=1e-7)
  rp=q.b.decode(m,rc.reshape(-1,128)).reshape(10,8,64,676);rz=(rp.reshape(-1,43264)@m['enc']+m['eb']).reshape(10,8,128);cz=np.stack([rz[c,chosen[:,c]] for c in range(10)],axis=1)
  z1=.9*m['z0']+.1*np.einsum('nc,ncd->nd',w1,cz)
  # Execute the single step directly in code space, preserving float32 update order.
  z1_affine=z1.copy();z1=np.empty_like(m['z0'])
  for start in range(0,len(x),64):
   end=min(start+64,len(x));Q=np.zeros_like(bottom[start:end])
   for c in range(10):Q+=w1[start:end,c,None,None]*rp[c,chosen[start:end,c]]
   p1=.8*bottom[start:end]+.2*(.5*bottom[start:end]+.5*Q)
   np.testing.assert_allclose(p1.sum(1),1,atol=2e-6)
   z1[start:end]=p1.reshape(end-start,-1)@m['enc']+m['eb']
  checks[str(seed)]={'reference_identity_matches_confirmation':True,'single_step_uses_direct_code_update':True,'affine_vs_direct_latent_max_error':float(abs(z1-z1_affine).max())}
  for mode in MODES:
   dest=OUT/f'model{seed}_{mode}.json'
   if dest.exists():rows+=json.loads(dest.read_text());continue
   status(seed=seed,mode=mode,completed=len(rows),total=18630)
   if mode in ['full','none']:
    on=int(mode=='full')
    with np.load(q.OUT/f'focal_model{seed}_{on}.npz') as z:images=z['images'];acts=z['activities'];changes=z['last10changes']
    winner=acts[-1].argmax(1);settled=changes.max(0)<1e-5
    old=json.loads((q.OUT/f'focal_model{seed}_{on}.json').read_text());pred=np.array([r['pixel_category'] for r in old])
   else:
    settled=[None]*len(x)
    if mode=='pixel_retrieval':images=pixels[retrieved_ids];winner=initial
    elif mode=='reference_decoding':images=q.b.render(m,m['codes'][retrieved_ids]);winner=initial
    elif mode=='single_step':images=q.b.render(m,z1);winner=a1.argmax(1)
    else:
     res=fixed.simulate(m,m['ids'],'fixed');images=res['images'];winner=res['acts'][-1].argmax(1);settled=res['changes'].max(0)<1e-5
     np.testing.assert_array_equal(res['chosen'],chosen);np.testing.assert_array_equal(res['first_weights'],w1)
     assert abs(res['coeff'][-1]-.5*(1-.8**500)*w1).max()<1e-7
    pred=q.b.E.five_nearest_predictions(pixels.reshape(60000,1024),labels,images.reshape(-1,1024))
   rr=[]
   for j,mm in enumerate(meta):
    err=(images[j]-clean[j])**2;t=mm['truth'];rr.append(dict(seed=seed,mode=mode,**mm,category=int(winner[j]),pixel_category=int(pred[j]),initial_category=int(initial[j]),full_category=int(fullwins[j]),retrieved_id=int(retrieved_ids[j]),category_correct=None if t is None else bool(winner[j]==t),pixel_correct=None if t is None else bool(pred[j]==t),agreement=bool(pred[j]==winner[j]),full_winner_agreement=bool(pred[j]==fullwins[j]),initial_winner_agreement=bool(pred[j]==initial[j]),clean_mse=float(err.mean()),input_mse=float(((images[j]-x[j])**2).mean()),hidden_mse=float(err[mask[j]].mean()) if mask[j].any() else None,visible_mse=float(err[~mask[j]].mean()),settled=None if settled[j] is None else bool(settled[j])))
   np.savez_compressed(dest.with_suffix('.npz'),images=images,categories=winner,pixel_categories=pred,chosen_reference_slots=chosen,retrieved_ids=retrieved_ids,reference_ids=m['ids']);q.dump(dest,rr);rows+=rr
  assert front.unchanged();checks[str(seed)]['weights_unchanged']=True
 q.dump(OUT/'results.json',dict(checks=checks,rows=rows));status(complete=True,completed=len(rows),total=18630,seconds=time.time()-started_at)
if __name__=='__main__':main()
