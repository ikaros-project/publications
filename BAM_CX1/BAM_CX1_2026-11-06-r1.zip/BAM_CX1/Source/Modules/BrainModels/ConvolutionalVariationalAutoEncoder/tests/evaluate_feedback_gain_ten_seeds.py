"""Paired ten-seed confirmation of continuous feedback gain .5."""
import json
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import feedback_gain_seed_worker as w
OUT=w.n.CAMPAIGN/'feedback_gain_ten_seeds'
SEEDS=list(range(71001,71011));GAINS=[0.,.25,.5]
def write(name,r):(OUT/name).write_text(json.dumps(r,indent=2)+'\n')
def stats(x):
    x=np.array(x);sd=float(x.std(ddof=1));h=2.2621571628540993*sd/np.sqrt(len(x));return dict(mean=float(x.mean()),sd=sd,ci95=[float(x.mean()-h),float(x.mean()+h)])
def run(seed):
    dest=OUT/f'seed{seed}';w.run(seed,dest);return seed

def main():
    OUT.mkdir(exist_ok=True)
    first=w.n.CAMPAIGN/'feedback_gain_sweep_seed1'
    protocol=json.loads((first/'protocol.json').read_text());protocol.update(seed=None,seeds=SEEDS,gains=GAINS,scope='Paired ten-seed comparison on same220 uncorrupted scenes. Seed71001 reused; nine additional seeds. Existing checkpoints and local decoders, no training. Gain.5 selected from first-seed exploration; remaining nine provide model-seed replication, not new stimulus validation.',statistics='Means and sample SD across10 seeds; paired t(9)95% descriptive intervals; nine-seed sensitivity excluding selection seed uses t(8). Images reused across seeds; not2200 independent scenes.')
    write('protocol.json',protocol);done=[71001];write('status.json',dict(stage='running',completed_seeds=done))
    with ProcessPoolExecutor(max_workers=2) as pool:
        jobs=[pool.submit(run,s) for s in SEEDS[1:]]
        for job in as_completed(jobs):
            done.append(job.result());write('status.json',dict(stage='running',completed_seeds=sorted(done)));print(f'COMPLETED {len(done)}/10 seeds',flush=True)
    records=[]
    for s in SEEDS:
        src=first if s==71001 else OUT/f'seed{s}';r=json.loads((src/'results.json').read_text());records.append(dict(seed=s,**r))
    def row(r,g):return next(v for v in r['aggregate'] if v['gain']==g)
    keys=[k for k in row(records[0],0) if k not in ['gain','component_case_count']]
    aggregate=[dict(gain=g,**{k:stats([row(r,g)[k] for r in records]) for k in keys}) for g in GAINS]
    comparisons={k:stats([row(r,.5)[k]-row(r,.25)[k] for r in records]) for k in keys}
    delta=np.array([row(r,.5)['final_winner_agreement']-row(r,.25)['final_winner_agreement'] for r in records]);d9=delta[1:];h=2.306004135204166*d9.std(ddof=1)/3
    result=dict(protocol=protocol,aggregate=aggregate,paired_gain_05_minus_025=comparisons,improved_seeds=int((delta>0).sum()),tied_seeds=int((delta==0).sum()),nine_seed_sensitivity=dict(mean=float(d9.mean()),ci95=[float(d9.mean()-h),float(d9.mean()+h)]),per_seed=records)
    write('results.json',result)
    lines=['# Feedback gain0.5 across ten seeds','','Same220 static uncorrupted scenes,200 iterations, frozen200-unit readouts and learned local pixel decoders. Seed71001 reused; nine additional seeds evaluated.','', '| Gain | Winner agreement mean ± SD | Equal-mixture agreement | Input MSE | Original-winner component MSE |','|---|---:|---:|---:|---:|']
    for r in aggregate:lines.append(f'| {r["gain"]:g} | {r["final_winner_agreement"]["mean"]:.3%} ± {100*r["final_winner_agreement"]["sd"]:.3f} pp | {r["equal_final_winner_agreement"]["mean"]:.2%} | {r["input_mse"]["mean"]:.6f} | {r["original_winner_component_mse"]["mean"]:.6f} |')
    d=comparisons['final_winner_agreement'];lines+=['',f'Gain0.5 minus0.25 winner agreement: {100*d["mean"]:+.3f} pp, descriptive95% paired CI [{100*d["ci95"][0]:+.3f}, {100*d["ci95"][1]:+.3f}]. Improved {result["improved_seeds"]}/10 seeds.', '', '| Seed | Gain0.25 agreement | Gain0.5 agreement | Change pp | Settled at0.5 | Winner changes at0.5 |','|---|---:|---:|---:|---:|---:|']
    for r in records:
        a=row(r,.25);b=row(r,.5);dyn=next(v for v in r['dynamics'] if v['gain']==.5)
        lines.append(f'| {r["seed"]} | {a["final_winner_agreement"]:.2%} | {b["final_winner_agreement"]:.2%} | {100*(b["final_winner_agreement"]-a["final_winner_agreement"]):+.2f} | {dyn["settled"]}/220 | {dyn["final_winner_changes"]} |')
    lines+=['','These intervals describe variation across training seeds on fixed reused images, not independent image populations. Gain0.5 was selected using seed71001. Nine-seed sensitivity excluding that seed is saved in results.json. Category reinforcement, including wrong winners, is separate from true-label recognition; component MSE uses fixed original winners so targets do not change with gain. Input MSE can increase with category resolution. All checkpoint hashes verified unchanged during each run; zero/.25 outputs matched prior decoder probabilities. No model training or default configuration change was performed.']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');write('status.json',dict(stage='complete',completed_seeds=SEEDS));print('\n'.join(lines),flush=True)
if __name__=='__main__':main()
