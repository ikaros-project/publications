"""Final fixed-parameter confirmation on twenty new MNIST images."""
import concurrent.futures,json,time,hashlib,shutil
from pathlib import Path
import numpy as np
import run_spatial_overlap_pilot as r
from run_spatial_absent_category import DiagnosticCircuit,reference_images,ROOT as PILOT
from run_spatial_population_feedback import PopulationFeedback
from run_spatial_population_search import ROOT as PRESENT,BASE
ROOT=PILOT.parent/'final_spatial_confirmation'

def init():
    r.init();r.Circuit=DiagnosticCircuit;r.CachedLocalFeedback=PopulationFeedback

def prepare():
    ROOT.mkdir(exist_ok=True)
    if (ROOT/'protocol.json').exists():return
    used=set()
    # Exclude images in the existing overlap/search development campaign, including prepared controls.
    for f in ROOT.parent.glob('**/stimuli.json'):
        if ROOT in f.parents:continue
        for row in json.loads(f.read_text()):used.update(i for i in row.get('test_indices',[]) if i>=0)
    raw=r.r.e.full.read_idx_images(r.r.e.full.RAW_ROOT/'t10k-images-idx3-ubyte.gz',10000)
    labels=r.r.e.full.read_idx_labels(r.r.e.full.RAW_ROOT/'t10k-labels-idx1-ubyte.gz',10000)
    chosen={c:[int(i) for i in range(9200,10000) if labels[i]==c and i not in used][:2] for c in range(10)}
    assert all(len(v)==2 for v in chosen.values());pairs=[(0,6),(1,7),(2,5),(3,8),(4,9)];rows=[];scenes=[];components=[];jobs=[]
    for repeat in range(2):
        for group,pair in enumerate(pairs):
            cats=list(pair if repeat==0 else pair[::-1]);ids=[chosen[c][repeat] for c in cats];comp=np.zeros((2,32,320),np.float32)
            for k,(i,pos) in enumerate(zip(ids,[124,164])):comp[k,:,pos:pos+32]=r.r.e.full.center_and_pad(raw[i]).astype(np.float32)/255
            j=len(rows);rows.append(dict(case=j,pair=j,repeat=repeat,category_pair_group=group,categories=cats,test_indices=ids,positions=[124,164],separation=40,kind='pair'))
            components.append(comp);scenes.append(np.maximum(*comp))
            other=list(pairs[(group+1)%5]);other=other if repeat==0 else other[::-1]
            for condition,requests in [('present',cats),('absent',other)]:
                for k,cat in enumerate(requests):jobs.append(dict(condition=condition,case=j,cue='A' if k==0 else 'B',requested=cat))
    assert len(set(i for row in rows for i in row['test_indices']))==20
    assert not (set(i for row in rows for i in row['test_indices']) & used)
    for condition in ['present','absent']:
        d=ROOT/condition;d.mkdir(exist_ok=True);np.savez_compressed(d/'stimuli.npz',input=scenes,components=components);r.r.dump(d/'stimuli.json',rows)
    d=ROOT/'parity';d.mkdir(exist_ok=True)
    for n in ['stimuli.json','stimuli.npz']:shutil.copyfile(BASE/'independent'/n,d/n)
    jobs.insert(0,dict(condition='parity',case=2,cue='A',requested=0));r.r.dump(ROOT/'jobs.json',jobs)
    names=['run_spatial_final_confirmation.py','run_spatial_absent_category.py','run_spatial_population_search.py','run_spatial_population_feedback.py','run_spatial_overlap_pilot.py','neural_spatial_rate_model.py','cached_spatial_content_feedback.py','spatial_content_feedback.py','run_spatial_overlap_feedback_strength.py']
    r.r.dump(ROOT/'protocol.json',dict(seed=71001,trials=40,verification_trials=1,steps=600,chosen_indices=chosen,excluded_indices=sorted(used),selection='First two MNIST test examples per category at indices9200:10000 excluding all images listed in existing overlap/search campaign stimuli. Twenty distinct images, no recognition screening or replacement. Five category pairings repeated with new images; left/right category order reversed in repeat2. Both category directions per pair. Absent requests are both categories in the next category pair cyclically, fixed before outcomes.',fixed='Neutral spatial initialization, zero spatial cue, category cue2, population routing, feedback0.65, frozen seed71001 weights/references, original relative binding and shared sensory residuals, alpha0.1,600updates. No early stopping, tuning or extensions.',primary='Target present: location within16pixels and active spatial mass>1e-7, plus separate unforced local category and joint success. Target absent: location response and induced requested local category are false matches. Primary mismatch is final spatial-activity-weighted Eplus+Eminus from existing shared sensory-error populations. Report all endpoints, continuous present/absent ranks and within-array mean mismatch contrasts; no threshold fitting or rejection node. Global clamped category never counted as recognition.',secondary='Retain category-template diagnostics for context only; no contribution to dynamics. Settling maximum normalized update below5e-6 during final100updates. Report failures without extending runs. One development present case must reproduce prior saved arrays exactly.',scope='Final confirmation on ten new pairs / twenty images and one frozen network. This tests new-image generalization within five fixed category pairings, not all pairings or population prevalence. No more experiments or mechanism changes after this confirmation; preserve bounded manuscript claims.',source_sha256={n:hashlib.sha256(Path(__file__).with_name(n).read_bytes()).hexdigest() for n in names}))
    print('PREPARED 40 confirmation trials and 1 reproduction',flush=True)

def worker(job):
    condition=job['condition'];j=job['case'];name='combined_category_'+job['cue'];r.ROOT=ROOT/condition;folder=r.ROOT/f'case{j:02d}_{name}'
    if (folder/'diagnostics.npz').exists() and (folder/'diagnostic_result.json').exists():return json.loads((folder/'diagnostic_result.json').read_text())
    DiagnosticCircuit.requested=job['requested'];row=r.worker((j,name));c=DiagnosticCircuit.last;local=PopulationFeedback.last
    assert c.max_external_spatial_input==0 and not c.initial_attention.any()
    refs=reference_images(r.FRONT);templates=refs[np.arange(10)[None,:],local.chosen];x=c.xw[0,:,None,:,:]
    pos=np.maximum(x-templates,0).mean((2,3));neg=np.maximum(templates-x,0).mean((2,3));mass=x.mean((2,3))+templates.mean((2,3));overlap=np.minimum(x,templates).mean((2,3))
    diagnostic=dict(**{k:np.array(v) for k,v in c.records.items()},template_positive=pos,template_negative=neg,template_overlap=overlap,template_l1=pos+neg,template_normalized_l1=(pos+neg)/np.maximum(mass,1e-12),template_mean=templates.mean((2,3)),sensory_mean=c.mean_x[0],template_images_requested=templates[:,job['requested']],final_positive_error=c.ep[0],final_negative_error=c.em[0],final_support=c.m[0])
    assert all(np.isfinite(v).all() for v in diagnostic.values())
    np.savez_compressed(folder/'diagnostics.npz',**diagnostic)
    parity=None
    if condition=='parity':
        with np.load(folder/'arrays.npz') as a,np.load(PRESENT/'neutral_population'/folder.name/'arrays.npz') as b:
            assert set(a.files)==set(b.files)
            for key in a.files:np.testing.assert_array_equal(a[key],b[key],err_msg=key)
        parity=True
    row=dict(**job,spatial_cue_zero=True,initial_spatial_zero=True,present_arrays_exact=parity,settled=row['settled'],seconds=row['seconds'],weights_unchanged=row['weights_unchanged'])
    r.r.dump(folder/'diagnostic_result.json',row);return row


def main():
    prepare();jobs=json.loads((ROOT/'jobs.json').read_text());start=time.time();rows=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=12,initializer=init) as pool:
        fs=[pool.submit(worker,j) for j in jobs]
        for f in concurrent.futures.as_completed(fs):
            row=f.result();rows.append(row);r.r.dump(ROOT/'status.json',dict(completed=len(rows),total=len(jobs),seconds=time.time()-start));print('DIAGNOSTICS',row['condition'],row['requested'],flush=True)
    r.r.dump(ROOT/'results.json',rows);print('FINAL CONFIRMATION COMPLETE',flush=True)
if __name__=='__main__':main()
