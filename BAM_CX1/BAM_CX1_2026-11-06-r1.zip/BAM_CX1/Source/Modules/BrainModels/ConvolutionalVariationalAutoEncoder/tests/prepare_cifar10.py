"""Deterministic balanced 2000/1000 grayscale CIFAR-10 subset, no resizing."""
import hashlib,json,tarfile
import numpy as np
import run_mnist_two_layer as e
ROOT=e.DATA/'cvae_cifar10_grayscale_32_2000_1000'
ARCHIVE=e.DATA/'cvae_cifar10/raw/cifar-10-binary.tar.gz'
CLASSES=['airplane','automobile','bird','cat','deer','dog','frog','horse','ship','truck']

def prepare():
    cached=ROOT/'subset.npz'
    if cached.exists():
        with np.load(cached) as f:return tuple(f[k].copy() for k in ('train_images','test_images','train_labels','test_labels'))
    assert hashlib.md5(ARCHIVE.read_bytes()).hexdigest()=='c32a1d4ab5d03f1284b67883e8d87530'
    ROOT.mkdir(parents=True,exist_ok=True)
    result={};metadata=dict(source='https://www.cs.toronto.edu/~kriz/cifar.html',archive_md5='c32a1d4ab5d03f1284b67883e8d87530',classes=CLASSES,grayscale='round((299R+587G+114B)/1000), uint8; divide by 255 for model input',resize=False,centering=False,augmentation=False)
    with tarfile.open(ARCHIVE,'r:gz') as archive:
        for split,per_class,seed in [('train',200,20260916),('test',100,20260917)]:
            names=[f'data_batch_{i}.bin' for i in range(1,6)] if split=='train' else ['test_batch.bin']
            batches=[]
            for name in names:
                data=archive.extractfile('cifar-10-batches-bin/'+name).read()
                assert len(data)==10000*3073
                batches.append(np.frombuffer(data,dtype=np.uint8).reshape(10000,3073))
            raw=np.concatenate(batches);labels=raw[:,0]
            rng=np.random.default_rng(seed)
            indices=np.concatenate([rng.choice(np.flatnonzero(labels==c),per_class,replace=False) for c in range(10)])
            rng.shuffle(indices)
            rgb=raw[indices,1:].reshape(-1,3,32,32).astype(np.uint32)
            images=((299*rgb[:,0]+587*rgb[:,1]+114*rgb[:,2]+500)//1000).astype(np.uint8)
            selected_labels=labels[indices].copy()
            assert np.all(np.bincount(selected_labels,minlength=10)==per_class)
            destination=ROOT/split;destination.mkdir(exist_ok=True)
            for i,x in enumerate(images):
                (destination/f'image_{i:05d}.pgm').write_bytes(b'P5\n32 32\n255\n'+x.tobytes())
            (destination/'labels.csv').write_text('label\n'+''.join(f'{int(x)}\n' for x in selected_labels))
            result[split+'_images']=images;result[split+'_labels']=selected_labels
            metadata[split]=dict(count=len(images),selection_seed=seed,official_split_indices=indices.tolist(),pixels_sha256=hashlib.sha256(images.tobytes()).hexdigest())
    (ROOT/'manifest.json').write_text(json.dumps(metadata,indent=2)+'\n')
    np.savez(cached,**result)
    return tuple(result[k] for k in ('train_images','test_images','train_labels','test_labels'))

if __name__=='__main__':
    values=prepare();print('Prepared balanced grayscale CIFAR-10:',[v.shape for v in values])
