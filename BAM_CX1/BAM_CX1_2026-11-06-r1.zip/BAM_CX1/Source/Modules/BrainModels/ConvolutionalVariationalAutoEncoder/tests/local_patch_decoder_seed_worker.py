"""Fit a local ridge decoder without changing sensory encoders; seed71001."""
import hashlib,json
from argparse import Namespace
import numpy as np
import evaluate_neural_feedback as n
import coupled_feedback_seed_worker as worker
f=n.f;e=n.e
OUT=n.CAMPAIGN/'local_linear_patch_decoder_seed1'
LAMBDAS=[0.,1e-8,1e-6,1e-4,1e-2]

def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def status(stage):write(OUT/'status.json',dict(stage=stage));print(stage,flush=True)
def activities(x,book):
    d=np.sum(x*x,1)[:,None]+np.sum(book*book,1)[None,:]-2*x@book.T
    v=-(d-d.min(1,keepdims=True))/(49*.08);v=np.exp(v);return v/v.sum(1,keepdims=True)
def patches(x):return np.lib.stride_tricks.sliding_window_view(x,(7,7),axis=(1,2)).reshape(len(x),676,49)
def overlap(x):
    x=x.reshape(-1,26,26,7,7);y=np.zeros((len(x),32,32),np.float32);counts=np.zeros((32,32),np.float32)
    for dy in range(7):
        for dx in range(7):
            y[:,dy:dy+26,dx:dx+26]+=x[:,:,:,dy,dx];counts[dy:dy+26,dx:dx+26]+=1
    return y/counts

def run(seed,output,fit_only=False):
    global OUT
    OUT=output
    OUT.mkdir(exist_ok=True);status('loading model and preparing local training patches')
    train,test,labels,test_labels=e.prepare_data(Namespace(train_count=60000,test_count=10000))
    tp=np.stack([e.full.center_and_pad(x) for x in train]).astype(np.float32)/255
    vp=np.stack([e.full.center_and_pad(x) for x in test]).astype(np.float32)/255
    folder=n.CAMPAIGN/f'hierarchy_s{seed}';readout=n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit'/f'grouped_softmax_s{seed}.npz'
    files=[folder/'model.state',folder/'codebook_final.npz',readout];hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    with np.load(folder/'codebook_final.npz') as z:book=z['prototypes'].astype(np.float32)
    with np.load(n.CAMPAIGN/'neural_readout_regularized_capacity/split_indices.npz') as z:fit=z['fit'];val=z['validation']
    rng=np.random.default_rng(20260920);positions=rng.integers(676,size=(60000,16))
    np.savez_compressed(OUT/'patch_sampling.npz',positions=positions,fit_indices=fit,validation_indices=val)
    protocol=dict(seed=seed,train_images=60000,test_images=10000,patches_per_image=16,fit_patch_count=864000,validation_patch_count=96000,refit_patch_count=960000,
        fitting='Local bottom-up activities A=softmax(-patch MSE/.08), target X=49 raw pixels. Fit D=(A.T A/N + lambda I)^-1 A.T X/N in float64; zero lambda uses pseudoinverse. No extra intercept since activities sum to1. Class labels do not enter fitting. Sample16 positions per image with replacement, RNG20260920.',
        selection='Use saved54000/6000 image split; minimize unsmoothed, unclipped validation patch MSE over fixed lambda grid. Freeze lambda then refit from scratch using sampled patches of all60000 images.',lambdas=LAMBDAS,
        comparison='Hard code selection; soft probability-weighted prototype sum; locally fitted linear D. All use identical overlap averaging. Report raw image MSE and image MSE clipped to[0,1]; clipping occurs after overlap, not per patch.',
        evaluation='All10000 test images: bottom-up local reconstruction and frozen upper-decoded reconstruction. Same220 feedback scenes: reconstruct identical upper probabilities with each decoder, independent pixel5NN and MSE. No feedback constants tuned. Three illustrative cases excluded from statistics.',
        scope='Per-seed replication of the local-decoder diagnostic. Lower codebook/encoder, upper encoder/decoder and200-unit readout frozen. No interlayer gradients. Learned mapping replaces only code-to-patch rendering, not the latent feedback dynamics. No native Ikaros decoder integration yet.',
        caveat='Upper-decoded distributions can differ from bottom-up activities used to fit D. Validation images previously seen by frozen sensory model; test reused. No claim of independent confirmation or generalization across seeds.')
    write(OUT/'protocol.json',protocol)
    def moments(ids):
        gram=np.zeros((64,64));cross=np.zeros((64,49));target2=0.;count=0
        for start in range(0,len(ids),256):
            ii=ids[start:start+256];pool=patches(tp[ii]);x=pool[np.arange(len(ii))[:,None],positions[ii]].reshape(-1,49)
            a=activities(x,book).astype(np.float64);xx=x.astype(np.float64)
            gram+=a.T@a;cross+=a.T@xx;target2+=float((xx*xx).sum());count+=len(x)
        return gram,cross,target2,count
    # Check soft code, overlap layout and synthetic least-squares recovery.
    xx=patches(tp[:1])[0];a=activities(xx,book);native,_=f.prior.Codebook(book).process(tp[0],False,.01,.08)
    np.testing.assert_allclose(a.T,native.reshape(64,676),atol=2e-6)
    np.testing.assert_array_equal(overlap(xx[None])[0],f.prior.reconstruct(xx))
    np.testing.assert_allclose(overlap(xx[None])[0],tp[0],atol=1e-6)
    synth=np.random.default_rng(12).normal(size=(1000,8));truth=np.random.default_rng(13).normal(size=(8,3));recovered=np.linalg.solve(synth.T@synth,synth.T@(synth@truth));np.testing.assert_allclose(recovered,truth,atol=1e-12)
    g,c,t,count=moments(fit);gv,cv,tv,nv=moments(val)
    rows=[];models=[]
    for lam in LAMBDAS:
        d=np.linalg.pinv(g/count,hermitian=True)@(c/count) if lam==0 else np.linalg.solve(g/count+lam*np.eye(64),c/count)
        loss=float((np.sum(d*(gv@d))-2*np.sum(d*cv)+tv)/(nv*49))
        rows.append(dict(ridge=lam,validation_patch_mse=loss,decoder_norm=float(np.linalg.norm(d))));models.append(d)
    best=min(range(len(rows)),key=lambda k:(rows[k]['validation_patch_mse'],rows[k]['ridge']));lam=rows[best]['ridge']
    write(OUT/'selection.json',dict(selected=rows[best],grid=rows));status(f'validation selected ridge {lam:g}; refitting on all training images')
    gf=g+gv;cf=c+cv;nf=count+nv
    d=np.linalg.pinv(gf/nf,hermitian=True)@(cf/nf) if lam==0 else np.linalg.solve(gf/nf+lam*np.eye(64),cf/nf)
    assert d.shape==(64,49) and np.isfinite(d).all();np.savez(OUT/'local_decoder.npz',decoder=d,ridge=lam,gram=gf,cross=cf,patch_count=nf)
    if fit_only:
        return
    d=d.astype(np.float32)
    state=json.loads((folder/'model.state').read_text())['items']
    def w(name):
        a=state['CVAE_TwoLayer.Upper.'+name];return np.array(a['value'],np.float32).reshape(a['shape'])
    dec=w('DIRECT_DECODER_WEIGHTS');db=w('DIRECT_DECODER_BIAS');del state
    codes,_,_=e.read_codes(folder/'test_codes.csv',test,test_labels,128)
    def upper(z):
        v=(z@dec+db).reshape(-1,64,676);v=v-v.max(1,keepdims=True);v=np.exp(v);return v/v.sum(1,keepdims=True)
    def render(a,method):
        if method=='hard':patch=book[a.argmax(2)]
        else:patch=a@(book if method=='soft' else d)
        return overlap(patch)
    totals={(source,method):dict(raw=0.,clipped=0.,outside=0) for source in ['local','upper'] for method in ['hard','soft','linear']};gallery={}
    status('evaluating all10000 test-image reconstructions')
    for start in range(0,10000,64):
        x=vp[start:start+64];rawpatch=patches(x);local=activities(rawpatch.reshape(-1,49),book).reshape(len(x),676,64)
        top=upper(codes[start:start+64].astype(np.float32)).transpose(0,2,1)
        for source,a in [('local',local),('upper',top)]:
            for method in ['hard','soft','linear']:
                y=render(a,method);q=totals[(source,method)];q['raw']+=float(((y-x)**2).sum(dtype=np.float64));q['clipped']+=float(((np.clip(y,0,1)-x)**2).sum(dtype=np.float64));q['outside']+=int(((y<0)|(y>1)).sum())
                if start==0:gallery[(source,method)]=np.clip(y[:8],0,1)
    clean=[dict(source=s,decoder=m,raw_mse=v['raw']/(10000*1024),clipped_mse=v['clipped']/(10000*1024),outside_fraction=v['outside']/(10000*1024)) for (s,m),v in totals.items()]
    write(OUT/'clean_results.json',clean)
    f.gallery(OUT/'clean_reconstructions.png','First eight test images; same frozen encoders; linear decoder trained locally',[[x for x in vp[:8]]]+[list(gallery[k]) for k in [('local','hard'),('local','soft'),('local','linear'),('upper','hard'),('upper','soft'),('upper','linear')]],['input','local hard','local soft','local linear','upper hard','upper soft','upper linear'],[str(int(t)) for t in test_labels[:8]])
    status('replaying fixed feedback to capture its unchanged upper probabilities')
    worker.run(seed,OUT/'feedback_inference',save_decoder_probabilities=True)
    source=OUT/'feedback_inference';feedback=json.loads((source/'results.json').read_text());oldpath=n.CAMPAIGN/'neural_readout_coupled_feedback_seed1/results.json' if seed==71001 else n.CAMPAIGN/'neural_readout_coupled_feedback_ten_seeds'/f'seed{seed}'/'results.json';old=json.loads(oldpath.read_text())
    for a,b in zip(feedback['aggregate'],old['aggregate']):
        for key in a:
            if isinstance(a[key],(int,float)):np.testing.assert_allclose(a[key],b[key],atol=1e-12)
    modes=['no_feedback','feedback_after','feedback_during'];methods=['hard','soft','linear'];outputs=[]
    with np.load(source/'upper_decoder_probabilities.npz') as z:
        for mode in modes:
            a=z[mode].transpose(0,2,1)
            for method in methods:outputs.append(np.clip(render(a,method),0,1))
    outputs=np.array(outputs);cases=feedback['protocol']['cases'];initial=np.array([r['initial_winner'] for r in feedback['per_case'] if r['mode']=='competition_only']);final=np.array([r['final_winner'] for r in feedback['per_case'] if r['mode']=='feedback_during'])
    status('scoring feedback reconstructions with independent pixel5NN')
    pred=e.five_nearest_predictions(tp.reshape(60000,1024),labels,outputs.reshape(-1,1024)).reshape(9,223)
    mix=np.array([r['mix'] for r in cases]);mask=np.arange(223)<220;dom=mask&(mix!=.5);cleanmask=mask&np.isin(mix,[0,1]);equal=mask&(mix==.5);truth=np.where(mix>.5,3,8)
    A=np.stack([vp[r['i']] for r in cases]);B=np.stack([vp[r['j']] for r in cases]);x=mix[:,None,None]*A+(1-mix[:,None,None])*B
    summaries=[]
    for idx,(mode,method) in enumerate((mo,me) for mo in modes for me in methods):
        winner=final if mode=='feedback_during' else initial
        row=dict(mode=mode,decoder=method,winner_agreement=float(np.mean(pred[idx,mask]==winner[mask])),equal_winner_agreement=float(np.mean(pred[idx,equal]==winner[equal])),dominant_reconstruction=float(np.mean(pred[idx,dom]==truth[dom])),clean_reconstruction=float(np.mean(pred[idx,cleanmask]==truth[cleanmask])),input_mse=float(((outputs[idx,mask]-x[mask])**2).mean()))
        if method=='hard':np.testing.assert_allclose(row['winner_agreement'],feedback['aggregate'][modes.index(mode)]['final_winner_agreement'],atol=1e-14)
        summaries.append(row)
    np.savez_compressed(OUT/'feedback_renderings.npz',images=outputs,pixel_predictions=pred)
    f.gallery(OUT/'feedback_decoders.png','Same equal-mixture input and feedback dynamics; only pixel decoding changes',[[x[221]]+[outputs[k*3+m,221] for k in range(3)] for m in range(3)],['hard patches','soft patches','linear decoder'],['input','no feedback','feedback after','feedback during'])
    assert all(hashlib.sha256(p.read_bytes()).hexdigest()==hashes[p.name] for p in files)
    write(OUT/'results.json',dict(protocol=protocol,selection=rows[best],clean=clean,feedback=summaries,unchanged_checkpoint_sha256=hashes,feedback_replay_matches=True))
    lines=['# Local linear patch decoder: first-seed diagnostic','','64 activity inputs ->49 pixel outputs; ridge selected on local validation patch MSE, then refitted on960000 patches from all60000 training images. All original weights frozen.','','| Signal source | Decoder | Raw image MSE | Clipped image MSE | Pixels outside[0,1] |','| --- | --- | ---: | ---: | ---: |']
    for r in clean:lines.append(f'| {r["source"]} | {r["decoder"]} | {r["raw_mse"]:.6f} | {r["clipped_mse"]:.6f} | {r["outside_fraction"]:.2%} |')
    lines+=['','| Feedback condition | Decoder | Winner agreement | Equal-mixture agreement | Dominant reconstruction |','| --- | --- | ---: | ---: | ---: |']
    for r in summaries:lines.append(f'| {r["mode"]} | {r["decoder"]} | {r["winner_agreement"]:.2%} | {r["equal_winner_agreement"]:.2%} | {r["dominant_reconstruction"]:.2%} |')
    lines+=['',f'Selected ridge: {lam:g}. Local training uses only bottom-up activities and original patches. The upper model was not retrained to target this decoder. Feedback dynamics and category winners are identical across renderers. All rendering uses overlap averaging; linear outputs are clipped only after overlap for the clipped metrics and pixel recognition.','', 'Single seed, reused test set and220 feedback scenes. Independent pixel5NN is a diagnostic proxy. Local reconstruction, full hierarchy reconstruction and category consistency are separate outcomes. Not yet integrated into native Ikaros; saved decoder is an offline artifact.']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');status('complete');print('\n'.join(lines),flush=True)


