"""Inspect all gain.5 switches; replay exact surrounding frames without learning."""
import json,hashlib,collections
from argparse import Namespace
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import evaluate_feedback_gain_ten_seeds as t
n=t.w.n;f=n.f;e=n.e;local=t.w.local
OUT=t.OUT/'winner_switches'
def write(name,x):(OUT/name).write_text(json.dumps(x,indent=2)+'\n')
def source(seed):return n.CAMPAIGN/'feedback_gain_sweep_seed1' if seed==71001 else t.OUT/f'seed{seed}'
def soft(v):
 v=v-v.max(1,keepdims=True);v=np.exp(v);return v/v.sum(1,keepdims=True)
def main():
 OUT.mkdir(exist_ok=True);rows=[];initial_margins=[];switchmask=[];saved={}
 for seed in t.SEEDS:
  src=source(seed);r=json.loads((src/'results.json').read_text());cases=[v for v in r['per_case'] if v['gain']==.5 and not v['illustration']]
  with np.load(src/'arrays.npz') as a:
   gi=list(a['gains']).index(.5);act=a['activities'][gi,:,:220];wins=act.argmax(2)
   for k,c in enumerate(cases):
    sw=np.flatnonzero(np.diff(wins[:,k])!=0)+1;v=np.sort(act[0,k]);margin=float(v[-1]-v[-2]);initial_margins.append(margin);switchmask.append(len(sw)>0)
    if not len(sw):continue
    old=int(wins[0,k]);new=int(wins[-1,k]);assert len(sw)==1 and old!=new
    row=dict(seed=seed,case_index=k,**c,switch_iteration=int(sw[0]),initial_relative_margin=margin,final_category_initial_rank=int(np.flatnonzero(np.argsort(-act[0,k])==new)[0])+1)
    rows.append(row);saved[(seed,k)]=dict(input=a['input'][k],activities=act[:,k].copy(),output=a['outputs'][gi,k].copy())
 assert len(rows)==49
 # Selected for distinct dynamics, not attractive reconstruction or correct recognition.
 chosen=[(71001,37),(71007,158),(71003,111),(71009,169)]
 write('protocol.json',dict(gain=.5,selection=[dict(seed=s,case_index=k,reason=reason) for (s,k),reason in zip(chosen,['First recorded switch:8 to3','Earliest3 to8 switch','Largest initial relative margin among switches;3 to2','Latest switch'])],replay='All49 switching seed-scene cases, exact unchanged inference rule. Capture0,t-2,t-1,t,t+1,t+2,200, where t is observed competition switch. Verify original activity trajectories and final images. Pixel5NN labels for frames are independent of competition.',scope='Descriptive analysis of existing outcomes. No new inputs, training, tuning or causal feature intervention. Intermediate categories can differ from both components.'))
 train,test,labels,tl=e.prepare_data(Namespace(train_count=60000,test_count=10000));tp=np.stack([e.full.center_and_pad(x) for x in train]).astype(np.float32)/255
 frames=[];prob_traces=[];act_traces=[];checks=[]
 for seed in t.SEEDS:
  rr=[r for r in rows if r['seed']==seed];x=np.stack([saved[(seed,r['case_index'])]['input'] for r in rr]);N=len(rr)
  folder=n.CAMPAIGN/f'hierarchy_s{seed}';rd=n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit'/f'grouped_softmax_s{seed}.npz';prior=n.CAMPAIGN/'local_linear_patch_decoder_seed1' if seed==71001 else n.CAMPAIGN/'local_linear_patch_decoder_ten_seeds'/f'seed{seed}';dp=prior/'local_decoder.npz';paths=[folder/'model.state',folder/'codebook_final.npz',rd,dp];hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
  state=json.loads(paths[0].read_text())['items']
  def w(key):
   a=state['CVAE_TwoLayer.Upper.'+key];return np.array(a['value'],np.float32).reshape(a['shape'])
  enc=w('DIRECT_MEAN_WEIGHTS');eb=w('DIRECT_MEAN_BIAS');dec=w('DIRECT_DECODER_WEIGHTS');db=w('DIRECT_DECODER_BIAS');del state
  with np.load(rd) as z:rw=z['weights'];rb=z['bias']
  with np.load(dp) as z:d=z['decoder'].astype(np.float32)
  with np.load(paths[1]) as z:book=f.prior.Codebook(z['prototypes'])
  codes,_,_=e.read_codes(folder/'train_codes.csv',train,labels,128)
  refs=json.loads((n.CAMPAIGN/'category_feedback_diagnostic/reference_indices.json').read_text())['71001'] if seed==71001 else json.loads((prior/'feedback_inference/reference_indices.json').read_text());ids=np.array([refs[str(c)] for c in range(10)]);rc=codes[ids].astype(np.float32)
  def encode(p):return p.reshape(len(p),-1)@enc+eb
  def decode(z):
   v=(z@dec+db).reshape(-1,64,676);v-=v.max(1,keepdims=True);return v-np.log(np.exp(v).sum(1,keepdims=True))
  def probs(z):return n.softmax(z@rw+rb).reshape(-1,10,20).sum(2)
  def render(q):return np.clip(local.overlap(np.exp(q).transpose(0,2,1)@d),0,1)
  rq=decode(rc.reshape(-1,128)).reshape(10,8,64,676);p0=np.stack([book.process(v,False,.01,.08)[0].reshape(64,676) for v in x]);lp=np.log(np.maximum(p0,1e-30));z=encode(p0);q=decode(z);pr=probs(z);a=pr/pr.max(1,keepdims=True);p=p0.copy();selected=((z[:,None,None]-rc[None])**2).sum(3).argmin(2);acts=[a.copy()];prs=[pr.copy()]
  timings=[[0,r['switch_iteration']-2,r['switch_iteration']-1,r['switch_iteration'],r['switch_iteration']+1,r['switch_iteration']+2,200] for r in rr];im={0:render(q)}
  for step in range(1,201):
   ev=pr/pr.max(1,keepdims=True);an=.8*a+.2*np.maximum(ev-1.5*(a.sum(1,keepdims=True)-a),0);weights=an/an.sum(1,keepdims=True);delta=np.zeros_like(p)
   for c in range(10):delta+=weights[:,c,None,None]*np.clip(rq[c,selected[:,c]]-q,-2,2)
   p=.8*p+.2*soft(lp+.5*delta);a=an;z=encode(p);q=decode(z);pr=probs(z);acts.append(a.copy());prs.append(pr.copy())
   if any(step in v for v in timings):im[step]=render(q)
  acts=np.array(acts);prs=np.array(prs)
  for j,r in enumerate(rr):
   old=saved[(seed,r['case_index'])];ae=float(abs(acts[:,j]-old['activities']).max());ie=float(abs(im[200][j]-old['output']).max());assert ae<2e-5 and ie<2e-5
   np.testing.assert_array_equal(acts[:,j].argmax(1),old['activities'].argmax(1))
   sw=r['switch_iteration'];r['frame_iterations']=timings[j];r['evidence_switch_iterations']=(np.flatnonzero(np.diff(prs[:,j].argmax(1))!=0)+1).tolist();r['competition_activity_before']={str(c):float(acts[sw-1,j,c]) for c in [r['initial_winner'],r['final_winner']]};r['competition_activity_at_switch']={str(c):float(acts[sw,j,c]) for c in [r['initial_winner'],r['final_winner']]}
   frames.append(np.stack([im[k][j] for k in timings[j]]));prob_traces.append(prs[:,j]);act_traces.append(acts[:,j]);checks.append(dict(seed=seed,case_index=r['case_index'],activity_max_error=ae,final_image_max_error=ie))
  assert [hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]==hashes
  print(f'Replayed seed{seed}: {N} switches',flush=True)
 frames=np.array(frames);pr=np.array(prob_traces);acts=np.array(act_traces)
 print('Scoring exact surrounding frames',flush=True);pixel=e.five_nearest_predictions(tp.reshape(60000,-1),labels,frames.reshape(-1,1024)).reshape(49,7)
 for k,r in enumerate(rows):r['frame_pixel_predictions']=pixel[k].tolist()
 summary=dict(switches=49,total_seed_scene_cases=2200,unique_scenes=len(set((r['pair_id'],r['mix']) for r in rows)),directions={f'{a}->{b}':v for (a,b),v in collections.Counter((r['initial_winner'],r['final_winner']) for r in rows).items()},iteration_min=min(r['switch_iteration'] for r in rows),iteration_median=float(np.median([r['switch_iteration'] for r in rows])),iteration_max=max(r['switch_iteration'] for r in rows),equal_mixture_switches=sum(r['mix']==.5 for r in rows),unmixed_switches=sum(r['mix'] in [0,1] for r in rows),final_pixel_agreement=int(sum(r['pixel_prediction']==r['final_winner'] for r in rows)),final_category_initial_ranks=dict(collections.Counter(r['final_category_initial_rank'] for r in rows)),median_initial_relative_margin_switch=float(np.median(np.array(initial_margins)[switchmask])),median_initial_relative_margin_no_switch=float(np.median(np.array(initial_margins)[~np.array(switchmask)])))
 write('results.json',dict(summary=summary,cases=rows,replay_checks=checks));np.savez_compressed(OUT/'arrays.npz',frames=frames,probabilities=pr,activities=acts,pixel_predictions=pixel)
 # Combined exact-frame figure with labels unique to each row.
 font=ImageFont.load_default(size=16);small=ImageFont.load_default(size=14)
 canvas=Image.new('RGB',(1160,790),'white');draw=ImageDraw.Draw(canvas);draw.text((18,12),'Winner changes during feedback: input fixed; columns show exact iterations',fill='black',font=font)
 indices=[next(i for i,r in enumerate(rows) if (r['seed'],r['case_index'])==v) for v in chosen]
 for ri,k in enumerate(indices):
  r=rows[k];y=55+ri*180;draw.text((15,y),f"{r['initial_winner']} -> {r['final_winner']}  at t={r['switch_iteration']}",fill='black',font=font);draw.text((15,y+28),f"seed {r['seed']}",fill='black',font=small);draw.text((15,y+50),f"3 fraction {r['mix']:g}",fill='black',font=small)
  imgs=[saved[(r['seed'],r['case_index'])]['input']]+list(frames[k]);labs=['input']+[f't={s}' for s in r['frame_iterations']]
  for j,(v,lab) in enumerate(zip(imgs,labs)):
   xx=190+j*119;draw.text((xx,y),lab,fill='black',font=small);tile=Image.fromarray(np.uint8(np.clip(v,0,1)*255)).resize((106,106),Image.Resampling.NEAREST);canvas.paste(tile,(xx,y+24))
   if j:draw.text((xx,y+135),f'pixel label {pixel[k,j-1]}',fill='#444444',font=small)
 canvas.save(OUT/'selected_switches.png')
 # Activities and pre-competition category evidence, first32cycles, all categories included.
 chart=Image.new('RGB',(1160,1090),'white');dr=ImageDraw.Draw(chart);dr.text((15,10),'Orange: initial winner; blue: final winner; grey: other categories; dashed: switch',fill='black',font=font)
 for ri,k in enumerate(indices):
  r=rows[k];base=65+ri*250;dr.text((15,base-20),f"Seed {r['seed']}, 3 fraction {r['mix']:g}: {r['initial_winner']} -> {r['final_winner']}",fill='black',font=font)
  for col,(values,title) in enumerate([(acts[k],'Competition activity'),(pr[k],'Category probability before competition')]):
   x0=65+col*575;y0=base+24;ww=480;hh=160;dr.text((x0,y0-23),title,fill='black',font=small)
   for level in [0,.5,1]:
    yy=y0+hh*(1-level);dr.line((x0,yy,x0+ww,yy),fill='#dddddd');dr.text((x0-35,yy-7),str(level),fill='#555555',font=small)
   xx=x0+r['switch_iteration']/32*ww
   for yy in range(y0,y0+hh,10):dr.line((xx,yy,xx,yy+5),fill='#555555')
   order=[c for c in range(10) if c not in [r['initial_winner'],r['final_winner']]]+[r['initial_winner'],r['final_winner']]
   for c in order:
    color='#d55e00' if c==r['initial_winner'] else '#0072b2' if c==r['final_winner'] else '#bbbbbb';dr.line([(x0+tt/32*ww,y0+hh*(1-float(v))) for tt,v in enumerate(values[:33,c])],fill=color,width=3 if c in order[-2:] else 1)
   for tt in [0,8,16,24,32]:dr.text((x0+tt/32*ww-5,y0+hh+6),str(tt),fill='black',font=small)
 chart.save(OUT/'selected_activity_traces.png')
 for start in range(0,49,10):
  group=rows[start:start+10];f.gallery(OUT/f'all_switches_{start//10+1}.png','All switches: exact frames around each case-specific switch t',[[saved[(r['seed'],r['case_index'])]['input']]+list(frames[start+j]) for j,r in enumerate(group)],[f"{r['seed']}:{r['case_index']} {r['initial_winner']}>{r['final_winner']} t{r['switch_iteration']}" for r in group],['input','0','t-2','t-1','t','t+1','t+2','200'])
 lines=['# Winner-switch analysis','','49 switches among2200 seed-scene runs;26 distinct inputs. Every switching case changed competition winner exactly once. Median switch iteration7, range5–24. Only2 were equal mixtures and5 were unmixed digits. These are deterministic changes during settling, not sustained perceptual alternations.','',json.dumps(summary,indent=2),'','All49 cases replayed with unchanged checkpoints; all competition winner sequences matched and activity/image errors were below2e-5. Independent pixel5NN scored exact surrounding frames. Selected examples cover the first recorded switch, earliest3-to8 switch, strongest initial margin, and latest switch. All49 examples are included in five additional galleries.','', 'Activity is the recurrent competitive state. Category probability is the feedforward readout of the current lower representation before competitive inhibition. Their winner changes need not occur on the same iteration. The input stays fixed, but lower probabilities and therefore category evidence evolve. Pixel images are renderings of the upper decoder; the pixels themselves are not fed back into inference. Image changes support descriptive interpretation, not a causal claim that a particular stroke caused a switch.','', '## Cases','', '| Seed | Case | 3 fraction | Transition | Switch iteration | Initial relative margin | Final pixel label |','|---|---|---:|---|---:|---:|---:|']
 for r in rows:lines.append(f"| {r['seed']} | {r['case_index']} | {r['mix']:g} | {r['initial_winner']} to {r['final_winner']} | {r['switch_iteration']} | {r['initial_relative_margin']:.3f} | {r['pixel_prediction']} |")
 (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__':main()
