"""Fifty affine softmax units pooled into ten fixed category groups."""
import hashlib
import json
from argparse import Namespace
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import evaluate_neural_readouts as n

OUT=n.CAMPAIGN/'neural_readout_grouped_softmax50'

def lse(x,axis):
    m=x.max(axis=axis,keepdims=True)
    return np.squeeze(m+np.log(np.exp(x-m).sum(axis=axis,keepdims=True)),axis=axis)

def objective(logits,y,gradient=False):
    grouped=logits.reshape(-1,10,5)
    chosen=grouped[np.arange(len(y)),y]
    loss=float(np.mean(lse(logits,1)-lse(chosen,1)))
    if not gradient:return loss
    d=n.softmax(logits).reshape(-1,10,5)
    d[np.arange(len(y)),y]-=n.softmax(chosen)
    return loss,d.reshape(-1,50)/len(y)

def check_gradient():
    rng=np.random.default_rng(391)
    logits=rng.normal(size=(3,50));y=np.array([0,4,9])
    _,d=objective(logits,y,True)
    for i,j in [(0,0),(0,21),(1,24),(2,49),(2,10)]:
        plus=logits.copy();minus=logits.copy();plus[i,j]+=1e-5;minus[i,j]-=1e-5
        numeric=(objective(plus,y)-objective(minus,y))/2e-5
        np.testing.assert_allclose(numeric,d[i,j],atol=1e-8,rtol=1e-6)
    np.testing.assert_allclose(d.sum(1),0,atol=1e-14)
    p=n.softmax(logits);np.testing.assert_allclose(p.reshape(-1,10,5).sum(2).sum(1),1)

def evaluate(x,y,w,b,usage=False):
    logits=x@w+b;grouped=logits.reshape(-1,10,5)
    pred=lse(grouped,2).argmax(1)
    result=dict(accuracy=float(np.mean(pred==y)),cross_entropy=objective(logits,y))
    if usage:
        rows=[]
        for c in range(10):
            scores=grouped[y==c,c,:];conditional=n.softmax(scores)
            wins=np.bincount(scores.argmax(1),minlength=5);shares=wins/wins.sum()
            positive=shares[shares>0]
            rows.append(dict(category=c,winner_counts=wins.tolist(),winner_shares=shares.tolist(),
                mean_conditional_activity=conditional.mean(0).tolist(),
                effective_units=float(np.exp(-(positive*np.log(positive)).sum())),
                units_above_one_percent=int(np.sum(shares>=.01)),largest_winner_share=float(shares.max())))
        result['usage']=rows
    return result,pred

def run_seed(seed):
    train,test,labels,test_labels=n.e.prepare_data(Namespace(train_count=60000,test_count=10000))
    folder=n.CAMPAIGN/f'hierarchy_s{seed}'
    hashes={k:hashlib.sha256((folder/k).read_bytes()).hexdigest() for k in ['model.state','codebook_final.npz']}
    x,_,_=n.e.read_codes(folder/'train_codes.csv',train,labels,128)
    z,_,_=n.e.read_codes(folder/'test_codes.csv',test,test_labels,128)
    x=x.astype(np.float32);z=z.astype(np.float32)
    rng=np.random.default_rng(seed+2000)
    w=rng.normal(0,.01,(128,50)).astype(np.float32);b=np.zeros(50,np.float32)
    mw=np.zeros_like(w);vw=np.zeros_like(w);mb=np.zeros_like(b);vb=np.zeros_like(b)
    step=0;history=[];snapshots={}
    for epoch in range(1,301):
        order=rng.permutation(len(x));loss=0
        for start in range(0,len(x),256):
            ids=order[start:start+256];batch=x[ids]
            value,d=objective(batch@w+b,labels[ids],True);loss+=value*len(ids)
            gw=batch.T@d;gb=d.sum(0);step+=1
            mw=.9*mw+.1*gw;vw=.999*vw+.001*gw*gw
            mb=.9*mb+.1*gb;vb=.999*vb+.001*gb*gb
            w-=.001*(mw/(1-.9**step))/(np.sqrt(vw/(1-.999**step))+1e-8)
            b-=.001*(mb/(1-.9**step))/(np.sqrt(vb/(1-.999**step))+1e-8)
        history.append(loss/len(x))
        if epoch in (30,100,300):
            snapshots[epoch]=(w.copy(),b.copy())
            (OUT/f'status_s{seed}.json').write_text(json.dumps(dict(stage='training',passes=epoch))+'\n')
    rows=[]
    for epoch,(w,b) in snapshots.items():
        assert np.isfinite(w).all() and np.isfinite(b).all()
        train_result,_=evaluate(x,labels,w,b,True)
        test_result,pred=evaluate(z,test_labels,w,b)
        row=dict(seed=seed,passes=epoch,train=train_result,test=test_result)
        rows.append(row)
        np.savez(OUT/f'grouped_softmax_s{seed}_passes{epoch}.npz',weights=w,bias=b,predictions=pred)
    assert all(hashlib.sha256((folder/k).read_bytes()).hexdigest()==v for k,v in hashes.items())
    (OUT/f'result_s{seed}.json').write_text(json.dumps(dict(results=rows,loss_history=history,sensory_checkpoint_sha256=hashes),indent=2)+'\n')
    (OUT/f'status_s{seed}.json').write_text(json.dumps(dict(stage='complete'))+'\n')
    print(f'Seed {seed}: '+', '.join(f'{r["passes"]} passes {r["test"]["accuracy"]:.2%}' for r in rows),flush=True)
    return rows

def main():
    OUT.mkdir(exist_ok=True);check_gradient()
    protocol=dict(seeds=list(range(71001,71011)),train_count=60000,test_count=10000,passes=[30,100,300],
        architecture='128 raw upper means -> 50 affine scores -> global softmax -> fixed sums over five units per category. No hidden sensory layer.',
        objective='Negative log of summed probability of the correct category. Logit gradient = global probability minus within-correct-category responsibility. No unit-level targets.',
        learning='Adam lr .001, beta1 .9, beta2 .999, epsilon1e-8, batch256, 300 shuffled passes. N(0,.01) weights, zero biases, RNG sensory seed+2000. No balancing penalty, regularization, or z-scores.',
        scope='Supervised gradients only update readout weights and biases; both sensory layers frozen. No feedback or recurrent competition simulation.',
        evaluation='Fixed 30/100/300 checkpoints; no test-guided selection. One fit per sensory seed. Compare paired seeds with saved ten-unit softmax checkpoints and 5NN.',
        specialization='Training-only within-correct-category winner shares and entropy effective unit count, plus mean conditional activities. Measures usage diversity; not proof of distinct handwriting styles.',
        checks='Finite-difference gradient check on synthetic data; image/code alignment and unchanged sensory checkpoint hashes.')
    (OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    (OUT/'status.json').write_text(json.dumps(dict(stage='running',workers=2))+'\n')
    with ProcessPoolExecutor(max_workers=2) as pool:rows=[r for group in pool.map(run_seed,protocol['seeds']) for r in group]
    old=json.loads((n.CAMPAIGN/'neural_readout_longer_learning/results.json').read_text())['per_seed']
    aggregate=[]
    for epoch in [30,100,300]:
        subset=[r for r in rows if r['passes']==epoch];a=np.array([r['test']['accuracy'] for r in subset])
        baseline=np.array([next(o['test_accuracy'] for o in old if o['seed']==r['seed'] and o['passes']==epoch) for r in subset])
        delta=a-baseline;half=2.2621571628540993*delta.std(ddof=1)/np.sqrt(10)
        usage=[c for r in subset for c in r['train']['usage']]
        aggregate.append(dict(passes=epoch,accuracy_mean=float(a.mean()),accuracy_sd=float(a.std(ddof=1)),
            train_accuracy=float(np.mean([r['train']['accuracy'] for r in subset])),
            train_ce=float(np.mean([r['train']['cross_entropy'] for r in subset])),test_ce=float(np.mean([r['test']['cross_entropy'] for r in subset])),
            ten_unit_mean=float(baseline.mean()),gain_over_ten=float(delta.mean()),gain_ci95=[float(delta.mean()-half),float(delta.mean()+half)],
            effective_units_mean=float(np.mean([c['effective_units'] for c in usage])),
            units_above_one_percent_mean=float(np.mean([c['units_above_one_percent'] for c in usage])),
            largest_winner_share_mean=float(np.mean([c['largest_winner_share'] for c in usage]))))
    (OUT/'results.json').write_text(json.dumps(dict(protocol=protocol,aggregate=aggregate,per_seed=rows),indent=2)+'\n')
    lines=['# Fifty grouped softmax units','',
        'Ten frozen full-MNIST sensory models. Five affine units per category; their global-softmax probabilities are summed to produce category probabilities. Only readout connections receive supervised gradients.', '',
        '| Passes | 50-unit accuracy | SD (pp) | 10-unit accuracy | Training accuracy | Gain over 10 (pp), 95% paired CI | Effective units/category |',
        '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for a in aggregate:
        lo,hi=a['gain_ci95'];lines.append(f'| {a["passes"]} | {a["accuracy_mean"]:.3%} | {100*a["accuracy_sd"]:.3f} | {a["ten_unit_mean"]:.3%} | {a["train_accuracy"]:.3%} | {100*a["gain_over_ten"]:+.3f} [{100*lo:+.3f}, {100*hi:+.3f}] | {a["effective_units_mean"]:.2f} |')
    lines+=['','5NN accuracy: 97.393% (SD .047 percentage points). Intervals describe paired seed variation on a fixed test set. Effective units are exp(entropy) of training winner shares within the correct category (range 1–5); usage diversity alone does not establish semantic specialization. No balancing penalty was imposed. Checkpoints were fixed beforehand, and all sensory weights stayed unchanged.']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
    (OUT/'status.json').write_text(json.dumps(dict(stage='complete',seeds=10))+'\n')
    print('\n'.join(lines),flush=True)

if __name__=='__main__':main()
