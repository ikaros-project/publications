"""Execute the frozen QMNIST protocol, resuming only completed endpoints."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import argparse,json,time,concurrent.futures
from dataclasses import asdict
import numpy as np
import qmnist_confirmation_common as q
from neural_spatial_rate_model import Circuit,windows
from run_spatial_population_feedback import PopulationFeedback
from run_spatial_overlap_pilot import PAR
from spatial_content_feedback import render_scene
OUT=q.OUT
_MODEL=None

def status(stage,**kw):
 q.dump(OUT/(stage+'_status.json'),dict(stage=stage,**kw));print(stage,kw,flush=True)
def get_model(seed):
 global _MODEL
 if _MODEL is None or _MODEL[0]!=seed:_MODEL=(seed,*q.load_model(seed))
 return _MODEL[1:]
def crop(a,pos):return np.pad(a,((0,0),(31,31)))[:,pos+31:pos+63]
def masked(err,mask):return float(err[mask].mean()) if mask.any() else None

def spatial_run(seed,job,x,meta,folder):
 _,front=get_model(seed)
 c=Circuit(x[None],PAR,closed=True,padding=31);local=PopulationFeedback(front,c,job['feedback'],True)
 u=np.zeros_like(c.a);v=np.zeros_like(c.c)
 if job['task']=='completion':u[0,meta['target_position']+31]=2
 else:v[0,meta['target_category']]=2
 changes=[];ct=[];at=[];start=time.time()
 for tick in range(601):
  prob,y=front.evidence(local.q)
  if tick==600:break
  new,dq,gate=local.propose(c);_,sensory_prediction=front.infer_pixels(windows(c.s,31)[0])
  change=c.update(prob[None],sensory_prediction[None],u=u,v=v);local.q=new
  changes.append(max(float(change[0]),dq)/PAR.alpha);ct.append(c.c[0].copy());at.append(c.a[0].copy())
  if (tick+1)%100==0:q.dump(folder/'progress.json',dict(tick=tick+1,seconds=time.time()-start))
 assert np.isfinite(y).all() and np.isfinite(local.q).all()
 np.testing.assert_allclose(local.q.sum(1),1,atol=1e-5)
 active=bool(c.a.sum()>1e-7);loc=int(c.a[0].argmax())-31 if active else None;cat=int(c.c[0].argmax()) if c.c.sum()>1e-7 else None
 arrays=dict(final_field_predictions=y,final_render=render_scene(y,320),category_trace=ct,spatial_trace=at,changes=changes,reference_slots=local.chosen,final_probability=prob)
 row=dict(seed=seed,**{**job,**meta},location=loc,offset=None if loc is None else loc-meta['target_position'],located=False if loc is None else abs(loc-meta['target_position'])<=16,category=cat,category_correct=cat==meta['target_category'] if job['task']=='completion' else None,local_category=None if loc is None else int(prob[loc+31].argmax()),settled=bool(max(changes[-100:])<5e-6),last100_rate=float(max(changes[-100:])),seconds=time.time()-start)
 row['local_category_correct']=row['local_category']==meta['target_category']
 return row,arrays

def spatial_worker(item):
 seed,job=item;folder=OUT/'spatial'/f"model{seed}_job{job['job']:03d}";folder.mkdir(parents=True,exist_ok=True)
 if (folder/'result.json').exists():return json.loads((folder/'result.json').read_text())
 meta=json.loads((OUT/'spatial_stimuli.json').read_text())[job['case']]
 with np.load(OUT/'spatial_stimuli.npz') as z:x=z['input'][job['case']];clean=z['clean'][job['case']];mask=z['mask'][job['case']]
 row,arrays=spatial_run(seed,job,x,meta,folder)
 for name,pos in [('target',meta['target_position']),('selected',row['location'])]:
  for region in ['hidden','visible','all']:row[name+'_'+region+'_mse']=None
  if pos is not None:
   ct=crop(clean,pos);mm=crop(mask,pos);err=(arrays['final_field_predictions'][pos+31]-ct)**2
   row.update({name+'_hidden_mse':masked(err,mm),name+'_visible_mse':masked(err,~mm),name+'_all_mse':float(err.mean())})
 np.savez_compressed(folder/'arrays.npz',**arrays);q.dump(folder/'result.json',row)
 return row

def parity():
 assert asdict(PAR)==dict(alpha=.1,**q.protocol()['spatial']['parameters'])
 folder=OUT/'implementation_parity';folder.mkdir(exist_ok=True)
 if (folder/'checks.json').exists():return
 # Existing completion case, not new confirmation data.
 data=OUT.parent/'neural_spatial_architecture_seed1/spatial_overlap_pilot/fixed_spatial_cue/article_fixed_model_suite'
 old=next(r for r in json.loads((data/'results.json').read_text()) if r['group']=='completion' and r['feedback'] and r['metadata']['occlusion']==12)
 with np.load(data/'stimuli.npz') as z:x=z['input'][old['case']]
 mm=old['metadata'];meta=dict(target_position=mm['positions'][0],target_category=mm['categories'][0])
 row,arr=spatial_run(71001,dict(task='completion',feedback=True),x,meta,folder)
 with np.load(data/f"trial{old['job']:04d}/arrays.npz") as z:
  errors={k:float(np.max(abs(np.asarray(arr[k])-z[k]))) for k in ['final_field_predictions','final_render','category_trace','spatial_trace','changes','reference_slots','final_probability']}
 assert max(errors.values())<1e-6,errors
 assert row['location']==old['location'] and row['category']==old['category']
 assert get_model(71001)[1].unchanged()
 q.dump(folder/'checks.json',dict(max_errors=errors,location_and_category_match=True,checkpoints_unchanged=True));status('parity',complete=True,errors=errors)

def spatial(workers):
 assert (OUT/'implementation_parity/checks.json').exists()
 jobs=json.loads((OUT/'spatial_jobs.json').read_text());items=[(s,j) for s in q.protocol()['models'] for j in jobs];rows=[];start=time.time()
 with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool:
  futures=[pool.submit(spatial_worker,item) for item in items]
  for f in concurrent.futures.as_completed(futures):
   rows.append(f.result());status('spatial',completed=len(rows),total=len(items),seconds=time.time()-start)
 rows.sort(key=lambda r:(r['seed'],r['job']));q.dump(OUT/'spatial_results.json',rows);status('spatial',complete=True,completed=len(rows),total=len(items),seconds=time.time()-start)

def focal():
 meta=json.loads((OUT/'focal_stimuli.json').read_text())
 with np.load(OUT/'focal_stimuli.npz') as z:x=z['input'];clean=z['clean'];mask=z['mask']
 raw=q.b.E.full.RAW_ROOT;train=q.b.E.full.read_idx_images(raw/'train-images-idx3-ubyte.gz',60000);labels=q.b.E.full.read_idx_labels(raw/'train-labels-idx1-ubyte.gz',60000)
 tp=np.stack([q.b.E.full.center_and_pad(v) for v in train]).astype(np.float32).reshape(60000,1024)/255
 start=time.time();allrows=[]
 for seed in q.protocol()['models']:
  m,front=get_model(seed)
  checkpath=OUT/f'focal_parity_{seed}.json'
  if not checkpath.exists():
   old=q.b.C/'relaxation_full_mixtures_ten_seeds'/f'seed{seed}.npz'
   with np.load(old) as z:
    oldx=z['input'][37:38].copy();known=z['snapshots'][2,-1,37:38].copy();knownact=z['activities'][2,:,37:38].copy()
   bb=np.stack([m['book'].process(v,False,.01,.08)[0].reshape(64,676) for v in oldx]);mm={**m,'b':bb,'z0':bb.reshape(1,-1)@m['enc']+m['eb']}
   rr=q.b.simulate(mm,m['ids'],True);errors=dict(image=float(abs(rr['images']-known).max()),activity=float(abs(rr['acts']-knownact).max()))
   assert max(errors.values())<3e-5,errors
   np.testing.assert_array_equal(rr['acts'].argmax(2),knownact.argmax(2));q.dump(checkpath,errors)
  # Original Codebook.process arithmetic matches saved focal runs.
  bottom=np.stack([m['book'].process(v,False,.01,.08)[0].reshape(64,676) for v in x]);m.update(b=bottom,z0=bottom.reshape(len(x),-1)@m['enc']+m['eb'])
  for on in [False,True]:
   path=OUT/f'focal_model{seed}_{int(on)}.json';arrpath=path.with_suffix('.npz')
   if path.exists():allrows+=json.loads(path.read_text());continue
   status('focal',seed=seed,feedback=on,stage_detail='inference')
   res=q.b.simulate(m,m['ids'],feedback=on)
   status('focal',seed=seed,feedback=on,stage_detail='pixel5NN scoring')
   pred=q.b.E.five_nearest_predictions(tp,labels,res['images'].reshape(-1,1024));wins=res['acts'].argmax(2);rows=[]
   for j,mm in enumerate(meta):
    err=(res['images'][j]-clean[j])**2;truth=mm['truth']
    rows.append(dict(seed=seed,feedback=on,**mm,category=int(wins[-1,j]),pixel_category=int(pred[j]),category_correct=None if truth is None else bool(wins[-1,j]==truth),pixel_correct=None if truth is None else bool(pred[j]==truth),agreement=bool(pred[j]==wins[-1,j]),clean_mse=float(err.mean()),input_mse=float(((res['images'][j]-x[j])**2).mean()),hidden_mse=masked(err,mask[j]),visible_mse=masked(err,~mask[j]),switched=bool(wins[-1,j]!=wins[0,j]),settled=bool(res['changes'][:,j].max()<1e-5)))
   np.savez_compressed(arrpath,images=res['images'],activities=res['acts'],last10changes=res['changes'],reference_slots=res['chosen'],reference_ids=m['ids']);q.dump(path,rows);allrows+=rows
   status('focal',completed=len(allrows),total=6210,seconds=time.time()-start)
  assert front.unchanged()
 q.dump(OUT/'focal_results.json',allrows);status('focal',complete=True,completed=len(allrows),total=6210,seconds=time.time()-start)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['parity','focal','spatial']);ap.add_argument('--workers',type=int,default=20);args=ap.parse_args();q.protocol()
 if args.mode=='parity':parity()
 elif args.mode=='focal':focal()
 else:spatial(args.workers)
if __name__=='__main__':main()
