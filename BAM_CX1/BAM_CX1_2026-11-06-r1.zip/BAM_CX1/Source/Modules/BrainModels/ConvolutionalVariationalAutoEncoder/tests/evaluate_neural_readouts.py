"""Compare locally trained category readouts on ten frozen full-MNIST models."""
import hashlib
import json
import time
from argparse import Namespace
import numpy as np
from run_full_mnist_feedback import CAMPAIGN
import run_mnist_two_layer as e

OUT = CAMPAIGN/'neural_readout_comparison'

def distances(x,c):
    return np.maximum((x*x).sum(1)[:,None]+(c*c).sum(1)[None,:]-2*x@c.T,0)

def softmax(x):
    a=np.exp(x-x.max(axis=1,keepdims=True))
    return a/a.sum(axis=1,keepdims=True)

def train_linear(x,y,seed,epochs=30,checkpoint=None):
    rng=np.random.default_rng(seed+2000)
    w=rng.normal(0,.01,(128,10)).astype(np.float32)
    b=np.zeros(10,np.float32)
    mw=np.zeros_like(w);vw=np.zeros_like(w);mb=np.zeros_like(b);vb=np.zeros_like(b)
    step=0;history=[]
    for epoch in range(epochs):
        order=rng.permutation(len(x));loss=0
        for start in range(0,len(x),256):
            ids=order[start:start+256];batch=x[ids];targets=y[ids]
            p=softmax(batch@w+b)
            loss-=float(np.log(np.maximum(p[np.arange(len(ids)),targets],1e-30)).sum())
            p[np.arange(len(ids)),targets]-=1;p/=len(ids)
            gw=batch.T@p;gb=p.sum(0);step+=1
            mw=.9*mw+.1*gw;vw=.999*vw+.001*gw*gw
            mb=.9*mb+.1*gb;vb=.999*vb+.001*gb*gb
            w-=.001*(mw/(1-.9**step))/(np.sqrt(vw/(1-.999**step))+1e-8)
            b-=.001*(mb/(1-.9**step))/(np.sqrt(vb/(1-.999**step))+1e-8)
        history.append(loss/len(x))
        if checkpoint is not None:
            checkpoint(epoch+1,w,b,history)
    assert np.isfinite(w).all() and np.isfinite(b).all()
    return w,b,history

def train_exemplars(x,y,seed,exemplars_per_category=8):
    rng=np.random.default_rng(seed+3000)
    centers=[];initial=[];history=[]
    for category in range(10):
        v=x[y==category]
        centroid=v.mean(0);dc=((v-centroid)**2).sum(1)
        pool=v[dc<=np.quantile(dc,.9)]
        chosen=[pool[np.argmin(((pool-centroid)**2).sum(1))].copy()]
        near=np.full(len(pool),np.inf)
        for _ in range(exemplars_per_category-1):
            near=np.minimum(near,((pool-chosen[-1])**2).sum(1))
            chosen.append(pool[np.argmax(near)].copy())
        c=np.stack(chosen);initial.append(c.copy())
        losses=[]
        for epoch in range(30):
            order=rng.permutation(len(v));loss=0
            for start in range(0,len(v),128):
                batch=v[order[start:start+128]];d=distances(batch,c);winner=d.argmin(1)
                loss+=float(d[np.arange(len(batch)),winner].sum())
                for k in np.unique(winner):
                    c[k]+=.01*(batch[winner==k].mean(0)-c[k])
            losses.append(loss/len(v))
        centers.append(c);history.append(losses)
    centers=np.stack(centers)
    residuals=np.concatenate([distances(x[y==c],centers[c]).min(1) for c in range(10)])
    # exp(-distance/tau): one shared width, derived from training residuals only.
    tau=float(np.median(residuals));assert tau>0 and np.isfinite(tau)
    return centers,tau,np.stack(initial),history

def exemplar_scores(x,c,tau):
    count=c.shape[1]
    log_activity=-distances(x,c.reshape(10*count,128)).reshape(-1,10,count)/tau
    maximum=log_activity.max(2)
    return maximum+np.log(np.exp(log_activity-maximum[:,:,None]).mean(2))

def main():
    OUT.mkdir(exist_ok=True)
    protocol=dict(seeds=list(range(71001,71011)),train_count=60000,test_count=10000,
        input='Frozen raw 128-dimensional upper mean, without z-score normalization.',
        linear='128 inputs, 10 affine softmax category units; supervised cross-entropy, Adam lr .001, beta1 .9, beta2 .999, epsilon 1e-8, batch256, 30 shuffled passes, no regularization; N(0,.01) weight initialization and zero biases.',
        exemplars='8 radial-basis exemplar units per category, 80 total. Initialize nearest class mean then farthest-point diversity within central 90%. Label restricts competition to the correct category during learning. Winning centers move .01 toward their assigned minibatch mean, batch128, 30 shuffled passes per category. No neighborhood relation.',
        category_pooling='Equal mean of exp(-squared Euclidean distance/tau) across each category\'s 8 units; one global tau is median final within-category nearest-center squared distance on all training codes. Highest category support wins; ties choose smallest category index.',
        randomness='Linear readout RNG = sensory seed + 2000; exemplar training RNG = sensory seed + 3000.',
        labels='Training labels used only by the readouts. Test labels used only after fitting for scoring.',
        scope='Offline readout experiment; no interlayer/classifier gradient to sensory model, no feedback, no new hidden sensory layer. Fixed settings, no test-guided selection. No recurrent lateral-inhibition simulation in this comparison.',
        baseline='Previously saved raw-code 5NN predictions on identical images; checked against stored accuracy.',
        statistics='Sample SD across ten paired model seeds; descriptive t(9) intervals of paired accuracy differences. One readout fit per sensory seed; sensory and readout random variation are not separated.')
    (OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    train,test,labels,test_labels=e.prepare_data(Namespace(train_count=60000,test_count=10000))
    rows=[]
    for seed in protocol['seeds']:
        (OUT/'status.json').write_text(json.dumps(dict(stage='fitting',seed=seed))+'\n')
        folder=CAMPAIGN/f'hierarchy_s{seed}'
        hashes={n:hashlib.sha256((folder/n).read_bytes()).hexdigest() for n in ['model.state','codebook_final.npz']}
        x,_,_=e.read_codes(folder/'train_codes.csv',train,labels,128)
        z,_,_=e.read_codes(folder/'test_codes.csv',test,test_labels,128)
        x=x.astype(np.float32);z=z.astype(np.float32)
        base=np.load(folder/'predictions_knn5.npy')
        baseline=float(np.mean(base==test_labels))
        assert baseline==json.loads((folder/'result_knn5.json').read_text())['classifier_accuracy']
        start=time.monotonic();w,b,linear_history=train_linear(x,labels,seed)
        linear_seconds=time.monotonic()-start
        start=time.monotonic();centers,tau,initial,exemplar_history=train_exemplars(x,labels,seed)
        exemplar_seconds=time.monotonic()-start
        linear_pred=(z@w+b).argmax(1)
        exemplar_pred=exemplar_scores(z,centers,tau).argmax(1)
        assert np.allclose(softmax(z[:32]@w+b).sum(1),1,atol=1e-6)
        # Recheck vectorized radial scores against their direct definition.
        direct=-((z[:3,None,None,:]-centers[None,:,:,:])**2).sum(3)/tau
        dm=direct.max(2)
        np.testing.assert_allclose(exemplar_scores(z[:3],centers,tau),dm+np.log(np.exp(direct-dm[:,:,None]).mean(2)),atol=2e-5,rtol=2e-5)
        row=dict(seed=seed,knn5=baseline,linear_softmax=float(np.mean(linear_pred==test_labels)),
                 competitive_exemplars=float(np.mean(exemplar_pred==test_labels)),
                 linear_train_accuracy=float(np.mean((x@w+b).argmax(1)==labels)),
                 exemplar_train_accuracy=float(np.mean(exemplar_scores(x,centers,tau).argmax(1)==labels)),
                 tau=tau,linear_training_seconds=linear_seconds,exemplar_training_seconds=exemplar_seconds,
                 linear_loss_history=linear_history,exemplar_distance_history=exemplar_history,
                 sensory_checkpoint_sha256=hashes)
        np.savez(OUT/f'readouts_s{seed}.npz',linear_weights=w,linear_bias=b,exemplar_centers=centers,
                 exemplar_initial=initial,exemplar_tau=tau,linear_predictions=linear_pred,exemplar_predictions=exemplar_pred)
        assert all(hashlib.sha256((folder/n).read_bytes()).hexdigest()==digest for n,digest in hashes.items())
        rows.append(row)
        (OUT/f'result_s{seed}.json').write_text(json.dumps(row,indent=2)+'\n')
        print(f'Seed {seed}: 5NN {baseline:.2%}, softmax {row["linear_softmax"]:.2%}, exemplars {row["competitive_exemplars"]:.2%}',flush=True)
    aggregate=[]
    for method in ['knn5','linear_softmax','competitive_exemplars']:
        values=np.array([r[method] for r in rows]);delta=values-np.array([r['knn5'] for r in rows])
        half=2.2621571628540993*delta.std(ddof=1)/np.sqrt(len(delta))
        aggregate.append(dict(method=method,mean=float(values.mean()),sd=float(values.std(ddof=1)),
                              difference_from_knn=float(delta.mean()),difference_ci95=[float(delta.mean()-half),float(delta.mean()+half)]))
    (OUT/'results.json').write_text(json.dumps(dict(protocol=protocol,aggregate=aggregate,per_seed=rows),indent=2)+'\n')
    lines=['# Neural category readouts','', 'Ten frozen full-MNIST sensory models; same 60,000 training and 10,000 test codes. No z-scores, sensory retraining, or classifier gradients to sensory layers.',
           '', '| Readout | Mean accuracy | Sample SD (pp) | Difference from 5NN (pp), 95% paired CI |', '| --- | ---: | ---: | ---: |']
    for a in aggregate:
        lo,hi=a['difference_ci95']
        lines.append(f'| {a["method"]} | {a["mean"]:.3%} | {100*a["sd"]:.3f} | {100*a["difference_from_knn"]:+.3f} [{100*lo:+.3f}, {100*hi:+.3f}] |')
    lines+=['','The softmax layer learns ten affine category scores. The exemplar layer learns eight centers per category with label-restricted competitive updates and pools radial-basis activity. These are two specific fixed configurations, not optimized bounds on either architecture. The confidence intervals describe paired training-seed differences on this fixed test set. Feedback and recurrent category competition were not evaluated here.','', 'Readout parameters and test predictions are saved for each seed. Native-code alignment and unchanged sensory checkpoint hashes were verified.']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
    (OUT/'status.json').write_text(json.dumps(dict(stage='complete',seeds=10))+'\n')
    print('\n'.join(lines),flush=True)

if __name__=='__main__':main()
