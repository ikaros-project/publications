"""Category-level label smoothing with validation selection and full-data refit."""
import hashlib
import json
from argparse import Namespace
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import evaluate_grouped_softmax as g
n=g.n
OUT=n.CAMPAIGN/'neural_readout_label_smoothing'
OLD=n.CAMPAIGN/'neural_readout_weight_decay'
SEEDS=list(range(71001,71011))
SMOOTHING=(0.,.02,.05,.1)

def objective(logits,y,epsilon,gradient=False):
    if epsilon==0:return g.objective(logits,y,gradient)
    grouped=logits.reshape(-1,10,5)
    group_lse=g.lse(grouped,2)
    target=np.full((len(y),10),epsilon/10,dtype=logits.dtype)
    target[np.arange(len(y)),y]+=1-epsilon
    loss=float(np.mean(g.lse(logits,1)-(target*group_lse).sum(1)))
    if not gradient:return loss
    conditional=np.exp(grouped-group_lse[:,:,None])
    d=n.softmax(logits).reshape(-1,10,5)-target[:,:,None]*conditional
    return loss,d.reshape(-1,50)/len(y)

def check_gradient():
    rng=np.random.default_rng(391);x=rng.normal(size=(3,50));y=np.array([0,4,9])
    for eps in SMOOTHING:
        _,d=objective(x,y,eps,True)
        for i,j in [(0,0),(0,21),(1,24),(2,49),(2,10)]:
            p=x.copy();m=x.copy();p[i,j]+=1e-5;m[i,j]-=1e-5
            numeric=(objective(p,y,eps)-objective(m,y,eps))/2e-5
            np.testing.assert_allclose(numeric,d[i,j],atol=1e-8,rtol=1e-6)
        np.testing.assert_allclose(d.sum(1),0,atol=1e-14)
        prob=n.softmax(x).reshape(-1,10,5).sum(2)
        target=np.full_like(prob,eps/10);target[np.arange(3),y]+=1-eps
        np.testing.assert_allclose(objective(x,y,eps),-(target*np.log(prob)).sum(1).mean())
    np.testing.assert_array_equal(objective(x,y,0,True)[1],g.objective(x,y,True)[1])

def run(seed,full=False):
    folder=n.CAMPAIGN/f'hierarchy_s{seed}'
    hashes={k:hashlib.sha256((folder/k).read_bytes()).hexdigest() for k in ['model.state','codebook_final.npz']}
    assert hashes==json.loads((OLD/f'validation_s{seed}.json').read_text())['sensory_checkpoint_sha256']
    images,test,labels,test_labels=n.e.prepare_data(Namespace(train_count=60000,test_count=10000))
    x,_,_=n.e.read_codes(folder/'train_codes.csv',images,labels,128);x=x.astype(np.float32)
    if full:
        setting=json.loads((OUT/'selection.json').read_text())['selected']
        epsilons=[setting['smoothing']];epochs=setting['passes'];dest=OUT/'full_refit'
        fit=np.arange(len(x))
    else:
        epsilons=SMOOTHING[1:];epochs=300;dest=OUT
        with np.load(OUT/'split_indices.npz') as s:fit=s['fit'];val=s['validation']
        xval=x[val];yval=labels[val]
    xf=x[fit];yf=labels[fit];rows=[]
    for eps in epsilons:
        rng=np.random.default_rng(seed+2000)
        w=rng.normal(0,.01,(128,50)).astype(np.float32);b=np.zeros(50,np.float32)
        mw=np.zeros_like(w);vw=np.zeros_like(w);mb=np.zeros_like(b);vb=np.zeros_like(b);step=0
        for epoch in range(1,epochs+1):
            order=rng.permutation(len(fit))
            for start in range(0,len(fit),256):
                ids=order[start:start+256];batch=xf[ids]
                _,d=objective(batch@w+b,yf[ids],eps,True);gw=batch.T@d;gb=d.sum(0);step+=1
                mw=.9*mw+.1*gw;vw=.999*vw+.001*gw*gw
                mb=.9*mb+.1*gb;vb=.999*vb+.001*gb*gb
                w*=1-.001*.1
                w-=.001*(mw/(1-.9**step))/(np.sqrt(vw/(1-.999**step))+1e-8)
                b-=.001*(mb/(1-.9**step))/(np.sqrt(vb/(1-.999**step))+1e-8)
            if epoch%10==0:
                (dest/f'status_s{seed}.json').write_text(json.dumps(dict(stage='training',smoothing=eps,passes=epoch))+'\n')
                if not full:
                    score,_=g.evaluate(xval,yval,w,b)
                    rows.append(dict(seed=seed,smoothing=eps,passes=epoch,validation_accuracy=score['accuracy'],validation_ce=score['cross_entropy']))
                    np.savez(dest/f'softmax_s{seed}_ls{eps:g}_passes{epoch}.npz',weights=w,bias=b)
        assert np.isfinite(w).all() and np.isfinite(b).all()
        if not full:
            best=min([r for r in rows if r['smoothing']==eps],key=lambda r:(-r['validation_accuracy'],r['validation_ce'],r['passes']))
            print(f'Seed {seed}, smoothing {eps:g}: best validation {best["validation_accuracy"]:.3%} at {best["passes"]} passes',flush=True)
    assert all(hashlib.sha256((folder/k).read_bytes()).hexdigest()==v for k,v in hashes.items())
    if full:
        z,_,_=n.e.read_codes(folder/'test_codes.csv',test,test_labels,128);z=z.astype(np.float32)
        tr,_=g.evaluate(x,labels,w,b,True);te,pred=g.evaluate(z,test_labels,w,b)
        np.savez(dest/f'grouped_softmax_s{seed}.npz',weights=w,bias=b,predictions=pred,adam_mw=mw,adam_vw=vw,adam_mb=mb,adam_vb=vb,step=step)
        row=dict(seed=seed,smoothing=eps,decay=.1,passes=epochs,train=tr,test=te,sensory_checkpoint_sha256=hashes,rng_state=rng.bit_generator.state,optimizer_steps=step)
        (dest/f'result_s{seed}.json').write_text(json.dumps(row,indent=2)+'\n')
        print(f'Seed {seed}: full-data test {te["accuracy"]:.3%}',flush=True)
    else:
        row=dict(rows=rows,sensory_checkpoint_sha256=hashes)
        (dest/f'validation_s{seed}.json').write_text(json.dumps(row,indent=2)+'\n')
    (dest/f'status_s{seed}.json').write_text(json.dumps(dict(stage='complete'))+'\n')
    return row if full else rows

def run_full(seed):return run(seed,True)

def main():
    OUT.mkdir(exist_ok=True);check_gradient()
    with np.load(OLD/'split_indices.npz') as s:np.savez(OUT/'split_indices.npz',fit=s['fit'],validation=s['validation'])
    protocol=dict(seeds=SEEDS,smoothing=list(SMOOTHING),decay=.1,checkpoints=list(range(10,301,10)),
        targets='Category targets t=(1-epsilon)*onehot(y)+epsilon/10. Correct category receives 1-0.9*epsilon; each other category epsilon/10. No target assignment among the five units within a category.',
        loss='Cross-entropy between category targets and sums of global softmax probabilities over each group of five. Exact readout-local gradient; no sensory gradients.',
        learning='Fresh matched seed+2000 initialization and shuffled passes. AdamW lr .001 beta1 .9 beta2 .999 epsilon1e-8; weight-only decay .1; batch256. Frozen raw128 sensory means; no inhibition or z-scores.',
        split='Exact saved proportional stratified 54000/6000 readout split, identical across seeds and strengths. Reuse saved zero-smoothing validation trajectories at decay .1.',
        selection='Shared smoothing and duration maximizing ten-seed mean validation accuracy; ties lower unsmoothed validation CE, shorter duration, smaller smoothing. Freeze choice before final test scoring.',
        refit='Fresh all60000 refit at selected setting, evaluating only final checkpoint; reuse completed baseline if epsilon0 and 290 passes wins.',
        caveat='Validation images previously seen in unsupervised sensory training; test set reused during exploration. Paired t intervals describe seed variability on this fixed test set.')
    (OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    (OUT/'status.json').write_text(json.dumps(dict(stage='validation_fitting',workers=2))+'\n')
    rows=[dict(r,smoothing=0.) for seed in SEEDS for r in json.loads((OLD/f'validation_s{seed}.json').read_text())['rows'] if r['decay']==.1]
    assert len(rows)==300
    with ProcessPoolExecutor(max_workers=2) as pool:rows += [r for group in pool.map(run,SEEDS) for r in group]
    grid=[]
    for eps in SMOOTHING:
        for epoch in protocol['checkpoints']:
            sub=[r for r in rows if r['smoothing']==eps and r['passes']==epoch];assert len(sub)==10
            grid.append(dict(smoothing=eps,passes=epoch,decay=.1,mean_validation_accuracy=float(np.mean([r['validation_accuracy'] for r in sub])),mean_validation_ce=float(np.mean([r['validation_ce'] for r in sub]))))
    key=lambda r:(-r['mean_validation_accuracy'],r['mean_validation_ce'],r['passes'],r['smoothing'])
    chosen=min(grid,key=key);best=[min([r for r in grid if r['smoothing']==eps],key=key) for eps in SMOOTHING]
    (OUT/'selection.json').write_text(json.dumps(dict(selected=chosen,best_per_smoothing=best,grid=grid),indent=2)+'\n')
    print('Frozen selection: '+json.dumps(chosen),flush=True)
    previous=json.loads((n.CAMPAIGN/'neural_readout_weight_decay_full_refit/results.json').read_text())
    reused=chosen['smoothing']==0 and chosen['passes']==290
    if reused:full=previous['per_seed']
    else:
        (OUT/'full_refit').mkdir(exist_ok=True)
        (OUT/'status.json').write_text(json.dumps(dict(stage='full_refit',selected=chosen))+'\n')
        with ProcessPoolExecutor(max_workers=2) as pool:full=list(pool.map(run_full,SEEDS))
    assert [r['seed'] for r in full]==[r['seed'] for r in previous['per_seed']]==SEEDS
    a=np.array([r['test']['accuracy'] for r in full]);b=np.array([r['test']['accuracy'] for r in previous['per_seed']]);d=a-b;h=2.2621571628540993*d.std(ddof=1)/np.sqrt(10)
    summary=dict(accuracy_mean=float(a.mean()),accuracy_sd=float(a.std(ddof=1)),paired_difference=float(d.mean()),paired_ci95=None if reused else [float(d.mean()-h),float(d.mean()+h)],baseline_reused=reused)
    (OUT/'results.json').write_text(json.dumps(dict(protocol=protocol,selection=chosen,best_per_smoothing=best,summary=summary,per_seed=full),indent=2)+'\n')
    lines=['# Category-level label smoothing','', '| Smoothing | Selected passes | Mean validation accuracy |', '| ---: | ---: | ---: |']
    for r in best:lines.append(f'| {r["smoothing"]:g} | {r["passes"]} | {r["mean_validation_accuracy"]:.3%} |')
    lines+=['',f'Selected smoothing {chosen["smoothing"]:g}, {chosen["passes"]} passes; weight decay 0.1.',f'Full-data test accuracy {a.mean():.3%}; sample SD {100*a.std(ddof=1):.3f} percentage points.']
    if reused:lines+=['The completed identical zero-smoothing full-data fit was reused; this is not a new independent replication.']
    else:lines+=[f'Paired change versus zero smoothing: {100*d.mean():+.3f} pp, descriptive 95% CI [{100*(d.mean()-h):+.3f}, {100*(d.mean()+h):+.3f}].']
    lines+=['','No sensory weights changed. Same readout split and training rules; selection uses unsmoothed validation metrics. Validation images were seen during prior unsupervised sensory training. The test set is reused, not independent confirmation.']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
    (OUT/'status.json').write_text(json.dumps(dict(stage='complete',seeds=10))+'\n')
    print('\n'.join(lines),flush=True)

if __name__=='__main__':main()
