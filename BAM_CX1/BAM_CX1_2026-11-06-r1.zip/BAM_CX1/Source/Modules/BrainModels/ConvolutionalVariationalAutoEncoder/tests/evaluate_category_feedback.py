"""Static externally cued feedback diagnostic using frozen MNIST weights."""
import json,hashlib
from argparse import Namespace
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import evaluate_topdown_codebook as prior
e=prior.e
BASE=e.OUTPUT/(prior.BASE.replace('codebook16','codebook64')+'_soft_tau_0p08_upper_categorical')
OUT=e.OUTPUT/'category_feedback_diagnostic'
GAINS=[0,.25,.5,1,2]

def logsoftmax(x):
    x=x-x.max(axis=0,keepdims=True)
    return x-np.log(np.exp(x).sum(axis=0,keepdims=True))

def gallery(path,title,panels,row_names,col_names):
    canvas=Image.new('RGB',(175+108*len(col_names),75+115*len(row_names)),'white')
    draw=ImageDraw.Draw(canvas);font=ImageFont.load_default(size=15)
    draw.text((12,10),title,fill='black',font=font)
    for c,label in enumerate(col_names):draw.text((175+c*108,45),label,fill='black',font=font)
    for r,label in enumerate(row_names):
        y=72+r*115;draw.text((8,y+35),label,fill='black',font=font)
        for c,x in enumerate(panels[r]):
            tile=Image.fromarray(np.uint8(np.clip(x,0,1)*255)).resize((96,96),Image.Resampling.NEAREST)
            canvas.paste(tile,(175+c*108,y))
    canvas.save(path)

def main(train_count=2000, test_count=1000, seeds=(71001,71002,71003)):
    OUT.mkdir(exist_ok=True)
    train,test,train_labels,test_labels=e.prepare_data(Namespace(train_count=train_count,test_count=test_count))
    train_px=np.stack([e.full.center_and_pad(x) for x in train]).astype(np.float32)/255
    test_px=np.stack([e.full.center_and_pad(x) for x in test]).astype(np.float32)/255
    pairs=[]
    for a,b in [(3,8),(4,9),(1,7)]:
        ia=np.flatnonzero(test_labels==a)[:10];ib=np.flatnonzero(test_labels==b)[:10]
        for i,j in zip(ia,ib):pairs.append((a,b,int(i),int(j)))
    protocol=dict(train_count=train_count,test_count=test_count,seeds=list(seeds),category_pairs=[[3,8],[4,9],[1,7]],pairs_per_category_pair=10,mixtures=[0,.25,.5,.75,1],gains=GAINS,references_per_category=8,
        reference_selection='Training-only: first nearest class mean, then farthest-point diversity within central 90% by distance to class mean; choose closest reference to input upper mean within the externally cued category.',
        feedback='p_g = softmax_channels(log(p_input) + gain * clip(log(q_reference)-log(q_input), -2, 2)); re-encode p_g, decode categorical probabilities, argmax prototypes and overlap-average. Input p_input remains the anchor; single update, no recurrent settling or competition.',
        scope='Frozen sensory weights; external category cue; static grayscale images; no spotlight, training or classifier gradients. References alone are a template-replacement control. Synthetic mixtures and first-example galleries are fixed before results.',pairs=pairs)
    (OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    rows=[];reference_ids={};checks=[];example_panels={}
    for seed in protocol['seeds']:
        d=BASE/f'hierarchy_s{seed}'
        hashes={name:hashlib.sha256((d/name).read_bytes()).hexdigest() for name in ['model.state','codebook_final.npz']}
        state=json.loads((d/'model.state').read_text())['items']
        def w(name):
            item=state['CVAE_TwoLayer.Upper.'+name]
            return np.array(item['value'],dtype=np.float32).reshape(item['shape'])
        encoder=w('DIRECT_MEAN_WEIGHTS');eb=w('DIRECT_MEAN_BIAS');decoder=w('DIRECT_DECODER_WEIGHTS');db=w('DIRECT_DECODER_BIAS')
        with np.load(d/'codebook_final.npz') as f:book=prior.Codebook(f['prototypes'])
        def decode(z):return logsoftmax((z@decoder+db).reshape(64,676))
        def image(logq):return prior.reconstruct(book.prototypes[logq.argmax(axis=0)])
        codes,_,_=e.read_codes(d/'train_codes.csv',train,train_labels,128)
        test_codes,_,_=e.read_codes(d/'test_codes.csv',test,test_labels,128)
        # Reproduce the previously saved native Ikaros probabilities.
        with (d/'categorical_parity.csv').open() as f:names=f.readline().strip().split(',')
        native=np.loadtxt(d/'categorical_parity.csv',delimiter=',',skiprows=1,ndmin=2)
        actual=native[:,[i for i,n in enumerate(names) if n.startswith('topdown:')]]
        computed=np.stack([np.exp(decode(z.astype(np.float32))).ravel() for z in test_codes[:8]])
        np.testing.assert_allclose(actual,computed,atol=2e-5,rtol=2e-5)
        refs={};ref_q={};ref_y={}
        for c in range(10):
            ids=np.flatnonzero(train_labels==c);v=codes[ids];dist=((v-v.mean(axis=0))**2).sum(axis=1)
            ids=ids[dist<=np.quantile(dist,.9)]
            first=ids[np.argmin(((codes[ids]-v.mean(axis=0))**2).sum(axis=1))];selected=[int(first)]
            minimum=np.full(len(ids),np.inf)
            for _ in range(7):
                minimum=np.minimum(minimum,((codes[ids]-codes[selected[-1]])**2).sum(axis=1))
                selected.append(int(ids[np.argmax(minimum)]))
            assert len(set(selected))==8 and np.all(train_labels[selected]==c)
            refs[c]=selected
            for i in selected:ref_q[i]=decode(codes[i].astype(np.float32));ref_y[i]=image(ref_q[i])
        reference_ids[str(seed)]=refs
        if seed==71001:
            gallery(OUT/'category_references.png','Training references and frozen two-layer reconstructions; seed 71001',
                [[train_px[refs[c][0]] for c in range(10)],[ref_y[refs[c][0]] for c in range(10)],
                 [train_px[refs[c][1]] for c in range(10)],[ref_y[refs[c][1]] for c in range(10)]],
                ['reference A','reconstruction A','reference B','reconstruction B'],[str(c) for c in range(10)])
        max_encoder_error=0
        seed_outputs=[];seed_row_ids=[]
        for pair_id,(a,b,i,j) in enumerate(pairs):
            A,B=test_px[i],test_px[j]
            for mix in protocol['mixtures']:
                x=mix*A+(1-mix)*B
                p,_=book.process(x,False,.01,.08);p=p.reshape(64,676)
                z=p.ravel()@encoder+eb;logq=decode(z);baseline=image(logq)
                if mix in (0,1):
                    expected=test_codes[i if mix==1 else j]
                    max_encoder_error=max(max_encoder_error,float(np.max(np.abs(z-expected))))
                for cue,target,other in [(a,A,B),(b,B,A)]:
                    ids=refs[cue];rid=ids[int(np.argmin(((codes[ids]-z)**2).sum(axis=1)))]
                    delta=np.clip(ref_q[rid]-logq,-2,2)
                    for gain in GAINS:
                        pg=np.exp(logsoftmax(np.log(np.maximum(p,1e-30))+gain*delta))
                        np.testing.assert_allclose(pg.sum(axis=0),1,atol=2e-6)
                        if gain==0:
                            # Preserve the exact baseline; normalization roundoff must not alter it.
                            np.testing.assert_allclose(pg,p,atol=2e-7)
                            y=baseline
                        else:y=image(decode(pg.ravel()@encoder+eb))
                        mse=lambda u,v:float(np.mean((u-v)**2))
                        row=dict(seed=seed,pair_id=pair_id,a=a,b=b,mix=mix,cue=cue,gain=gain,reference_train_index=rid,
                            target_mse=mse(y,target),other_mse=mse(y,other),input_mse=mse(y,x),baseline_shift_mse=mse(y,baseline),reference_distance_mse=mse(y,ref_y[rid]),
                            template_target_mse=mse(ref_y[rid],target),baseline_target_mse=mse(baseline,target),baseline_reference_mse=mse(baseline,ref_y[rid]),
                            clean_truth=(a if mix==1 else b if mix==0 else None))
                        rows.append(row);seed_row_ids.append(len(rows)-1);seed_outputs.append(y.ravel())
                        if seed==71001 and pair_id==0 and mix in (.5,1):
                            example_panels[(mix,cue,gain)]=y
                            example_panels[(mix,cue,'reference')]=ref_y[rid]
            if (pair_id+1)%10==0:print(f'Seed {seed}: {pair_id+1}/30 pairs evaluated',flush=True)
        assert max_encoder_error<1e-4
        # Independent diagnostic readout: raw-pixel 5NN, not the upper category associations.
        predictions=e.five_nearest_predictions(train_px.reshape(train_count,-1),train_labels,np.asarray(seed_outputs))
        for idx,pred in zip(seed_row_ids,predictions):rows[idx]['pixel_knn_prediction']=int(pred)
        assert all(hashlib.sha256((d/name).read_bytes()).hexdigest()==h for name,h in hashes.items())
        checks.append(dict(seed=seed,encoder_max_error=max_encoder_error,native_decoder_max_error=float(np.max(np.abs(actual-computed))),unchanged_checkpoint_sha256=hashes))
        print(f'Seed {seed}: readout and frozen-checkpoint verification complete',flush=True)
    (OUT/'reference_indices.json').write_text(json.dumps(reference_ids,indent=2)+'\n')
    aggregate=[]
    for gain in GAINS:
        amb=[r for r in rows if r['gain']==gain and r['mix']==.5]
        clean=[r for r in rows if r['gain']==gain and r['clean_truth'] is not None and r['cue']!=r['clean_truth']]
        aggregate.append(dict(gain=gain,ambiguous_target_mse=float(np.mean([r['target_mse'] for r in amb])),
            ambiguous_cued_pixel_knn_accuracy=float(np.mean([r['pixel_knn_prediction']==r['cue'] for r in amb])),
            ambiguous_fraction_better_than_no_feedback=float(np.mean([r['target_mse']<r['baseline_target_mse']-1e-8 for r in amb])),
            ambiguous_template_target_mse=float(np.mean([r['template_target_mse'] for r in amb])),
            ambiguous_reference_distance_mse=float(np.mean([r['reference_distance_mse'] for r in amb])),
            wrong_cue_clean_input_mse=float(np.mean([r['input_mse'] for r in clean])),
            wrong_cue_clean_truth_accuracy=float(np.mean([r['pixel_knn_prediction']==r['clean_truth'] for r in clean])),
            wrong_cue_followed_fraction=float(np.mean([r['pixel_knn_prediction']==r['cue'] for r in clean]))))
    (OUT/'results.json').write_text(json.dumps(dict(protocol=protocol,checks=checks,per_case=rows,aggregate=aggregate),indent=2)+'\n')
    for mix,label in [(.5,'ambiguous'),(1,'clean_wrong_cue')]:
        columns=['input','no feedback','gain .25','gain .5','gain 1','gain 2','reference only']
        x=mix*test_px[pairs[0][2]]+(1-mix)*test_px[pairs[0][3]]
        panel=[]
        for cue in (3,8):panel.append([x]+[example_panels[(mix,cue,g)] for g in GAINS]+[example_panels[(mix,cue,'reference')]])
        gallery(OUT/f'{label}.png','Same fixed input, two category cues; seed 71001; first held-out 3/8 pair',panel,['cue 3','cue 8'],columns)
    print(json.dumps(aggregate,indent=2),flush=True)

if __name__=='__main__':main()
