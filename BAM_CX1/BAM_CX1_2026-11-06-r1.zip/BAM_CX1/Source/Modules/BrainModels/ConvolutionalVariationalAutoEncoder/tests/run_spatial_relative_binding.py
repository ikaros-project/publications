"""Fixed within-field evidence normalization test and matched absence controls."""
import concurrent.futures,json,hashlib
from pathlib import Path
import numpy as np
import run_spatial_content_feedback as r
DATA=r.ROOT
CONTROL=DATA/'relative_binding_controls'
NORMAL='combined_separated_normalized_600'
BASE='combined_separated_600'

def prepare():
    CONTROL.mkdir(exist_ok=True)
    original=json.loads((DATA/'stimuli.json').read_text())
    with np.load(DATA/'stimuli.npz') as z: clean=z['clean'].copy()
    rows=[];images=[]
    replacement={3:4,8:9,4:3,9:8}
    for j in [0,2,4,6]:
        m=original[j];tp=m['target_position'];cat=m['target_category']
        for present in [True,False]:
            x=clean[j].copy();source=next(a for a in original if a['occlusion']==0 and a['target_category']==replacement[cat])
            if not present:x[:,tp:tp+32]=clean[source['case'],:,source['target_position']:source['target_position']+32]
            meta=dict(m);meta.update(case=len(rows),source_case=j,cue_mode='category',target_present=present,physical_target_category=cat if present else replacement[cat],replacement_test_index=None if present else source['test_indices'][0])
            rows.append(meta);images.append(x)
    np.savez_compressed(CONTROL/'stimuli.npz',input=images,clean=images,mask=np.zeros_like(images,dtype=bool))
    r.dump(CONTROL/'stimuli.json',rows)
    r.dump(DATA/'relative_binding_protocol.json',dict(seed=71001,new_trials=28,updates=600,early_stop=False,normalization='Only binding excitation uses P_wc/max_d(P_wd), denominator floor epsilon. Original category probability, sensory support, negative mismatch, inhibition, gains, readout and all trained weights unchanged. Default off.',main='Twelve original fixed cases: four pairs with intact,8x8,12x12 target deletion. Spatial cue2. Compare normalized separated feedback to saved unnormalized separated600 and spatial-only600.',controls='Four intact pairs, category cue2 and no spatial cue, crossed target present/absent and unnormalized/normalized separated content feedback:16 new runs. Absent target replaced by an existing target image of a different category from both requested target and distractor, preserving both objects and positions. Mapping3->4,8->9,4->3,9->8. No new screening.',scoring='Last20 and last100 normalized max changes<5e-6. Category active if mass>1e-7. Category-cued output is externally imposed and not scored as recognition. Controls report binding evidence at selected field and physical-object selection, including requested-category dominance and absolute binding strength. No calibrated not-found decision exists; these are diagnostics, not population false-positive estimates.',separation='Mismatch from instantaneous original frontend on current sensory pixels; bypasses content feedback and the additional local-code delay. Same route in both variants.',scope='One frozen model, repeated existing examples, no tuning or training. Do not adopt model or modify manuscript automatically.',source_sha256={n:hashlib.sha256(Path(__file__).with_name(n).read_bytes()).hexdigest() for n in ['neural_spatial_rate_model.py','spatial_content_feedback.py','run_spatial_content_feedback.py','run_spatial_relative_binding.py']}))

def worker(job):
    group,j,name=job
    r.ROOT=DATA if group=='main' else CONTROL
    return dict(group=group,**r.worker((j,name)))

def main():
    prepare()
    jobs=[('main',j,NORMAL) for j in range(12)]+[('control',j,name) for j in range(8) for name in [BASE,NORMAL]]
    with concurrent.futures.ProcessPoolExecutor(max_workers=8,initializer=r.init) as pool:rows=list(pool.map(worker,jobs))
    r.dump(DATA/'relative_binding_results.json',dict(cases=rows));print('RELATIVE BINDING COMPLETE',flush=True)
if __name__=='__main__':main()
