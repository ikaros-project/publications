"""Proposed spatial rate circuit, without engineered Q/log-confidence scoring.

Inference only. Exact pooling of mismatch populations is valid for fixed X:
0 <= Eplus <= X implies mean(relu(X-Eplus)) = mean(X)-mean(Eplus).
The explicit pixel-population reference is checked in test_neural_spatial_rate_model.

Optional horizontal extraction padding leaves the sensory display unchanged.
Locations are physical receptive-field left edges, which can be negative;
use spatial_mass to distinguish an absent output from a negative location.
"""
from dataclasses import dataclass,asdict
import numpy as np
from evaluate_spatial_two_objects import FrozenModel
from evaluate_spatial_single_stimulus import softmax

def phi(x):return np.clip(x,0,1)

def windows(x,padding=0):
    if padding:
        x=np.pad(x,((0,0),(0,0),(padding,padding)))
    return np.lib.stride_tricks.sliding_window_view(x,32,axis=-1).transpose(0,2,1,3).copy()

@dataclass(frozen=True)
class Parameters:
    alpha:float=.2
    k_M:float=12.
    k_F:float=12.
    k_A:float=1.
    k_C:float=.25
    k_Z:float=1.
    theta_T:float=0.
    inhibition:float=1.5
    epsilon:float=1e-6
    gamma_E:float=5.
    gamma_I:float=4.
    sigma:float=24.
    category_spatial_eta:float=0. # Zero preserves historical unweighted pooling.
    spatial_category_weighting:bool=False # Optional attention-weighted category readout.
    binding_relative_evidence:bool=False # Experimental within-field max normalization.

class Frontend(FrozenModel):
    def infer_pixels(self,images):
        ps=[];ys=[]
        for start in range(0,len(images),128):
            x=images[start:start+128];n=len(x)
            patch=np.lib.stride_tricks.sliding_window_view(x,(7,7),axis=(1,2)).reshape(-1,49)
            b=self.book.prototypes
            dist=(patch*patch).sum(1)[:,None]+(b*b).sum(1)[None]-2*patch@b.T
            act=softmax(-dist/(49*.08)).reshape(n,676,64).transpose(0,2,1).copy()
            z=act.reshape(n,-1)@self.enc+self.eb
            p=softmax(z@self.rw+self.rb).reshape(n,10,20).sum(2)
            top=softmax((z@self.dec+self.db).reshape(n,64,676).transpose(0,2,1))
            patches=(top@self.decoder).reshape(n,26,26,7,7);y=np.zeros_like(x)
            for dy in range(7):
                for dx in range(7):y[:,dy:dy+26,dx:dx+26]+=patches[:,:,:,dy,dx]
            ps.append(p);ys.append(np.clip(y/self.counts,0,1))
        return np.concatenate(ps),np.concatenate(ys)
    def scenes(self,x,padding=0):
        shape=x.shape[0];count=x.shape[-1]+2*padding-31
        xx=windows(x,padding).reshape(-1,32,32)
        active=np.any(xx!=0,axis=(1,2))
        if not hasattr(self,'blank'):self.blank=self.infer_pixels(np.zeros((1,32,32),np.float32))
        p=np.broadcast_to(self.blank[0],(len(xx),10)).copy();y=np.broadcast_to(self.blank[1],(len(xx),32,32)).copy()
        if np.any(active):p[active],y[active]=self.infer_pixels(xx[active])
        return p.reshape(shape,count,10),y.reshape(shape,count,32,32)

class Circuit:
    def __init__(self,x,params=Parameters(),closed=True,padding=0):
        self.x=np.asarray(x,np.float32).copy();self.par=params;self.closed=closed
        self.padding=padding
        self.positions=np.arange(-padding,self.x.shape[-1]-31+padding)
        self.xw=windows(self.x,padding);self.mean_x=self.xw.mean((2,3))
        n=len(x);self.s=self.x.copy()
        self.ep=np.zeros((n,len(self.positions)),np.float32);self.em=self.ep.copy();self.m=self.ep.copy()
        self.t=np.zeros((n,len(self.positions),10),np.float32);self.a=np.zeros((n,len(self.positions)),np.float32);self.c=np.zeros((n,10),np.float32)
        self.kernel=np.exp(-.5*((np.arange(self.x.shape[-1])[None,:]-(self.positions[:,None]+15.5))/params.sigma)**2).astype(np.float32)
        self.iteration=0
    def gain(self):
        p=self.par
        if not self.closed:return np.ones((len(self.x),self.x.shape[-1]),np.float32)
        return (1+p.gamma_E*(self.a@self.kernel))/(1+p.gamma_I*self.a.sum(1,keepdims=True))
    def update(self,prob,prediction=None,u=None,v=None,residual_means=None):
        p=self.par;alpha=p.alpha
        if u is None:u=np.zeros_like(self.a)
        if v is None:v=np.zeros_like(self.c)
        if residual_means is None:
            plus=np.maximum(self.xw-prediction,0).mean((2,3));minus=np.maximum(prediction-self.xw,0).mean((2,3))
        else:plus,minus=residual_means
        gain=self.gain()
        ns=(1-alpha)*self.s+alpha*phi(self.x*gain[:,None,:])
        ep=(1-alpha)*self.ep+alpha*plus
        em=(1-alpha)*self.em+alpha*minus
        m=(1-alpha)*self.m+alpha*np.maximum(self.mean_x-self.ep,0)
        # Category-specific residual populations may supply one M/Eminus per
        # binding unit; historical populations remain shared across categories.
        support=self.m[:,:,None] if self.m.ndim==2 else self.m
        negative=self.em[:,:,None] if self.em.ndim==2 else self.em
        evidence=prob/np.maximum(prob.max(2,keepdims=True),p.epsilon) if p.binding_relative_evidence else prob
        drive=p.k_M*support*evidence*(1+p.k_C*self.c[:,None,:])-p.k_F*negative-p.theta_T
        nt=(1-alpha)*self.t+alpha*phi(drive-p.inhibition*(self.t.sum(2,keepdims=True)-self.t))
        spatial_drive=self.t.sum(2)
        if p.category_spatial_eta:
            weight=(1+p.category_spatial_eta*self.c)/(1+p.category_spatial_eta*self.c.sum(1,keepdims=True))
            spatial_drive=(self.t*weight[:,None,:]).sum(2)
        na=(1-alpha)*self.a+alpha*phi(p.k_A*spatial_drive+u-p.inhibition*(self.a.sum(1,keepdims=True)-self.a))
        # Use the old spatial and binding states, preserving synchronous updates.
        category_binding=self.t*self.a[:,:,None] if p.spatial_category_weighting else self.t
        z=category_binding.sum(1)/(p.epsilon+category_binding.sum((1,2))[:,None])
        nc=(1-alpha)*self.c+alpha*phi(p.k_Z*z+v-p.inhibition*(self.c.sum(1,keepdims=True)-self.c))
        change=np.maximum.reduce([abs(ns-self.s).max((1,2)),abs(ep-self.ep).reshape(len(self.x),-1).max(1),abs(em-self.em).reshape(len(self.x),-1).max(1),abs(m-self.m).reshape(len(self.x),-1).max(1),abs(nt-self.t).max((1,2)),abs(na-self.a).max(1),abs(nc-self.c).max(1)])
        self.s,self.ep,self.em,self.m,self.t,self.a,self.c=ns,ep,em,m,nt,na,nc
        self.iteration+=1
        return change
    def snapshot(self):
        return dict(sensory=self.s.copy(),positive_error=self.ep.copy(),negative_error=self.em.copy(),support=self.m.copy(),binding=self.t.copy(),spatial=self.a.copy(),category=self.c.copy(),gain=self.gain().copy())
    def result(self):
        return dict(category=self.c.argmax(1),location=self.positions[self.a.argmax(1)],category_mass=self.c.sum(1),spatial_mass=self.a.sum(1),spatial_dominance=self.a.max(1)/np.maximum(self.a.sum(1),1e-30))

def simulate(frontend,x,params=Parameters(),closed=True,steps=300,u=None,v=None,initial=None,trace_steps=(0,1,5,10,20,50,100,200,300),padding=0):
    model=Circuit(x,params,closed,padding) if initial is None else initial
    fixed=None
    if not closed:fixed=frontend.scenes(model.s,model.padding)
    trace={0:model.snapshot()} if 0 in trace_steps else {};changes=[]
    for t in range(1,steps+1):
        prob,y=fixed if fixed is not None else frontend.scenes(model.s,model.padding)
        changes.append(model.update(prob,y,u,v))
        if t in trace_steps:trace[t]=model.snapshot()
    return model,np.array(changes),trace
