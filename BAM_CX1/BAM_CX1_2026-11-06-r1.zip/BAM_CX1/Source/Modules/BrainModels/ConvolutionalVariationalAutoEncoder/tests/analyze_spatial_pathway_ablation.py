"""Wait for the frozen ablation campaign, then report all outcomes and paired effects."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import json,time,traceback
import numpy as np
from PIL import Image,ImageDraw
import qmnist_confirmation_common as q
from run_spatial_pathway_ablation import OUT,MODES,read,freeze

def interval(rows,key,baseline=None):
 seeds=[71001,71002,71003];clusters=sorted({r['cluster'] for r in rows});matrix=np.full((3,len(clusters)),np.nan)
 for r in rows:
  value=r.get(key)
  if value is None:continue
  if baseline is not None:
   b=baseline[r['seed'],r['case']].get(key)
   if b is None:continue
   value=float(value)-float(b)
  matrix[seeds.index(r['seed']),clusters.index(r['cluster'])]=float(value)
 if np.isnan(matrix).all():return None
 rng=np.random.default_rng(2026110604);mi=rng.integers(0,3,(2000,3));ci=rng.integers(0,len(clusters),(2000,len(clusters)));samples=matrix[mi[:,:,None],ci[:,None,:]]
 with np.errstate(invalid='ignore'):boot=np.nanmean(samples,axis=(1,2))
 boot=boot[np.isfinite(boot)]
 return dict(mean=float(np.nanmean(matrix)),ci95=np.quantile(boot,[.025,.975]).tolist(),observed=int(np.isfinite(matrix).sum()),undefined=int(np.isnan(matrix).sum()),per_model=[None if np.isnan(a).all() else float(np.nanmean(a)) for a in matrix])

def auc(present,absent):
 if not len(present) or not len(absent):return None
 d=np.array(absent)[:,None]-np.array(present)[None,:];return float(np.mean((d>0)+.5*(d==0)))

def analyze():
 freeze();rows=read(OUT/'results.json');assert len(rows)==1260
 base={(r['seed'],r['case']):r for r in rows if r['mode']=='full'}
 for r in rows:
  r['nonsettled']=not r['settled'];r['no_output']=r['location'] is None;r['local_correct']=None if not r['present'] else r['local_category']==r['category']
  if r['task']=='recognition':
   b=base[r['seed'],r['case']];loc=b['location'];folder=OUT/'trials'/f"{r['seed']}_{r['case']:03d}_{r['mode']}"
   with np.load(folder/'arrays.npz') as z:
    for key,array in [('fixed_field_raw_correct','raw_probability'),('fixed_field_gain_correct','gain_probability'),('fixed_field_recurrent_correct','final_probability')]:r[key]=None if loc is None else bool(z[array][loc+31].argmax()==r['category'])
   r['exactly_aligned']=r['location']==r['position'];r['abs_offset']=None if r['offset'] is None else abs(r['offset'])
 summaries=[]
 metrics=['global_correct','local_correct','located','nonsettled','no_output','mismatch','spatial_mass','cue_local_agreement','target_hidden_mse','target_visible_mse','selected_hidden_mse','selected_visible_mse','target_foreground_mse','selected_foreground_mse']
 for task in ['recognition','selection','completion','present','absent']:
  for mode in MODES:
   rr=[r for r in rows if r['task']==task and r['mode']==mode]
   summaries.append(dict(task=task,mode=mode,n=len(rr),metrics={k:interval(rr,k) for k in metrics},paired_difference_from_full={k:interval(rr,k,base) for k in metrics}))
 gap=[]
 gapmetrics=['target_raw_correct','selected_raw_correct','target_gain_correct','selected_gain_correct','target_recurrent_correct','selected_recurrent_correct','global_correct','fixed_field_raw_correct','fixed_field_gain_correct','fixed_field_recurrent_correct','exactly_aligned','abs_offset']
 for mode in ['full','no_content','no_gain','no_gain_no_content']:
  rr=[r for r in rows if r['task']=='recognition' and r['mode']==mode];gap.append(dict(mode=mode,metrics={k:interval(rr,k) for k in gapmetrics}))
 absent=[]
 for mode in MODES:
  rr=[r for r in rows if r['mode']==mode and r['task'] in ['present','absent']];pr=[r['mismatch'] for r in rr if r['task']=='present' and r['mismatch'] is not None];ab=[r['mismatch'] for r in rr if r['task']=='absent' and r['mismatch'] is not None]
  absent.append(dict(mode=mode,present_n=len(pr),absent_n=len(ab),undefined=60-len(pr)-len(ab),auroc=auc(pr,ab)))
  # Bootstrap whole matched arrays and trained models, retaining both cue conditions.
  lookup={(r['seed'],r['cluster'],r['task']):r['mismatch'] for r in rr};clusters=sorted({r['cluster'] for r in rr});rng=np.random.default_rng(2026110604);boots=[]
  for _ in range(2000):
   ss=rng.choice([71001,71002,71003],3);cc=rng.choice(clusters,len(clusters));a=[lookup[s,c,'absent'] for s in ss for c in cc if lookup[s,c,'absent'] is not None];b=[lookup[s,c,'present'] for s in ss for c in cc if lookup[s,c,'present'] is not None];v=auc(b,a)
   if v is not None:boots.append(v)
  absent[-1]['ci95']=np.quantile(boots,[.025,.975]).tolist() if boots else None
 assert all(q.sha(p)==q.protocol()['checkpoint_sha256'][str(p.relative_to(q.C))] for s in [71001,71002,71003] for p in q.paths(s))
 q.dump(OUT/'enriched_results.json',rows);q.dump(OUT/'summary.json',dict(tasks=summaries,accuracy_gap=gap,target_absent=absent,weights_unchanged=True))
 def fmt(v,percent=False):
  if v is None:return 'undefined'
  scale=100 if percent else 1;suffix='%' if percent else ''
  return f"{v['mean']*scale:.3g}{suffix} [{v['ci95'][0]*scale:.3g}, {v['ci95'][1]*scale:.3g}]"
 lines=['# Spatial pathway ablation and accuracy-gap analysis','','Protocol frozen before simulation. Three trained models, original reference banks and unchanged weights. These are matched follow-up tests on reused QMNIST images. The model is not retuned.','','## Accuracy-gap decomposition','','All20 single digits per model are tested at the same known position. Exact-target-field measurements are scoring controls and do not force inference to that field. Raw selected-field recognition isolates crop/alignment from gain and recurrent content. Gain and content comparisons use a2x2design. Fixed-field results use each full-model trial’s selected position in every condition to prevent changed field choice from masquerading as changed processing. Global competition output is distinct from local evidence.','','| Condition | Raw exact field | Raw selected field | Gain exact field | Gain selected field | Recurrent selected field | Global output |','|---|---|---|---|---|---|---|']
 for g in gap:
  mm=g['metrics'];lines.append('| '+g['mode']+' | '+' | '.join(fmt(mm[k],True) for k in ['target_raw_correct','selected_raw_correct','target_gain_correct','selected_gain_correct','selected_recurrent_correct','global_correct'])+' |')
 lines+=['','## Selective pathway controls','','No-category-bias removes direct category modulation of binding and spatial pooling, while category-weighted content feedback remains. No-spatial-competition removes spatial lateral inhibition only. No-gain sets gain to1. No-mismatch removes both mismatch influences on binding, preserving original-input support and diagnostic error updates. These controls establish dependence on specific connections, not additive independent contributions.','','| Task | Condition | Global accuracy | Local accuracy | Localization | Nonsettled |','|---|---|---|---|---|---|']
 for g in summaries:
  mm=g['metrics'];lines.append('| '+g['task']+' | '+g['mode']+' | '+' | '.join(fmt(mm[k],True) for k in ['global_correct','local_correct','located','nonsettled'])+' |')
 lines+=['','## Completion','','| Condition | Hidden MSE at target | Visible MSE at target | Hidden MSE at selected field | Foreground MSE at selected field |','|---|---|---|---|---|']
 for g in summaries:
  if g['task']=='completion':lines.append('| '+g['mode']+' | '+' | '.join(fmt(g['metrics'][k]) for k in ['target_hidden_mse','target_visible_mse','selected_hidden_mse','selected_foreground_mse'])+' |')
 lines+=['','Selected-field hidden error is undefined when the selected field contains no masked pixels. Undefined counts are retained in summary.json. Foreground MSE is undefined for empty foreground fields. These conditional averages must not be mistaken for improved completion if selection changes.','','## Target-absent search','','| Condition | Mismatch AUROC | 95% interval | Undefined mismatch |','|---|---:|---|---:|']
 for a in absent:lines.append(f"| {a['mode']} | {a['auroc']} | {a['ci95']} | {a['undefined']} |")
 lines+=['','Mismatch remains a diagnostic readout in the mismatch-disconnected control. It is not zeroed artificially. AUROC describes discrimination on these arrays, not an implemented absence decision. Externally cued category activity is never scored as category recognition.','','## Reporting limits','','All600-update endpoints are retained. Settling and correct selection are different outcomes. Intervals resample models and source clusters jointly2000times, keeping each array’s conditions paired. Three models and ten pairs limit precision. Paired differences from the full model, per-model values, undefined-event counts and fixed-field decomposition are saved in summary.json. All available full-model counterparts must exactly match their saved original trajectories. No original model or manuscript was changed.']
 (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
 # Scientific summary graph, using a fixed0..100% scale for every comparison.
 fig=Image.new('RGB',(1150,650),'white');d=ImageDraw.Draw(fig);d.text((20,15),'Accuracy decomposition on identical single digits (three models,20 images each)',fill='black')
 keys=['target_raw_correct','selected_raw_correct','selected_gain_correct','selected_recurrent_correct','global_correct'];labels=['Raw exact field','Raw selected field','Gain selected field','Recurrent selected field','Global output'];colors=['#0072B2','#D55E00','#009E73','#CC79A7']
 for i,(key,label) in enumerate(zip(keys,labels)):
  y=65+i*110;d.text((15,y+30),label,fill='black')
  for j,g in enumerate(gap):
   value=g['metrics'][key];yy=y+j*21
   if value:
    d.rectangle((190,yy,190+value['mean']*680,yy+15),fill=colors[j]);d.text((880,yy),f"{value['mean']*100:.1f}%",fill='black')
 for j,g in enumerate(gap):d.rectangle((950,60+j*35,965,75+j*35),fill=colors[j]);d.text((975,60+j*35),g['mode'],fill='black')
 fig.save(OUT/'accuracy_decomposition.png');q.dump(OUT/'complete.json',dict(complete=True,runs=1260,weights_unchanged=True));print('Analysis complete',flush=True)
if __name__=='__main__':
 try:
  while not (OUT/'results.json').exists():
   errors=list((OUT/'trials').glob('*/error.json'))
   if errors:raise RuntimeError('Trial error recorded: '+','.join(str(p.relative_to(OUT)) for p in errors))
   time.sleep(45)
  analyze()
 except Exception:q.dump(OUT/'analysis_error.json',dict(error=traceback.format_exc()));raise
