"""Nested2/4/8-object displays: category search, cue switches and spatial controls."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import copy,json,time,fcntl,concurrent.futures
from dataclasses import asdict
import numpy as np
from neural_spatial_rate_model import Frontend,Parameters,Circuit
from evaluate_neural_spatial_architecture import OUT,dump
from evaluate_spatial_single_stimulus import e
ROOT=OUT/'spatial_set_size'
PAR=Parameters(alpha=.1,k_C=.25,category_spatial_eta=4,gamma_E=1.4,gamma_I=1,spatial_category_weighting=True)
FRONT=None
COUNTS=[2,4,8];WIDTH=640

def prepare():
    ROOT.mkdir(exist_ok=True)
    if (ROOT/'stimuli.npz').exists():return
    raw=e.full.read_idx_images(e.full.RAW_ROOT/'t10k-images-idx3-ubyte.gz',4000)
    labels=e.full.read_idx_labels(e.full.RAW_ROOT/'t10k-labels-idx1-ubyte.gz',4000)
    pools={c:list((np.flatnonzero(labels[3000:4000]==c)+3000).tolist()) for c in range(10)}
    rng=np.random.default_rng(92025);scenes=[];meta=[];used=[]
    for base in range(10):
        targets=[base,(base+3)%10]
        extra=rng.permutation([c for c in range(10) if c not in targets])[:6].tolist()
        cats=targets+extra;ids=[pools[c].pop(0) for c in cats];used+=ids
        images=np.stack([e.full.center_and_pad(raw[i]) for i in ids]).astype(np.float32)/255
        positions=(24+80*rng.permutation(8)+int(rng.integers(-8,9))).tolist()
        for mirror in [False,True]:
            pp=[WIDTH-32-p for p in positions] if mirror else positions
            for count in COUNTS:
                x=np.zeros((32,WIDTH),np.float32)
                for im,pos in zip(images[:count],pp[:count]):x[:,pos:pos+32]=im
                scenes.append(x);meta.append(dict(scene=len(meta),base=base,mirror=mirror,count=count,positions=pp[:count],categories=cats[:count],test_indices=ids[:count]))
    assert len(used)==len(set(used))==80
    a=np.array(scenes)
    for m,x in zip(meta,a):
        assert len(set(m['categories']))==m['count']
        assert min(np.diff(sorted(m['positions'])))>=80
        assert min(m['positions'])>=0 and max(m['positions'])+32<=WIDTH
        assert np.all((x>=0)&(x<=1))
    for base in range(10):
        for mirror in [False,True]:
            mm=[m for m in meta if m['base']==base and m['mirror']==mirror]
            assert [m['count'] for m in mm]==COUNTS
            for m in mm:
                assert m['positions'][:2]==mm[0]['positions'] and m['test_indices'][:2]==mm[0]['test_indices']
                for index in range(2):
                    p=m['positions'][index]
                    np.testing.assert_array_equal(a[m['scene'],:,p:p+32],a[mm[0]['scene'],:,p:p+32])
    np.savez_compressed(ROOT/'stimuli.npz',scenes=a);dump(ROOT/'stimuli.json',meta)

def init():
    global FRONT
    FRONT=Frontend();assert FRONT.hashes==json.loads((OUT/'checkpoint_hashes.json').read_text())

def episode(x,meta,name,target,spatial=False,initial=None):
    c=Circuit(x,PAR,padding=31) if initial is None else copy.deepcopy(initial)
    v=np.zeros((len(x),10),np.float32);u=np.zeros_like(c.a)
    for j,m in enumerate(meta):
        if spatial:u[j,m['positions'][target]+31]=2
        else:v[j,m['categories'][target]]=2
    stable=np.zeros(len(x),int);hist=[];acts=[];cats=[];gains=[];snap={0:c.snapshot()}
    for tick in range(1,601):
        p,y=FRONT.scenes(c.s,31);change=c.update(p,y,u=u,v=v)
        stable=np.where(change/PAR.alpha<5e-6,stable+1,0)
        hist.append(change);acts.append(c.a.copy());cats.append(c.c.copy());gains.append(c.gain().copy())
        if tick in [1,5,10,20,50,100,200,400,600]:snap[tick]=c.snapshot()
        if np.all(stable>=20):break
    result=c.result();rows=[]
    for j,m in enumerate(meta):
        active=result['spatial_mass'][j]>1e-7;loc=int(result['location'][j]) if active else None
        candidates=[] if loc is None else [i for i,pos in enumerate(m['positions']) if abs(loc-pos)<=16]
        assert len(candidates)<=1
        selected=candidates[0] if candidates else None
        pred=int(result['category'][j]) if result['category_mass'][j]>1e-7 else -1
        binding=c.t[j,c.a[j].argmax()];local=int(binding.argmax()) if binding.max()>1e-7 else None
        rows.append(dict(**m,condition=name,target=target,target_category=m['categories'][target],cue_type='spatial' if spatial else 'category',location=loc,selected=selected,location_correct=selected==target,category=pred,category_correct=pred==m['categories'][target],category_equals_selected=None if selected is None else pred==m['categories'][selected],category_is_distractor=pred in [q for i,q in enumerate(m['categories']) if i!=target],selected_binding_category=local,selected_binding_matches_cue=local==m['categories'][target],spatial_mass=float(result['spatial_mass'][j]),category_mass=float(result['category_mass'][j]),dominance=float(result['spatial_dominance'][j]),settled=bool(stable[j]>=20),settled_at=int(tick-stable[j]+20) if stable[j]>=20 else None,updates=tick,last_rate=float(change[j]/PAR.alpha)))
    arr=dict(changes=np.array(hist),spatial_trace=np.array(acts),category_trace=np.array(cats),gain_trace=np.array(gains),**{'final_'+k:z for k,z in c.snapshot().items()},**{f't{t}_{k}':z for t,s in snap.items() for k,z in s.items()})
    return c,rows,arr

def worker(job):
    count,base,x,meta=job;path=ROOT/f'n{count}'/f'base{base:02d}';path.mkdir(parents=True,exist_ok=True)
    with (path/'run.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        if (path/'cases.json').exists():return json.loads((path/'cases.json').read_text())
        states={};rows=[]
        for name,target,spatial in [('category_a',0,False),('category_b',1,False),('a_to_b',1,False),('b_to_a',0,False),('spatial_a',0,True),('spatial_b',1,True)]:
            initial=states.get('category_a' if name=='a_to_b' else 'category_b') if '_to_' in name else None
            c,rr,arr=episode(x,meta,name,target,spatial,initial);rows+=rr
            if name in ['category_a','category_b']:states[name]=c
            np.savez_compressed(path/(name+'.npz'),**arr)
            dump(path/'progress.json',dict(last_condition=name,completed_trials=len(rows)))
        assert FRONT.unchanged();dump(path/'cases.json',rows);return rows

def main():
    prepare();meta=json.loads((ROOT/'stimuli.json').read_text())
    with np.load(ROOT/'stimuli.npz') as z:scenes=z['scenes']
    protocol=dict(parameters=asdict(PAR),display_shape=[32,WIDTH],receptive_field=[32,32],stride=1,padding=31,processing_positions=671,object_counts=COUNTS,base_arrays=10,layouts_per_base=2,displays_per_count=20,unique_images=80,selection='First unused examples of each requested label in MNIST test indices3000:4000. Each base uses8 different categories and8 unique images, never reused across bases. Target categories are base and(base+3)%10, balancing each category equally as first/second target. Six other categories sampled without replacement. No screening by model performance.',placement='Eight slots80 pixels apart; random assignment plus shared jitter[-8,8], RNG92025. Mirror layout reverses positions but never reflects digit pixels. All object counts share the same640-pixel canvas, first two target images and positions, and nested distractors. Minimum48-pixel empty gap means a32-pixel receptive field cannot contain two stimuli. This changes visual extent and image sample relative to the earlier320-pixel pilot, so compare counts within this experiment.',conditions=['category_a','category_b','a_to_b','b_to_a','spatial_a','spatial_b'],trials_per_count=120,total_trials=360,category_cue=2,spatial_cue=2,maximum_updates=600,settling='Maximum state change/alpha<5e-6 for20 consecutive updates; settling time is end of first20 updates in the final uninterrupted stable interval. No state reset on category-cue switches.',scoring='Initial localization40/count; switches conditional on correct preceding initial selection plus joint success over40 opportunities; common correct-start subset across counts. Spatial cues without category priming independently test target category output, localization and distractor errors (40/count). Category output under a clamped category cue is reported but not counted as recognition evidence. Selected location within16pixels of target tile left edge; spatial mass>1e-7. All silent/unsettled outcomes retained.',scope='One frozen model, small nested set-size pilot. Mirrored layouts, opposite cues and nested counts are dependent observations. No new learning, mechanism tuning, overlapping stimuli, absent targets or duplicated categories in this first comparison.',checkpoint_hashes=json.loads((OUT/'checkpoint_hashes.json').read_text()))
    p=ROOT/'protocol.json'
    if p.exists():assert json.loads(p.read_text())==protocol
    else:dump(p,protocol)
    jobs=[]
    for base in range(10):
        for count in COUNTS:
            mm=[m for m in meta if m['base']==base and m['count']==count]
            jobs.append((count,base,scenes[[m['scene'] for m in mm]],mm))
    rows=[];start=time.time()
    with concurrent.futures.ProcessPoolExecutor(max_workers=12,initializer=init) as pool:
        ff={pool.submit(worker,j):j[:2] for j in jobs}
        for n,f in enumerate(concurrent.futures.as_completed(ff),1):
            rows+=f.result();msg=dict(completed=n,total=len(jobs),condition=ff[f],elapsed_seconds=time.time()-start)
            dump(ROOT/'status.json',msg);print(msg,flush=True)
    dump(ROOT/'cases.json',rows);dump(ROOT/'status.json',dict(stage='complete',elapsed_seconds=time.time()-start))
if __name__=='__main__':main()
