"""Insert verified fixed-model statistics into the six question-based sections."""
import json,re,argparse,hashlib
from pathlib import Path
from summarize_spatial_article_suite import ROOT,PREFIX

def fig(name,label,caption):
    return '\n\\begin{figure}[p]\n\\centering\n\\includegraphics[width=\\linewidth,height=0.77\\textheight,keepaspectratio]{'+PREFIX+'_'+name+'.pdf}\n\\caption{'+caption+'}\n\\label{fig:'+label+'}\n\\end{figure}\n'

def table(headers,rows,caption,label):
    return '\n\\begin{table}[htbp]\n\\centering\n\\small\n\\begin{tabular}{'+'l'*len(headers)+'}\n\\toprule\n'+' & '.join(headers)+' \\\\\n\\midrule\n'+'\n'.join(' & '.join(str(x) for x in row)+' \\\\' for row in rows)+'\n\\bottomrule\n\\end{tabular}\n\\caption{'+caption+'}\n\\label{tab:'+label+'}\n\\end{table}\n'

def f(x):return '--' if x is None else f'{x:.5f}'
def avg(v):return sum(v)/len(v)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--partial',action='store_true');args=ap.parse_args()
    s=json.loads((ROOT/(PREFIX+('_partial' if args.partial else '_statistics')+'.json')).read_text())
    if not args.partial:
        assert s['complete']
        validation=json.loads((ROOT/(PREFIX+'_validation.json')).read_text());assert validation['all_required_checks_passed']
    else:
        for name,sha in s['protocol']['source_sha256'].items():assert hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest()==sha
    done=lambda group:sum(r['group']==group for r in s['rows'])==s['protocol']['counts'][group]
    rows=s['rows'];path=ROOT/'spatial_processing.tex';text=path.read_text()
    def replace(label,body):
        nonlocal text
        start=text.index('\\label{'+label+'}')+len('\\label{'+label+'}')
        nxt=text.find('\\subsection{',start);end=len(text) if nxt<0 else nxt
        text=text[:start]+'\n\n'+body.strip()+'\n\n'+text[end:]

    if done('translation'):
        q=s['translation'];tr=[r for r in rows if r['group']=='translation'];correct=sum(r['global_correct'] for r in tr);located=sum(r['located'] for r in tr);settled=sum(r['settled'] for r in tr)
        body=rf'''\paragraph{{Question and conditions.}}
    We presented the same 100 original test images at tile origins 0, 16, 144, 272 and 288, with neither a spatial nor a category cue. Every image was therefore processed in five independent trials, including placements at both display boundaries. The centered focal readout on these same images provided a reference for categorization before recurrent spatial processing. The 500 placements are repeated observations on 100 images.

    \paragraph{{Results.}}
    The final global category was correct in {correct}/500 placements and the selected location lay within 16 pixels of the object origin in {located}/500 (Figure~\ref{{fig:suite-translation}}). The focal readout classified {q['focal_correct']}/100 images correctly. Across all five positions, {q['category_consistent']}/100 images had the same active category output and {q['offset_consistent']}/100 had the same signed location offset. Numerical settling occurred in {settled}/500 trials; all endpoints were retained.
    '''
        body+=table(['Origin','Category','Location','Settled'],[[r['position'],f"{r['correct']}/100",f"{r['located']}/100",f"{r['settled']}/100"] for r in q['by_position']], 'Recognition and localization across horizontal position. Each row uses the same 100 images.','suite-translation')
        body+=fig('translation','suite-translation','Recognition across position with the final model. The example is the first image in the fixed stimulus list. Outlines identify selected receptive fields on the original input; they are analysis annotations. The category and location scores include every placement. Coincident points overlap in the position plot.')
        body+=rf'''\paragraph{{Answer.}}
    The observed category consistency was {q['category_consistent']}/100 across the five placements. Position tolerance therefore coexisted with lower accuracy than the centered focal readout: 86\% versus 98\% on the same images. The experiment does not isolate whether altered receptive-field alignment, sensory gain, or content feedback accounts for this reduction. It demonstrates horizontal position tolerance on these reused digits, without establishing precise recovery of the tile origin or generalization to vertical translation or natural scenes.'''
        replace('sec:spatial-translation',body)

    if done('spatial_selection'):
        q=s['spatial_selection'];ss=[r for r in rows if r['group']=='spatial_selection'];neutral=[r for r in ss if r['target'] is None];ncat=sum(r['category'] in r['metadata']['categories'] for r in neutral);nsettle=sum(r['settled'] for r in neutral);dd=q['deltas'];joint=sum(r['target_sensory']>1e-6 and r['distractor_sensory']<-1e-6 for r in dd)
        body=rf'''\paragraph{{Question and conditions.}}
    We used the original 45 distinct-category image pairs in both left--right orders, giving 90 layouts. Each layout received no cue, a cue at the first object, or a cue at the second object, for 270 trials. No category cue was supplied. The point cue had strength 2; sensory gain arose from the recurrent spatial population. We compared global categorization, localization and the final sensory response to each object's original foreground pixels (intensity above 0.05) with the matched neutral trial.

    \paragraph{{Results.}}
    Spatially cued trials categorized the requested object correctly in {q['correct']}/180 cases and localized it in {q['located']}/180. Of the 90 neutral trials, {ncat} expressed one of the two input categories. Numerical settling occurred in {q['settled']}/180 cued and {nsettle}/90 neutral trials.

    Relative to the neutral condition, mean sensory foreground intensity changed by {q['mean_target_sensory_change']:+.5f} for the selected object and {q['mean_distractor_sensory_change']:+.5f} for the other object. Simultaneous enhancement of the selected foreground and attenuation of the other foreground occurred in {joint}/180 paired comparisons. These changes concern sensory activity; they are not a claim that the decoded scene exactly restores the selected image. Figure~\ref{{fig:suite-selection}} shows the first fixed layout, its gain profiles and all paired intensity changes.
    '''
        body+=fig('selection','suite-selection','Selection by a spatial cue with no category cue. Sensory-state images and gain profiles show the first fixed display under neutral, left and right cues. Yellow outlines mark selected fields. Foreground changes compare each cued trial with its neutral counterpart, with all repeated layouts and cue directions retained. Horizontal green marks indicate means; dots are dependent observations.')
        body+=rf'''\paragraph{{Answer.}}
    Spatial attention selected the requested location in {q['located']}/180 trials, while its category output was correct in {q['correct']}/180. The paired feature measurements quantify the accompanying sensory enhancement and suppression, rather than inferring these effects from categorization alone.'''
        replace('sec:spatially-guided-recognition',body)

    if done('set_size') and done('duplicates'):
        # Keep the already verified new-image present/absent experiment and its figures.
        start=text.index('\\subsection{Can a category expectation');end=text.index('\\subsection{Can feedback complete',start);block=text[start:end]
        block=block.replace('The completed conditions concern two-object displays. Matched distractor-load and duplicate-target conditions remain to be run with the final model on the common display.','The conditions comprise two-object present/absent search, nested distractor-load displays and identical duplicate targets, all on the common display.')
        cut=min(block.index('\\paragraph{Answer.}'),block.find('\\paragraph{Distractor load and duplicate targets.}') if '\\paragraph{Distractor load and duplicate targets.}' in block else len(block));block=block[:cut]
        block+=r'''\paragraph{Distractor load and duplicate targets.}
    Ten original eight-image arrays were arranged at 40-pixel slot intervals on the common display. We tested nested subsets of two, four and eight objects, both reversed left--right arrangements (without reflecting individual images), and two sustained category requests per layout, giving 40 trials per count. Images and targets were retained across counts. The 32-pixel field cannot contain two complete neighboring tiles, although sensory-gain profiles can span several objects. These compact layouts replace the earlier wider displays and therefore test both additional distractors and their presence within the common spatial extent.

    We also presented identical copies of one image from each category at origins 64 and 224. Each pair received the category cue alone or the same category cue together with a spatial cue at either copy, giving 30 trials. Exemplars were the first per-category images in the fixed translation set, without performance screening. With category cues alone either copy is a legitimate target; we report divided activity rather than scoring one side as uniquely correct.
    '''
        block+=table(['Objects','Location','Local category','Joint','Settled'],[[r['count'],f"{r['located']}/40",f"{r['local_correct']}/40",f"{r['joint']}/40",f"{r['settled']}/40"] for r in s['set_size']], 'Category-guided selection with nested distractor loads. The same ten arrays, reversed layouts and category requests recur across counts; rows are not independent samples.','suite-load')
        first,last=s['set_size'][0],s['set_size'][-1]
        block+=rf'''
    Increasing object count reduced correct localization from {first['located']}/40 to {last['located']}/40, whereas the local readout expressed the requested category in {last['local_correct']}/40 eight-object conditions. Joint location-and-category success fell from {first['joint']}/40 to {last['joint']}/40. Thus category agreement increasingly included responses at a nonmatching location.

    '''
        dup=s['duplicates'];alone=dup[0];cued=dup[1:]
        block+=rf'''
    With duplicate targets and only a category cue, spatial output was active in {alone['active']}/10 trials and the selected local readout matched in {alone['local_correct']}/10. Both object neighborhoods contained at least 10\% of total spatial activity in {alone['both_basins10']}/10 endpoints; a neighborhood included field origins within 16 pixels of the corresponding tile. Adding a spatial cue localized the requested copy in {sum(r['located'] for r in cued)}/20 trials, with matching local category in {sum(r['local_correct'] for r in cued)}/20. Settling occurred in {alone['settled']}/10 category-only and {sum(r['settled'] for r in cued)}/20 combined-cue trials (Figure~\ref{{fig:suite-load}}).
    '''
        block+=fig('load_duplicates','suite-load','Distractor load and duplicate targets. The upper panel separates location, unforced local categorization and their joint success across nested object counts. The lower panel shows the fixed category-0 duplicate example, with final spatial activity under a category cue alone or combined category and location cues. Dark markers identify category-only activity at its active fields, which coincide with the cued peaks. No outcome-based example selection was used.')
        block+=rf'''\paragraph{{Answer.}}
    Category expectation supported location selection, with joint success falling from {first['joint']}/40 to {last['joint']}/40 as object count increased. Adding a spatial cue resolved {sum(r['located'] for r in cued)}/20 duplicate-target conditions. Requested-category agreement alone did not establish correct selection or target presence; the model has no calibrated absence decision.

    \clearpage
    '''
        text=text[:start]+block+text[end:]

    if done('completion'):
        comp=s['completion'];co=s['completion_contrasts'];rr=[r for r in rows if r['group']=='completion'];body=r'''\paragraph{Question and conditions.}
    Twenty original target--distractor pairs, with two targets per category and one target on each side, were tested intact and with a central $8\times8$ or $12\times12$ square deleted from the target. A spatial cue selected the target without supplying a category. Each input was processed with content feedback active or disconnected, giving 120 trials. Both conditions used the same remaining recurrent equations. Clean targets and deletion masks were scoring data only.

    We measured squared reconstruction error in the deleted and visible target pixels at the known target field, together with global categorization, localization and error at the distractor field. The known field permits a matched reconstruction comparison without changing the circuit's selected location. It is not a selected-field rendering rule.

    \paragraph{Results.}
    '''
        body+=table(['Deletion','Feedback','Category','Hidden MSE','Visible MSE'],[[r['size'],'On' if r['mode']=='feedback' else 'Off',f"{r['correct']}/20",f(r['hidden_mse']),f(r['visible_mse'])] for r in comp], 'Target reconstruction and categorization. Hidden error is undefined for intact targets. Visible error includes all nondeleted target-field pixels. Every condition contains the same 20 pairs.','suite-completion')
        for size in [8,12]:
            c=[r for r in co if r['size']==size];improved=sum(r['hidden_mse']<-1e-6 for r in c)
            body+=rf'''
    For the {size}-pixel deletion, feedback changed mean hidden-region error by {avg([r['hidden_mse'] for r in c]):+.5f}, with lower error in {improved}/20 pairs. Mean visible-region error changed by {avg([r['visible_mse'] for r in c]):+.5f}. These are paired feedback-on minus feedback-off differences.
    '''
        assert max(abs(r['distractor_mse']) for r in co)<1e-8
        body+=rf'''
    Distractor-field error changed by less than $10^{{-8}}$ in every matched comparison. Across all 120 conditions, localization was correct in {sum(r['located'] for r in rr)}/120 and {sum(r['settled'] for r in rr)}/120 settled. Figure~\ref{{fig:suite-completion}} includes all twenty severe-deletion examples in pair order, including incorrect interpretations.
    '''
        body+=fig('completion','suite-completion','Completion with the final retinotopic model. Mean errors use all 20 pairs at each deletion size. Examples compare the clean target, occluded input and target-field predictions with content feedback off and on for all twenty targets at 12-pixel deletion. These are explicitly local-field predictions, not scene outputs. Error in the hidden region is unavailable for intact inputs.')
        body+=r'''\paragraph{Answer.}
    Content feedback reduced missing-region error in 18/20 pairs at each deletion size, while increasing mean error in visible target pixels. Categorization changed little. Category persistence and missing-pixel fidelity are distinct outcomes: a coherent category interpretation can change visible strokes or supply a plausible hidden stroke that differs from the original. Neither the local-field comparison nor a correct category establishes recovery of the exact missing image.'''
        replace('sec:spatial-content-feedback',body)

    if done('overlap_control'):
        ov=s['overlap'];body=r'''\paragraph{Question and conditions.}
    Five fixed digit pairs spanning all ten categories were tested at tile offsets of 0, 8 and 40 pixels, together with their ten isolated components. Pair inputs were the pixelwise maximum of the two images. Both category directions were tested with a category cue and a spatial cue at the requested object's origin. At full overlap the spatial cue was identical under category reversal. At nonzero offsets, category and spatial cues jointly specified the target.

    We reused 40 verified focused population-feedback endpoints and added 40 matched trials with only content feedback disconnected. Distinctive-feature changes compare the same physical pixels under the two conditions. A separate cue-reversal contrast compares each object's distinctive features when its own category is requested and when the other category is requested. Whole-canvas predictions use uniform averaging of every field, with no winner mask.

    \paragraph{Results.}
    '''
        body+=table(['Offset','Target change','Other change','Joint pattern','Cue contrast'],[[r['group'],f(r['target_change']),f(r['loser_change']),f"{r['target_preserved_loser_reduced']}/10",f"{r['positive_cue_contrasts']}/10"] for r in ov['aggregates'] if r['group']!='isolated'], 'Feature-specific effects on ten requests per offset. Changes are mean feedback-on minus feedback-off intensities. The joint pattern preserves or increases requested features while reducing competing features (tolerance $10^{-6}$). Cue contrast counts directions with stronger own-object features under their own cue. Conditions share five image pairs.','suite-overlap')
        for mode in ov['by_mode']:
            body+=rf"With content feedback {'active' if mode['mode']=='feedback' else 'disconnected'}, the unforced local readout matched {mode['local_correct']}/40 requests and {mode['settled']}/40 trials settled. "
        body+='\n\n'
        changes=', '.join(f"{r['mse_change']:+.5f}" for r in ov['aggregates']);counts=', '.join(f"{r['mse_improved']}/10" for r in ov['aggregates'])
        body+=f'Mean union-foreground target error changed by {changes} in isolated, fully overlapping, partially overlapping and separated conditions, respectively. Error decreased in {counts} requests in the same order. '
        body+='\n\n'+fig('overlap','suite-overlap','Object selection and distinctive features under overlap. Examples use the first fixed pair at all three offsets and display uniformly pooled scene predictions in a common crop and intensity range. The feature panel compares feedback on and off at fixed cues; the cue-reversal panel compares active-feedback endpoints under opposite requests. Shared pixels are excluded. At full overlap the spatial cue does not distinguish the objects.')
        full=next(r for r in ov['aggregates'] if r['group']==0);part=next(r for r in ov['aggregates'] if r['group']==8)
        body+=rf'''
    Across the final 100 updates, the maximum gain-profile difference between feedback-on and feedback-off trials was {max(r['max_feedback_gain_difference'] for r in ov['aggregates']):.3g}. At full overlap, gain profiles were also identical under category-cue reversal (maximum difference {full['max_cue_gain_difference']:.3g}). The full-overlap cue effect therefore occurred without a change in the final spatial gain profile.

    At the 8-pixel offset, mean target error over the union foreground decreased from {part['mse_by_mode']['feedback_off']:.5f} to {part['mse_by_mode']['feedback']:.5f}. This improvement coexisted with a mean decline in the requested object's distinctive-feature intensity. The fidelity advantage concerns the comparison with the requested component, including removal of competing strokes; it is not evidence that all requested strokes were preserved.

    '''
        body+=rf'''\paragraph{{Answer.}}
    The joint requested-feature preservation and competing-feature attenuation pattern occurred in {part['target_preserved_loser_reduced']}/10 partial-overlap and {full['target_preserved_loser_reduced']}/10 full-overlap requests. Positive cue contrast demonstrates category-dependent modification of the same image, but can coexist with attenuation of both objects. These small-sample results therefore quantify selective processing without equating category agreement, general dimming or cue dependence with reliable recovery of a separate original object.'''
        replace('sec:spatial-overlap',body)

    if done('imagery'):
        im=s['imagery'];both=[r for r in im if r['condition']=='category_spatial'];control=next(r for r in im if r['condition']=='spatial_only');nmatch=sum(r['cued_field_category']==r['category_cue'] for r in both);nz=sum(r['spatial_mass']>1e-7 for r in both);ns=sum(r['settled'] for r in both)
        assert all(r['sensory_max']==0 and r['support_max']==0 for r in im)
        body=rf'''\paragraph{{Question and conditions.}}
    A blank display received each of ten category cues either alone or together with a spatial cue at origin 144. One additional blank trial received only that spatial cue. The ten category-only trials were verified saved endpoints; the eleven remaining conditions were run with the same model. All sensory pixels and initial recurrent populations were zero. The feedback gate and sensory-support mechanism were unchanged.

    \paragraph{{Results.}}
    In the ten category-only blank trials, sensory support, binding and spatial activity remained exactly zero. Reconstructions were identical across categories, with low background intensity only (mean 0.00870, maximum 0.02584). Category activation alone therefore could not open the spatial content-feedback gate from this initial state.

    With both cues, spatial output was active in {nz}/10 trials, selected the supplied origin exactly in {sum(r['location']==144 for r in both)}/10, and the unforced local readout at the cued field matched the requested category in {nmatch}/10. Across all eleven new blank trials, sensory activity and sensory support remained exactly zero. Mean rendered intensity across the full display ranged from {min(r['render_mean'] for r in both):.5f} to {max(r['render_mean'] for r in both):.5f}; peak intensity ranged from {min(r['render_max'] for r in both):.5f} to {max(r['render_max'] for r in both):.5f}. In the location-only control, mean and peak intensity were {control['render_mean']:.5f} and {control['render_max']:.5f}, respectively. Numerical settling occurred in {sum(r['settled'] for r in im)}/11 new trials. Figure~\ref{{fig:suite-imagery}} shows every requested category and the common control on the same intensity scale.
    '''
        body+=fig('imagery','suite-imagery','Blank-display generation with an explicit category and location. All ten requested categories are shown in numerical order, together with the spatial-only control. Images are 64-column crops of uniformly pooled scene reconstructions, centered on the requested field. Labels give the unforced local category at that field, not the externally driven global category. Low-intensity backgrounds are not rescaled separately.')
        body+=r'''\paragraph{Answer.}
    Combined category and location cues produced category-specific reconstructed patterns with matching local readouts for all ten categories. Neither cue alone generated category-specific imagery from a blank initial state. Sensory support cannot initiate attention when the input is absent, but an external spatial cue can activate the spatial population and open the existing content-feedback gate when category activity is also supplied. The generated pattern is a prediction, not an increase in sensory activity. These results concern sustained cues at one supplied location, not autonomous initiation or persistence after cue removal.'''
        replace('sec:spatial-imagery',body)
    if not args.partial:assert 'pending' not in text and 'remain to be run' not in text
    path.write_text(text)
    if not args.partial:
        p=ROOT/'introduction.tex';intro=p.read_text();intro=intro.replace('Completed final-model results are distinguished from conditions awaiting matched reruns; earlier development configurations do not supply missing answers.','All six questions are evaluated with the same final inference configuration, with explicitly identified pathway-disconnection controls; earlier development configurations do not supply missing answers.').replace('The question-based spatial structure will be completed with matched final-model conditions before stronger common-model claims are made.','The spatial experiments retain incorrect, silent and nonsettled endpoints and distinguish categorization, localization and image-feature effects.');p.write_text(intro)
    print('Updated complete spatial sections:',[g for g in s['protocol']['counts'] if g!='parity' and done(g)])
if __name__=='__main__':main()
