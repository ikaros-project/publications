"""Fixed-spotlight feedback-gain comparison; frozen weights and matched inputs."""
import argparse,concurrent.futures,json,time,hashlib,shutil
from pathlib import Path
import numpy as np
import run_spatial_overlap_pilot as r
from run_spatial_overlap_fixed_spotlight import ROOT as BASE,CuedCircuit
from cached_spatial_content_feedback import CachedLocalFeedback
from neural_spatial_rate_model import windows
ROOT=BASE/'feedback_strength'

class StrengthFeedback(CachedLocalFeedback):
    maximum=.5
    def propose(self,circuit):
        b=self.front.bottom(windows(circuit.s,31)[0])
        gate=np.ones(len(b),np.float32)
        if self.attention:gate=np.clip((circuit.a[0]@self.field_kernel)/max(1.,float(circuit.a.sum())),0,1)
        c=circuit.c[0];mass=float(c.sum())
        lam=self.maximum*gate if self.feedback and mass>1e-7 else np.zeros_like(gate)
        target=b.copy()
        if np.any(lam):
            weights=c/mass
            if not hasattr(self,'_weights') or not np.array_equal(weights,self._weights):
                Q=np.zeros_like(b)
                for k in range(10):
                    if weights[k]!=0:Q+=weights[k]*self.front.rp[k,self.chosen[:,k]]
                self._weights=weights.copy();self._Q=Q
            target=(1-lam[:,None,None])*b+lam[:,None,None]*self._Q
        new=(1-circuit.par.alpha)*self.q+circuit.par.alpha*target
        return new,float(np.max(abs(new-self.q))),gate

def gain_folder(gain):return ROOT/('gain_'+str(gain).replace('.','p'))

def init():
    r.init();r.Circuit=CuedCircuit;r.CachedLocalFeedback=StrengthFeedback

def prepare():
    ROOT.mkdir(exist_ok=True)
    if (ROOT/'protocol.json').exists():return
    meta=json.loads((BASE/'stimuli.json').read_text());jobs=[]
    for gain in [.5,.65,.8]:
        dest=gain_folder(gain);dest.mkdir(exist_ok=True)
        for name in ['stimuli.json','stimuli.npz']:shutil.copyfile(BASE/name,dest/name)
        for m in meta:
            if m['kind']=='pair' and m['separation']==0:
                for name in ['combined_category_A','combined_category_B']:
                    if gain!=.5 or (m['case']==0 and name=='combined_category_A'):jobs.append([gain,m['case'],name])
    r.r.dump(ROOT/'jobs.json',jobs)
    r.r.dump(ROOT/'protocol.json',dict(network_seed=71001,maximum_feedback_weights=[.5,.65,.8],new_experimental_trials=12,reused_baseline_trials=6,additional_verification_runs=1,reused_no_feedback_controls=6,steps=600,early_stop=False,pairs='Same3/8,4/9,1/7 pairs at full overlap, both category cues; no new selection or screening.',control='Same spatial cue2 at144 plus category cue2. Only local-code maximum feedback weight changes; actual final100-update spotlight/gain equality will be verified. Sensory mismatch, within-field normalization, sigma24, alpha0.1, references, weights and uniform pooling unchanged.',scores='Requested, losing and shared pixel intensities; changes relative to0.5 and no-feedback controls; local and canvas target-image MSE; unforced local readout; last100 max update/alpha<5e-6. Category clamp is not recognition evidence. Cue-reversal contrast and exact positive/negative contributions across fields; coverage-weighted opposing-field fraction. Also mean cross-field prediction variance on fixed union foreground, to distinguish cue-sign agreement from consistency of absolute predictions.',scope='Fixed exploratory three-pair one-model comparison; no confidence intervals, new training, model-default changes or selective-inhibition test. Reuse all six matched0.5 endpoints; reproduce one of them bit-for-bit before accepting the new runner.',source_sha256={name:hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest() for name in ['run_spatial_overlap_feedback_strength.py','run_spatial_overlap_pilot.py','run_spatial_overlap_fixed_spotlight.py','cached_spatial_content_feedback.py']}))

def worker(job):
    gain,j,name=job;StrengthFeedback.maximum=gain;r.ROOT=gain_folder(gain)
    row=r.worker((j,name))
    if gain==.5:
        with np.load(r.ROOT/f'case{j:02d}_{name}/arrays.npz') as a,np.load(BASE/f'case{j:02d}_{name}/arrays.npz') as b:
            assert set(a.files)==set(b.files)
            for key in a.files:np.testing.assert_array_equal(a[key],b[key],err_msg=key)
        r.r.dump(ROOT/'parity.json',dict(all_saved_arrays_bit_identical=True,case=j,method=name))
    return dict(maximum_feedback_weight=gain,**row)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=13);args=ap.parse_args();prepare();start=time.time();rows=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,initializer=init) as pool:
        futures=[pool.submit(worker,j) for j in json.loads((ROOT/'jobs.json').read_text())]
        for f in concurrent.futures.as_completed(futures):
            rows.append(f.result());r.r.dump(ROOT/'status.json',dict(completed=len(rows),total=13,seconds=time.time()-start))
    r.r.dump(ROOT/'results.json',dict(new_runs=rows,baseline_source='parent fixed_spatial_cue; all six0.5 trials reused',parity=json.loads((ROOT/'parity.json').read_text())))
    print('FEEDBACK STRENGTH COMPLETE',flush=True)
if __name__=='__main__':main()
