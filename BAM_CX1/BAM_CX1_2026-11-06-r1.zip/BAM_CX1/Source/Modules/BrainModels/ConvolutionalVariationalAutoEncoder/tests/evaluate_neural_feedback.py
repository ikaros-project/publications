"""Matched first-seed neural-readout feedback and training-unit specialization."""
import hashlib,json
from argparse import Namespace
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import evaluate_category_feedback as f
from evaluate_full_population_competition import compete
from evaluate_neural_readouts import CAMPAIGN,softmax
from evaluate_regularized_capacity import evaluate

e=f.e
OUT=CAMPAIGN/'neural_readout_feedback_seed1'
SEED=71001
MODES=['no_feedback','category8','nearest_unit_bank','winning_unit']

def status(stage):
    (OUT/'status.json').write_text(json.dumps(dict(stage=stage,seed=SEED))+'\n')
    print(stage,flush=True)

def atlas(c,info,pixels):
    canvas=Image.new('RGB',(1040,720),'white');draw=ImageDraw.Draw(canvas);font=ImageFont.load_default(size=15)
    draw.text((12,10),f'Category {c}: units 1-20; three strongest conditional responses + representative (R)',fill='black',font=font)
    for u,r in enumerate(info):
        x=10+(u%4)*258;y=48+(u//4)*132
        draw.text((x,y),f'Unit {u+1}: {r["winner_count"]} winners',fill='black',font=font)
        for j,idx in enumerate(r['top_indices'][:3]+[r['representative']]):
            tile=Image.fromarray(np.uint8(pixels[idx]*255)).resize((56,56),Image.Resampling.NEAREST)
            canvas.paste(tile,(x+j*62,y+25))
            draw.text((x+j*62,y+85),'R' if j==3 else str(j+1),fill='black',font=font)
    canvas.save(OUT/f'unit_specialization_category{c}.png')

def main():
    OUT.mkdir(exist_ok=True);status('loading frozen model and retained readout')
    train,test,labels,test_labels=e.prepare_data(Namespace(train_count=60000,test_count=10000))
    tp=np.stack([e.full.center_and_pad(x) for x in train]).astype(np.float32)/255
    vp=np.stack([e.full.center_and_pad(x) for x in test]).astype(np.float32)/255
    folder=CAMPAIGN/f'hierarchy_s{SEED}'
    readout=CAMPAIGN/'neural_readout_regularized_capacity/full_refit'/f'grouped_softmax_s{SEED}.npz'
    files=[folder/'model.state',folder/'codebook_final.npz',readout]
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    codes,_,_=e.read_codes(folder/'train_codes.csv',train,labels,128)
    test_codes,_,_=e.read_codes(folder/'test_codes.csv',test,test_labels,128)
    with np.load(readout) as saved:w=saved['weights'];b=saved['bias'];saved_pred=saved['predictions']
    assert w.shape==(128,200)
    _,pred=evaluate(test_codes.astype(np.float32),test_labels,w,b)
    np.testing.assert_array_equal(pred,saved_pred)
    state=json.loads((folder/'model.state').read_text())['items']
    def weight(name):
        a=state['CVAE_TwoLayer.Upper.'+name];return np.array(a['value'],np.float32).reshape(a['shape'])
    enc=weight('DIRECT_MEAN_WEIGHTS');eb=weight('DIRECT_MEAN_BIAS');dec=weight('DIRECT_DECODER_WEIGHTS');db=weight('DIRECT_DECODER_BIAS')
    del state
    with np.load(folder/'codebook_final.npz') as a:book=f.prior.Codebook(a['prototypes'])
    def decode(z):return f.logsoftmax((z@dec+db).reshape(64,676))
    def image(q):return f.prior.reconstruct(book.prototypes[q.argmax(0)])
    def read(z):
        scores=(z@w+b).reshape(10,20)
        probs=softmax(scores.reshape(1,200)).reshape(10,20).sum(1)
        return probs,scores
    native_path=folder/'categorical_parity.csv'
    names=native_path.open().readline().strip().split(',')
    native=np.loadtxt(native_path,delimiter=',',skiprows=1,ndmin=2)
    actual=native[:,[i for i,name in enumerate(names) if name.startswith('topdown:')]]
    predicted=np.stack([np.exp(decode(z.astype(np.float32))).ravel() for z in test_codes[:8]])
    np.testing.assert_allclose(actual,predicted,atol=2e-5,rtol=2e-5)
    previous=json.loads((CAMPAIGN/'category_competition_full_population/results.json').read_text())
    pairs=previous['protocol']['pairs'];mixtures=previous['protocol']['mixtures']
    protocol=dict(seed=SEED,train_count=60000,test_count=10000,pairs=pairs,mixtures=mixtures,modes=MODES,gain=.25,
        readout='Retained 200-unit readout, 20 units/category, AdamW decay .1, smoothing .05, 260 passes; no dropout/noise. Frozen raw128 means.',
        selection='Sum global200 softmax within categories; rescale category evidence by its maximum for the unchanged lateral competition. Winning unit is maximum affine score within winning category.',
        competition='Same 200-step damped rectified competition as previous diagnostic, with fixed evidence; winner then fixed for a single feedback update. Not a coupled recurrent perception loop.',
        category8='Reuse original eight training references per category; choose nearest in raw128 code distance.',
        unit_bank='One training representative per unit: among true-category examples for which that unit wins within its category, choose the example nearest their mean raw128 code. If none, use the largest conditional-response example from the true category. No test inputs or labels used to construct references.',
        nearest_unit_bank='Select nearest of the same 20 unit representatives within winning category; controls reference-bank choice versus unit-based addressing.',
        winning_unit='Use representative of strongest unit within winning category. This is an explicit exemplar association, not a learned inverse of the classifier or proof of a generative unit template.',
        feedback='p_fb=softmax_channels(log(p_input)+.25*clip(log(q_reference)-log(q_original),-2,2)); re-encode, decode, hard prototype selection and overlap-average. No gates, no direct replacement.',
        scoring='Independent raw-pixel 5NN against all60000 centered training images. Winner agreement separate from dominant-category truth and MSE. Prior 5NN selector results retained as descriptive matched-scene comparator.',
        limitation='Single-seed diagnostic on reused twenty 3/8 pairs, eleven mixtures, 220 cases. Correlated cases and reused stimuli; no generalization claim or tuning gain on these results. Wrong-category reinforcement is expected behavior and reported separately.')
    (OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    status('measuring training-unit usage and selecting representatives')
    logits=(codes.astype(np.float32)@w+b).reshape(-1,10,20)
    references={};usage=[]
    for c in range(10):
        ids=np.flatnonzero(labels==c);local=logits[ids,c];responsibility=softmax(local);wins=local.argmax(1)
        items=[];counts=np.bincount(wins,minlength=20);shares=counts/len(ids);positive=shares[shares>0]
        for u in range(20):
            assigned=ids[wins==u];top=ids[np.argsort(-responsibility[:,u],kind='stable')[:5]]
            if len(assigned):
                v=codes[assigned];rid=int(assigned[np.argmin(((v-v.mean(0))**2).sum(1))])
            else:rid=int(top[0])
            items.append(dict(unit=u,global_unit=c*20+u,winner_count=int(counts[u]),winner_share=float(shares[u]),representative=rid,empty_fallback=not len(assigned),top_indices=top.tolist()))
        references[c]=[r['representative'] for r in items]
        usage.append(dict(category=c,effective_units=float(np.exp(-(positive*np.log(positive)).sum())),active_units=int((counts>0).sum()),units=items))
        if c in (3,8):atlas(c,items,tp)
    del logits
    (OUT/'unit_specialization.json').write_text(json.dumps(usage,indent=2)+'\n')
    refs8={int(k):v for k,v in json.loads((CAMPAIGN/'category_feedback_diagnostic/reference_indices.json').read_text())[str(SEED)].items()}
    cache={}
    def refq(idx):
        if idx not in cache:cache[idx]=decode(codes[idx].astype(np.float32))
        return cache[idx]
    rows=[];outputs=[];examples={};encoder_error=0;argmax_mismatches=0
    for pair_id,(i,j) in enumerate(pairs):
        A,B=vp[i],vp[j]
        for mix in mixtures:
            x=mix*A+(1-mix)*B;p,_=book.process(x,False,.01,.08);p=p.reshape(64,676)
            z=p.ravel()@enc+eb;q=decode(z);base=image(q)
            probs,scores=read(z);evidence=probs/probs.max();winner,activity,trace=compete(evidence)
            argmax_mismatches+=int(winner!=probs.argmax());assert winner==int(probs.argmax())
            if mix in (0,1):
                idx=i if mix==1 else j;encoder_error=max(encoder_error,float(abs(z-test_codes[idx]).max()));assert winner==int(saved_pred[idx])
            u=int(scores[winner].argmax())
            chosen={'category8':refs8[winner][int(np.argmin(((codes[refs8[winner]]-z)**2).sum(1)))],
                    'nearest_unit_bank':references[winner][int(np.argmin(((codes[references[winner]]-z)**2).sum(1)))],
                    'winning_unit':references[winner][u]}
            for mode in MODES:
                if mode=='no_feedback':zf=z;y=base;rid=None
                else:
                    rid=int(chosen[mode]);pf=np.exp(f.logsoftmax(np.log(np.maximum(p,1e-30))+.25*np.clip(refq(rid)-q,-2,2)))
                    np.testing.assert_allclose(pf.sum(0),1,atol=2e-6)
                    zf=pf.ravel()@enc+eb;y=image(decode(zf))
                post,_=read(zf)
                row=dict(seed=SEED,pair_id=pair_id,mix=mix,mode=mode,winner=winner,winning_unit=u,category_probabilities=probs.tolist(),post_category_probabilities=post.tolist(),post_winner=int(post.argmax()),reference_index=rid,
                    dominant_truth=3 if mix>.5 else 8 if mix<.5 else None,input_mse=float(np.mean((y-x)**2)),
                    winner_component_mse=float(np.mean((y-(A if winner==3 else B))**2)) if winner in (3,8) else None,
                    loser_fraction=float((activity.sum()-activity.max())/max(activity.sum(),1e-12)),settling_last_step=float(abs(trace[-1]-trace[-2]).max()))
                rows.append(row);outputs.append(y.ravel())
                if pair_id==0:examples[(mix,mode)]=y
            if pair_id==0:examples[(mix,'input')]=x;examples[(mix,'winner')]=winner
        if (pair_id+1)%5==0:status(f'feedback evaluated for {pair_id+1}/20 pairs')
    assert encoder_error<1e-4
    status('scoring reconstructions with independent pixel 5NN')
    preds=e.five_nearest_predictions(tp.reshape(60000,-1),labels,np.asarray(outputs))
    for row,prediction in zip(rows,preds):row['pixel_knn_prediction']=int(prediction)
    # Same sensory reconstruction and pixel scorer as the earlier matched-scene diagnostic.
    oldbase={(r['pair_id'],r['mix']):r for r in previous['per_case'] if r['mode']=='argmax'}
    for r in rows:
        if r['mode']=='no_feedback':assert r['pixel_knn_prediction']==oldbase[(r['pair_id'],r['mix'])]['pixel_knn_prediction']
    aggregate=[]
    for mode in MODES:
        subset=[r for r in rows if r['mode']==mode];clean=[r for r in subset if r['mix'] in (0,1)];dom=[r for r in subset if r['mix']!=.5];eq=[r for r in subset if r['mix']==.5];eligible=[r for r in eq if r['winner'] in (3,8)]
        def agreement(data):return float(np.mean([r['pixel_knn_prediction']==r['winner'] for r in data])) if data else None
        aggregate.append(dict(mode=mode,n=len(subset),winner_agreement=agreement(subset),clean_selection=float(np.mean([r['winner']==r['dominant_truth'] for r in clean])),dominant_selection=float(np.mean([r['winner']==r['dominant_truth'] for r in dom])),
            equal_component_selection=float(np.mean([r['winner'] in (3,8) for r in eq])),equal_winner_agreement=agreement(eq),
            clean_reconstruction_accuracy=float(np.mean([r['pixel_knn_prediction']==r['dominant_truth'] for r in clean])),dominant_reconstruction_accuracy=float(np.mean([r['pixel_knn_prediction']==r['dominant_truth'] for r in dom])),
            equal_winner_component_mse=float(np.mean([r['winner_component_mse'] for r in eligible])) if eligible else None,
            wrong_dominant_winner_agreement=agreement([r for r in dom if r['winner']!=r['dominant_truth']]),
            post_winner_retained=float(np.mean([r['post_winner']==r['winner'] for r in subset]))))
    assert all(hashlib.sha256(p.read_bytes()).hexdigest()==hashes[p.name] for p in files)
    result=dict(protocol=protocol,aggregate=aggregate,per_case=rows,checks=dict(encoder_max_error=encoder_error,native_decoder_max_error=float(abs(actual-predicted).max()),checkpoint_sha256=hashes,argmax_mismatches=argmax_mismatches,baseline_pixel_predictions_match_prior=True),prior_5nn_aggregate=previous['aggregate'])
    (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    np.savez(OUT/'reconstruction_images.npz',images=np.asarray(outputs).reshape(-1,32,32),pixel_predictions=preds)
    cols=[0,.2,.4,.5,.6,.8,1]
    f.gallery(OUT/'feedback_comparison.png','Fixed pair 0, seed 71001; same input and winner for each column',[[examples[(m,k)] for m in cols] for k in ['input']+MODES],['input','no feedback','category bank (8)','nearest unit ref','winning unit ref'],[f'3:{m:.1f} win:{examples[(m,"winner")]}' for m in cols])
    lines=['# Neural-readout feedback: matched first-seed diagnostic','', 'Retained 200-unit readout; frozen sensory seed 71001; same 20 pairs of digits 3 and 8 and eleven mixtures as the earlier experiment. Gain .25 fixed. No training or gates.','', '| Reference rule | Reconstruction agrees with winner | Equal-mixture agreement | Dominant-category reconstruction | Clean reconstruction |','| --- | ---: | ---: | ---: | ---: |']
    for r in aggregate:lines.append(f'| {r["mode"]} | {r["winner_agreement"]:.2%} | {r["equal_winner_agreement"]:.2%} | {r["dominant_reconstruction_accuracy"]:.2%} | {r["clean_reconstruction_accuracy"]:.2%} |')
    r=aggregate[0];lines+=['',f'Neural category selection: clean {r["clean_selection"]:.2%}; dominant component {r["dominant_selection"]:.2%}; equal-mixture component selection {r["equal_component_selection"]:.2%}.',f'Mean effective within-category units on training examples: {np.mean([u["effective_units"] for u in usage]):.2f}/20. Empty units: {sum(20-u["active_units"] for u in usage)} of 200.','', 'The category8 vs nearest_unit_bank comparison changes the reference bank; nearest_unit_bank vs winning_unit uses exactly the same bank and changes addressing. Representatives are training exemplars associated with units, not learned generative weights. Galleries show the three highest conditional responses and a representative for every unit in categories 3 and 8; they are descriptive and do not establish semantic specialization.', '', 'Winner agreement is separate from ground-truth accuracy. Reinforcing a wrong winner is expected behavior, not automatically a failure. Single-seed descriptive results on reused, correlated scenes; no uncertainty across seeds estimated. Competition uses fixed evidence before one feedback step, not a recurrent loop. The independent pixel classifier is a diagnostic proxy, not human recognition. No general claim about feedback or spatial attention follows.', '', 'Offline encoder and native decoder parity checks passed; clean readout predictions and baseline reconstruction labels match saved records; all sensory and readout hashes remained unchanged.']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');status('complete');print('\n'.join(lines),flush=True)

if __name__=='__main__':main()
