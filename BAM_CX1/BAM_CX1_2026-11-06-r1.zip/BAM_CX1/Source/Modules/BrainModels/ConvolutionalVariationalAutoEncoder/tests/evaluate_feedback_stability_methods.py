"""Prespecified single-seed comparison of unified sensory/top-down update rules."""
import json, hashlib, time
from argparse import Namespace
import numpy as np
import evaluate_local_patch_decoder as local
n=local.n; f=n.f; e=n.e
OUT=n.CAMPAIGN/'feedback_stability_methods_seed1'
METHODS=['cumulative','relaxation','leaky','adaptive']
STEPS=[0,8,32,64,128,200,300,400,500]
def soft(v):
 v=v-v.max(1,keepdims=True); v=np.exp(v); return v/v.sum(1,keepdims=True)
def dump(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
def status(s):
 dump('status.json',{'stage':s}); print(s,flush=True)
def main():
 OUT.mkdir(exist_ok=True)
 protocol=dict(seed=71001,methods=METHODS,iterations=500,snapshots=STEPS,noise_cases=80,mixture_cases=60,alpha=.2,top_down_fraction={'noise':1.,'mixtures':.5},gain=.5,leak=.1,adaptive_error_scale=.1,
 common='q=upper_decode(encode(p)); Q=sum_c competition_weight_c * q_reference_c; delta=sum_c weight_c * clip(log(q_reference_c)-log(q),-2,2). p_next=(1-alpha_t)*p+alpha_t*((1-lambda)*b+lambda*r). b is fixed sensory code; lambda=1 disables b for no input. Category clamped for noise, autonomous unchanged competition for mixtures.',
 cumulative='r=softmax(log(p)+0.5*delta). New unified cumulative comparator; historical sensory baseline is separately evaluated with r=softmax(log(b)+0.5*delta), p_next=.8*p+.2*r.',
 relaxation='r=Q. Convex relaxation to the current category-weighted top-down prediction.',
 leaky='u_next=.9*u+.1*delta, u_0=0; r=softmax(log(Q)+0.5*u_next). Since delta is clipped to [-2,2], u stays bounded there. Correction is around the top-down prediction, not an accumulating perturbation of p.',
 adaptive='r=softmax(log(p)+0.5*delta); alpha_t=.2*min(1,mean(abs(delta))/.1), calculated separately per case. No positive floor. Low update size alone is not evidence of a solved prediction error.',
 sampling='All eight references per category, one shared logistic-normal internal starting state (RNG20260921) for 80 noise cases. Twenty previously used held-out 3/8 pairs at mixture fractions .3,.5,.7 for 60 mixtures. References fixed: all in turn for noise, nearest of eight per category in original raw latent space for mixtures.',
 evaluation='Frozen model, independent pixel5NN on 60000 training images; snapshots 200 and500 scored, plus noise initialization and direct references. Category agreement not held-out categorization accuracy. Final10 steps: max p and category-activity changes <1e-5; leaky additionally max u change <1e-5. Pixel drift from400 to500, prediction discrepancy and update size reported separately. Single seed exploratory, no parameter search.',
 scope='No training, no backpropagation, no sensory noise or occlusion. Internal initialization noise only. New variants share mixing architecture, but differ from historical error-correction rule in more than one algebraic term; no isolated causal attribution.')
 dump('protocol.json',protocol);status('loading frozen model')
 train,test,labels,tl=e.prepare_data(Namespace(train_count=60000,test_count=10000))
 tp=np.stack([e.full.center_and_pad(v) for v in train]).astype(np.float32)/255
 vp=np.stack([e.full.center_and_pad(v) for v in test]).astype(np.float32)/255
 folder=n.CAMPAIGN/'hierarchy_s71001'; rd=n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit/grouped_softmax_s71001.npz'; dp=n.CAMPAIGN/'local_linear_patch_decoder_seed1/local_decoder.npz'
 paths=[folder/'model.state',folder/'codebook_final.npz',rd,dp];hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 state=json.loads(paths[0].read_text())['items']
 def w(key):
  a=state['CVAE_TwoLayer.Upper.'+key];return np.array(a['value'],np.float32).reshape(a['shape'])
 enc=w('DIRECT_MEAN_WEIGHTS');eb=w('DIRECT_MEAN_BIAS');dec=w('DIRECT_DECODER_WEIGHTS');db=w('DIRECT_DECODER_BIAS');del state
 with np.load(rd) as z:rw=z['weights'];rb=z['bias']
 with np.load(dp) as z:d=z['decoder'].astype(np.float32)
 with np.load(paths[1]) as z:book=f.prior.Codebook(z['prototypes'])
 def encode(p):return p.reshape(len(p),-1)@enc+eb
 def decode(z):
  v=(z@dec+db).reshape(-1,64,676);v-=v.max(1,keepdims=True);return v-np.log(np.exp(v).sum(1,keepdims=True))
 def probs(z):return n.softmax(z@rw+rb).reshape(-1,10,20).sum(2)
 def render(q):return np.clip(local.overlap(np.exp(q).transpose(0,2,1)@d),0,1)
 codes,_,_=e.read_codes(folder/'train_codes.csv',train,labels,128)
 refs=json.loads((n.CAMPAIGN/'category_feedback_diagnostic/reference_indices.json').read_text())['71001'];ids=np.array([refs[str(c)] for c in range(10)])
 rc=codes[ids].astype(np.float32);rq=decode(rc.reshape(-1,128)).reshape(10,8,64,676);rp=np.exp(rq)
 cats=np.repeat(np.arange(10),8);direct=render(rq.reshape(80,64,676))
 starts=soft(np.random.default_rng(20260921).normal(size=(1,64,676)).astype(np.float32));noise=np.repeat(starts,80,axis=0)
 old=json.loads((n.OUT/'results.json').read_text());cases=[dict(pair=k,i=i,j=j,mix=m) for k,(i,j) in enumerate(old['protocol']['pairs']) for m in [.3,.5,.7]]
 x=np.stack([c['mix']*vp[c['i']]+(1-c['mix'])*vp[c['j']] for c in cases]);b=np.stack([book.process(v,False,.01,.08)[0].reshape(64,676) for v in x]);z0=encode(b)
 chosen=((z0[:,None,None,:]-rc[None])**2).sum(3).argmin(2)
 dump('cases.json',dict(noise_reference_ids=ids.tolist(),mixtures=cases))
 summary=[]; bundles={}; scoring=[]; score_keys=[]
 for mode in ['noise','mixtures']:
  p0=noise if mode=='noise' else b;N=len(p0);lam=1. if mode=='noise' else .5
  z=encode(p0);pr0=probs(z);a0=np.eye(10,dtype=np.float32)[cats] if mode=='noise' else pr0/pr0.max(1,keepdims=True)
  methods=METHODS if mode=='noise' else METHODS+['historical']
  for method in methods:
   status(f'{mode}/{method}: starting');p=p0.copy();q=decode(z);pr=pr0.copy();a=a0.copy();u=np.zeros_like(p);changes=[];acts=[a.copy()];residuals=[];alphas=[];saved=[render(q)]
   for step in range(1,501):
    an=a if mode=='noise' else .8*a+.2*np.maximum(pr/pr.max(1,keepdims=True)-1.5*(a.sum(1,keepdims=True)-a),0)
    weights=an/an.sum(1,keepdims=True)
    if mode=='noise':
     Q=rp.reshape(80,64,676);delta=np.clip(rq.reshape(80,64,676)-q,-2,2)
    else:
     Q=np.zeros_like(p);delta=np.zeros_like(p)
     for c in range(10):
      wc=weights[:,c,None,None];Q+=wc*rp[c,chosen[:,c]];delta+=wc*np.clip(rq[c,chosen[:,c]]-q,-2,2)
    err=np.abs(delta).mean((1,2));alpha=np.full(N,.2,np.float32);uc=np.zeros(N,np.float32)
    if method=='relaxation':r=Q
    elif method=='leaky':
     un=.9*u+.1*delta;uc=abs(un-u).max((1,2));u=un;r=soft(np.log(np.maximum(Q,1e-30))+.5*u)
    else:
     anchor=b if method=='historical' else p
     r=soft(np.log(np.maximum(anchor,1e-30))+.5*delta)
     if method=='adaptive':alpha=.2*np.minimum(1,err/.1)
    target=r if method=='historical' or mode=='noise' else (1-lam)*b+lam*r
    pn=(1-alpha[:,None,None])*p+alpha[:,None,None]*target
    changes.append(np.stack([abs(pn-p).max((1,2)),abs(an-a).max(1),uc],axis=1));residuals.append(err);alphas.append(alpha)
    p=pn;a=an;zz=encode(p);q=decode(zz);pr=probs(zz);acts.append(a.copy())
    if step in STEPS:saved.append(render(q))
    if step%100==0:status(f'{mode}/{method}: {step}/500')
   np.testing.assert_allclose(p.sum(1),1,atol=4e-6);assert np.isfinite(q).all()
   ch=np.array(changes);act=np.array(acts);saved=np.array(saved);settled=ch[-10:].max((0,2))<1e-5
   row=dict(mode=mode,method=method,cases=N,settled=int(settled.sum()),settled_at200=int((ch[190:200].max((0,2))<1e-5).sum()),median_last10_change=float(np.median(ch[-10:].max((0,2)))),max_last10_change=float(ch[-10:].max()),pixel_mse_400_to500=float(((saved[-1]-saved[-2])**2).mean()),mean_final_clipped_error=float(np.mean(residuals[-1])),mean_final_alpha=float(np.mean(alphas[-1])),late_winner_switches=int((np.diff(act[-100:].argmax(2),axis=0)!=0).sum()),winner_changes=int((act[-1].argmax(1)!=a0.argmax(1)).sum()),final_readout_agreement=float((pr.argmax(1)==(cats if mode=='noise' else a.argmax(1))).mean()))
   if mode=='noise':row.update(direct_mse_200=float(((saved[STEPS.index(200)]-direct)**2).mean()),direct_mse_500=float(((saved[-1]-direct)**2).mean()))
   else:row.update(input_mse=float(((saved[-1]-x)**2).mean()))
   summary.append(row);key=mode+'_'+method;bundles[key]=dict(snapshots=saved,activities=act,changes=ch,residuals=np.array(residuals),alphas=np.array(alphas),final_readout=pr)
   np.savez_compressed(OUT/(key+'.npz'),**bundles[key]);dump('partial_results.json',summary)
   for t in [200,500]:scoring.append(saved[STEPS.index(t)]);score_keys.append((len(summary)-1,t))
 status('scoring outputs with independent pixel5NN')
 preds=e.five_nearest_predictions(tp.reshape(60000,-1),labels,np.concatenate(scoring).reshape(-1,1024));pos=0
 for ri,t in score_keys:
  row=summary[ri];N=row['cases'];pred=preds[pos:pos+N];pos+=N
  act=bundles[row['mode']+'_'+row['method']]['activities'];target=cats if row['mode']=='noise' else act[t].argmax(1)
  row['category_agreement_'+str(t)]=float((pred==target).mean())
  if row['mode']=='mixtures':
   mask=np.array([c['mix']!=.5 for c in cases]);truth=np.array([3 if c['mix']>.5 else 8 for c in cases]);row['dominant_recognition_'+str(t)]=float((pred[mask]==truth[mask]).mean());row['equal_agreement_'+str(t)]=float((pred[~mask]==target[~mask]).mean())
 assert all(hashlib.sha256(p.read_bytes()).hexdigest()==hashes[p.name] for p in paths)
 # Verify historical baseline on the same subset; no model changes.
 oldarr=n.CAMPAIGN/'feedback_gain_sweep_seed1/arrays.npz'
 with np.load(oldarr) as oldz:
  gi=int(np.flatnonzero(np.isclose(oldz['gains'],.5))[0]); indices=np.array([c['pair']*11+int(round(c['mix']*10)) for c in cases]);expected=oldz['outputs'][gi,indices]
  parity=float(abs(bundles['mixtures_historical']['snapshots'][STEPS.index(200)]-expected).max());np.testing.assert_allclose(bundles['mixtures_historical']['snapshots'][STEPS.index(200)],expected,atol=2e-5)
 with np.load(n.CAMPAIGN/'category_generation_seed1/arrays.npz') as oldz:
  expected=oldz['snapshots'][-1,::3];noiseparity=float(abs(bundles['noise_cumulative']['snapshots'][STEPS.index(200)]-expected).max());np.testing.assert_allclose(bundles['noise_cumulative']['snapshots'][STEPS.index(200)],expected,atol=3e-5)
 dump('results.json',dict(protocol=protocol,summary=summary,checks=dict(weights_unchanged=True,hashes=hashes,historical_parity=parity,noise_parity=noiseparity)))
 for mode,index in [('noise',24),('mixtures',10)]:
  methods=METHODS if mode=='noise' else METHODS+['historical']
  panels=[[bundles[mode+'_'+m]['snapshots'][STEPS.index(t),index] for t in [0,32,200,500]] for m in methods]
  cols=['initial','32','200','500']
  if mode=='mixtures':panels=[[x[index]]+row for row in panels];cols=['input']+cols
  f.gallery(OUT/(mode+'_comparison.png'),f'{mode}: prespecified example; all methods, same initial state',panels,methods,cols)
 lines=['# Feedback stability methods — first-seed comparison','','See protocol.json for exact equations and prespecified parameters. All layers frozen. Category clamped only in the no-input condition.','', '| Condition | Method | Agreement 200 | Agreement 500 | Settled 500 | Pixel drift 400–500 |','|---|---|---:|---:|---:|---:|']
 for r in summary:lines.append(f'| {r["mode"]} | {r["method"]} | {r["category_agreement_200"]:.2%} | {r["category_agreement_500"]:.2%} | {r["settled"]}/{r["cases"]} | {r["pixel_mse_400_to500"]:.8f} |')
 lines+=['','Agreement is independent pixel5NN agreement with the clamped category or current competitive winner, not general recognition accuracy. Settling checks p, category activity and (for leaky) correction state. Small updates under adaptive damping can reflect reduced speed; residual errors are retained in results.json. All parameters fixed before outcomes; single seed and reused references/stimuli. Historical sensory baseline and prior no-input cumulative results numerically reproduced.']
 (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');status('complete');print('\n'.join(lines),flush=True)
if __name__=='__main__':main()
