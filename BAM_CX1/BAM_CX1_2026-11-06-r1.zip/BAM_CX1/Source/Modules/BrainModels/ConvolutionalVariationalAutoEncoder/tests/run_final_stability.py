"""Execute the frozen final-model stability protocol, preserving original runs."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import json,time,copy,traceback,concurrent.futures
from dataclasses import replace
import numpy as np
import qmnist_confirmation_common as q
import run_qmnist_confirmation as old
import run_qmnist_spatial_extension as ext
from freeze_final_stability_protocol import OUT
from neural_spatial_rate_model import Circuit,windows
from run_spatial_population_feedback import PopulationFeedback
from run_spatial_overlap_pilot import PAR
from spatial_content_feedback import render_scene
FIELDS=['s','ep','em','m','t','a','c']
def read(p):return json.loads(p.read_text())
def protocol():
 assert q.sha(OUT/'protocol.json')==(OUT/'protocol.sha256').read_text().strip()
 return read(OUT/'protocol.json')
def requests():
 jobs=read(q.OUT/'spatial_jobs.json');meta=read(q.OUT/'spatial_stimuli.json');result=[]
 for cat in [0,2,4,6,8]:
  j=next(j for j in jobs if j['task']=='category_search' and j['feedback'] and meta[j['case']]['target_category']==cat)
  m=meta[j['case']];result.append(dict(name=f'search{cat}',source='original',job=j['job'],case=j['case'],category=cat,position=m['target_position'],spatial=None))
 jobs=read(ext.OUT/'jobs.json');meta=read(ext.OUT/'stimuli.json')
 for cat,sep in zip([1,3,5,7,9],[0,8,0,8,0]):
  j=next(j for j in jobs if meta[j['case']]['group']=='overlap' and meta[j['case']]['categories'][0]==cat and meta[j['case']]['separation']==sep and j['target']==0 and j['feedback'])
  result.append(dict(name=f'overlap{cat}',source='extension',job=j['job'],case=j['case'],category=cat,position=j['spatial_cue'],spatial=j['spatial_cue']))
 return result
def configs(r):
 base=dict(maximum=.65,inhibition=1.5,alpha=.1,category_cue=2.,spatial_cue=2.)
 out=[dict(name='default',**base)]
 for key,vals in [('maximum',[.5,.8]),('inhibition',[1.2,1.8]),('alpha',[.05,.2]),('category_cue',[.5,1.])]+([] if r['spatial'] is None else [('spatial_cue',[.5,1.])]):
  for v in vals:out.append(dict(name=f'{key}_{v}',**{**base,key:v}))
 for f,h in protocol()['step3']['corners']:out.append(dict(name=f'corner_{f}_{h}',**{**base,'maximum':f,'inhibition':h}))
 return out
def folder(j):return OUT/'spatial'/f"{j['seed']}_{j['request']['name']}_{j['name']}"
def perturb(c,local,amplitude,rng):
 noise=rng.normal(size=local.q.shape).astype(np.float32);noise-=noise.max(1,keepdims=True);np.exp(noise,out=noise);noise/=noise.sum(1,keepdims=True)
 local.q=(1-amplitude)*local.q+amplitude*noise
 for key in ['a','c']:
  a=getattr(c,key);r=rng.random(a.shape).astype(np.float32);r/=r.sum(1,keepdims=True);mass=a.sum(1,keepdims=True);setattr(c,key,(1-amplitude)*a+amplitude*r*np.where(mass>0,mass,1))
def step(c,local,front,u,v):
 prob,y=front.evidence(local.q);new,dq,_=local.propose(c);_,pred=front.infer_pixels(windows(c.s,31)[0]);delta=c.update(prob[None],pred[None],u=u,v=v);local.q=new
 return max(float(delta[0]),dq)/c.par.alpha
def residual(c,local,front,u,v):
 cc=copy.deepcopy(c);cc.par=replace(cc.par,alpha=1.);ll=copy.copy(local);ll.q=local.q.copy();return step(cc,ll,front,u,v)
def state(c,local):return {**{k:getattr(c,k) for k in FIELDS},'q':local.q,'chosen':local.chosen}
def continuation_diagnosis(a,changes):
 if max(changes[-100:])<5e-6:return 'settled'
 z=a[-1200:];v=z[:,np.ptp(z,axis=0).argmax()];amp=float(np.ptp(v))
 if amp<.001:return 'unresolved'
 w=v-v.mean();ac=np.array([np.dot(w[:-lag],w[lag:])/max(np.linalg.norm(w[:-lag])*np.linalg.norm(w[lag:]),1e-30) for lag in range(10,401)]);lag=int(ac.argmax())+10
 peaks=np.flatnonzero((v[1:-1]>v[:-2])&(v[1:-1]>=v[2:]))+1;kept=[]
 for k in peaks:
  if not kept or k-kept[-1]>=lag/2:kept.append(int(k))
 ratio=np.ptp(v[len(v)//2:])/max(np.ptp(v[:len(v)//2]),1e-30)
 return 'sustained_oscillation' if ac.max()>=.8 and len(kept)>=3 and .5<=ratio<=2 else 'unresolved'
def worker(j):
 dest=folder(j);dest.mkdir(parents=True,exist_ok=True)
 if (dest/'result.json').exists():return read(dest/'result.json')
 try:
  protocol();r=j['request'];cfg=j['config'];_,front=old.get_model(j['seed']);source=q.OUT if r['source']=='original' else ext.OUT
  with np.load(source/('spatial_stimuli.npz' if r['source']=='original' else 'stimuli.npz')) as z:x=z['input'][r['case']]
  c=Circuit(x[None],replace(PAR,alpha=cfg['alpha'],inhibition=cfg['inhibition']),closed=True,padding=31);local=PopulationFeedback(front,c,True,True);local.maximum=cfg['maximum']
  baseline=None;baseline_state=None
  if j['stage'] in ['endpoint','release']:
   b=folder({**j,'name':'default'});baseline=read(b/'result.json')
   with np.load(b/'state.npz') as z:
    for k in FIELDS:setattr(c,k,z[k])
    local.q=z['q'];np.testing.assert_array_equal(local.chosen,z['chosen']);baseline_state={k:z[k] for k in FIELDS+['q']}
  if j.get('amplitude',0):perturb(c,local,j['amplitude'],np.random.default_rng(np.random.SeedSequence([2026110512,j['id']])))
  u=np.zeros_like(c.a);v=np.zeros_like(c.c)
  if r['spatial'] is not None:u[0,r['spatial']+31]=cfg['spatial_cue']
  if j['stage']!='release':v[0,r['category']]=cfg['category_cue']
  changes=[];ct=[];at=[];start=time.time();parity=None
  for tick in range(j['updates']):
   changes.append(step(c,local,front,u,v));ct.append(c.c[0].copy());at.append(c.a[0].copy())
   if tick+1==600 and (j['name']=='default' or j['stage']=='diagnostic'):
    prob,y=front.evidence(local.q);oldpath=source/('spatial' if r['source']=='original' else 'trials')/f"model{j['seed']}_job{r['job']:03d}"/'arrays.npz'
    with np.load(oldpath) as z:
     now=dict(category_trace=np.array(ct),spatial_trace=np.array(at),changes=np.array(changes),reference_slots=local.chosen,final_field_predictions=y,final_probability=prob,final_render=render_scene(y,320))
     parity={k:float(np.max(abs(vv-z[k]))) for k,vv in now.items()}
    assert max(parity.values())==0,parity
    q.dump(dest/'parity.json',parity);np.savez_compressed(dest/'state600.npz',**state(c,local))
   if (tick+1)%100==0:q.dump(dest/'progress.json',dict(updates=tick+1,total=j['updates'],seconds=time.time()-start))
  prob,y=front.evidence(local.q);render=render_scene(y,320);window=round(10/c.par.alpha);settled=max(changes[-window:])<5e-6
  loc=int(c.a[0].argmax())-31 if c.a.sum()>1e-7 else None;cat=int(c.c[0].argmax()) if c.c.sum()>1e-7 else None
  bad=np.flatnonzero(np.array(changes)>=5e-6);stable_start=int(bad[-1]+2) if len(bad) else 1;stable_time=stable_start*c.par.alpha if len(changes)-stable_start+1>=window else None
  row=dict(**j,category=cat,location=loc,located=loc is not None and abs(loc-r['position'])<=16,local_category=None if loc is None else int(prob[loc+31].argmax()),settled=bool(settled),settling_time=stable_time,last_window_rate=float(max(changes[-window:])),residual=residual(c,local,front,u,v),seconds=time.time()-start,baseline_settled=None if baseline is None else baseline['settled'],baseline_category=None if baseline is None else baseline['category'],baseline_location=None if baseline is None else baseline['location'],state_mse=None if baseline_state is None else {k:float(np.mean((getattr(c,k)-baseline_state[k])**2)) for k in FIELDS},code_mse=None if baseline_state is None else float(np.mean((local.q-baseline_state['q'])**2)))
  if j['stage']=='diagnostic':row['diagnosis']=continuation_diagnosis(np.array(at),changes)
  assert np.isfinite(local.q).all() and np.isfinite(render).all();np.testing.assert_allclose(local.q.sum(1),1,atol=1e-5)
  np.savez_compressed(dest/'arrays.npz',changes=changes,category_trace=ct,spatial_trace=at,final_render=render,final_probability=prob,reference_slots=local.chosen)
  if j['name']=='default' or j['stage']=='diagnostic':np.savez_compressed(dest/'state.npz',**state(c,local))
  front.unchanged();q.dump(dest/'result.json',row);return row
 except Exception:q.dump(dest/'error.json',dict(error=traceback.format_exc()));raise

def plan():
 req=requests();jobs=[]
 def add(seed,r,name,config,stage,updates,**kw):jobs.append(dict(id=len(jobs),seed=seed,request=r,name=name,config=config,stage=stage,updates=updates,**kw))
 for seed in protocol()['models']:
  for r in req:
   for cfg in configs(r):add(seed,r,cfg['name'],cfg,'parameter',round(60/cfg['alpha']))
 assert len(jobs)==420
 for seed in protocol()['models']:
  for r in req:
   for stage in ['fresh','endpoint','release']:
    for amp in ([0.] if stage=='release' else [])+[.05,.1]:
     for draw in range(1 if amp==0 else 3):add(seed,r,f'{stage}_{amp}_{draw}',configs(r)[0],stage,600,amplitude=amp,draw=draw)
 assert len(jobs)==990
 oldjobs=read(q.OUT/'spatial_jobs.json');meta=read(q.OUT/'spatial_stimuli.json')
 for seed,jid in protocol()['step2']['cases']:
  jj=next(j for j in oldjobs if j['job']==jid);m=meta[jj['case']];r=dict(name=f'diagnostic{jid}',source='original',job=jid,case=jj['case'],category=m['target_category'],position=m['target_position'],spatial=None);add(seed,r,'continuation',configs(r)[0],'diagnostic',3000)
 q.dump(OUT/'jobs.json',jobs);q.dump(OUT/'implementation.json',dict(rng='SeedSequence([2026110512, immutable job id]); three draws per amplitude with unique job ids.',default_cue=2,source_checksums={n:q.sha(__import__('pathlib').Path(__file__).with_name(n)) for n in ['run_final_stability.py','neural_spatial_rate_model.py','run_spatial_population_feedback.py','qmnist_confirmation_common.py']},known_problem_in_sample=[j['id'] for j in jobs[:420] if [j['seed'],j['request']['job']] in protocol()['step2']['cases'] and j['request']['source']=='original']))
 return jobs

def main():
 jobs=plan();start=time.time();rows=[]
 # Original default trajectories must match exactly before perturbation runs can start.
 with concurrent.futures.ProcessPoolExecutor(max_workers=20) as pool:
  for phase in [[j for j in jobs if j['name']=='default'],[j for j in jobs if j['name']!='default']]:
   fs=[pool.submit(worker,j) for j in phase]
   for f in concurrent.futures.as_completed(fs):
    rows.append(f.result());v=dict(completed=len(rows),total=len(jobs),seconds=time.time()-start);q.dump(OUT/'spatial_status.json',v);print(v,flush=True)
 q.dump(OUT/'spatial_results.json',sorted(rows,key=lambda r:r['id']));q.dump(OUT/'spatial_status.json',dict(complete=True,completed=len(rows),total=len(jobs),seconds=time.time()-start))
if __name__=='__main__':main()
