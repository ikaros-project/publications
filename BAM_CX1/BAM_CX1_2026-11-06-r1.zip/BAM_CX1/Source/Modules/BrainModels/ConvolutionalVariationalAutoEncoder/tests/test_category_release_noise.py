"""Noise perturbation of the saved oscillatory case; frozen model and references."""
import os
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['VECLIB_MAXIMUM_THREADS']='2'
import json,hashlib
import numpy as np
import category_release_seed_worker as w
from argparse import Namespace
n=w.n;root=n.CAMPAIGN/'category_release_ten_seeds';src=root/'seed71009';out=root/'noise_perturbation';out.mkdir(exist_ok=True)
folder=n.CAMPAIGN/'hierarchy_s71009';rd=n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit/grouped_softmax_s71009.npz';dp=n.CAMPAIGN/'local_linear_patch_decoder_ten_seeds/seed71009/local_decoder.npz'
paths=[folder/'model.state',rd,dp];hashes=[hashlib.sha256(x.read_bytes()).hexdigest() for x in paths]
s=json.loads(paths[0].read_text())['items']
def weight(k):
 v=s['CVAE_TwoLayer.Upper.'+k];return np.array(v['value'],np.float32).reshape(v['shape'])
enc=weight('DIRECT_MEAN_WEIGHTS');eb=weight('DIRECT_MEAN_BIAS');dec=weight('DIRECT_DECODER_WEIGHTS');db=weight('DIRECT_DECODER_BIAS');del s
with np.load(rd) as v:rw=v['weights'];rb=v['bias']
with np.load(dp) as v:d=v['decoder'].astype(np.float32)
with np.load(src/'setup.npz') as v:p=v['release_lower_activity'][60:61].copy();ids=v['reference_ids'];chosen=v['chosen_reference_slots'][60].copy()
train,test,labels,tl=w.e.prepare_data(Namespace(train_count=60000,test_count=10000));codes,_,_=w.e.read_codes(folder/'train_codes.csv',train,labels,128)
def decode(z):
 v=(z@dec+db).reshape(-1,64,676);v-=v.max(1,keepdims=True);return v-np.log(np.exp(v).sum(1,keepdims=True))
def render(p):return np.clip(w.local.overlap(np.exp(decode(p.reshape(len(p),-1)@enc+eb)).transpose(0,2,1)@d),0,1)
refs=np.exp(decode(codes[ids].astype(np.float32).reshape(80,128))).reshape(10,8,64,676)[np.arange(10),chosen]
with np.load(src/'released.npz') as v:acts=v['activities'][:,60].copy();prs=v['probabilities'][:,60].copy();original_image=v['images'][-1,60].copy()
for a in acts[1:]:
 Q=np.zeros_like(p)
 for c in range(10):Q+=(a[c]/a.sum())*refs[c]
 p=.8*p+.2*Q
error=float(abs(render(p)[0]-original_image).max());assert error<3e-5,error
sigmas=np.array([0]+[.01]*20+[.05]*20,np.float32);N=len(sigmas);rngs=[np.random.default_rng(2026092200+i) for i in range(N)]
p=np.repeat(p,N,axis=0);a=np.repeat(acts[-1:],N,axis=0);pr=np.repeat(prs[-1:],N,axis=0)
protocol=dict(model_seed=71009,case=60,category=7,start='saved autonomous update1000, reconstructed and pixel-verified',noise='Independent Gaussian noise added to normalized category drive before rectification; damping0.2 and inhibition1.5 unchanged',sigmas=[0,.01,.05],repeats_per_nonzero_sigma=20,noisy_updates=1000,noise_free_followup=1000,random_seeds=[2026092200+i for i in range(N)],endpoint='max lower/category change <1e-5 over final10 updates; late category amplitude and winner switches',scope='One previously selected oscillating case; no training or parameter tuning')
(out/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
trace=[a.copy()];changes=[];images=[render(p)];image_times=[0]
for step in range(1,2001):
 noise=np.stack([r.normal(0,float(sg),10) for r,sg in zip(rngs,sigmas)]).astype(np.float32) if step<=1000 else 0
 an=.8*a+.2*np.maximum(pr/pr.max(1,keepdims=True)-1.5*(a.sum(1,keepdims=True)-a)+noise,0)
 ww=an/an.sum(1,keepdims=True);Q=np.zeros_like(p)
 for c in range(10):Q+=ww[:,c,None,None]*refs[c]
 pn=.8*p+.2*Q
 changes.append(np.stack([abs(pn-p).max((1,2)),abs(an-a).max(1)],1));p=pn;a=an;z=p.reshape(N,-1)@enc+eb;pr=n.softmax(z@rw+rb).reshape(N,10,20).sum(2);trace.append(a.copy())
 if step in [1000,1800,1900,2000]:images.append(render(p));image_times.append(step)
 if step%100==0:print(f'noise test {step}/2000',flush=True)
trace=np.array(trace);changes=np.array(changes);images=np.array(images);rows=[]
for i,sg in enumerate(sigmas):
 rows.append(dict(trial=i,sigma=float(sg),random_seed=2026092200+i,settled=bool(changes[-10:,i].max()<1e-5),final_winner=int(trace[-1,i].argmax()),ever_switched=bool((trace[:,i].argmax(1)!=7).any()),late_winner_switches=int((np.diff(trace[-201:,i].argmax(1))!=0).sum()),late_category7_min=float(trace[-201:,i,7].min()),late_category7_max=float(trace[-201:,i,7].max()),late_activity_range=float(np.ptp(trace[-201:,i],axis=0).max()),final_max_update=float(changes[-10:,i].max())))
assert [hashlib.sha256(x.read_bytes()).hexdigest() for x in paths]==hashes
np.testing.assert_allclose(p.sum(1),1,atol=5e-6);assert np.isfinite(p).all()
result=dict(protocol=protocol,endpoint_pixel_error=error,weights_unchanged=True,cases=rows)
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');np.savez_compressed(out/'traces.npz',activity=trace,changes=changes,images=images,image_times=image_times,sigmas=sigmas)
for sg in [0,.01,.05]:
 rr=[r for r in rows if abs(r['sigma']-sg)<1e-7];print(sg,'settled',sum(r['settled'] for r in rr),'/',len(rr),'switched',sum(r['ever_switched'] for r in rr),'range',min(r['late_activity_range'] for r in rr),max(r['late_activity_range'] for r in rr),flush=True)
