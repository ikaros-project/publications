"""Frozen-parameter loaders and outcome-independent QMNIST stimuli."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import csv,gzip,json,hashlib,itertools
from pathlib import Path
import numpy as np
from freeze_qmnist_confirmation import OUT,C,STUDY,paths,sha
import evaluate_reference_bank_sensitivity as b
from cached_spatial_content_feedback import CachedFrontend

def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def protocol():
 p=OUT/'protocol.json';assert sha(p)==(OUT/'protocol.sha256').read_text().strip()
 return json.loads(p.read_text())
def idx(path):
 raw=gzip.decompress(path.read_bytes());magic=int.from_bytes(raw[:4],'big');n=magic&255
 shape=np.frombuffer(raw,dtype='>i4',count=n,offset=4)
 return np.frombuffer(raw,dtype='>i4' if magic>>8==12 else np.uint8,offset=4+4*n).reshape(tuple(shape)).copy()

def load_model(seed):
 pp=paths(seed);pr=protocol()
 assert all(sha(p)==pr['checkpoint_sha256'][str(p.relative_to(C))] for p in pp)
 state=json.loads(pp[0].read_text())['items']
 def w(k):
  v=state['CVAE_TwoLayer.Upper.'+k];return np.array(v['value'],np.float32).reshape(v['shape'])
 m={k:w(v) for k,v in [('enc','DIRECT_MEAN_WEIGHTS'),('eb','DIRECT_MEAN_BIAS'),('dec','DIRECT_DECODER_WEIGHTS'),('db','DIRECT_DECODER_BIAS')]}
 del state
 with np.load(pp[1]) as z:m['book']=b.original.f.prior.Codebook(z['prototypes'])
 with np.load(pp[2]) as z:m.update(rw=z['weights'].copy(),rb=z['bias'].copy())
 with np.load(pp[3]) as z:m['decoder']=z['decoder'].astype(np.float32)
 refs=json.loads(pp[5].read_text());refs=refs[str(seed)] if seed==71001 else refs
 ids=np.array([refs[str(c)] for c in range(10)]);needed=set(ids.ravel().tolist());codes=np.zeros((60000,128),np.float32)
 with pp[4].open() as f:
  reader=csv.reader(f);header=next(reader);cols=[i for i,s in enumerate(header) if s=='code' or s.startswith('code:')];assert len(cols)==128
  for j,row in enumerate(reader):
   if j in needed:codes[j]=[float(row[k]) for k in cols];needed.remove(j)
   if not needed:break
 assert not needed
 m.update(codes=codes,ids=ids,paths=pp)
 front=CachedFrontend.__new__(CachedFrontend)
 for k in ['enc','eb','dec','db','book','rw','rb','decoder']:setattr(front,k,m[k])
 front.paths=pp;front.hashes=[sha(p) for p in pp];front.ids=ids;front.rc=codes[ids];front.rp=front.decode(front.rc.reshape(80,128)).reshape(10,8,64,676)
 front.counts=np.zeros((32,32),np.float32)
 for dy in range(7):
  for dx in range(7):front.counts[dy:dy+26,dx:dx+26]+=1
 return m,front

def prepare():
 p=protocol()
 if (OUT/'stimuli_manifest.json').exists():return
 labels=idx(OUT/'downloads/qmnist-test-labels-idx2-int.gz');training=idx(OUT/'downloads/qmnist-train-labels-idx2-int.gz')
 assert labels.shape==(60000,8) and training.shape==(60000,8)
 eligible=labels[10000:,5];old=np.concatenate([training[:,5],labels[:10000,5]])
 assert not set(map(int,eligible))&set(map(int,old)), 'Source digit overlap'
 rng=np.random.default_rng(p['sampling']['seed']);pool={c:rng.permutation(np.flatnonzero(labels[10000:,0]==c)+10000) for c in range(10)}
 singles=[int(i) for c in range(10) for i in pool[c][:10]]
 pairlists={c:iter(map(int,pool[c][10:19])) for c in range(10)}
 mixtures=[(ca,cb,next(pairlists[ca]),next(pairlists[cb])) for ca,cb in itertools.combinations(range(10),2)]
 spatial=[];distractors={c:iter(map(int,pool[c][21:23])) for c in range(10)};layout=np.random.default_rng(p['sampling']['layout_seed'])
 for c in range(10):
  for rep in range(2):
   dc=(c+(1 if rep==0 else 3))%10;ti=int(pool[c][19+rep]);di=next(distractors[dc]);left=64+int(layout.integers(-24,25));right=224+int(layout.integers(-24,25));tp,dp=(left,right) if rep==0 else (right,left)
   spatial.append(dict(pair=len(spatial),target_category=c,distractor_category=dc,target_id=ti,distractor_id=di,target_position=tp,distractor_position=dp))
 used=singles+[i for _,_,a,bb in mixtures for i in [a,bb]]+[i for s in spatial for i in [s['target_id'],s['distractor_id']]]
 assert len(used)==len(set(used))==230 and min(used)>=10000
 raw=idx(OUT/'downloads/qmnist-test-images-idx3-ubyte.gz');assert raw.shape==(60000,28,28)
 images={i:b.E.full.center_and_pad(raw[i]).astype(np.float32)/255 for i in used}
 # Exact byte overlap check against all original training and test examples.
 old_hashes=set()
 for name,n in [('train-images-idx3-ubyte.gz',60000),('t10k-images-idx3-ubyte.gz',10000)]:
  a=b.E.full.read_idx_images(b.E.full.RAW_ROOT/name,n)
  old_hashes.update(hashlib.sha256(im.tobytes()).digest() for im in a)
 overlap=[i for i in used if hashlib.sha256(raw[i].tobytes()).digest() in old_hashes]
 assert not overlap, 'Selected exact-image overlap requires protocol deviation review'
 fm=[];xx=[];cc=[];mm=[];nr=np.random.default_rng(p['sampling']['noise_seed'])
 def add(x,clean,mask,**meta):
  fm.append(dict(case=len(fm),**meta));xx.append(x);cc.append(clean);mm.append(mask)
 for i in singles:
  im=images[i];cat=int(labels[i,0]);empty=np.zeros((32,32),bool)
  add(im,im,empty,task='clean',level=0,cluster=str(i),truth=cat,ids=[i],realization=None)
  for size in [8,12]:
   mask=empty.copy();lo=(32-size)//2;mask[lo:lo+size,lo:lo+size]=True;x=im.copy();x[mask]=0
   add(x,im,mask,task='occlusion',level=size,cluster=str(i),truth=cat,ids=[i],realization=None)
  for sigma in [.25,.5]:
   for rep in range(3):
    x=np.clip(im+nr.normal(0,sigma,im.shape).astype(np.float32),0,1)
    add(x,im,empty,task='noise',level=sigma,cluster=str(i),truth=cat,ids=[i],realization=rep)
 for pair,(ca,cb,a,bb) in enumerate(mixtures):
  for frac in [.25,.5,.75]:
   x=frac*images[a]+(1-frac)*images[bb]
   add(x,x,np.zeros((32,32),bool),task='mixture',level=frac,cluster=str(pair),truth=None if frac==.5 else ca if frac>.5 else cb,ids=[a,bb],categories=[ca,cb],realization=None)
 assert len(fm)==1035
 np.savez_compressed(OUT/'focal_stimuli.npz',input=xx,clean=cc,mask=mm);dump(OUT/'focal_stimuli.json',fm)
 sx=[];sc=[];sm=[];meta=[];jobs=[]
 for pair in spatial:
  clean=np.zeros((32,320),np.float32);tp=pair['target_position'];dp=pair['distractor_position'];clean[:,tp:tp+32]=images[pair['target_id']];clean[:,dp:dp+32]=images[pair['distractor_id']]
  for size in [0,8,12]:
   mask=np.zeros_like(clean,bool)
   if size:lo=(32-size)//2;mask[lo:lo+size,tp+lo:tp+lo+size]=True
   x=clean.copy();x[mask]=0;j=len(meta);meta.append(dict(case=j,deletion=size,**pair));sx.append(x);sc.append(clean);sm.append(mask)
   for on in [False,True]:jobs.append(dict(job=len(jobs),case=j,task='completion',feedback=on))
   if size==0:
    for on in [False,True]:jobs.append(dict(job=len(jobs),case=j,task='category_search',feedback=on))
 assert len(jobs)==160
 np.savez_compressed(OUT/'spatial_stimuli.npz',input=sx,clean=sc,mask=sm);dump(OUT/'spatial_stimuli.json',meta);dump(OUT/'spatial_jobs.json',jobs)
 manifest=dict(protocol_sha256=sha(OUT/'protocol.json'),source_digit_overlap_count=0,selected_exact_image_overlap_count=len(overlap),selected_unique_images=len(used),source_metadata={str(i):labels[i].tolist() for i in used},focal_inputs=len(fm),spatial_jobs_per_model=len(jobs),preprocessing_note='Existing center_and_pad includes integer center-of-mass recentering before32x32 padding; used unchanged.',files={n:sha(OUT/n) for n in ['focal_stimuli.npz','focal_stimuli.json','spatial_stimuli.npz','spatial_stimuli.json','spatial_jobs.json']})
 dump(OUT/'stimuli_manifest.json',manifest);print('Prepared230 distinct source images,1035 focal inputs,160 spatial runs/model',flush=True)
if __name__=='__main__':prepare()
