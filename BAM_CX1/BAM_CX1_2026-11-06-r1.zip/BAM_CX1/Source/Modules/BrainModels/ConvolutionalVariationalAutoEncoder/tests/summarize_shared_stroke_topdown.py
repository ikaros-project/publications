import json,csv
from pathlib import Path
import numpy as np
import evaluate_shared_stroke_topdown as e
out=e.OUT;M=Path(__file__).resolve().parents[5]/'Manuscript';rows=json.loads((out/'results.json').read_text())['cases']
def get(seed,j,td,mode):return next(r for r in rows if r['seed']==seed and r['candidate']==j and r['topdown']==td and r['mode']==mode)
def stats(v):
 v=np.array(v);mean=v.mean();sd=v.std(ddof=1);h=2.262157*sd/np.sqrt(len(v));return dict(mean=float(mean),sd=float(sd),ci95=[float(mean-h),float(mean+h)])
summary=[];perseed=[]
for td in [.5,.75,1.]:
 rr=[v for v in rows if v['topdown']==td and v['mode']!='none'];captured=[v for v in rr if v['winner_at_release']==v['cue']]
 s=dict(topdown=td,captured=len(captured),cue_final=sum(v['final_winner']==v['cue'] for v in rr),retained=sum(v['final_winner']==v['cue'] for v in captured),pixel_cue=sum(v['final_pixel']==v['cue'] for v in rr),image_winner=sum(v['image_winner_agreement'] for v in rr),settled=sum(v['settled'] for v in rr),post_release_switch_cases=sum(any(t>50 for t in v['switch_iterations']) for v in rr),late_switches=sum(v['late_switches'] for v in rr))
 for name,require_image in [('bidirectional',False),('bidirectional_category_and_image',True)]:
  s[name]=sum(all(get(seed,j,td,m)['final_winner']==get(seed,j,td,m)['cue'] and (not require_image or get(seed,j,td,m)['final_pixel']==get(seed,j,td,m)['cue']) for m in ['bias_a','bias_b']) for seed in range(71001,71011) for j in range(1,7))
 for seed in range(71001,71011):
  ss=[v for v in rr if v['seed']==seed];perseed.append(dict(seed=seed,topdown=td,**{key:float(np.mean([v[key] for v in ss])) for key in ['shared_stroke_mse','shared_stroke_mae','shared_stroke_intensity','input_mse']},pixel_cue=float(np.mean([v['final_pixel']==v['cue'] for v in ss]))))
 for key in ['shared_stroke_mse','shared_stroke_mae','input_mse']:s[key]=stats([v[key] for v in perseed if v['topdown']==td])
 summary.append(s)
paired={}
for td in [.75,1.]:
 paired[str(td)]={key:stats([next(v[key] for v in perseed if v['seed']==seed and v['topdown']==td)-next(v[key] for v in perseed if v['seed']==seed and v['topdown']==.5) for seed in range(71001,71011)]) for key in ['shared_stroke_mse','shared_stroke_mae','pixel_cue']}
result=dict(summary=summary,paired_vs_50=paired,per_seed=perseed,all_settled=sum(v['settled'] for v in rows),runs=len(rows))
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
with (M/'shared_stroke_topdown_statistics.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
lines=['# Top-down fraction with fixed category bias','','Six preselected shared-stroke inputs,ten frozen models, both cue directions plus matched no-bias control at each fraction (540 runs). Bias amplitude2 for50 updates then500 without bias. Topdown fractions.5,.75,1 stay fixed for the whole run; inhibition and updates unchanged. At1, ongoing sensory anchoring disappears, but initial state and fixed reference selection depend on input.','','| Topdown | Cued final /120 | Pixel cue /120 | Both directions /60 | Both directions and images /60 | Shared-stroke MSE | Shared-stroke MAE |','|---|---|---|---|---|---|---|']
for s in summary:lines.append(f"|{s['topdown']}|{s['cue_final']}|{s['pixel_cue']}|{s['bidirectional']}|{s['bidirectional_category_and_image']}|{s['shared_stroke_mse']['mean']:.6f}|{s['shared_stroke_mae']['mean']:.6f}|")
lines+=['','## Detailed results','',json.dumps(result,indent=2),'','## Scope and checks','','Shared-stroke errors use only observed input pixels with intensity>.25, so added strokes elsewhere are not penalized by that metric. Evaluation mask never enters inference. MSE is a coordinate-wise preservation measure, not perceptual similarity or faithful recovery of either original. Pixel5NN provides a separate depiction measure. At100% a good depiction can reflect category-driven imagery rather than sensory-constrained completion. Comparisons average model-wise scores; t9 descriptive intervals reflect model variation on these six selected inputs, not independent stimulus uncertainty. No bias-outcome exclusions, retraining or default changes. Matched50% conditions reproduced saved amplitude2/no-bias trajectories and images. Initial readout/reference parity, probability normalization and frozen hashes verified.','','Article body unchanged pending review. Full protocol, arrays, snapshots, metrics and plotting data saved.']
(M/'shared_stroke_topdown_source_notes.md').write_text('\n'.join(lines)+'\n');(out/'REPORT.md').write_text('\n'.join(lines)+'\n')
with np.load(out/'seed71001/arrays.npz') as z:
 panels=[];labels=[]
 for j in range(6):
  panels.append([z['input'][j]]+[z['snapshots'][-1,k*6+j] for k in [1,2,4,5,7,8]])
  r=get(71001,j+1,.5,'bias_a');labels.append(f"#{j+1}: {r['a']} / {r['b']}")
 e.f.gallery(M/'shared_stroke_topdown_first_seed.png','Top-down influence:500 updates after category-bias removal',panels,labels,['shared input','50%: A','50%: B','75%: A','75%: B','100%: A','100%: B'])
print('\n'.join(lines),flush=True)
