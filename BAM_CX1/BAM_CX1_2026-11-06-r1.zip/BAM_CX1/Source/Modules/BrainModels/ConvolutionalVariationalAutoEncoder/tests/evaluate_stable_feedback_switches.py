"""Replay all 49 previously identified switches with three frozen feedback rules."""
import json,hashlib,time
from argparse import Namespace
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import analyze_feedback_winner_switches as prior
n=prior.n;f=prior.f;e=prior.e;local=prior.local
OUT=n.CAMPAIGN/'stable_feedback_winner_switches'
METHODS=['historical','relaxation','leaky']
STEPS=list(range(33))+[64,128,200,300,400,500]
CHOSEN=[(71001,37),(71007,158),(71003,111),(71009,169)]
def dump(name,v):(OUT/name).write_text(json.dumps(v,indent=2)+'\n')
def status(s):dump('status.json',dict(stage=s));print(s,flush=True)
def soft(v):
 v=v-v.max(1,keepdims=True);v=np.exp(v);return v/v.sum(1,keepdims=True)
def main():
 OUT.mkdir(exist_ok=True);source=json.loads((prior.OUT/'results.json').read_text());rows=source['cases'];assert len(rows)==49
 protocol=dict(methods=METHODS,seeds=sorted(set(r['seed'] for r in rows)),cases=49,unique_inputs=26,steps=500,snapshots=STEPS,
 selection='All previously identified 49 gain0.5 winner-switching seed-scene cases, across ten frozen seeds. Selection is conditional on historical switching, so switch retention is not a population switch rate.',
 references='Same training references and nearest-per-category choices fixed from initial input. Same codebook, upper network, grouped readout and learned local pixel decoder. No learning, new input perturbation, or parameter tuning.',
 historical='a_next=.8*a+.2*relu(prob/max(prob)-1.5*sum_other(a)); w=a_next/sum(a_next); delta=sum_c w_c*clip(log(qref_c)-log(q),-2,2); p_next=.8*p+.2*softmax(log(b)+.5*delta).',
 relaxation='Same category competition. Q=sum_c w_c*qref_c; p_next=.8*p+.2*(.5*b+.5*Q).',
 leaky='Same category competition. u_next=.9*u+.1*delta, u_0=0; r=softmax(log(Q)+.5*u_next); p_next=.8*p+.2*(.5*b+.5*r). Correction includes a prediction anchor; this is not a leak-only ablation.',
 evaluation='Switch count and timing, final winner relative to original and historical winners, trajectories, pixel5NN agreement with final winner, convergence of p/a/u over last10 (<1e-5), pixel MSE400to500, input fidelity. Original historical trajectory through200 verified before interpreting comparisons. All500 iterations evaluated.',
 illustrations=[dict(seed=s,case_index=k) for s,k in CHOSEN],scope='Targeted switching replay only. No top-down parameter sweep or broader all-seed stimulus confirmation. lambda0.5 and other parameters retained from preceding stability comparison; historical gain0.5 is not equivalent to mixing lambda0.5.')
 dump('protocol.json',protocol);status('loading data')
 train,test,labels,tl=e.prepare_data(Namespace(train_count=60000,test_count=10000));tp=np.stack([e.full.center_and_pad(v) for v in train]).astype(np.float32)/255
 allrows=[];allims=[];allacts=[];allprs=[];allchanges=[];allinputs=[];checks=[]
 for seed in protocol['seeds']:
  rr=[r for r in rows if r['seed']==seed];src=prior.source(seed)
  with np.load(src/'arrays.npz') as old:
   gi=list(old['gains']).index(.5);ix=np.array([r['case_index'] for r in rr]);x=old['input'][ix].copy();oldact=old['activities'][gi][:,ix].copy();oldim=old['outputs'][gi,ix].copy()
  N=len(rr);status(f'seed {seed}: {N} known switches')
  folder=n.CAMPAIGN/f'hierarchy_s{seed}';rd=n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit'/f'grouped_softmax_s{seed}.npz';pdir=n.CAMPAIGN/'local_linear_patch_decoder_seed1' if seed==71001 else n.CAMPAIGN/'local_linear_patch_decoder_ten_seeds'/f'seed{seed}';dp=pdir/'local_decoder.npz';paths=[folder/'model.state',folder/'codebook_final.npz',rd,dp];hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
  state=json.loads(paths[0].read_text())['items']
  def w(key):
   v=state['CVAE_TwoLayer.Upper.'+key];return np.array(v['value'],np.float32).reshape(v['shape'])
  enc=w('DIRECT_MEAN_WEIGHTS');eb=w('DIRECT_MEAN_BIAS');dec=w('DIRECT_DECODER_WEIGHTS');db=w('DIRECT_DECODER_BIAS');del state
  with np.load(rd) as z:rw=z['weights'];rb=z['bias']
  with np.load(dp) as z:d=z['decoder'].astype(np.float32)
  with np.load(paths[1]) as z:book=f.prior.Codebook(z['prototypes'])
  codes,_,_=e.read_codes(folder/'train_codes.csv',train,labels,128)
  refs=json.loads((n.CAMPAIGN/'category_feedback_diagnostic/reference_indices.json').read_text())['71001'] if seed==71001 else json.loads((pdir/'feedback_inference/reference_indices.json').read_text())
  ids=np.array([refs[str(c)] for c in range(10)]);rc=codes[ids].astype(np.float32)
  def encode(p):return p.reshape(len(p),-1)@enc+eb
  def decode(z):
   v=(z@dec+db).reshape(-1,64,676);v-=v.max(1,keepdims=True);return v-np.log(np.exp(v).sum(1,keepdims=True))
  def probs(z):return n.softmax(z@rw+rb).reshape(-1,10,20).sum(2)
  def render(q):return np.clip(local.overlap(np.exp(q).transpose(0,2,1)@d),0,1)
  rq=decode(rc.reshape(-1,128)).reshape(10,8,64,676);rp=np.exp(rq)
  b=np.stack([book.process(v,False,.01,.08)[0].reshape(64,676) for v in x]);lb=np.log(np.maximum(b,1e-30));z0=encode(b);q0=decode(z0);pr0=probs(z0);a0=pr0/pr0.max(1,keepdims=True);selected=((z0[:,None,None]-rc[None])**2).sum(3).argmin(2)
  seedrows=[];seedims=[];seedacts=[];seedprs=[];seedchanges=[]
  for method in METHODS:
   p=b.copy();q=q0.copy();pr=pr0.copy();a=a0.copy();u=np.zeros_like(p);acts=[a.copy()];prs=[pr.copy()];changes=[];ims=[render(q)]
   for step in range(1,501):
    an=.8*a+.2*np.maximum(pr/pr.max(1,keepdims=True)-1.5*(a.sum(1,keepdims=True)-a),0);ww=an/an.sum(1,keepdims=True);delta=np.zeros_like(p);Q=np.zeros_like(p)
    for c in range(10):
     wc=ww[:,c,None,None];delta+=wc*np.clip(rq[c,selected[:,c]]-q,-2,2)
     if method!='historical':Q+=wc*rp[c,selected[:,c]]
    uc=np.zeros(N,np.float32)
    if method=='historical':target=soft(lb+.5*delta)
    elif method=='relaxation':target=.5*b+.5*Q
    else:
     un=.9*u+.1*delta;uc=abs(un-u).max((1,2));u=un;target=.5*b+.5*soft(np.log(np.maximum(Q,1e-30))+.5*u)
    pn=.8*p+.2*target;changes.append(np.stack([abs(pn-p).max((1,2)),abs(an-a).max(1),uc],axis=1));p=pn;a=an;zz=encode(p);q=decode(zz);pr=probs(zz);acts.append(a.copy());prs.append(pr.copy())
    if step in STEPS:ims.append(render(q))
   ch=np.array(changes);act=np.array(acts);prs=np.array(prs);ims=np.array(ims);wins=act.argmax(2);settled=ch[-10:].max((0,2))<1e-5
   np.testing.assert_allclose(p.sum(1),1,atol=4e-6);assert np.isfinite(q).all()
   if method=='historical':
    ae=float(abs(act[:201]-oldact).max());ie=float(abs(ims[STEPS.index(200)]-oldim).max());assert ae<2e-5 and ie<2e-5;np.testing.assert_array_equal(wins[:201],oldact.argmax(2));checks.append(dict(seed=seed,activity_max_error=ae,image_max_error=ie))
   for j,r in enumerate(rr):
    switches=np.flatnonzero(np.diff(wins[:,j])!=0)+1
    seedrows.append(dict(seed=seed,case_index=r['case_index'],pair_id=r['pair_id'],mix=r['mix'],method=method,original_winner=int(wins[0,j]),historical_winner=r['final_winner'],historical_switch_iteration=r['switch_iteration'],switch_iterations=switches.tolist(),switch_sequence=[int(wins[0,j])]+wins[switches,j].tolist(),final_winner=int(wins[-1,j]),winner_at200=int(wins[200,j]),settled=bool(settled[j]),settled_at200=bool(ch[190:200,j].max()<1e-5),max_last10_change=float(ch[-10:,j].max()),late_switches=int(np.sum(switches>400)),input_mse=float(((ims[-1,j]-x[j])**2).mean()),pixel_drift_mse=float(((ims[-1,j]-ims[-2,j])**2).mean())))
   seedims.append(ims);seedacts.append(act);seedprs.append(prs);seedchanges.append(ch);status(f'seed {seed}/{method}: 500 iterations complete')
  assert [hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]==hashes
  np.savez_compressed(OUT/f'seed{seed}.npz',input=x,snapshots=np.array(seedims),snapshot_steps=STEPS,activities=np.array(seedacts),probabilities=np.array(seedprs),changes=np.array(seedchanges),case_indices=ix)
  dump(f'seed{seed}_results.json',seedrows);allrows+=seedrows;allims.append(np.array(seedims));allacts.append(np.array(seedacts));allprs.append(np.array(seedprs));allchanges.append(np.array(seedchanges));allinputs.append(x)
  del enc,dec,codes,rc,rq,rp
 # Unified ordering: method, time, all49 cases in seed order.
 ims=np.concatenate(allims,axis=2);acts=np.concatenate(allacts,axis=2);prs=np.concatenate(allprs,axis=2);changes=np.concatenate(allchanges,axis=2);inputs=np.concatenate(allinputs)
 status('scoring final images with independent pixel5NN')
 pred=e.five_nearest_predictions(tp.reshape(60000,-1),labels,ims[:,-1].reshape(-1,1024)).reshape(3,49)
 keys=[(r['seed'],r['case_index']) for r in rows];lookup={(r['method'],r['seed'],r['case_index']):r for r in allrows};summary=[]
 for mi,method in enumerate(METHODS):
  rr=[lookup[(method,s,k)] for s,k in keys]
  for j,r in enumerate(rr):r['pixel_prediction']=int(pred[mi,j]);r['pixel_winner_agreement']=bool(pred[mi,j]==r['final_winner'])
  switched=[r for r in rr if r['switch_iterations']];first=[r['switch_iterations'][0] for r in switched]
  summary.append(dict(method=method,cases=49,ever_switched=len(switched),final_changed=sum(r['final_winner']!=r['original_winner'] for r in rr),same_historical_final=sum(r['final_winner']==r['historical_winner'] for r in rr),original_final=sum(r['final_winner']==r['original_winner'] for r in rr),other_final=sum(r['final_winner'] not in [r['original_winner'],r['historical_winner']] for r in rr),multiple_switch_cases=sum(len(r['switch_iterations'])>1 for r in rr),first_switch_median=float(np.median(first)) if first else None,first_switch_range=[min(first),max(first)] if first else None,settled=sum(r['settled'] for r in rr),settled_at200=sum(r['settled_at200'] for r in rr),late_switches=sum(r['late_switches'] for r in rr),pixel_winner_agreement=sum(r['pixel_winner_agreement'] for r in rr),input_mse=float(np.mean([r['input_mse'] for r in rr])),pixel_drift_mse=float(np.mean([r['pixel_drift_mse'] for r in rr]))))
 dump('results.json',dict(protocol=protocol,summary=summary,cases=allrows,checks=checks,weights_unchanged=True))
 np.savez_compressed(OUT/'combined.npz',input=inputs,snapshots=ims,steps=STEPS,activities=acts,probabilities=prs,changes=changes,pixel_predictions=pred,case_keys=keys)
 # Identical four previously selected examples; include actual input and competition labels.
 font=ImageFont.load_default(size=15);small=ImageFont.load_default(size=13)
 can=Image.new('RGB',(1030,1740),'white');dr=ImageDraw.Draw(can);dr.text((15,12),'Previously observed winner switches: same inputs, three feedback mechanisms',fill='black',font=font)
 for ci,key in enumerate(CHOSEN):
  j=keys.index(key);y0=48+ci*420;dr.text((15,y0),f'Seed {key[0]}, case {key[1]}: historical '+str(rows[j]['initial_winner'])+' -> '+str(rows[j]['final_winner']),fill='black',font=font)
  for mi,method in enumerate(METHODS):
   y=y0+28+mi*127;r=lookup[(method,*key)];dr.text((15,y+35),method,fill='black',font=font)
   panels=[inputs[j]]+[ims[mi,STEPS.index(t),j] for t in [0,8,32,200,500]];labs=['input']+[f't={t}, winner {acts[mi,t,j].argmax()}' for t in [0,8,32,200,500]]
   for k,(v,lab) in enumerate(zip(panels,labs)):
    xx=155+k*143;dr.text((xx,y),lab,fill='black',font=small);can.paste(Image.fromarray(np.uint8(np.clip(v,0,1)*255)).resize((100,100)),(xx,y+20))
 can.save(OUT/'selected_comparison.png')
 # Competition trajectories through64 for all ten nodes, one panel per method.
 chart=Image.new('RGB',(1250,1020),'white');dr=ImageDraw.Draw(chart);dr.text((12,10),'Competition: orange = original winner; blue = historical final winner; grey = others',fill='black',font=font)
 for ri,key in enumerate(CHOSEN):
  j=keys.index(key);ybase=65+ri*235;dr.text((12,ybase-25),f'Seed {key[0]}, case {key[1]}',fill='black',font=font);orig=rows[j]['initial_winner'];fin=rows[j]['final_winner']
  for mi,method in enumerate(METHODS):
   xx=45+mi*410;yy=ybase+22;ww=345;hh=145;dr.text((xx,yy-20),method,fill='black',font=font)
   for level in [0,.5,1]:
    v=yy+hh*(1-level);dr.line((xx,v,xx+ww,v),fill='#dddddd');dr.text((xx-25,v-6),str(level),fill='#555555',font=small)
   for c in [c for c in range(10) if c not in [orig,fin]]+[orig,fin]:
    color='#d55e00' if c==orig else '#0072b2' if c==fin else '#bbbbbb';dr.line([(xx+t*ww/64,yy+hh*(1-float(v))) for t,v in enumerate(acts[mi,:65,j,c])],fill=color,width=3 if c in [orig,fin] else 1)
   for t in [0,16,32,48,64]:dr.text((xx+t*ww/64-5,yy+hh+5),str(t),fill='black',font=small)
 chart.save(OUT/'selected_competition.png')
 lines=['# Stable feedback replay of known winner switches','','All49 previously selected seed-scene cases across10 frozen seeds;500 iterations; no parameter tuning. Results are conditional on prior switching.','', '| Method | Any switch | Different final from initial | Same historical final | Settled | Pixel/winner agreement |','|---|---:|---:|---:|---:|---:|']
 for r in summary:lines.append(f'| {r["method"]} | {r["ever_switched"]}/49 | {r["final_changed"]}/49 | {r["same_historical_final"]}/49 | {r["settled"]}/49 | {r["pixel_winner_agreement"]}/49 |')
 lines+=['','Full per-case switch sequences, timing, image fidelity and trajectories are saved. Original historical winner trajectories and images at200 reproduced within2e-5; weights unchanged. Selected figures reuse the same four earlier examples, not selected from new outcomes. Input column shows the fixed sensory stimulus. Other image columns render the upper decoder; rendered pixels are not fed back. No population switch-rate or biological-equivalence claim follows from this selected sample.']
 (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');status('complete');print('\n'.join(lines),flush=True)
if __name__=='__main__':main()
