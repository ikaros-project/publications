"""Paired follow-up controls, clustered uncertainty and fixed-order illustrations."""
import csv,json
import numpy as np
import run_qmnist_retrieval_controls as run
import plot_qmnist_confirmation as plot
OUT=run.OUT;q=run.q

def contrast(rows,task,level,metric,control):
 rr=[r for r in rows if r['task']==task and (level=='all' or r['level']==level)]
 seeds=q.protocol()['models'];clusters=sorted(set(r['cluster'] for r in rr));a=np.full((3,len(clusters),2),np.nan)
 for i,s in enumerate(seeds):
  for j,c in enumerate(clusters):
   for k,mode in enumerate([control,'full']):
    v=[float(r[metric]) for r in rr if r['seed']==s and r['cluster']==c and r['mode']==mode and r[metric] is not None]
    if v:a[i,j,k]=np.mean(v)
 a=a[:,np.isfinite(a).all((0,2))]
 if not a.shape[1]:return None
 delta=a[:,:,1]-a[:,:,0];rng=np.random.default_rng(2026110509);draw=[]
 for _ in range(2000):draw.append(delta[np.ix_(rng.integers(0,3,3),rng.integers(0,a.shape[1],a.shape[1]))].mean())
 return dict(task=task,level=level,metric=metric,control=control,clusters=a.shape[1],full_minus_control=float(delta.mean()),ci95=np.quantile(draw,[.025,.975]).tolist(),by_model=delta.mean(1).tolist())

def main():
 result=json.loads((OUT/'results.json').read_text());rows=result['rows'];assert len(rows)==18630
 groups=[('clean',0),('mixture','all'),('mixture',.5),('occlusion',8),('occlusion',12),('noise',.25),('noise',.5)]
 metrics=['agreement','full_winner_agreement','initial_winner_agreement','category_correct','pixel_correct','clean_mse','hidden_mse','visible_mse']
 means=[];contrasts=[]
 for task,level in groups:
  for mode in run.MODES:
   rr=[r for r in rows if r['task']==task and (level=='all' or r['level']==level) and r['mode']==mode]
   rec=dict(task=task,level=level,mode=mode,n=len(rr))
   for metric in metrics:
    vv=[r[metric] for r in rr if r[metric] is not None];rec[metric]=float(np.mean(vv)) if vv else None
   rec['by_model']=[dict(model=s,**{metric:float(np.mean(v)) if v else None for metric in metrics for v in [[r[metric] for r in rr if r['seed']==s and r[metric] is not None]]}) for s in q.protocol()['models']];means.append(rec)
  for metric in ['full_winner_agreement','agreement','pixel_correct','clean_mse','hidden_mse','visible_mse']:
   for control in run.MODES[:-1]:
    r=contrast(rows,task,level,metric,control)
    if r:contrasts.append(r)
 q.dump(OUT/'summary.json',dict(means=means,paired=contrasts,checks=result['checks']))
 with (OUT/'means.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=[k for k in means[0] if k!='by_model']);w.writeheader();w.writerows({k:v for k,v in r.items() if k!='by_model'} for r in means)
 lines=['# Retrieval and recurrence controls: QMNIST follow-up','', 'This is a follow-up on the same QMNIST confirmation inputs, not a new independent confirmation. The comparison protocol was frozen before evaluating the additional controls. All1035 focal inputs and three unchanged trained models were included. Six conditions give18,630 scored endpoints, of which6,210 full/no-feedback endpoints are reused exactly. No spatial or blank-input imagery tests are included.','', '## Definitions','', '- Pixel retrieval returns the original training pixels of the nearest bank reference within the initial bottom-up winning category.','- Direct reference decoding uses exactly that reference identity, but decodes its stored latent representation through the VAE and patch decoders.','- Single-step mixing performs one original category update and one code update, then decodes immediately. With alpha0.2 and mixture fraction0.5, the actual code state contains90% sensory codes and10% weighted reference predictions.','- Fixed feedback holds the normalized first-update category weights constant throughout500 updates. Category activity still evolves.','- Full feedback updates the category weights recurrently for500 updates.','- No feedback keeps the sensory code state fixed while category competition continues.','', 'All per-category reference addresses come from the actual ambiguous or degraded input. No clean target or true category selects a reference. Retrieval and one-step conditions use their initial/once-updated category as output. Therefore both own-category agreement and agreement with the SAME full-model winning category are reported. The latter removes differences in the agreement target across conditions. Neither agreement measure establishes stimulus recovery.','', '## Mean results','']
 for task,level in [('mixture','all'),('occlusion',12),('noise',.5)]:
  lines += [f'### {task}, level {level}','','| Condition | Own-category agreement (%) | Full-winner agreement (%) | Pixel recognition (%) | Clean MSE | Hidden MSE | Visible MSE |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
  for r in means:
   if r['task']!=task or r['level']!=level:continue
   fmt=lambda key,rate=False:'—' if r[key] is None else f"{r[key]*(100 if rate else 1):.2f}" if rate else f"{r[key]:.5f}"
   lines.append('| '+r['mode']+' | '+' | '.join([fmt('agreement',True),fmt('full_winner_agreement',True),fmt('pixel_correct',True),fmt('clean_mse'),fmt('hidden_mse'),fmt('visible_mse')])+' |')
 lines+=['','## Paired uncertainty','','Intervals resample models and source-image/pair clusters independently with replacement (2,000 crossed bootstrap replicates). Repetitions remain within source clusters. Only three models were tested. Values below are full recurrence minus the named control. Agreement differences are percentage points.','','| Task | Level | Measure | Control | Difference | 95% interval |','| --- | --- | --- | --- | ---: | --- |']
 for r in contrasts:
  if not ((r['task']=='mixture' and r['level']=='all' and r['metric']=='full_winner_agreement') or (r['task']=='occlusion' and r['level']==12 and r['metric']=='hidden_mse')):continue
  mult=100 if 'agreement' in r['metric'] else 1;lo,hi=r['ci95'];lines.append(f"| {r['task']} | {r['level']} | {r['metric']} | {r['control']} | {mult*r['full_minus_control']:.5f} | [{mult*lo:.5f}, {mult*hi:.5f}] |")
 lines+=['','## Interpretation constraints','','The single-step condition also has less total feedback influence than the settled conditions. Its comparison with full recurrence therefore does not isolate repeated category evaluation. The500-update fixed-weight control provides that more specific contrast. Retrieval baselines output complete stored content, which may score well for category consistency without recovering the particular hidden source image. The raw-pixel retrieval baseline also shares its exemplar set with the training-image5NN evaluator. Common-winner agreement, physical reconstruction error and pixel recognition should be interpreted together. No advantage of recurrence is assumed.','', 'The manuscript and reviewer reply have not been changed. Full per-case results, per-model means and all paired intervals accompany this report.']
 text='\n'.join(lines)+'\n';(OUT/'REPORT.md').write_text(text);(q.STUDY/'Manuscript/qmnist_retrieval_controls_source_notes.md').write_text(text)
 with np.load(q.OUT/'focal_stimuli.npz') as z:x=z['input'];clean=z['clean']
 meta=json.loads((q.OUT/'focal_stimuli.json').read_text());images={}
 for mode in run.MODES:
  with np.load(OUT/f'model71001_{mode}.npz') as z:images[mode]=z['images']
 for task in ['occlusion','mixture']:
  selected=[next(r for r in meta if r['task']=='occlusion' and r['level']==12 and r['truth']==c) for c in range(10)] if task=='occlusion' else [next(r for r in meta if r['task']=='mixture' and r['level']==.5 and r['cluster']==str(c)) for c in range(6)]
  gallery=[(str(r['truth']) if task=='occlusion' else str(r['categories']),[clean[r['case']],x[r['case']]]+[images[m][r['case']] for m in run.MODES]) for r in selected]
  plot.panel(gallery,['Clean/mixture','Input','No feedback','Pixel retrieval','Ref. decoding','Single step','Fixed weights','Full'],OUT/f'{task}_examples.png','QMNIST: retrieval and recurrence controls','Fixed-order examples from first model. No outcome-based selection. Clean mixture equals input for mixture rows.')
 print('Analysis, report and fixed-order figures saved.')
if __name__=='__main__':main()
