"""Shared spatially aligned category reconstruction; frozen-network diagnostic."""
import concurrent.futures,hashlib,json,shutil,time
from pathlib import Path
import numpy as np
import run_spatial_overlap_pilot as r
from run_spatial_overlap_fixed_spotlight import ROOT as FIXED,CuedCircuit
from run_spatial_overlap_feedback_strength import StrengthFeedback,gain_folder
from neural_spatial_rate_model import windows
BASE=gain_folder(.65)
ROOT=FIXED/'aligned_feedback'

def pixels(front,p):
    patches=(p.transpose(0,2,1)@front.decoder).reshape(-1,26,26,7,7)
    y=np.zeros((len(p),32,32),np.float32)
    for dy in range(7):
        for dx in range(7):y[:,dy:dy+26,dx:dx+26]+=patches[:,:,:,dy,dx]
    return np.clip(y/front.counts,0,1)

def place(im,position,width=320):
    canvas=np.zeros((32,width),np.float32)
    lo=max(0,position);hi=min(width,position+32)
    if hi>lo:canvas[:,lo:hi]=im[:,lo-position:hi-position]
    return canvas

class AlignedFeedback(StrengthFeedback):
    maximum=.65
    mode='aligned'
    last=None
    def __init__(self,*args):
        super().__init__(*args);type(self).last=self;self.anchors=[];self.templates={}
        if self.mode!='parity':
            self.ref_images=pixels(self.front,self.front.rp.reshape(80,64,676)).reshape(10,8,32,32)
            if self.mode=='roundtrip':self.roundtrip=self.front.bottom(self.ref_images.reshape(80,32,32)).reshape(10,8,64,676)
    def propose(self,circuit):
        if self.mode=='parity':return super().propose(circuit)
        b=self.front.bottom(windows(circuit.s,31)[0])
        gate=np.clip((circuit.a[0]@self.field_kernel)/max(1.,float(circuit.a.sum())),0,1)
        c=circuit.c[0];mass=float(c.sum());anchor=int(circuit.a[0].argmax()) if circuit.a.sum()>1e-7 else -1
        self.anchors.append(anchor-31 if anchor>=0 else -999)
        lam=self.maximum*gate if self.feedback and mass>1e-7 else np.zeros_like(gate)
        target=b.copy()
        if np.any(lam):
            weights=c/mass;key=(anchor,weights.tobytes())
            if getattr(self,'_key',None)!=key:
                Q=np.zeros_like(b)
                for k in range(10):
                    if weights[k]==0:continue
                    if self.mode=='roundtrip':q=self.roundtrip[k,self.chosen[:,k]]
                    else:
                        assert anchor>=0
                        slot=int(self.chosen[anchor,k]);cache=(anchor,k,slot)
                        if cache not in self.templates:
                            canvas=place(self.ref_images[k,slot],int(circuit.positions[anchor]))
                            self.templates[cache]=self.front.bottom(windows(canvas[None],31)[0])
                        q=self.templates[cache]
                    Q+=weights[k]*q
                self._key=key;self._Q=Q
            target=(1-lam[:,None,None])*b+lam[:,None,None]*self._Q
        new=(1-circuit.par.alpha)*self.q+circuit.par.alpha*target
        return new,float(np.max(abs(new-self.q))),gate

def init():
    r.init();r.Circuit=CuedCircuit;r.CachedLocalFeedback=AlignedFeedback

def prepare():
    ROOT.mkdir(exist_ok=True)
    if (ROOT/'protocol.json').exists():return
    meta=json.loads((BASE/'stimuli.json').read_text());jobs=[]
    for mode in ['aligned','roundtrip','parity']:
        dest=ROOT/mode;dest.mkdir(exist_ok=True)
        for n in ['stimuli.json','stimuli.npz']:shutil.copyfile(BASE/n,dest/n)
        for m in meta:
            if m['kind']=='pair' and m['separation']==0:
                for cue in ['combined_category_A','combined_category_B']:
                    if mode!='parity' or (m['case']==0 and cue.endswith('_A')):jobs.append([mode,m['case'],cue])
    r.r.dump(ROOT/'jobs.json',jobs)
    r.r.dump(ROOT/'protocol.json',dict(seed=71001,experimental_runs=12,parity_runs=1,steps=600,early_stop=False,feedback=.65,selection='Same three full-overlap pairs and both category cues; no screening.',mechanism='At each update choose argmax spatial activity. For each active category use that field original-input nearest reference slot. Decode its existing predicted codes directly through the existing patch decoder and overlap average to a32x32 reconstruction. Place it at the selected field origin on a zero-background32x320 canvas, crop all351 stride-one fields and re-encode with the existing lower encoder. Mix category templates by normalized category activity. Existing0.65 attention-gated code relaxation remains unchanged. No target images, masks, labels or coordinates used by mechanism.',control='Roundtrip control reconstructs and re-encodes each independently selected reference in its own local coordinates; same pixel-code conversion without sharing/alignment. Reuse all six independent-reference0.65 baselines. One parity run bypasses new mechanism.',fixed='Same spatial cue2 at144 and category cue2; frozen weights, separated sensory mismatch, normalization, alpha0.1, sigma24, uniform pooling and600updates. Actual final spotlight equality checked.',scores='Local and canvas target/loser/shared features, target foreground MSE, unforced local category, cue reversal, opposing field coverage and cross-field variance, settling and selected location. No global recognition claims under category clamp.',scope='Exploratory one-network three-pair mechanism test. Shared single-location template adds a winner-selection routing operation; it is not yet a fully distributed neural implementation. Zero background encodes an empty scene outside this single-object hypothesis, a possible source of suppression. No adoption or manuscript body changes.',source_sha256={n:hashlib.sha256(Path(__file__).with_name(n).read_bytes()).hexdigest() for n in ['run_spatial_overlap_aligned_feedback.py','run_spatial_overlap_feedback_strength.py','run_spatial_overlap_pilot.py','spatial_content_feedback.py','cached_spatial_content_feedback.py','run_spatial_overlap_fixed_spotlight.py']}))

def worker(job):
    mode,j,name=job;AlignedFeedback.mode=mode;r.ROOT=ROOT/mode
    row=r.worker((j,name));local=AlignedFeedback.last
    if mode=='parity':
        with np.load(r.ROOT/f'case{j:02d}_{name}/arrays.npz') as a,np.load(BASE/f'case{j:02d}_{name}/arrays.npz') as b:
            assert set(a.files)==set(b.files)
            for key in a.files:np.testing.assert_array_equal(a[key],b[key],err_msg=key)
        r.r.dump(ROOT/'parity.json',dict(all_saved_arrays_bit_identical=True))
    else:
        np.savez_compressed(r.ROOT/f'case{j:02d}_{name}/alignment.npz',anchor_trace=np.array(local.anchors),final_template_codes=local._Q)
    return dict(alignment_mode=mode,**row)

def main():
    prepare();rows=[];start=time.time()
    with concurrent.futures.ProcessPoolExecutor(max_workers=13,initializer=init) as pool:
        fs=[pool.submit(worker,j) for j in json.loads((ROOT/'jobs.json').read_text())]
        for f in concurrent.futures.as_completed(fs):
            rows.append(f.result());r.r.dump(ROOT/'status.json',dict(completed=len(rows),total=13,seconds=time.time()-start))
    r.r.dump(ROOT/'results.json',dict(new_runs=rows,parity=json.loads((ROOT/'parity.json').read_text())))
    print('ALIGNED FEEDBACK COMPLETE',flush=True)
if __name__=='__main__':main()
