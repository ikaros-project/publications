"""Exploratory coupling of existing focal code relaxation to the spatial circuit.

All fields are evaluated at stride one, with no inferred-position crop. Learned
weights, reference bank, and spatial equations are unchanged. The new local code
population is integrated synchronously at alpha=.1 in every condition, including
controls, so disabling feedback does not remove its response-time lag.
"""
import csv,json
import numpy as np
from neural_spatial_rate_model import Frontend,windows
from evaluate_spatial_single_stimulus import CAMPAIGN,softmax

class ContentFrontend(Frontend):
    def bottom(self,x):
        out=[]
        for start in range(0,len(x),64):
            p=np.lib.stride_tricks.sliding_window_view(x[start:start+64],(7,7),axis=(1,2)).reshape(-1,49)
            b=self.book.prototypes
            dist=(p*p).sum(1)[:,None]+(b*b).sum(1)[None]-2*p@b.T
            out.append(softmax(-dist/(49*.08)).reshape(-1,676,64).transpose(0,2,1))
        return np.concatenate(out).astype(np.float32)
    def encode(self,p):return p.reshape(len(p),-1)@self.enc+self.eb
    def decode(self,z):return softmax((z@self.dec+self.db).reshape(-1,64,676).transpose(0,2,1)).transpose(0,2,1)
    def evidence(self,p):
        z=self.encode(p);prob=softmax(z@self.rw+self.rb).reshape(-1,10,20).sum(2)
        patches=(self.decode(z).transpose(0,2,1)@self.decoder).reshape(-1,26,26,7,7)
        y=np.zeros((len(p),32,32),np.float32)
        for dy in range(7):
            for dx in range(7):y[:,dy:dy+26,dx:dx+26]+=patches[:,:,:,dy,dx]
        return prob,np.clip(y/self.counts,0,1)
    def references(self):
        refpath=CAMPAIGN/'category_feedback_diagnostic/reference_indices.json'
        refs=json.loads(refpath.read_text())['71001'];ids=np.array([refs[str(c)] for c in range(10)])
        needed=set(ids.ravel().tolist());codes={}
        with (CAMPAIGN/'hierarchy_s71001/train_codes.csv').open() as f:
            reader=csv.reader(f);header=next(reader);cols=[i for i,s in enumerate(header) if s=='code' or s.startswith('code:')]
            assert len(cols)==128
            for j,row in enumerate(reader):
                if j in needed:codes[j]=np.array([row[k] for k in cols],np.float32)
                if len(codes)==len(needed):break
        self.rc=np.stack([codes[i] for i in ids.ravel()]).reshape(10,8,128)
        self.rp=self.decode(self.rc.reshape(80,128)).reshape(10,8,64,676)
        return ids

class LocalFeedback:
    def __init__(self,front,circuit,feedback,attention):
        self.front=front;self.feedback=feedback;self.attention=attention
        self.q=front.bottom(windows(circuit.x,31)[0]);z=front.encode(self.q)
        self.chosen=((z[:,None,None]-front.rc[None])**2).sum(3).argmin(2)
        pos=circuit.positions
        self.field_kernel=np.exp(-.5*((pos[:,None]-pos[None,:])/circuit.par.sigma)**2).astype(np.float32)
    def propose(self,circuit):
        b=self.front.bottom(windows(circuit.s,31)[0])
        gate=np.ones(len(b),np.float32)
        if self.attention:
            gate=np.clip((circuit.a[0]@self.field_kernel)/max(1.,float(circuit.a.sum())),0,1)
        c=circuit.c[0];mass=float(c.sum())
        lam=.5*gate if self.feedback and mass>1e-7 else np.zeros_like(gate)
        target=b.copy()
        if np.any(lam):
            Q=np.zeros_like(b)
            for k in range(10):Q+=(c[k]/mass)*self.front.rp[k,self.chosen[:,k]]
            target=(1-lam[:,None,None])*b+lam[:,None,None]*Q
        new=(1-circuit.par.alpha)*self.q+circuit.par.alpha*target
        return new,float(np.max(abs(new-self.q))),gate

def render_scene(y,width):
    """Uniform overlap average: all fields, no location selection or oracle."""
    out=np.zeros((32,width+62),np.float32);count=np.zeros(width+62,np.float32)
    for i,im in enumerate(y):out[:,i:i+32]+=im;count[i:i+32]+=1
    return (out/np.maximum(count,1)[None])[:,31:31+width]
