"""Synchronous spatial WTA driven by the locked joint score, with soft category pooling.

The compact simulation omits only locations proven to have zero rectified drive.
All available overlapping locations compete without any sequential scan.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['VECLIB_MAXIMUM_THREADS']='2'
import json,time,hashlib
import numpy as np
from evaluate_spatial_joint_selection import CAMPAIGN
OUT=CAMPAIGN/'spatial_competition_seed1'
SOURCE=CAMPAIGN/'spatial_joint_selection_seed1'
STEPS=[1,2,5,10,20,50,100,200,500,1000]
XS=np.r_[np.arange(31),31,np.arange(258,289)]
EXPAND=np.r_[np.arange(31),np.full(227,31),np.arange(32,63)]

def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')

def step(activity,evidence):
    """All units use the same old state; no argmax or sequential update."""
    inhibition=1.5*(activity.sum(-1,keepdims=True)-activity)
    return .8*activity+.2*np.maximum(evidence-inhibition,0)

def drives(prob,quality):
    d=np.arange(-31,32)
    valid=(d[None,:]<=XS[:,None])&(d[None,:]>=XS[:,None]-288)
    q=quality[:,:63][:,None,:]
    qmax=np.max(np.where(valid[None],q,-np.inf),axis=2,keepdims=True)
    assert np.all(qmax>0)
    scores=q/qmax+.1*np.log(np.maximum(prob[:,:63].max(2)[:,None,:],1e-30))
    blank=quality[:,63,None,None]/qmax+.1*np.log(prob[:,63].max(1)[:,None,None])
    assert np.all(blank<0), 'Cannot omit active blank positions.'
    scores=np.where(valid[None],scores,-np.inf)
    e=np.maximum(scores,0);e/=e.max(2,keepdims=True)
    return e,scores,valid

def main():
    OUT.mkdir(exist_ok=True)
    files=[SOURCE/'arrays.npz',SOURCE/'selection.json',SOURCE/'results.json']
    hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in files]
    assert json.loads(files[1].read_text())['selected_method']==['log_add',.1]
    with np.load(files[0]) as z:prob=z['relative_probabilities'].astype(np.float64);quality=z['quality'].astype(np.float64);labels=z['labels'];ids=z['test_indices'];reference=z['predictions'][:,2];refpos=z['selected_positions'][:,2]
    evidence,scores,valid=drives(prob,quality)
    N=len(labels);shape=evidence.shape;e=evidence.reshape(-1,63)
    dump(OUT/'protocol.json',dict(seed=71001,evaluation_indices=[1000,1999],display=[32,320],positions=289,placements=289,source_sha256=hashes,evidence='relu(Q/max_position(Q)+0.1*log(max_category_probability)), divided by its spatial maximum. Locked previous joint rule. Unavailable receptive fields masked; blank fields proved negative before rectification.',initialization='All activities zero; no location cue or random asymmetry.',dynamics='a_next = 0.8*a + 0.2*relu(e - 1.5*(sum(a)-a)); synchronous, fixed evidence, up to1000 updates.',parameters='Reuse category-competition inhibition1.5 and update rate0.2; no accuracy-based tuning.',readout='Normalize spatial activities to sum1, then pool the ten category probabilities with those weights. No hard location selection in dynamic readout.',settling='Freeze after10 consecutive steps with max absolute update <1e-7 and winner activity fraction >=0.9999. Report unresolved trials. Strong dominance at0.99 recorded separately.',scope='One frozen model and previously evaluated1000-image subset. This tests dynamics and readout preservation, not independent recognition generalization. No sensory feedback, spatial spotlight gain, multiple objects, or new training. Iterations have no biological time calibration.',compression='63 distinct stimulus placements weighted to289; 63 local offset units per case. Other289-position units have negative score and remain zero from zero initialization; exact omission, not coarse sampling.'))
    activity=np.zeros_like(e);active=np.arange(len(e));stable=np.zeros(len(e),np.int16)
    settled=np.full(len(e),-1,np.int16);first99=np.full(len(e),-1,np.int16)
    snapshots=[];metrics=[];dominances=[];preds=[];t0=time.time()
    pp=np.broadcast_to(prob[:,:63][:,None],(N,len(XS),63,10)).reshape(-1,63,10)
    initial_arg=e.argmax(1)
    for t in range(1,1001):
        old=activity[active];new=step(old,e[active]);delta=abs(new-old).max(1)
        total=new.sum(1);dom=new.max(1)/np.maximum(total,1e-300)
        activity[active]=new
        now99=(dom>=.99)&(first99[active]<0);first99[active[now99]]=t
        good=(delta<1e-7)&(dom>=.9999)
        stable[active]=np.where(good,stable[active]+1,0)
        done=stable[active]>=10;settled[active[done]]=t;active=active[~done]
        if t in STEPS:
            dom=activity.max(1)/activity.sum(1)
            cat=np.einsum('nw,nwc->nc',activity,pp)/activity.sum(1,keepdims=True)
            cat=cat.reshape(N,len(XS),10);prediction=cat.argmax(2)[:,EXPAND]
            acc=float((prediction==labels[:,None]).mean())
            metric=dict(iteration=t,accuracy=acc,reference_category_agreement=float((prediction==reference).mean()),fraction_dominant99=float((dom.reshape(N,len(XS))[:,EXPAND]>=.99).mean()),fraction_settled=float((settled.reshape(N,len(XS))[:,EXPAND]>=0).mean()),unsettled_unique_cases=int(len(active)))
            metrics.append(metric);preds.append(prediction);snapshots.append(activity.reshape(shape)[:,31].copy());dominances.append(dom.reshape(N,len(XS)))
            print(metric,flush=True);dump(OUT/'status.json',dict(stage='running',iteration=t,unsettled_unique_cases=len(active)))
    final=activity.reshape(shape)
    # Resume converged states without freezing, to verify that early termination
    # did not conceal further meaningful dynamics.
    continued=activity.copy()
    for _ in range(100):continued=step(continued,e)
    continuation_change=float(abs(continued-activity).max())
    assert continuation_change<1e-6
    np.testing.assert_array_equal(continued.argmax(1),activity.argmax(1))
    tied=np.zeros((1,2));silent=np.zeros((1,289))
    for _ in range(200):
        tied=step(tied,np.ones((1,2)));silent=step(silent,np.zeros_like(silent))
    np.testing.assert_allclose(tied,[[.4,.4]],atol=1e-12)
    np.testing.assert_array_equal(silent,np.zeros_like(silent))
    # Ordering invariance and exact full289-unit parity on sampled cases.
    checks=[]
    for j in [0,27,156,999]:
        for x in [0,144,288]:
            dd=x-np.arange(289);ix=np.where(abs(dd)<=31,dd+31,63)
            q=quality[j,ix];s=q/q.max()+.1*np.log(prob[j,ix].max(1));ee=np.maximum(s,0);ee/=ee.max()
            aa=np.zeros(289);reverse=aa.copy();tt=int(settled.reshape(N,len(XS))[j,EXPAND[x]]);tt=1000 if tt<0 else tt
            for _ in range(tt):aa=step(aa,ee);reverse=step(reverse,ee[::-1])
            np.testing.assert_allclose(aa,reverse[::-1],atol=1e-10,rtol=1e-10)
            v=abs(dd)<=31;expected=np.zeros(289);expected[v]=final[j,EXPAND[x],dd[v]+31]
            np.testing.assert_allclose(aa,expected,atol=1e-9,rtol=1e-9)
            checks.append(float(abs(aa-expected).max()))
    # The offset order is reversed spatially, but no exact winner ties were broken silently.
    ordered=np.sort(e,axis=1);margin=ordered[:,-1]-ordered[:,-2]
    winners=final.argmax(2);pos=XS[None,:]-(winners-31)
    pos=pos[:,EXPAND]+np.arange(289)[None,:]-XS[EXPAND][None,:]
    last=preds[-1];expanded_settle=settled.reshape(N,len(XS))[:,EXPAND];expanded99=first99.reshape(N,len(XS))[:,EXPAND]
    assert hashes==[hashlib.sha256(p.read_bytes()).hexdigest() for p in files]
    result=dict(metrics=metrics,accuracy=float((last==labels[:,None]).mean()),correct_every_position=int((last==labels[:,None]).all(1).sum()),category_invariant_every_position=int((last==last[:,:1]).all(1).sum()),location_reference_agreement=float((pos==refpos).mean()),category_reference_agreement=float((last==reference).mean()),exact_drive_ties=int((margin==0).sum()),minimum_drive_margin=float(margin.min()),first99_quantiles=np.quantile(expanded99[expanded99>=0],[.5,.9,.95,.99,1]).tolist(),settled_quantiles=np.quantile(expanded_settle[expanded_settle>=0],[.5,.9,.95,.99,1]).tolist(),unsettled_placements=int((expanded_settle<0).sum()),unfrozen_100_update_max_change=continuation_change,symmetric_tie_activity=tied.tolist(),zero_drive_stays_silent=True,full_vs_compact_max_error=max(checks),elapsed_seconds=time.time()-t0)
    np.savez_compressed(OUT/'arrays.npz',steps=STEPS,representative_placements=XS,expansion=EXPAND,evidence=evidence,final_activity=final,interior_traces=np.array(snapshots),dominance=np.array(dominances),predictions=np.array(preds),settled=settled.reshape(N,len(XS)),first99=first99.reshape(N,len(XS)),labels=labels,test_indices=ids,winning_positions=pos)
    dump(OUT/'results.json',result);dump(OUT/'status.json',dict(stage='complete',iteration=1000));print(json.dumps({k:v for k,v in result.items() if k!='metrics'},indent=2),flush=True)
if __name__=='__main__':main()
