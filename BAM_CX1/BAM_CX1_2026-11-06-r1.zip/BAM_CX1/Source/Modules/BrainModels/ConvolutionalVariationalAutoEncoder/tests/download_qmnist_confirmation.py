"""Download only public QMNIST assets; no local material is uploaded."""
from pathlib import Path
import urllib.request,hashlib,json
from freeze_qmnist_confirmation import OUT
assert (OUT/'protocol.sha256').exists()
p=OUT/'downloads';p.mkdir(exist_ok=True)
records=[]
for name in ['qmnist-test-images-idx3-ubyte.gz','qmnist-test-labels-idx2-int.gz','qmnist-train-labels-idx2-int.gz','README.md','LICENSE']:
 url='https://raw.githubusercontent.com/facebookresearch/qmnist/main/'+name
 dest=p/name
 if not dest.exists():
  with urllib.request.urlopen(url,timeout=60) as response:dest.write_bytes(response.read())
 records.append(dict(file=name,url=url,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),bytes=dest.stat().st_size))
 print(name,dest.stat().st_size,flush=True)
(OUT/'download_manifest.json').write_text(json.dumps(records,indent=2)+'\n')
