"""Frozen current-feedback occlusion comparison; masks used only for scoring."""
import os
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['VECLIB_MAXIMUM_THREADS']='2'
import json,hashlib,concurrent.futures
import numpy as np
from argparse import Namespace
import evaluate_relaxation_full_mixtures as base
n=base.n;e=base.e;local=base.local;f=base.f
OUT=n.CAMPAIGN/'relaxation_occlusion_ten_seeds';SIZES=[0,8,12,16];STEPS=[0,8,32,64,128,200,500]
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def run(seed):
 target=OUT/f'seed{seed}';target.mkdir(exist_ok=True)
 def status(t):dump(target/'status.json',dict(stage=t));print(seed,t,flush=True)
 status('loading')
 train,test,labels,tl=e.prepare_data(Namespace(train_count=60000,test_count=10000))
 pairs=json.loads((n.OUT/'results.json').read_text())['protocol']['pairs'];indices=[i for pair in pairs for i in pair];assert len(indices)==40
 clean40=np.stack([e.full.center_and_pad(test[i]) for i in indices]).astype(np.float32)/255
 clean=np.concatenate([clean40]*4);truth=np.tile(tl[indices],4);x=clean.copy();mask=np.zeros_like(x,dtype=bool)
 for k,size in enumerate(SIZES):
  if size:
   lo=16-size//2;mask[k*40:(k+1)*40,lo:lo+size,lo:lo+size]=True
 x[mask]=0;N=len(x)
 folder=n.CAMPAIGN/f'hierarchy_s{seed}';rd=n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit'/f'grouped_softmax_s{seed}.npz';pd=n.CAMPAIGN/'local_linear_patch_decoder_seed1' if seed==71001 else n.CAMPAIGN/'local_linear_patch_decoder_ten_seeds'/f'seed{seed}'
 paths=[folder/'model.state',folder/'codebook_final.npz',rd,pd/'local_decoder.npz'];hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
 state=json.loads(paths[0].read_text())['items']
 def weight(k):
  v=state['CVAE_TwoLayer.Upper.'+k];return np.array(v['value'],np.float32).reshape(v['shape'])
 enc=weight('DIRECT_MEAN_WEIGHTS');eb=weight('DIRECT_MEAN_BIAS');dec=weight('DIRECT_DECODER_WEIGHTS');db=weight('DIRECT_DECODER_BIAS');del state
 with np.load(rd) as z:rw=z['weights'];rb=z['bias']
 with np.load(paths[1]) as z:book=f.prior.Codebook(z['prototypes'])
 with np.load(paths[3]) as z:decoder=z['decoder'].astype(np.float32)
 codes,_,_=e.read_codes(folder/'train_codes.csv',train,labels,128)
 refs=json.loads((n.CAMPAIGN/'category_feedback_diagnostic/reference_indices.json').read_text())['71001'] if seed==71001 else json.loads((pd/'feedback_inference/reference_indices.json').read_text())
 ids=np.array([refs[str(c)] for c in range(10)]);rc=codes[ids].astype(np.float32)
 def encode(p):return p.reshape(len(p),-1)@enc+eb
 def decode(z):
  v=(z@dec+db).reshape(-1,64,676);v-=v.max(1,keepdims=True);return v-np.log(np.exp(v).sum(1,keepdims=True))
 def probs(z):return n.softmax(z@rw+rb).reshape(-1,10,20).sum(2)
 def render(z):return np.clip(local.overlap(np.exp(decode(z)).transpose(0,2,1)@decoder),0,1)
 rp=np.exp(decode(rc.reshape(80,128))).reshape(10,8,64,676)
 b=np.stack([book.process(v,False,.01,.08)[0].reshape(64,676) for v in x]);z0=encode(b);pr0=probs(z0);a0=pr0/pr0.max(1,keepdims=True);chosen=((z0[:,None,None]-rc[None])**2).sum(3).argmin(2);im0=render(z0)
 outputs=[];activities=[];change_arrays=[];rows=[]
 for method in ['none','relaxation']:
  p=b.copy();a=a0.copy();pr=pr0.copy();acts=[a.copy()];ims=[im0.copy()];changes=[]
  for step in range(1,501):
   an=.8*a+.2*np.maximum(pr/pr.max(1,keepdims=True)-1.5*(a.sum(1,keepdims=True)-a),0)
   if method=='none':pn=b
   else:
    ww=an/an.sum(1,keepdims=True);Q=np.zeros_like(p)
    for c in range(10):Q+=ww[:,c,None,None]*rp[c,chosen[:,c]]
    pn=.8*p+.2*(.5*b+.5*Q)
   changes.append(np.stack([abs(pn-p).max((1,2)),abs(an-a).max(1)],1));p=pn;a=an
   if method!='none':z=encode(p);pr=probs(z)
   acts.append(a.copy())
   if step in STEPS:ims.append(im0.copy() if method=='none' else render(z))
   if step%100==0:status(f'{method} {step}/500')
  acts=np.array(acts);ims=np.array(ims);ch=np.array(changes);wins=acts.argmax(2)
  assert np.isfinite(p).all();np.testing.assert_allclose(p.sum(1),1,atol=5e-6)
  if method=='none':np.testing.assert_array_equal(ims[-1],ims[0])
  outputs.append(ims);activities.append(acts);change_arrays.append(ch)
  for j in range(N):
   err=(ims[-1,j]-clean[j])**2;hidden=mask[j];stroke=hidden&(clean[j]>.25);bg=hidden&~(clean[j]>.25)
   sw=(np.flatnonzero(np.diff(wins[:,j])!=0)+1).tolist()
   rows.append(dict(seed=seed,method=method,case_index=j,test_index=int(indices[j%40]),size=SIZES[j//40],truth=int(truth[j]),initial_winner=int(wins[0,j]),final_winner=int(wins[-1,j]),switch_iterations=sw,settled=bool(ch[-10:,j].max()<1e-5),settled_at200=bool(ch[190:200,j].max()<1e-5),hidden_mse=float(err[hidden].mean()) if hidden.any() else None,visible_mse=float(err[~hidden].mean()),full_mse=float(err.mean()),hidden_stroke_mse=float(err[stroke].mean()) if stroke.any() else None,hidden_background_mse=float(err[bg].mean()) if bg.any() else None,hidden_stroke_pixels=int(stroke.sum()),hidden_stroke_intensity=float(ims[-1,j][stroke].mean()) if stroke.any() else None,hidden_target_intensity=float(clean[j][stroke].mean()) if stroke.any() else None))
 status('scoring pixel 5NN')
 outputs=np.array(outputs);tp=np.stack([e.full.center_and_pad(v) for v in train]).astype(np.float32)/255
 pixel=e.five_nearest_predictions(tp.reshape(60000,-1),labels,outputs[:,-1].reshape(-1,1024)).reshape(2,N)
 for mi,method in enumerate(['none','relaxation']):
  for j,row in enumerate([v for v in rows if v['method']==method]):row.update(pixel_prediction=int(pixel[mi,j]),pixel_winner_agreement=bool(pixel[mi,j]==row['final_winner']))
 assert [hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]==hashes
 # The clean baseline must reproduce the earlier unoccluded full-mixture comparison.
 old=json.loads((base.OUT/f'seed{seed}_results.json').read_text())['cases']
 for mi,method in enumerate(['none','relaxation']):
  for j in range(40):
   ci=(j//2)*11+(10 if j%2==0 else 0);previous=next(v for v in old if v['method']==method and v['case_index']==ci)
   row=rows[mi*N+j];assert row['final_winner']==previous['final_winner'];assert row['pixel_prediction']==previous['pixel_prediction']
 np.savez_compressed(target/'arrays.npz',clean=clean,input=x,mask=mask,snapshots=outputs,steps=STEPS,activities=activities,changes=change_arrays,chosen_reference_slots=chosen,reference_ids=ids)
 dump(target/'results.json',dict(cases=rows,weights_unchanged=True,checkpoint_sha256=hashes,clean_endpoint_labels_match_previous=True));status('complete');return seed

def main():
 OUT.mkdir(exist_ok=True)
 dump(OUT/'protocol.json',dict(seeds=list(range(71001,71011)),stimuli='Same40 digit3/8 test images from20 earlier pairs; central black square sizes0,8,12,16 in32x32 images;160 inputs/model',methods=['none','relaxation'],iterations=500,alpha=.2,topdown_fraction=.5,selection='All40 single-digit endpoints; no outcome filtering. Same masks and exemplars across models.',inference='No clean target, true category or occlusion mask supplied. Category competition autonomous; nearest-of-eight reference fixed from occluded input. Frozen models, no learning.',scoring='Mean pixel squared error separately inside/outside known mask against original clean image; secondary hidden stroke/background error with clean intensity threshold.25. Clean0 condition has undefined hidden error. Pixel5NN and network categorization separate.',statistics='Paired differences aggregated per training seed; t9 descriptive95% intervals. Shared reused40 images, exploratory not held-out confirmation.',scope='Black deletion is not explicitly marked as missing; no precision weighting or spatial attention introduced.'))
 with concurrent.futures.ProcessPoolExecutor(max_workers=2) as pool:
  for seed in pool.map(run,range(71001,71011)):print('finished',seed,flush=True)
 cases=[v for seed in range(71001,71011) for v in json.loads((OUT/f'seed{seed}/results.json').read_text())['cases']]
 dump(OUT/'results.json',dict(cases=cases));print('ALL COMPLETE',flush=True)
if __name__=='__main__':main()
