"""Full MNIST training followed by matched, frozen-model feedback diagnostics."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
from argparse import Namespace
import xml.etree.ElementTree as ET
import run_mnist_two_layer as e

HERE = Path(__file__).resolve().parent
CAMPAIGN = e.OUTPUT / 'n60000_test10000_ticks1800000_patch_codebook64_kernel7_valid_upper128_soft_tau_0p08_upper_categorical'

def status(stage, **details):
    data = dict(stage=stage, pid=os.getpid(), updated=time.strftime('%Y-%m-%dT%H:%M:%S%z'), **details)
    temporary = CAMPAIGN / 'status.tmp'
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    temporary.replace(CAMPAIGN / 'status.json')
    print(json.dumps(data), flush=True)

def main():
    CAMPAIGN.mkdir(parents=True, exist_ok=True)
    protocol = dict(train_count=60000, test_count=10000, passes=30, ticks=1800000,
        seeds=[71001,71002,71003], code_count=64, kernel=7, padding='valid', temperature=.08,
        upper_latent_size=128, upper_beta=.003, upper_loss='categorical',
        simultaneous_local_training=True, interlayer_backpropagation=False,
        classifier='raw-code Euclidean 5NN on all 60000 training codes',
        references='Eight per category, selected from full training population by the existing central-90% diversity rule.',
        diagnostics='Repeat externally cued feedback and autonomous full-population competition on the same image indices and gains as the small-data tests.',
        interpretation='Measure reconstruction agreement with winning category and input preservation separately from ground-truth recognition. Pixel 5NN readout also uses full training population, so comparisons change both representation training and classifier population.')
    (CAMPAIGN / 'campaign_protocol.json').write_text(json.dumps(protocol, indent=2) + '\n')
    for seed in protocol['seeds']:
        status('training_and_extraction', seed=seed, target_ticks=1800000)
        subprocess.run([sys.executable, str(HERE/'run_mnist_patch_codebook.py'),
            '--train-count','60000','--test-count','10000','--ticks','1800000',
            '--seed',str(seed),'--agent',f'full_mnist_feedback_{seed}',
            '--code-count','64','--kernel','7','--temperature','.08','--upper-loss','categorical'], check=True)
        d = CAMPAIGN / f'hierarchy_s{seed}'
        status('native_decoder_parity', seed=seed)
        tree = ET.parse(d/'extract_test.ikg')
        root = tree.getroot()
        root.find("module[@name='Images']").set('filecount','8')
        root.find("module[@name='Record']").set('filename','categorical_parity.csv')
        ET.SubElement(root,'connection',source='Upper.OUTPUT',target='Record.INPUT',delay='0',label='topdown')
        tree.write(d/'categorical_parity.ikg',encoding='unicode')
        args=Namespace(ikaros=e.ROOT/'Bin/ikaros_categorical',python_executable=sys.executable)
        e.run_ikaros(args,d/'categorical_parity.ikg',d/'categorical_parity.log',8,load=d/'model.state')
    import evaluate_category_feedback as feedback
    import evaluate_full_population_competition as competition
    feedback.BASE = CAMPAIGN
    feedback.OUT = CAMPAIGN/'category_feedback_diagnostic'
    status('externally_cued_feedback')
    feedback.main(train_count=60000,test_count=10000)
    competition.OUT = CAMPAIGN/'category_competition_full_population'
    status('autonomous_competition_feedback')
    competition.main(train_count=60000,test_count=10000,reference_root=feedback.OUT)
    results = [json.loads((CAMPAIGN/f'hierarchy_s{s}'/'result_knn5.json').read_text()) for s in protocol['seeds']]
    import numpy as np
    accuracy = [r['classifier_accuracy'] for r in results]
    summary = dict(protocol=protocol, per_seed=results, accuracy_mean=float(np.mean(accuracy)), accuracy_sample_sd=float(np.std(accuracy,ddof=1)),
        feedback=json.loads((feedback.OUT/'results.json').read_text())['aggregate'],
        competition=json.loads((competition.OUT/'results.json').read_text())['aggregate'])
    (CAMPAIGN/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    status('complete', accuracy_mean=summary['accuracy_mean'], accuracy_sample_sd=summary['accuracy_sample_sd'])

if __name__ == '__main__':
    try:
        main()
    except BaseException as exc:
        status('failed', error=type(exc).__name__)
        traceback.print_exc()
        raise
