"""Score saved model outputs and simple baselines. Never run recurrent inference."""
import os
os.environ['OPENBLAS_NUM_THREADS']='4';os.environ['VECLIB_MAXIMUM_THREADS']='4'
import time,traceback
import numpy as np
import qmnist_confirmation_common as q
import run_qmnist_confirmation as old
import run_qmnist_spatial_extension as ext
import run_qmnist_retrieval_controls as retrieval
from run_independent_image_evaluator import OUT,read,predict,freeze
MODES=['input','pixel_reference','decoded_reference','none','full']
def masked(v,mask):return float(v[mask].mean()) if mask.any() else None
def patch(scene,pos):return old.crop(scene,pos)
def probs(weights,images):return predict(weights,np.asarray(images)).argmax(1)
def main():
 freeze()
 while not (OUT/'evaluator_frozen.json').exists():time.sleep(30)
 frozen=read(OUT/'evaluator_frozen.json');assert q.sha(OUT/'evaluator_weights.npz')==frozen['sha256']
 with np.load(OUT/'evaluator_weights.npz') as z:weights={k:z[k] for k in z.files}
 if not (OUT/'calibration.json').exists():
  raw=q.b.E.full.RAW_ROOT;test=q.b.E.full.read_idx_images(raw/'t10k-images-idx3-ubyte.gz',10000);labels=q.b.E.full.read_idx_labels(raw/'t10k-labels-idx1-ubyte.gz',10000);test=np.stack([q.b.E.full.center_and_pad(v) for v in test]).astype(np.float32)/255;pred=probs(weights,test)
  meta=read(q.OUT/'focal_stimuli.json');ids=[r['case'] for r in meta if r['task']=='clean']
  with np.load(q.OUT/'focal_stimuli.npz') as z:clean=z['input'][ids]
  cp=probs(weights,clean);truth=np.array([meta[i]['truth'] for i in ids]);q.dump(OUT/'calibration.json',dict(mnist_accuracy=float((pred==labels).mean()),mnist_n=10000,qmnist_clean_accuracy=float((cp==truth).mean()),qmnist_n=100,evaluator_frozen_before_scoring=True));np.savez_compressed(OUT/'calibration_predictions.npz',mnist=pred,qmnist_clean=cp)
 if not (OUT/'focal_results.json').exists():
  focal=[]
  for seed in [71001,71002,71003]:
   for mode in retrieval.MODES:
    source=retrieval.OUT/f'model{seed}_{mode}';rr=read(source.with_suffix('.json'))
    with np.load(source.with_suffix('.npz')) as z:images=z['images']
    pred=probs(weights,images)
    for r,label in zip(rr,pred):
     t=r['truth'];r.update(mlp_category=int(label),mlp_correct=None if t is None else bool(label==t),mlp_agreement=bool(label==r['category']),mlp_full_agreement=bool(label==r['full_category']),mlp_initial_agreement=bool(label==r['initial_category']))
     r['evaluator_accuracy_difference']=None if t is None else float(r['mlp_correct'])-float(r['pixel_correct']);r['evaluator_agreement_difference']=float(r['mlp_full_agreement'])-float(r['full_winner_agreement'])
    focal+=rr;q.dump(OUT/'scoring_status.json',dict(stage='focal',completed=len(focal),total=18630));print('focal',len(focal),flush=True)
  q.dump(OUT/'focal_results.json',focal)
 raw=q.b.E.full.RAW_ROOT;train=q.b.E.full.read_idx_images(raw/'train-images-idx3-ubyte.gz',60000)
 jobs=read(q.OUT/'spatial_jobs.json');meta=read(q.OUT/'spatial_stimuli.json');ejobs=read(ext.OUT/'jobs.json');emeta=read(ext.OUT/'stimuli.json')
 with np.load(q.OUT/'spatial_stimuli.npz') as z:xx=z['input'];cc=z['clean'];masks=z['mask']
 with np.load(ext.OUT/'stimuli.npz') as z:ex=z['input'];components=z['components']
 allrows=[]
 for seed in [71001,71002,71003]:
  file=OUT/f'spatial_model{seed}.json'
  if file.exists():allrows+=read(file);continue
  m,front=q.load_model(seed);rpixels={int(i):q.b.E.full.center_and_pad(train[i]).astype(np.float32)/255 for i in m['ids'].ravel()};decoded=q.b.render(m,m['codes'][m['ids'].ravel()]).reshape(10,8,32,32);rows=[]
  for mm in meta:
   pairjobs=[next(j for j in jobs if j['case']==mm['case'] and j['task']=='completion' and j['feedback']==on) for on in [False,True]];arr=[];state=[]
   for j in pairjobs:
    path=q.OUT/'spatial'/f"model{seed}_job{j['job']:03d}";state.append(read(path/'result.json'))
    with np.load(path/'arrays.npz') as z:arr.append({k:z[k] for k in ['final_field_predictions','reference_slots']})
   np.testing.assert_array_equal(arr[0]['reference_slots'],arr[1]['reference_slots']);pos=mm['target_position'];x=xx[mm['case']];clean=cc[mm['case']];mask=masks[mm['case']];initial=int(front.infer_pixels(patch(x,pos)[None])[0].argmax(1)[0]);slot=int(arr[1]['reference_slots'][pos+31,initial]);rid=int(m['ids'][initial,slot]);refscene=np.zeros_like(x);refscene[:,pos:pos+32]=rpixels[rid];decscene=np.zeros_like(x);decscene[:,pos:pos+32]=decoded[initial,slot]
   cueimages=[];selectedimages=[];sel=state[1]['location']
   for mode in MODES:
    scene={'input':x,'pixel_reference':refscene,'decoded_reference':decscene}.get(mode)
    im=patch(scene,pos) if scene is not None else arr[int(mode=='full')]['final_field_predictions'][pos+31];sim=None if sel is None else patch(scene,sel) if scene is not None else arr[int(mode=='full')]['final_field_predictions'][sel+31]
    row=dict(seed=seed,group='completion',case=mm['case'],cluster=str(mm['pair']),level=mm['deletion'],mode=mode,truth=mm['target_category'],full_category=state[1]['category'],reference_category=initial,reference_slot=slot,reference_id=rid,selected_location=sel)
    for name,field,image in [('target',pos,im),('selected',sel,sim)]:
     for region in ['hidden','visible','foreground','all']:row[name+'_'+region+'_mse']=None
     row[name+'_mlp_correct']=None;row[name+'_mlp_full_agreement']=None
     if image is not None:
      target=patch(clean,field);maskfield=patch(mask,field);error=(image-target)**2;label=int(probs(weights,image[None])[0]);row[name+'_mlp_category']=label;row[name+'_mlp_correct']=label==row['truth'];row[name+'_mlp_full_agreement']=label==row['full_category']
      for region,regionmask in [('hidden',maskfield),('visible',~maskfield),('foreground',target>.05),('all',np.ones_like(maskfield))]:row[name+'_'+region+'_mse']=masked(error,regionmask)
    rows.append(row);cueimages.append(im);selectedimages.append(np.full((32,32),np.nan) if sim is None else sim)
   np.savez_compressed(OUT/f'completion_{seed}_{mm["case"]:03d}.npz',cue_images=cueimages,selected_images=selectedimages,input=patch(x,pos),clean=patch(clean,pos),mask=patch(mask,pos),modes=MODES)
  for j in ejobs:
   mm=emeta[j['case']]
   if not j['feedback'] or mm['group'] not in ['overlap','isolated']:continue
   off=next(a for a in ejobs if a['case']==j['case'] and a['target']==j['target'] and not a['feedback']);arr=[]
   for job in [off,j]:
    with np.load(ext.OUT/'trials'/f"model{seed}_job{job['job']:03d}"/'arrays.npz') as z:arr.append({k:z[k] for k in ['final_render','reference_slots']})
   np.testing.assert_array_equal(arr[0]['reference_slots'],arr[1]['reference_slots']);pos=j['spatial_cue'];cat=j['category_cue'];slot=int(arr[1]['reference_slots'][pos+31,cat]);rid=int(m['ids'][cat,slot]);x=ex[j['case']];comp=components[j['case']];own=comp[j['target']];other=comp[1-j['target']];ownmask=(own>=.25)&(other<=.05);othermask=(other>=.25)&(own<=.05);union=np.maximum(own,other)>.05
   refscene=np.zeros_like(x);refscene[:,pos:pos+32]=rpixels[rid];decscene=np.zeros_like(x);decscene[:,pos:pos+32]=decoded[cat,slot];scenes=[x,refscene,decscene,arr[0]['final_render'],arr[1]['final_render']];labels=probs(weights,[patch(im,pos) for im in scenes])
   for mode,im,label in zip(MODES,scenes,labels):
    rows.append(dict(seed=seed,group=mm['group'],case=j['case'],cluster=mm['cluster'],level=mm['separation'],target=j['target'],mode=mode,truth=cat,reference_category=cat,reference_slot=slot,reference_id=rid,mlp_category=int(label),mlp_requested_agreement=bool(label==cat),union_mse=masked((im-own)**2,union),foreground_mse=masked((im-own)**2,own>.05),own_unique_mean=masked(im,ownmask),other_unique_mean=masked(im,othermask),own_unique_pixels=int(ownmask.sum()),other_unique_pixels=int(othermask.sum())))
   np.savez_compressed(OUT/f'overlap_{seed}_{j["job"]:03d}.npz',scenes=scenes,components=comp,cue_position=pos,modes=MODES)
  assert front.unchanged();q.dump(file,rows);allrows+=rows;q.dump(OUT/'scoring_status.json',dict(stage='spatial',completed=len(allrows),total=2100));print('spatial',len(allrows),flush=True)
 for r in allrows:
  if r['group']=='completion':continue
  for control in ['input','none']:
   b=next(b for b in allrows if b['seed']==r['seed'] and b['case']==r['case'] and b.get('target')==r.get('target') and b['group']==r['group'] and b['mode']==control)
   defined=r['own_unique_mean'] is not None and r['other_unique_mean'] is not None;r['joint_vs_'+control]=None if not defined else r['own_unique_mean']-b['own_unique_mean']>=-1e-6 and r['other_unique_mean']-b['other_unique_mean']<-1e-6
  if r['group']=='overlap':
   opposite=next(b for b in allrows if b['seed']==r['seed'] and b['case']==r['case'] and b.get('target')==1-r['target'] and b['group']=='overlap' and b['mode']==r['mode']);r['cue_reversal']=None if r['own_unique_mean'] is None else r['own_unique_mean']-opposite['other_unique_mean']
 assert len(allrows)==2100;q.dump(OUT/'spatial_results.json',allrows);assert q.sha(OUT/'evaluator_weights.npz')==frozen['sha256'];q.dump(OUT/'scoring_status.json',dict(complete=True,focal=18630,spatial=2100,evaluator_unchanged=True));print('Scoring complete',flush=True)
if __name__=='__main__':
 try:main()
 except Exception:q.dump(OUT/'scoring_error.json',dict(error=traceback.format_exc()));raise
