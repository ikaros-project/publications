"""Rescore saved spatial completion endpoints for Reviewer 1, Comment 4.

No inference, retraining, field realignment, or output modification is performed.
"""
from pathlib import Path
import csv
import hashlib
import json
import numpy as np

STUDY = Path(__file__).resolve().parents[5]
DATA = STUDY / 'UserData/output/cvae_mnist_two_layer/n60000_test10000_ticks1800000_patch_codebook64_kernel7_valid_upper128_soft_tau_0p08_upper_categorical/neural_spatial_architecture_seed1/spatial_overlap_pilot/fixed_spatial_cue/article_fixed_model_suite'
OUT = DATA / 'selected_field_analysis_20261105'


def crop(a, position):
    """Scene-coordinate crop with the model's zero extension."""
    padded = np.pad(a, ((0, 0), (31, 31)), mode='constant')
    return padded[:, position + 31:position + 63]


def mse(prediction, truth, mask):
    return float(np.mean((prediction[mask] - truth[mask]) ** 2)) if mask.any() else None


def mean(values):
    values = [v for v in values if v is not None]
    return float(np.mean(values)) if values else None


def main():
    OUT.mkdir(exist_ok=True)
    jobs = [r for r in json.loads((DATA / 'results.json').read_text()) if r['group'] == 'completion']
    assert len(jobs) == 120
    with np.load(DATA / 'stimuli.npz') as z:
        clean, masks = z['clean'], z['mask']
    rows = []
    for job in jobs:
        with np.load(DATA / f"trial{job['job']:04d}/arrays.npz") as z:
            activity = z['spatial_trace'][-1]
            assert float(activity.sum()) > 1e-7
            location = int(activity.argmax()) - 31
            assert location == job['location']
            predictions = z['final_field_predictions']
            target = job['metadata']['positions'][0]
            r = dict(job=job['job'], case=job['case'], pair=job['metadata']['pair'], deletion=job['metadata']['occlusion'], condition=job['condition'], target=target, selected=location, offset=location-target, absolute_offset=abs(location-target))
            for name, position in [('target', target), ('selected', location)]:
                truth = crop(clean[job['case']], position)
                mask = crop(masks[job['case']], position)
                pred = predictions[position + 31]
                assert truth.shape == mask.shape == pred.shape == (32, 32)
                for region, selected in [('hidden', mask), ('visible', ~mask), ('all', np.ones_like(mask, bool))]:
                    r[f'{name}_{region}_mse'] = mse(pred, truth, selected)
            r['max_prediction_difference'] = float(abs(predictions[target+31]-predictions[location+31]).max())
            for region in ['hidden', 'visible', 'all']:
                a, b = r[f'selected_{region}_mse'], r[f'target_{region}_mse']
                r[f'{region}_selected_minus_target'] = None if a is None else a-b
            rows.append(r)
    rows.sort(key=lambda r: r['job'])
    aggregates=[]
    for size in [0,8,12]:
        for mode in ['feedback','feedback_off']:
            rr=[r for r in rows if r['deletion']==size and r['condition']==mode]
            aggregates.append(dict(deletion=size,condition=mode,n=len(rr),exact_locations=sum(r['offset']==0 for r in rr),mean_absolute_offset=mean([r['absolute_offset'] for r in rr]),**{k:mean([r[k] for r in rr]) for k in rr[0] if k.endswith('_mse') or k.endswith('_minus_target')}))
    contrasts=[]
    for size in [8,12]:
        rr=[r for r in rows if r['deletion']==size and r['condition']=='feedback']
        delta=[]
        for r in rr:
            off=next(v for v in rows if v['case']==r['case'] and v['condition']=='feedback_off')
            assert r['selected']==off['selected']
            delta.append(r['selected_hidden_mse']-off['selected_hidden_mse'])
        contrasts.append(dict(deletion=size,n=len(delta),hidden_improved=sum(d<0 for d in delta),mean_hidden_feedback_minus_off=mean(delta)))
    # Cross-check the main manuscript's rounded target-field values.
    expected=[(None,.02549),(None,.00729),(.25519,.02466),(.34107,.00762),(.25755,.01922),(.33649,.00713)]
    for r,(h,v) in zip(aggregates,expected):
        assert abs(r['target_visible_mse']-v)<.0000051
        if h is not None: assert abs(r['target_hidden_mse']-h)<.0000051
    checks=dict(all_selected_positions_match_saved_activity=True,all_120_exact_target_locations=all(r['offset']==0 for r in rows),max_field_prediction_difference=max(r['max_prediction_difference'] for r in rows),manuscript_table_reproduced_to_printed_precision=True,matched_feedback_off_locations=True)
    assert checks['all_120_exact_target_locations'] and checks['max_field_prediction_difference']==0
    result=dict(protocol=dict(source='Saved fixed-model article suite completion endpoints',n_trials=120,n_original_pairs=20,deletion_sizes=[0,8,12],fields='32x32 local predictions at argmax of final spatial activity, offset -31 for padding',scoring='Prediction, clean scene and deletion mask evaluated at identical scene coordinates. Visible pixels are the complement of the deletion mask within each field.',scope='One frozen trained model, reused stimuli and paired feedback conditions. No new inference or tuning. Original outputs unchanged.',correlation='Undefined because localization error is zero for every observation.',analysis_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),checks=checks,aggregates=aggregates,contrasts=contrasts,rows=rows)
    (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    with (OUT/'per_trial.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    lines=['# Selected-field spatial completion analysis','', '## Procedure','', 'We rescored all 120 saved completion endpoints: 20 target–distractor pairs, intact or with 8×8 or 12×12 deletions, with content feedback on or off. The model-selected field was the maximum of final spatial activity. Its position was independently recovered from the saved activity arrays and checked against the recorded result. Local-field predictions, the clean display and deletion masks were cropped at matching scene coordinates. Feedback-off outputs were scored at the same locations. No inference was rerun and no parameters or source outputs were changed.','', '## Results','', '**Every trial selected the exact target field.** All 120 signed and absolute localization errors were zero pixels, in both feedback conditions and at every deletion size. Selected- and target-field predictions were exactly identical, as were all reconstruction scores. The original manuscript table was reproduced to its printed precision.','', '| Deletion | Feedback | N | Target hidden MSE | Selected hidden MSE | Target visible MSE | Selected visible MSE |','| --- | --- | ---: | ---: | ---: | ---: | ---: |']
    fmt=lambda v:'—' if v is None else f'{v:.5f}'
    for r in aggregates:
        lines.append(f"| {r['deletion']} | {'On' if r['condition']=='feedback' else 'Off'} | {r['n']} | {fmt(r['target_hidden_mse'])} | {fmt(r['selected_hidden_mse'])} | {fmt(r['target_visible_mse'])} | {fmt(r['selected_visible_mse'])} |")
    lines+=['','At both deletion sizes, feedback reduced hidden-region error in 18/20 pairs at the selected field, exactly as at the known target field. Every paired selected-minus-target MSE difference was zero.','', '## Interpretation and limits','', 'The original spatial completion result is unchanged by evaluating the model-selected rather than known target field in this stimulus set. A correlation with localization error cannot be estimated because localization error has no variation. These results therefore do not establish robustness to nonzero spatial offsets. The explicit spatial cue and this particular set of completion inputs should be retained when describing the scope. The observations reuse 20 original pairs in one trained model and are not independent confirmation.','', 'A scatterplot would place every observation at zero localization error and would not add useful evidence. The table and explicit exact-localization count are more informative. Per-trial scores are retained in per_trial.csv.','', 'The manuscript and reviewer response have not been modified.']
    report='\n'.join(lines)+'\n'
    (OUT/'REPORT.md').write_text(report)
    (STUDY/'Manuscript/selected_field_completion_source_notes.md').write_text(report)
    print(json.dumps(dict(checks=checks,aggregates=aggregates,contrasts=contrasts),indent=2))

if __name__=='__main__':main()
