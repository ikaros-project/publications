"""All-outcome spatial confirmation analysis with crossed clustered intervals."""
import json,csv
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import run_qmnist_spatial_extension as r
q=r.q;OUT=r.OUT

def estimate(rows,key):
 seeds=q.protocol()['models'];clusters=sorted(set(v['cluster'] for v in rows));a=np.full((3,len(clusters)),np.nan)
 for i,s in enumerate(seeds):
  for j,c in enumerate(clusters):
   vv=[float(v[key]) for v in rows if v['seed']==s and v['cluster']==c and v[key] is not None]
   if vv:a[i,j]=np.mean(vv)
 if not np.isfinite(a).any():return dict(mean=None,ci95=None,n_valid=0,n_total=len(rows),by_model=[])
 rng=np.random.default_rng(2026110511);boot=[]
 for _ in range(2000):
  sample=a[np.ix_(rng.integers(0,3,3),rng.integers(0,len(clusters),len(clusters)))];vv=sample[np.isfinite(sample)]
  if len(vv):boot.append(float(vv.mean()))
 return dict(mean=float(np.nanmean(a)),ci95=np.quantile(boot,[.025,.975]).tolist(),n_valid=sum(v[key] is not None for v in rows),n_total=len(rows),n_clusters=len(clusters),by_model=[dict(model=s,mean=None if not np.isfinite(a[i]).any() else float(np.nanmean(a[i]))) for i,s in enumerate(seeds)])

def main():
 rows=json.loads((OUT/'results.json').read_text());assert len(rows)==870
 checks=json.loads((OUT/'parity/checks.json').read_text());trans=[v for v in rows if v['group']=='translation'];selection=[v for v in rows if v['group']=='selection'];over=[v for v in rows if v['group'] in ['overlap','isolated']]
 f=json.loads((OUT/'focal_comparison.json').read_text());catmap={str(k):v[0] for k,v in json.loads((OUT/'stimuli_manifest.json').read_text())['source_metadata'].items()}
 focal=[dict(seed=v['seed'],cluster=str(v['id']),correct=v['category']==catmap[str(v['id'])]) for v in f]
 translation=[]
 for pos in [0,16,144,272,288]:
  rr=[v for v in trans if v['positions'][0]==pos]
  for v in rr:v['absolute_offset']=None if v['offset'] is None else abs(v['offset'])
  translation.append(dict(position=pos,accuracy=estimate(rr,'category_correct'),localization=estimate(rr,'located'),absolute_offset=estimate(rr,'absolute_offset')))
 consistent=[]
 for seed in q.protocol()['models']:
  for c in sorted(set(v['cluster'] for v in trans)):
   rr=[v for v in trans if v['seed']==seed and v['cluster']==c];assert len(rr)==5
   consistent.append(dict(seed=seed,cluster=c,consistent=all(v['category'] is not None for v in rr) and len(set(v['category'] for v in rr))==1,all_correct=all(v['category_correct'] for v in rr)))
 sd=[]
 for v in selection:
  if v['target'] is None:continue
  neutral=next(b for b in selection if b['seed']==v['seed'] and b['case']==v['case'] and b['target'] is None);k=v['target']
  sd.append(dict(seed=v['seed'],cluster=v['cluster'],target=k,correct=v['category_correct'],located=v['located'],target_sensory_change=v['sensory_foreground'][k]-neutral['sensory_foreground'][k],distractor_sensory_change=v['sensory_foreground'][1-k]-neutral['sensory_foreground'][1-k]))
 pairs=[]
 for v in over:
  if not v['feedback']:continue
  off=next(b for b in over if b['seed']==v['seed'] and b['case']==v['case'] and b['target']==v['target'] and not b['feedback'])
  d=dict(seed=v['seed'],cluster=v['cluster'],group=v['group'],separation=v['separation'],target=v['target'],case=v['case'],local_correct=v['local_correct'],located=v['located'],own_unique_pixels=v['own_unique_pixels'],other_unique_pixels=v['other_unique_pixels'])
  for key in ['own_unique_mean','other_unique_mean','union_mse','target_foreground_mse']:d[key+'_change']=None if v[key] is None or off[key] is None else v[key]-off[key]
  own=d['own_unique_mean_change'];other=d['other_unique_mean_change'];d['joint_success']=None if own is None or other is None else own>=-1e-6 and other<-1e-6
  d['cue_own_contrast']=None
  if v['group']=='overlap':
   opp=next(b for b in over if b['seed']==v['seed'] and b['case']==v['case'] and b['target']!=v['target'] and b['feedback'])
   d['cue_own_contrast']=None if v['own_unique_mean'] is None else v['own_unique_mean']-opp['other_unique_mean']
  pairs.append(d)
 overlap=[]
 for group in [0,8,40,'isolated']:
  rr=[v for v in pairs if (v['group']=='isolated' if group=='isolated' else v['group']=='overlap' and v['separation']==group)]
  overlap.append(dict(group=group,n=len(rr),joint_success_count=sum(v['joint_success'] is True for v in rr),joint_defined=sum(v['joint_success'] is not None for v in rr),metrics={key:estimate(rr,key) for key in ['joint_success','own_unique_mean_change','other_unique_mean_change','union_mse_change','target_foreground_mse_change','cue_own_contrast','local_correct','located']}))
 summary=dict(n=870,settled=sum(v['settled'] for v in rows),parity=checks,protocol_sha256=q.sha(OUT/'protocol.json'),focal_accuracy=estimate(focal,'correct'),translation=translation,translation_consistency=estimate(consistent,'consistent'),translation_all_correct=estimate(consistent,'all_correct'),selection={key:estimate(sd,key) for key in ['correct','located','target_sensory_change','distractor_sensory_change']},overlap=overlap,selection_paired=sd,overlap_paired=pairs)
 r.dump('summary.json',summary)
 with (OUT/'overlap_paired.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(pairs[0]));w.writeheader();w.writerows(pairs)
 fmt=lambda e,rate=False:'undefined' if e['mean'] is None else (f"{100*e['mean']:.1f}% [{100*e['ci95'][0]:.1f}, {100*e['ci95'][1]:.1f}]" if rate else f"{e['mean']:.5f} [{e['ci95'][0]:.5f}, {e['ci95'][1]:.5f}]")
 lines=['# Fresh-image spatial confirmation','', 'The protocol was frozen before selecting or evaluating40 additional QMNIST images, excluding all230 images in the earlier confirmation. Source identifiers and exact raw-image content were checked against original MNIST. The same three existing models, original reference banks and all inference parameters were retained. Twenty images(two/category) supplied the translation tests. Ten distinct-category pairs supplied the other tests, with every category appearing once as each member. Pair images were disjoint from translation images. No response screening occurred.','', 'All870 fixed600-update endpoints were retained. Intervals are95% percentile crossed bootstrap intervals over trained models and source-image/pair clusters,2000 replicates. Repeated positions,cues and conditions stay within the source cluster. Only three models and ten object pairs limit precision. This study does not retest distractor load or blank-display imagery.','',f"Settled endpoints: {summary['settled']}/870. The new runner exactly reproduced a saved trial before new-model evaluation. Checkpoints remained unchanged.",'', '## Translation tolerance','', 'Centered focal category accuracy: '+fmt(summary['focal_accuracy'],True)+'.','','| Field origin | Spatial category accuracy | Localization | Mean absolute offset |','| ---: | --- | --- | --- |']
 for v in translation:lines.append(f"| {v['position']} | {fmt(v['accuracy'],True)} | {fmt(v['localization'],True)} | {fmt(v['absolute_offset'])} |")
 lines+=['','Category consistency across all five positions: '+fmt(summary['translation_consistency'],True)+'.','', '## Two-object spatial selection','', 'Each unchanged intact display received neutral,A-location andB-location cues with content feedback active and no category cue. Cued category accuracy: '+fmt(summary['selection']['correct'],True)+'. Localization: '+fmt(summary['selection']['located'],True)+'.','', 'Mean cued-target sensory foreground change relative to neutral: '+fmt(summary['selection']['target_sensory_change'])+'. Distractor change: '+fmt(summary['selection']['distractor_sensory_change'])+'.','', '## Overlap, separation and isolated controls','', 'Category and spatial cues selected each object in turn. Feedback-on and feedback-off trials retained every other pathway. At full overlap the spatial cues were identical. Output is the original uniformly pooled whole-display reconstruction. Masks are scoring data only. Joint success requires preserved own unique-feature intensity(change>=−1e−6) and decreased competitor unique-feature intensity(change<−1e−6). Empty masks are undefined and explicitly counted.','','| Separation/control | Joint success | Own unique-feature change | Competitor unique-feature change | Union MSE change | Cue-reversal own contrast |','| --- | --- | --- | --- | --- | --- |']
 for v in overlap:
  m=v['metrics'];lines.append(f"| {v['group']} | {v['joint_success_count']}/{v['joint_defined']} defined ({v['n']} total) | {fmt(m['own_unique_mean_change'])} | {fmt(m['other_unique_mean_change'])} | {fmt(m['union_mse_change'])} | {fmt(m['cue_own_contrast'])} |")
 lines+=['','Changes are feedback on minus off. Positive cue-reversal contrast means an object\'s own unique pixels receive more reconstructed intensity when its category is cued than when the other category is cued. This is distinct from preserving its features relative to feedback off. The same source pair is counted twice for the two requests and across three models, so these are not independent sample counts.','', 'All per-model estimates and paired scores are retained in summary.json and overlap_paired.csv. Original manuscript and reviewer replies are unchanged.']
 report='\n'.join(lines)+'\n';(OUT/'REPORT.md').write_text(report);(q.STUDY/'Manuscript/qmnist_spatial_extension_source_notes.md').write_text(report)
 # Prespecified first five pair examples, all separations and both category requests.
 meta=json.loads((OUT/'stimuli.json').read_text())
 with np.load(OUT/'stimuli.npz') as z:inputs=z['input']
 selected=[m for m in meta if m['group']=='overlap' and int(m['cluster'])<5];selected.sort(key=lambda m:(int(m['cluster']),m['separation']))
 font=lambda n:ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',n)
 image=Image.new('RGB',(1490,120+len(selected)*100),'white');d=ImageDraw.Draw(image);d.text((20,15),'QMNIST: overlap cue reversals and feedback controls',font=font(24),fill='black')
 for k,label in enumerate(['Input','Cue A, off','Cue A, on','Cue B, off','Cue B, on']):d.text((160+k*260,60),label,font=font(18),fill='black')
 for j,m in enumerate(selected):
  y=100+j*100;d.text((10,y+15),f"{m['categories']}\nOffset {m['separation']}",font=font(16),fill='black');ims=[inputs[m['case']]]
  for target,fb in [(0,False),(0,True),(1,False),(1,True)]:
   row=next(v for v in rows if v['seed']==71001 and v['case']==m['case'] and v['target']==target and v['feedback']==fb)
   with np.load(OUT/'trials'/f"model71001_job{row['job']:03d}"/'arrays.npz') as z:ims.append(z['final_render'])
  for k,im in enumerate(ims):image.paste(Image.fromarray(np.uint8(np.clip(im[:,96:224],0,1)*255)).convert('RGB').resize((256,64),Image.Resampling.NEAREST),(160+k*260,y))
 image.save(OUT/'overlap_examples.png');print('Spatial statistics, report and fixed-order examples complete.',flush=True)
if __name__=='__main__':main()
