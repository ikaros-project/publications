"""Population-weighted retinotopic code feedback; no spatial argmax in routing."""
import concurrent.futures,json,time,hashlib,shutil,argparse
from pathlib import Path
import numpy as np
import run_spatial_overlap_pilot as r
from run_spatial_overlap_code_alignment import ROOT as HARD,BASE,CodeAlignedFeedback,project_codes
from run_spatial_overlap_aligned_validation import TargetCuedCircuit
from run_spatial_overlap_feedback_strength import StrengthFeedback
from neural_spatial_rate_model import windows
ROOT=HARD.parent/'population_feedback_pilot'

def population_map(refs,blank,chosen,activity):
    """Average translated code templates on global patch coordinates, float64 sum."""
    n=len(activity);w=np.asarray(activity,np.float64);w=w/w.sum()
    total=np.zeros((64,26,n+25),np.float64);coverage=np.zeros(n+25,np.float64)
    for i in np.flatnonzero(w): # Exact zero omission only; no threshold or top-k.
        total[:,:,i:i+26]+=w[i]*refs[chosen[i]].reshape(64,26,26)
        coverage[i:i+26]+=w[i]
    # Blank codes are spatially constant; retain their exact float32 values.
    total+=np.maximum(0,1-coverage)[None,None,:]*blank.reshape(64,26,26)[:,:,:1]
    return np.lib.stride_tricks.sliding_window_view(total,26,axis=2).transpose(2,0,1,3).reshape(n,64,676).astype(np.float32)

class PopulationFeedback(StrengthFeedback):
    maximum=.65
    last=None
    def __init__(self,*args):
        super().__init__(*args);type(self).last=self;self.blank=self.front.bottom(np.zeros((1,32,32),np.float32))[0]
        self.diagnostics=[]
    def propose(self,circuit):
        b=self.front.bottom(windows(circuit.s,31)[0]);a=circuit.a[0];amass=float(a.sum())
        gate=np.clip((a@self.field_kernel)/max(1.,amass),0,1)
        c=circuit.c[0];mass=float(c.sum())
        lam=self.maximum*gate if self.feedback and mass>1e-7 and amass>1e-7 else np.zeros_like(gate)
        target=b.copy()
        if np.any(lam):
            weights=c/mass;key=(a.tobytes(),weights.tobytes())
            if getattr(self,'_key',None)!=key:
                Q=np.zeros_like(b)
                for k in range(10):
                    if weights[k]!=0:Q+=weights[k]*population_map(self.front.rp[k],self.blank,self.chosen[:,k],a)
                self._key=key;self._Q=Q
            target=(1-lam[:,None,None])*b+lam[:,None,None]*self._Q
        self.diagnostics.append(dict(spatial_mass=amass,effective_locations=float(amass**2/max(float((a.astype(np.float64)**2).sum()),1e-30)),feedback_active=bool(np.any(lam))))
        new=(1-circuit.par.alpha)*self.q+circuit.par.alpha*target
        return new,float(np.max(abs(new-self.q))),gate

class InitialAttentionCircuit(TargetCuedCircuit):
    profile='focused'
    object_positions=[144,144]
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        if self.profile=='broad':
            a=np.maximum(0,9-abs(self.positions-self.cue_position)).astype(np.float32);self.a[0]=a/a.sum()
        elif self.profile=='divided':
            for pos in self.object_positions:self.a[0,pos+31]+=.5
        self.initial_attention=self.a[0].copy()

def init():
    r.init();r.Circuit=InitialAttentionCircuit

def mechanism_checks():
    rng=np.random.default_rng(71001);n=41
    refs=rng.random((8,64,676),dtype=np.float32);refs/=refs.sum(1,keepdims=True)
    b=rng.random(64,dtype=np.float32);b/=b.sum();blank=np.broadcast_to(b[:,None],(64,676)).copy();chosen=np.arange(n)%8;positions=np.arange(n)
    for anchor in [0,20,40]:
        a=np.zeros(n,np.float32);a[anchor]=.37
        q=population_map(refs,blank,chosen,a);expected=project_codes(refs[chosen[anchor]],blank,positions,anchor)
        np.testing.assert_array_equal(q,expected)
    a=np.zeros(n,np.float32);a[[7,32]]=[.4,.6]
    q=population_map(refs,blank,chosen,a)
    expected=.4*project_codes(refs[chosen[7]],blank,positions,7)+.6*project_codes(refs[chosen[32]],blank,positions,32)
    np.testing.assert_allclose(q,expected,atol=1e-7,rtol=1e-6)
    broad=np.maximum(0,9-abs(positions-20)).astype(np.float32);q=population_map(refs,blank,chosen,broad).reshape(n,64,26,26)
    np.testing.assert_array_equal(q[:-1,:,:,1:],q[1:,:,:,:-1]);np.testing.assert_allclose(q.sum(1),1,atol=1e-6)
    assert (q>=0).all()
    return dict(single_active_location_exactly_matches_winner=True,two_location_weighted_mixture=True,shared_patch_codes_exact=True,normalized_nonnegative=True,all_nonzero_activity_included=True)

def prepare():
    ROOT.mkdir(exist_ok=True)
    if (ROOT/'protocol.json').exists():return
    checks=mechanism_checks();meta=json.loads((BASE/'independent'/'stimuli.json').read_text());jobs=[]
    conditions=['focused_population','broad_winner','broad_population','divided_winner','divided_population','focused_parity']
    for condition in conditions:
        folder=ROOT/condition;folder.mkdir(exist_ok=True)
        for n in ['stimuli.json','stimuli.npz']:shutil.copyfile(BASE/'independent'/n,folder/n)
        for m in meta:
            for cue in ['A','B'] if m['kind']=='pair' else ['A']:
                if condition=='focused_population' or (condition=='focused_parity' and m['case']==0 and cue=='A') or (condition.startswith(('broad','divided')) and m['kind']=='pair' and m['separation']==40):jobs.append([condition,m['case'],'combined_category_'+cue])
    jobs.sort(key=lambda j:j[0]!='focused_parity');assert len(jobs)==81
    r.r.dump(ROOT/'jobs.json',jobs);r.r.dump(ROOT/'mechanism_checks.json',checks)
    names=['run_spatial_population_feedback.py','run_spatial_overlap_code_alignment.py','run_spatial_overlap_aligned_validation.py','run_spatial_overlap_feedback_strength.py','run_spatial_overlap_pilot.py','spatial_content_feedback.py','cached_spatial_content_feedback.py','neural_spatial_rate_model.py']
    r.r.dump(ROOT/'protocol.json',dict(seed=71001,new_experimental_runs=80,parity_runs=1,reused_focused_winner_runs=40,steps=600,early_stop=False,feedback=.65,selection='Same five pairs, ten images, no screening. Forty focused population trials cover0/8/40 offsets and isolated controls. Broad/divided initial attention tested on all five separated pairs, both category cues, population and winner routing:40 further trials.',mechanism='Q_j=sum_s [a_s/sum(a)] sum_k [c_k/sum(c)] T_s,k,j. T is the unchanged retinotopically translated category-reference patch-code tensor, with blank codes outside26 patch origins. Each location uses its existing original-input nearest reference for that category. All nonzero spatial activity contributes; no argmax, top-k or activity threshold in routing. Existing attention gate and0.65 relaxation remain. Shared global patch coordinates compute the weighted sum efficiently; float64 accumulation then float32 codes.',initial_attention='Focused: original all-zero spatial initialization with constant point cue2. Broad: triangular activity max(0,9-|position-target|),17 nonzero locations normalized to total1. Divided:0.5 at each separated object location. Both broad and divided states then evolve freely under unchanged spatial competition. Category cue2 and target-point spatial cue2 remain constant from the first update; images never change. These are initial-condition/settling tests, not sustained clamping of broad attention or visual sequences.',controls='Identical broad/divided initial populations for winner and population routes. Reuse40 focused winner endpoints; one fresh winner run must reproduce every saved array. Verify focused population equality and broad/divided paired gain/location changes rather than assume equal trajectories.',fixed='Weights, references, patch-boundary/blank convention, separated sensory mismatch, relative binding, alpha0.1, sigma24, uniform pooling, cue strengths and600updates unchanged. No learning, added inhibition, new precision/gain parameters or gradients.',scores='Focused: all prior reconstruction, feature suppression, category, settling and gain endpoints. Broad/divided: report transient effective location count, target spatial share, chosen location, prediction differences, early reconstruction MSE, local readout, numerical settling and final comparison with focused states. Inspect actual intervals with feedback active and distributed attention. All cases retained; no extended oscillation investigation.',scope='Small five-pair/one-network test. Spatial argmax removed from feedback routing only; existing discrete nearest-reference selection remains. Population multiplication, normalization and fixed projection have a neural interpretation but do not establish a complete biophysical circuit. No default or manuscript-body changes.',source_sha256={n:hashlib.sha256(Path(__file__).with_name(n).read_bytes()).hexdigest() for n in names}))

def worker(job):
    condition,j,name=job;r.ROOT=ROOT/condition;folder=r.ROOT/f'case{j:02d}_{name}'
    if (folder/'routing.json').exists() and (folder/'result.json').exists():return dict(population_condition=condition,**json.loads((folder/'result.json').read_text()))
    meta=json.loads((r.ROOT/'stimuli.json').read_text())[j];k=0 if name.endswith('_A') else 1
    InitialAttentionCircuit.cue_position=meta['positions'][k];InitialAttentionCircuit.object_positions=meta['positions'];InitialAttentionCircuit.profile=condition.split('_')[0]
    population=condition.endswith('_population');r.CachedLocalFeedback=PopulationFeedback if population else CodeAlignedFeedback;CodeAlignedFeedback.mode='codes'
    row=r.worker((j,name));local=PopulationFeedback.last if population else CodeAlignedFeedback.last
    if condition=='focused_parity':
        with np.load(folder/'arrays.npz') as a,np.load(HARD/'codes'/folder.name/'arrays.npz') as b:
            assert set(a.files)==set(b.files)
            for key in a.files:np.testing.assert_array_equal(a[key],b[key],err_msg=key)
        r.r.dump(ROOT/'parity.json',dict(all_saved_arrays_bit_identical=True))
    r.r.dump(folder/'routing.json',dict(profile=InitialAttentionCircuit.profile,population_weighted=population,external_spatial_cue=InitialAttentionCircuit.cue_position,diagnostics=local.diagnostics if population else [],anchor_trace=[] if population else local.anchors))
    return dict(population_condition=condition,**row)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=12);args=ap.parse_args();prepare();rows=[];start=time.time()
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,initializer=init) as pool:
        fs=[pool.submit(worker,j) for j in json.loads((ROOT/'jobs.json').read_text())]
        for f in concurrent.futures.as_completed(fs):
            rows.append(f.result());r.r.dump(ROOT/'status.json',dict(completed=len(rows),total=81,seconds=time.time()-start))
    r.r.dump(ROOT/'results.json',dict(new_runs=rows,parity=json.loads((ROOT/'parity.json').read_text())))
    print('POPULATION FEEDBACK COMPLETE',flush=True)
if __name__=='__main__':main()
