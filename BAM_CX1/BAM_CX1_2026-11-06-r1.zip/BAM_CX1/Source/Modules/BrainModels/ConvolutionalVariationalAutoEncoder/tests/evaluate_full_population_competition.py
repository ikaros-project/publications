"""Full-population 5NN category support for fixed competition and feedback."""
import json,hashlib
from argparse import Namespace
import numpy as np
import evaluate_category_feedback as f
e=f.e
OUT=e.OUTPUT/'category_competition_full_population'

def compete(evidence):
    activity=evidence.copy();trace=[activity.copy()]
    for _ in range(200):
        drive=np.maximum(evidence-1.5*(activity.sum()-activity),0)
        activity=.8*activity+.2*drive
        trace.append(activity.copy())
    return int(activity.argmax()),activity,np.array(trace)

def main(train_count=2000, test_count=1000, reference_root=None, seeds=(71001,71002,71003)):
    reference_root = reference_root or e.OUTPUT/'category_feedback_diagnostic'
    OUT.mkdir(exist_ok=True)
    train,test,labels,test_labels=e.prepare_data(Namespace(train_count=train_count,test_count=test_count))
    train_px=np.stack([e.full.center_and_pad(x) for x in train]).astype(np.float32)/255
    test_px=np.stack([e.full.center_and_pad(x) for x in test]).astype(np.float32)/255
    pairs=list(zip(np.flatnonzero(test_labels==3)[40:60].tolist(),np.flatnonzero(test_labels==8)[40:60].tolist()))
    assert len(pairs)==20
    for name in ['category_feedback_diagnostic','category_feedback_ambiguity_gate','category_feedback_local_compatibility','category_feedback_recurrent']:
        old=json.loads((e.OUTPUT/name/'protocol.json').read_text())
        assert not ({i for p in pairs for i in p}&{i for p in old['pairs'] for i in p[2:]})
    mixtures=[i/10 for i in range(11)]
    protocol=dict(train_count=train_count,test_count=test_count,seeds=list(seeds),pairs=pairs,mixtures=mixtures,
        category_candidates=list(range(10)),reference_source='Eight training-only references per class from the corresponding externally cued feedback diagnostic; unchanged selection rule.',
        evidence=f'Five nearest neighbors among all {train_count} training upper means, raw Euclidean distance and stable training-index ties. Category votes plus a bounded 0.001/(1+first-neighbor-rank) tie preference for represented classes, divided by their maximum. The perturbation preserves integer vote ordering and reproduces the existing closest-member tie rule. Relative activity, not calibrated probabilities.',
        competition='a(0)=e; a(t+1)=.8*a(t)+.2*relu(e-1.5*sum(other activities)); 200 updates with fixed evidence, all 10 classes compete. Argmax ties use the lowest index and are reported separately.',
        feedback='One fixed-gain .25 update: p_fb=softmax(log(p_original)+.25*clip(log(q_winner_reference)-log(q_original),-2,2)); re-encode and decode. Winner reference chosen from original upper code within winning category. No local gate.',
        controls=['argmax without feedback','competition without feedback','argmax with identical weak feedback','competition with weak feedback'],
        scope='Frozen sensory model; static images; autonomous bottom-up category selection, no supplied category cue, no spotlight or sensory training. Competition settles before feedback; post-feedback evidence is measured but is not fed back into another competition cycle.',
        interpretation='Dominant-component accuracy excludes 50/50 mixtures and is an operational criterion, not a claim that mixture weight determines perceived category. At equal mixtures measure component-category selection and reconstruction toward selected actual component.')
    original_protocol=json.loads((e.OUTPUT/'category_competition_diagnostic/protocol.json').read_text())
    assert [list(pair) for pair in protocol['pairs']]==original_protocol['pairs'] and protocol['mixtures']==original_protocol['mixtures']
    (OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    rows=[];checks=[];calibrations=[];panels={};trace_examples=[]
    for seed in protocol['seeds']:
        d=f.BASE/f'hierarchy_s{seed}'
        hashes={name:hashlib.sha256((d/name).read_bytes()).hexdigest() for name in ['model.state','codebook_final.npz']}
        state=json.loads((d/'model.state').read_text())['items']
        def w(name):
            a=state['CVAE_TwoLayer.Upper.'+name];return np.asarray(a['value'],dtype=np.float32).reshape(a['shape'])
        enc=w('DIRECT_MEAN_WEIGHTS');eb=w('DIRECT_MEAN_BIAS');dec=w('DIRECT_DECODER_WEIGHTS');db=w('DIRECT_DECODER_BIAS')
        with np.load(d/'codebook_final.npz') as a:book=f.prior.Codebook(a['prototypes'])
        codes,_,_=e.read_codes(d/'train_codes.csv',train,labels,128)
        test_codes,_,_=e.read_codes(d/'test_codes.csv',test,test_labels,128)
        refs={int(k):v for k,v in json.loads((reference_root/'reference_indices.json').read_text())[str(seed)].items()}
        def decode(z):return f.logsoftmax((z@dec+db).reshape(64,676))
        def image(q):return f.prior.reconstruct(book.prototypes[q.argmax(axis=0)])
        def nearest_indices(z):return np.argsort(((codes-z)**2).sum(axis=1),kind='stable')[:5]
        def support(z):
            ids=nearest_indices(z);neighbor_labels=labels[ids]
            votes=np.bincount(neighbor_labels,minlength=10).astype(float)
            for c in np.flatnonzero(votes):votes[c]+=.001/(1+np.flatnonzero(neighbor_labels==c)[0])
            return votes/votes.max()
        original_predictions=np.load(d/'predictions_knn5.npy')
        calibrations.append(dict(seed=seed,reference_population_count=len(codes),neighbors=5,tie_perturbation=.001,temperature=None))
        with (d/'categorical_parity.csv').open() as handle:names=handle.readline().strip().split(',')
        native=np.loadtxt(d/'categorical_parity.csv',delimiter=',',skiprows=1,ndmin=2)
        actual=native[:,[i for i,n in enumerate(names) if n.startswith('topdown:')]]
        predicted=np.stack([np.exp(decode(z.astype(np.float32))).ravel() for z in test_codes[:8]])
        np.testing.assert_allclose(actual,predicted,atol=2e-5,rtol=2e-5)
        outputs=[];indices=[];encoder_error=0
        for pair_id,(i,j) in enumerate(pairs):
            A,B=test_px[i],test_px[j]
            for mix in mixtures:
                x=mix*A+(1-mix)*B;p,_=book.process(x,False,.01,.08);p=p.reshape(64,676)
                z=p.ravel()@enc+eb;q=decode(z);base=image(q)
                if mix in (0,1):encoder_error=max(encoder_error,float(np.max(np.abs(z-test_codes[i if mix==1 else j]))))
                evidence=support(z);argmax=int(evidence.argmax());winner,activity,trace=compete(evidence)
                assert winner==argmax
                neighbor_ids=nearest_indices(z);counts=np.bincount(labels[neighbor_ids],minlength=10)
                expected=next(int(c) for c in labels[neighbor_ids] if counts[c]==counts.max())
                assert winner==expected
                if mix in (0,1):assert winner==int(original_predictions[i if mix==1 else j])
                ids=refs[winner];rid=ids[int(np.argmin(((codes[ids]-z)**2).sum(axis=1)))]
                refq=decode(codes[rid].astype(np.float32))
                pf=np.exp(f.logsoftmax(np.log(np.maximum(p,1e-30))+.25*np.clip(refq-q,-2,2)))
                np.testing.assert_allclose(pf.sum(axis=0),1,atol=2e-6)
                zf=pf.ravel()@enc+eb;feedback=image(decode(zf));post=int(support(zf).argmax())
                for mode,y in [('argmax',base),('competition',base),('argmax_feedback',feedback),('competition_feedback',feedback)]:
                    mse=lambda a,b:float(np.mean((a-b)**2))
                    row=dict(seed=seed,pair_id=pair_id,mix=mix,mode=mode,winner=winner,argmax=argmax,dominant_truth=3 if mix>.5 else 8 if mix<.5 else None,
                        evidence=evidence.tolist(),activity=activity.tolist(),neighbor_indices=neighbor_ids.tolist(),neighbor_labels=labels[neighbor_ids].tolist(),vote_tie=bool(np.count_nonzero(counts==counts.max())>1),loser_fraction=float((activity.sum()-activity.max())/max(activity.sum(),1e-12)),
                        settling_last_step=float(np.max(np.abs(trace[-1]-trace[-2]))),tie=bool(np.count_nonzero(evidence==evidence.max())>1),
                        post_feedback_winner=post,reference_train_index=rid,input_mse=mse(y,x),target3_mse=mse(y,A),target8_mse=mse(y,B),reference_distance_mse=mse(y,image(refq)),
                        winner_component_mse=mse(y,A if winner==3 else B) if winner in (3,8) else None)
                    rows.append(row);indices.append(len(rows)-1);outputs.append(y.ravel())
                if seed==71001 and pair_id==0:
                    panels[mix]=dict(input=x,baseline=base,feedback=feedback,winner=winner)
                    if mix in (0,.5,1):trace_examples.append(dict(mix=mix,evidence=evidence.tolist(),trace=trace.tolist()))
            if (pair_id+1)%10==0:print(f'Seed {seed}: {pair_id+1}/20 mixture sweeps complete',flush=True)
        preds=e.five_nearest_predictions(train_px.reshape(train_count,-1),labels,np.asarray(outputs))
        for idx,pred in zip(indices,preds):rows[idx]['pixel_knn_prediction']=int(pred)
        assert encoder_error<1e-4
        assert all(hashlib.sha256((d/name).read_bytes()).hexdigest()==h for name,h in hashes.items())
        checks.append(dict(seed=seed,encoder_max_error=encoder_error,native_decoder_max_error=float(np.max(np.abs(actual-predicted))),checkpoint_sha256=hashes))
    aggregates=[]
    for mode in ['argmax','competition','argmax_feedback','competition_feedback']:
        subset=[r for r in rows if r['mode']==mode];dom=[r for r in subset if r['dominant_truth'] is not None];clean=[r for r in dom if r['mix'] in (0,1)];equal=[r for r in subset if r['mix']==.5];eligible=[r for r in equal if r['winner'] in (3,8)]
        aggregates.append(dict(mode=mode,dominant_selection_accuracy=float(np.mean([r['winner']==r['dominant_truth'] for r in dom])),
            clean_selection_accuracy=float(np.mean([r['winner']==r['dominant_truth'] for r in clean])),equal_component_selection=float(np.mean([r['winner'] in (3,8) for r in equal])),
            reconstruction_agrees_with_winner=float(np.mean([r['pixel_knn_prediction']==r['winner'] for r in subset])),
            dominant_reconstruction_accuracy=float(np.mean([r['pixel_knn_prediction']==r['dominant_truth'] for r in dom])),
            clean_reconstruction_accuracy=float(np.mean([r['pixel_knn_prediction']==r['dominant_truth'] for r in clean])),
            equal_winner_component_mse=float(np.mean([r['winner_component_mse'] for r in eligible])),clean_input_mse=float(np.mean([r['input_mse'] for r in clean])),
            mean_loser_fraction=float(np.mean([r['loser_fraction'] for r in subset])),max_settling_step=float(max(r['settling_last_step'] for r in subset)),tie_count=sum(r['tie'] for r in subset)))
    result=dict(protocol=protocol,calibrations=calibrations,checks=checks,aggregate=aggregates,per_case=rows)
    (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n');(OUT/'example_activity_traces.json').write_text(json.dumps(trace_examples)+'\n')
    cols=[0,.2,.4,.5,.6,.8,1]
    f.gallery(OUT/'mixture_sweep.png','Autonomous selection; fixed image per column; seed 71001, same pair as small-reference comparison',[[panels[m]['input'] for m in cols],[panels[m]['baseline'] for m in cols],[panels[m]['feedback'] for m in cols]],['input','no feedback','winner feedback'],[f'3:{m:.1f} win:{panels[m]["winner"]}' for m in cols])
    print(json.dumps(aggregates,indent=2),flush=True)
if __name__=='__main__':main()
