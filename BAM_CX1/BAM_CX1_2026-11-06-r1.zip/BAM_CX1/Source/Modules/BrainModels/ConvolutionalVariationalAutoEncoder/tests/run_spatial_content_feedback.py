"""Small fixed 2x2 attention/content-feedback pilot; no learning or tuning."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import json,time,concurrent.futures
from dataclasses import asdict,replace
import numpy as np
from spatial_content_feedback import ContentFrontend,LocalFeedback,render_scene
from neural_spatial_rate_model import Circuit,windows
from run_spatial_set_size import PAR
from evaluate_neural_spatial_architecture import OUT,dump
from evaluate_spatial_single_stimulus import e
ROOT=OUT/'spatial_content_feedback_pilot'
FRONT=None
METHODS={'baseline':(False,False),'spatial_only':(False,True),'content_only':(True,False),'combined':(True,True)}

def init():
    global FRONT
    FRONT=ContentFrontend();FRONT.ids=FRONT.references()
    assert FRONT.hashes==json.loads((OUT/'checkpoint_hashes.json').read_text())

def prepare():
    ROOT.mkdir(exist_ok=True)
    if (ROOT/'stimuli.npz').exists():return
    raw=e.full.read_idx_images(e.full.RAW_ROOT/'t10k-images-idx3-ubyte.gz',7000)
    lab=e.full.read_idx_labels(e.full.RAW_ROOT/'t10k-labels-idx1-ubyte.gz',7000)
    used=set();meta=[];clean=[];inputs=[];masks=[]
    for pair,(tc,dc) in enumerate([(3,8),(8,3),(4,9),(9,4)]):
        ids=[]
        for cat in [tc,dc]:
            i=next(int(i) for i in np.flatnonzero(lab[6000:7000]==cat)+6000 if int(i) not in used);used.add(i);ids.append(i)
        tp,dp=(64,224) if pair%2==0 else (224,64)
        scene=np.zeros((32,320),np.float32)
        for i,pos in zip(ids,[tp,dp]):scene[:,pos:pos+32]=e.full.center_and_pad(raw[i])/255
        for size in [0,12]:
            mask=np.zeros_like(scene,bool)
            if size:mask[10:22,tp+10:tp+22]=True
            x=scene.copy();x[mask]=0
            clean.append(scene);inputs.append(x);masks.append(mask)
            meta.append(dict(case=len(meta),pair=pair,target_category=tc,distractor_category=dc,target_position=tp,distractor_position=dp,test_indices=ids,occlusion=size))
    np.savez_compressed(ROOT/'stimuli.npz',clean=clean,input=inputs,mask=masks);dump(ROOT/'stimuli.json',meta)
    dump(ROOT/'protocol.json',dict(parameters=asdict(PAR),seed=71001,methods=METHODS,scenes=8,total_trials=32,display=[32,320],padding=31,fields=351,selection='First unused examples of categories3,8,4,9 in test indices6000:7000; four ordered target/distractor pairs; eight unique images; alternating target sides; no screening.',occlusion='Central12x12 deletion in target, plus intact controls. Labels, clean images, and masks used only for scoring; spatial cue supplies target location in attention conditions.',coupling='New per-field64x676 local code population initialized from input, synchronized alpha0.1 in ALL conditions. q <- .9q+.1[(1-lambda_w)B(S_w)+lambda_w Q_w(C)]. Q uses original eight/category reference bank with nearest reference/category/field fixed from original occluded input. No category clamp. Feedback lambda=.5; zero until category mass>1e-7. In combined condition lambda_w=.5*clip(sum_v A_v exp(-(w-v)^2/(2*24^2))/max(1,sum A),0,1). Content-only lambda_w=.5 everywhere. Spatial circuit receives probability/reconstruction from old q; all updates synchronous. Sensory S remains gain-modulated original pixels; reconstructed code activity feeds category/binding/mismatch and thus spatial competition, not a second pixel-reinjection pathway.',attention='Attention conditions: usual gain gammaE1.4/gammaI1 plus spatial cue2 at target tile left. Other conditions: gain1, no spatial cue, endogenous spatial/category competition remains for outputs.',rendering='All351 decoded fields uniformly overlap-averaged to full canvas, including padded exterior before cropping. Also report exact target/distractor field reconstructions; ground-truth positions enter scoring only, never reconstruction or inference.',steps=600,settling='Last20 normalized max changes across all7 spatial populations AND local code population <5e-6.',scope='Exploratory integration candidate, not replacement default. One model, four dependent pairs, no uncertainty intervals or generalization claims. Added code response-time lag shared across all4 conditions. No training, parameter search or overlapping-object tests.'))

def worker(job):
    j,name=job;folder=ROOT/f'case{j:02d}_{name}';folder.mkdir(exist_ok=True)
    if (folder/'result.json').exists():return json.loads((folder/'result.json').read_text())
    meta=json.loads((ROOT/'stimuli.json').read_text())[j]
    with np.load(ROOT/'stimuli.npz') as z:x=z['input'][j];clean=z['clean'][j];mask=z['mask'][j]
    feedback,attention=(True,True) if name in ['combined_sensory_mismatch','combined_600','combined_separated_600','combined_separated_normalized_600'] else (False,True) if name=='spatial_only_600' else METHODS[name]
    par=replace(PAR,binding_relative_evidence=True) if name=='combined_separated_normalized_600' else PAR
    c=Circuit(x[None],par,closed=attention,padding=31);local=LocalFeedback(FRONT,c,feedback,attention)
    u=np.zeros_like(c.a);v=np.zeros_like(c.c)
    if meta.get('cue_mode')=='category':v[0,meta['target_category']]=2
    elif attention:u[0,meta['target_position']+31]=2
    changes=[];cats=[];locs=[];gain=[];stable=0;snap={};start=time.time()
    for tick in range(601):
        prob,y=FRONT.evidence(local.q)
        if tick in [0,1,8,32,64,128,200,400,600]:
            snap[f't{tick}_render']=render_scene(y,320);snap[f't{tick}_sensory']=c.s[0].copy();snap[f't{tick}_target']=y[meta['target_position']+31].copy();snap[f't{tick}_distractor']=y[meta['distractor_position']+31].copy()
        if tick==600 or (stable>=20 and not name.endswith('_600')):break
        qnew,dq,gate=local.propose(c)
        mismatch_prediction=y
        if name in ['combined_sensory_mismatch','combined_separated_600','combined_separated_normalized_600']:
            _,mismatch_prediction=FRONT.infer_pixels(windows(c.s,31)[0])
        change=c.update(prob[None],mismatch_prediction[None],u=u,v=v);local.q=qnew
        rate=max(float(change[0]),dq)/PAR.alpha;changes.append(rate);stable=stable+1 if rate<5e-6 else 0
        cats.append(c.c[0].copy());locs.append(c.a[0].copy());gain.append(c.gain()[0].copy())
        if (tick+1)%100==0:dump(folder/'progress.json',dict(tick=tick+1,seconds=time.time()-start,rate=rate))
    assert np.isfinite(local.q).all();np.testing.assert_allclose(local.q.sum(1),1,atol=1e-5)
    assert FRONT.unchanged()
    rendered=render_scene(y,320);res=c.result();tp=meta['target_position'];dp=meta['distractor_position'];roi=np.zeros_like(mask);roi[:,tp:tp+32]=True;dr=np.zeros_like(mask);dr[:,dp:dp+32]=True
    def err(im,truth,region):return float(((im-truth)**2)[region].mean()) if region.any() else None
    field=y[tp+31];fm=mask[:,tp:tp+32];fc=clean[:,tp:tp+32]
    row=dict(**meta,method=name,updates=tick,seconds=time.time()-start,settled=stable>=20,last_rate=changes[-1],category=int(res['category'][0]) if res['category_mass'][0]>1e-7 else -1,category_mass=float(res['category_mass'][0]),category_correct=bool(res['category_mass'][0]>1e-7 and int(res['category'][0])==meta['target_category']),location=int(res['location'][0]),location_correct=bool(res['spatial_mass'][0]>1e-7 and abs(res['location'][0]-tp)<=16),spatial_mass=float(res['spatial_mass'][0]),target_field_category=int(prob[tp+31].argmax()),target_field_correct=int(prob[tp+31].argmax())==meta['target_category'],full_mse=err(rendered,clean,np.ones_like(mask)),hidden_mse=err(rendered,clean,mask),visible_target_mse=err(rendered,clean,roi&~mask),distractor_mse=err(rendered,clean,dr),background_mse=err(rendered,clean,~(roi|dr)),field_hidden_mse=err(field,fc,fm),field_visible_mse=err(field,fc,~fm),field_distractor_mse=float(((y[dp+31]-clean[:,dp:dp+32])**2).mean()),weights_unchanged=True)
    np.savez_compressed(folder/'arrays.npz',**snap,final_binding=c.t[0],final_mismatch=c.em[0],final_support=c.m[0],final_probability=prob,final_field_predictions=y,final_render=rendered,final_target=field,final_distractor=y[dp+31],final_sensory=c.s[0],category_trace=cats,spatial_trace=locs,gain_trace=gain,changes=changes,reference_slots=local.chosen,reference_ids=FRONT.ids,final_gate=gate)
    dump(folder/'result.json',row);print('DONE',j,name,tick,round(row['seconds'],1),flush=True);return row

def main():
    prepare()
    with concurrent.futures.ProcessPoolExecutor(max_workers=8,initializer=init) as pool:
        rows=list(pool.map(worker,[(j,m) for j in range(8) for m in METHODS]))
    dump(ROOT/'results.json',dict(cases=rows));print('ALL COMPLETE',flush=True)
if __name__=='__main__':main()
