"""Fresh-image spatial confirmation: frozen sampling, original circuit, all outcomes."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import argparse,datetime,json,time,traceback,concurrent.futures
from pathlib import Path
from dataclasses import asdict
import numpy as np
import qmnist_confirmation_common as q
import run_qmnist_confirmation as previous
from neural_spatial_rate_model import Circuit,windows
from run_spatial_population_feedback import PopulationFeedback
from run_spatial_overlap_pilot import PAR
from spatial_content_feedback import render_scene
OUT=q.C/'qmnist_spatial_extension_20261105'

def dump(name,v):q.dump(OUT/name,v)
def freeze():
 OUT.mkdir(exist_ok=True)
 if (OUT/'protocol.json').exists():
  assert q.sha(OUT/'protocol.json')==(OUT/'protocol.sha256').read_text().strip();return
 p=dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='New-image confirmation of translation tolerance, spatial selection and partial/full overlap across three existing models. Scientific choices fixed before selecting or evaluating additional images.',models=q.protocol()['models'],checkpoint_sha256=q.protocol()['checkpoint_sha256'],parameters=asdict(PAR),maximum_feedback=.65,updates=600,early_stop=False,sampling=dict(seed=2026110510,eligible='QMNIST test indices10000..59999, excluding ALL230 previously selected images. Independently permute remaining category pools in category order0..9. First2/category for translation. Next2/category for pair images. No response screening.',translation='20images(two/category), each at origins0,16,144,272,288 on32x320 canvas. No cues, content feedback on. Compare with centered focal bottom-up classification.',pairs='Ten distinct-category pairs: pair c contains categories c and(c+1)%10. First pair-image of each category serves as A in its own pair, second serves as B in preceding pair.20images total, no reuse between pairs. Same pair reused across spatial-selection, overlap, separation and isolated controls.',unique_images=40),translation=dict(runs_per_model=100,primary=['global category accuracy','localization within16px','exact offsets','category consistency across translations','focal comparison']),selection=dict(positions=[64,224],conditions=['neutral','spatial cue2 at A','spatial cue2 at B'],category_cue=False,feedback=True,runs_per_model=30,primary=['global category accuracy for cued target','localization','target and distractor foreground sensory intensity relative to neutral']),overlap=dict(separations=[0,8,40],positions='A=144-floor(separation/2), B=144+floor(separation/2)',combine='pixelwise maximum',conditions='Both category targets separately, with category cue2 and spatial cue2 at corresponding target origin, feedback on/off. At full overlap spatial cue identical for both category cues.',isolated='Each component alone at origin144, matched category/spatial cues, feedback on/off.',runs_per_model=160,primary=['requested-object unique-feature preservation and competitor suppression versus matched feedback-off','cue-reversal contrast on distinctive features','MSE versus requested component over union foreground','unforced local category and selected location'],masks='Own unique:own>=0.25 and other<=0.05. Shared:both>=0.25. Union:max(components)>0.05. Scoring only; never supplied to model.',joint_success='Own unique-feature mean change>=-1e-6 AND competitor unique-feature mean change<-1e-6, feedback-on minus off. Undefined if either mask empty, reported explicitly rather than discarded.',output='Uniform whole-display rendering over all fields, unchanged original rule. No spatial maximum mask.'),settling='All600update endpoints retained. Maximum normalized change across last100 updates<5e-6.',statistics='Report all model and stimulus counts. Paired bootstrap with2000 crossed resamples of3models and source images/pairs, RNG2026110511. All translations,cues,variants remain in original clusters. Per-model results and uncertainty reported; three models limit uncertainty precision.',examples='First target image per category, first five pairs in fixed order. No outcome-based selection.',total_endpoints=870,prior_protocol_sha256=q.sha(q.OUT/'protocol.json'),source_sha256={n:q.sha(Path(__file__).with_name(n)) for n in ['neural_spatial_rate_model.py','spatial_content_feedback.py','run_spatial_population_feedback.py','qmnist_confirmation_common.py']})
 dump('protocol.json',p);(OUT/'protocol.sha256').write_text(q.sha(OUT/'protocol.json')+'\n')
 (q.STUDY/'Manuscript/qmnist_spatial_extension_protocol.md').write_text('# Frozen additional spatial confirmation protocol\n\n```json\n'+json.dumps(p,indent=2)+'\n```\n')
 print('Frozen additional spatial protocol',p['frozen_utc'],flush=True)

def prepare():
 freeze()
 if (OUT/'stimuli_manifest.json').exists():return
 labels=q.idx(q.OUT/'downloads/qmnist-test-labels-idx2-int.gz');used=set(map(int,json.loads((q.OUT/'stimuli_manifest.json').read_text())['source_metadata']));rng=np.random.default_rng(2026110510)
 pools={c:rng.permutation([i for i in np.flatnonzero(labels[:,0]==c) if i>=10000 and int(i) not in used]) for c in range(10)}
 singles=[int(i) for c in range(10) for i in pools[c][:2]];pairs=[(c,(c+1)%10,int(pools[c][2]),int(pools[(c+1)%10][3])) for c in range(10)]
 ids=singles+[i for _,_,a,b in pairs for i in [a,b]];assert len(ids)==len(set(ids))==40 and not set(ids)&used
 raw=q.idx(q.OUT/'downloads/qmnist-test-images-idx3-ubyte.gz');im={i:q.b.E.full.center_and_pad(raw[i]).astype(np.float32)/255 for i in ids}
 trainmeta=q.idx(q.OUT/'downloads/qmnist-train-labels-idx2-int.gz');old=set(map(int,np.concatenate([trainmeta[:,5],labels[:10000,5]])));assert not set(map(int,labels[ids,5]))&old
 oldhash=set()
 for name,n in [('train-images-idx3-ubyte.gz',60000),('t10k-images-idx3-ubyte.gz',10000)]:
  a=q.b.E.full.read_idx_images(q.b.E.full.RAW_ROOT/name,n);oldhash.update(__import__('hashlib').sha256(v.tobytes()).digest() for v in a)
 assert all(__import__('hashlib').sha256(raw[i].tobytes()).digest() not in oldhash for i in ids)
 cases=[];inputs=[];components=[];jobs=[]
 def case(group,comp,**meta):
  j=len(cases);cases.append(dict(case=j,group=group,**meta));inputs.append(comp.max(0));components.append(comp);return j
 def job(j,target=None,spatial=False,category=False,feedback=True):
  m=cases[j];jobs.append(dict(job=len(jobs),case=j,target=target,spatial_cue=None if not spatial else m['positions'][target],category_cue=None if not category else m['categories'][target],feedback=feedback))
 for i in singles:
  for pos in [0,16,144,272,288]:
   comp=np.zeros((2,32,320),np.float32);comp[0,:,pos:pos+32]=im[i];j=case('translation',comp,cluster=str(i),ids=[i],categories=[int(labels[i,0])],positions=[pos],separation=None);job(j,0)
 for pair,(a,b,ia,ib) in enumerate(pairs):
  comp=np.zeros((2,32,320),np.float32)
  for k,(i,pos) in enumerate([(ia,64),(ib,224)]):comp[k,:,pos:pos+32]=im[i]
  j=case('selection',comp,cluster=str(pair),ids=[ia,ib],categories=[a,b],positions=[64,224],separation=160);job(j)
  for k in [0,1]:job(j,k,spatial=True)
  for sep in [0,8,40]:
   pp=[144-sep//2,144+sep//2];comp=np.zeros((2,32,320),np.float32)
   for k,(i,pos) in enumerate(zip([ia,ib],pp)):comp[k,:,pos:pos+32]=im[i]
   j=case('overlap',comp,cluster=str(pair),ids=[ia,ib],categories=[a,b],positions=pp,separation=sep)
   for k in [0,1]:
    for fb in [False,True]:job(j,k,spatial=True,category=True,feedback=fb)
  for k,(i,cat) in enumerate([(ia,a),(ib,b)]):
   comp=np.zeros((2,32,320),np.float32);comp[0,:,144:176]=im[i];j=case('isolated',comp,cluster=str(pair),ids=[i],categories=[cat],positions=[144],separation=None)
   for fb in [False,True]:job(j,0,spatial=True,category=True,feedback=fb)
 assert len(jobs)==290
 np.savez_compressed(OUT/'stimuli.npz',input=inputs,components=components,single_images=np.stack([im[i] for i in singles]),single_ids=singles)
 dump('stimuli.json',cases);dump('jobs.json',jobs);dump('stimuli_manifest.json',dict(unique_images=40,previously_selected_overlap=0,old_source_overlap=0,exact_image_overlap=0,source_metadata={str(i):labels[i].tolist() for i in ids},sha256={n:q.sha(OUT/n) for n in ['stimuli.npz','stimuli.json','jobs.json']}));print('Prepared40fresh images,290jobs/model',flush=True)

def core(seed,x,job,folder):
 _,front=previous.get_model(seed);c=Circuit(x[None],PAR,closed=True,padding=31);local=PopulationFeedback(front,c,job['feedback'],True)
 u=np.zeros_like(c.a);v=np.zeros_like(c.c)
 if job['spatial_cue'] is not None:u[0,job['spatial_cue']+31]=2
 if job['category_cue'] is not None:v[0,job['category_cue']]=2
 changes=[];ct=[];at=[];start=time.time()
 for tick in range(601):
  prob,y=front.evidence(local.q)
  if tick==600:break
  new,dq,gate=local.propose(c);_,prediction=front.infer_pixels(windows(c.s,31)[0]);delta=c.update(prob[None],prediction[None],u=u,v=v);local.q=new
  changes.append(max(float(delta[0]),dq)/PAR.alpha);ct.append(c.c[0].copy());at.append(c.a[0].copy())
  if (tick+1)%100==0:q.dump(folder/'progress.json',dict(tick=tick+1,seconds=time.time()-start))
 assert np.isfinite(y).all();np.testing.assert_allclose(local.q.sum(1),1,atol=1e-5)
 loc=int(c.a[0].argmax())-31 if c.a.sum()>1e-7 else None
 return dict(final_field_predictions=y,final_render=render_scene(y,320),final_probability=prob,final_sensory=c.s[0],final_gain=c.gain()[0],category_trace=np.array(ct),spatial_trace=np.array(at),changes=np.array(changes),reference_slots=local.chosen),dict(location=loc,category=int(c.c[0].argmax()) if c.c.sum()>1e-7 else None,local_category=None if loc is None else int(prob[loc+31].argmax()),settled=bool(max(changes[-100:])<5e-6),last100_rate=float(max(changes[-100:])),seconds=time.time()-start)

def parity():
 folder=OUT/'parity';folder.mkdir(exist_ok=True)
 if (folder/'checks.json').exists():return
 oldjob=next(j for j in json.loads((q.OUT/'spatial_jobs.json').read_text()) if j['task']=='completion' and j['feedback'])
 meta=json.loads((q.OUT/'spatial_stimuli.json').read_text())[oldjob['case']]
 with np.load(q.OUT/'spatial_stimuli.npz') as z:x=z['input'][oldjob['case']]
 arr,row=core(71001,x,dict(spatial_cue=meta['target_position'],category_cue=None,feedback=True),folder)
 source=q.OUT/'spatial'/f"model71001_job{oldjob['job']:03d}"
 with np.load(source/'arrays.npz') as z:
  errors={key:float(abs(arr[key]-z[key]).max()) for key in ['final_field_predictions','final_render','final_probability','category_trace','spatial_trace','changes','reference_slots']}
 assert max(errors.values())==0,errors
 q.dump(folder/'checks.json',dict(errors=errors,exact_saved_trial_match=True));print('Parity passed: all compared arrays exact',flush=True)

def score(seed,job,meta,arr,state,comp):
 row=dict(seed=seed,**{**job,**meta,**state});k=job['target'];pos=None if k is None else meta['positions'][k];cat=None if k is None else meta['categories'][k]
 row.update(offset=None if pos is None or state['location'] is None else state['location']-pos,located=None if pos is None else state['location'] is not None and abs(state['location']-pos)<=16,category_correct=None if cat is None or job['category_cue'] is not None else state['category']==cat,local_correct=None if cat is None else state['local_category']==cat)
 row['sensory_foreground']=[previous.masked(arr['final_sensory'],v>.05) for v in comp];row['render_foreground']=[previous.masked(arr['final_render'],v>.05) for v in comp]
 if meta['group'] in ['overlap','isolated']:
  own=comp[k];other=comp[1-k];mask=(own>=.25)&(other<=.05);othermask=(other>=.25)&(own<=.05);union=np.maximum(own,other)>.05
  row.update(own_unique_pixels=int(mask.sum()),other_unique_pixels=int(othermask.sum()),own_unique_mean=previous.masked(arr['final_render'],mask),other_unique_mean=previous.masked(arr['final_render'],othermask),union_mse=previous.masked((arr['final_render']-own)**2,union),target_foreground_mse=previous.masked((arr['final_render']-own)**2,own>.05))
 return row

def worker(item):
 seed,job=item;folder=OUT/'trials'/f"model{seed}_job{job['job']:03d}";folder.mkdir(parents=True,exist_ok=True)
 if (folder/'result.json').exists():return json.loads((folder/'result.json').read_text())
 try:
  meta=json.loads((OUT/'stimuli.json').read_text())[job['case']]
  with np.load(OUT/'stimuli.npz') as z:x=z['input'][job['case']];comp=z['components'][job['case']]
  arr,state=core(seed,x,job,folder);row=score(seed,job,meta,arr,state,comp)
  np.savez_compressed(folder/'arrays.npz',**arr);q.dump(folder/'result.json',row);return row
 except Exception:q.dump(folder/'error.json',dict(error=traceback.format_exc()));raise

def execute(workers):
 prepare();parity()
 # Smoke-check complete scoring/serialization using saved arrays before launching new trials.
 sj=json.loads((OUT/'jobs.json').read_text());sm=json.loads((OUT/'stimuli.json').read_text())
 test=next(j for j in sj if sm[j['case']]['group']=='overlap');meta=sm[test['case']]
 with np.load(OUT/'stimuli.npz') as z:comp=z['components'][test['case']]
 synthetic=dict(final_sensory=comp.max(0),final_render=comp.max(0));state=dict(location=meta['positions'][0],category=meta['categories'][0],local_category=meta['categories'][0],settled=True,last100_rate=0.,seconds=0.)
 json.dumps(score(71001,test,meta,synthetic,state,comp))
 focal=[]
 with np.load(OUT/'stimuli.npz') as z:ims=z['single_images'];ids=z['single_ids']
 for seed in q.protocol()['models']:
  _,front=previous.get_model(seed);p,_=front.infer_pixels(ims);focal.extend(dict(seed=seed,id=int(i),category=int(c)) for i,c in zip(ids,p.argmax(1)))
 dump('focal_comparison.json',focal)
 rows=[];start=time.time();items=[(s,j) for s in q.protocol()['models'] for j in sj]
 with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool:
  futures=[pool.submit(worker,j) for j in items]
  for f in concurrent.futures.as_completed(futures):
   rows.append(f.result());v=dict(completed=len(rows),total=870,seconds=time.time()-start);dump('status.json',v);print(v,flush=True)
 assert all(q.sha(p)==q.protocol()['checkpoint_sha256'][str(p.relative_to(q.C))] for s in q.protocol()['models'] for p in q.paths(s))
 rows.sort(key=lambda r:(r['seed'],r['job']));dump('results.json',rows);dump('status.json',dict(complete=True,completed=870,total=870,seconds=time.time()-start,weights_unchanged=True))
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--workers',type=int,default=20);a=ap.parse_args()
 if a.prepare:prepare()
 else:execute(a.workers)
