"""Broader frozen-network confirmation: 220 mixtures x ten seeds, three methods."""
import json,hashlib,os,concurrent.futures
from argparse import Namespace
import numpy as np
import evaluate_stable_feedback_switches as previous
prior=previous.prior;n=previous.n;f=previous.f;e=previous.e;local=previous.local
OUT=n.CAMPAIGN/'relaxation_full_mixtures_ten_seeds'
METHODS=['none','historical','relaxation'];SEEDS=list(range(71001,71011));STEPS=[0,8,32,64,128,200,300,400,500]
soft=previous.soft
def dump(path,v):path.write_text(json.dumps(v,indent=2)+'\n')
def progress(seed,text):
 dump(OUT/f'seed{seed}_status.json',dict(stage=text));print(f'seed {seed}: {text}',flush=True)
def run(seed):
 progress(seed,'loading frozen model and data')
 train,test,labels,tl=e.prepare_data(Namespace(train_count=60000,test_count=10000));tp=np.stack([e.full.center_and_pad(v) for v in train]).astype(np.float32)/255;vp=np.stack([e.full.center_and_pad(v) for v in test]).astype(np.float32)/255
 src=prior.source(seed);oldresult=json.loads((src/'results.json').read_text());cases=[v for v in oldresult['per_case'] if v['gain']==.5 and not v['illustration']];assert len(cases)==220
 with np.load(src/'arrays.npz') as z:
  x=z['input'][:220].copy();g0=list(z['gains']).index(0.);g5=list(z['gains']).index(.5);oldims={m:z['outputs'][g,:220].copy() for m,g in [('none',g0),('historical',g5)]};oldacts={m:z['activities'][g,:,:220].copy() for m,g in [('none',g0),('historical',g5)]}
 N=220
 folder=n.CAMPAIGN/f'hierarchy_s{seed}';rd=n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit'/f'grouped_softmax_s{seed}.npz';pdir=n.CAMPAIGN/'local_linear_patch_decoder_seed1' if seed==71001 else n.CAMPAIGN/'local_linear_patch_decoder_ten_seeds'/f'seed{seed}';dp=pdir/'local_decoder.npz';paths=[folder/'model.state',folder/'codebook_final.npz',rd,dp];hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
 state=json.loads(paths[0].read_text())['items']
 def w(key):
  v=state['CVAE_TwoLayer.Upper.'+key];return np.array(v['value'],np.float32).reshape(v['shape'])
 enc=w('DIRECT_MEAN_WEIGHTS');eb=w('DIRECT_MEAN_BIAS');dec=w('DIRECT_DECODER_WEIGHTS');db=w('DIRECT_DECODER_BIAS');del state
 with np.load(rd) as z:rw=z['weights'];rb=z['bias']
 with np.load(dp) as z:d=z['decoder'].astype(np.float32)
 with np.load(paths[1]) as z:book=f.prior.Codebook(z['prototypes'])
 codes,_,_=e.read_codes(folder/'train_codes.csv',train,labels,128)
 refs=json.loads((n.CAMPAIGN/'category_feedback_diagnostic/reference_indices.json').read_text())['71001'] if seed==71001 else json.loads((pdir/'feedback_inference/reference_indices.json').read_text())
 ids=np.array([refs[str(c)] for c in range(10)]);rc=codes[ids].astype(np.float32)
 def encode(p):return p.reshape(len(p),-1)@enc+eb
 def decode(z):
  v=(z@dec+db).reshape(-1,64,676);v-=v.max(1,keepdims=True);return v-np.log(np.exp(v).sum(1,keepdims=True))
 def probs(z):return n.softmax(z@rw+rb).reshape(-1,10,20).sum(2)
 def render(q):return np.clip(local.overlap(np.exp(q).transpose(0,2,1)@d),0,1)
 rq=decode(rc.reshape(-1,128)).reshape(10,8,64,676);rp=np.exp(rq)
 b=np.stack([book.process(v,False,.01,.08)[0].reshape(64,676) for v in x]);z0=encode(b);q0=decode(z0);pr0=probs(z0);a0=pr0/pr0.max(1,keepdims=True);selected=((z0[:,None,None]-rc[None])**2).sum(3).argmin(2)
 lb=np.log(np.maximum(b,1e-30));initial=a0.argmax(1);mix=np.array([v['mix'] for v in cases]);eq=mix==.5;clean=(mix==0)|(mix==1);dom=~eq;truth=np.where(mix>.5,3,8);component_mask=np.isin(initial,[3,8]);wrong=dom&(initial!=truth)
 components=np.stack([vp[v['i'] if initial[j]==3 else v['j']] for j,v in enumerate(cases)])
 outputs=[];allact=[];allpr=[];allch=[];rows=[];checks=[]
 with np.load(previous.OUT/f'seed{seed}.npz') as z:known_indices=z['case_indices'].copy();knownact=z['activities'][previous.METHODS.index('relaxation')].copy();knownim=z['snapshots'][previous.METHODS.index('relaxation'),-1].copy()
 for method in METHODS:
  p=b.copy();q=q0.copy();pr=pr0.copy();a=a0.copy();acts=[a.copy()];prs=[pr.copy()];changes=[];ims=[render(q)]
  for step in range(1,501):
   an=.8*a+.2*np.maximum(pr/pr.max(1,keepdims=True)-1.5*(a.sum(1,keepdims=True)-a),0)
   if method=='none':pn=b
   else:
    ww=an/an.sum(1,keepdims=True);v=np.zeros_like(p)
    for c in range(10):
     wc=ww[:,c,None,None]
     v+=wc*(rp[c,selected[:,c]] if method=='relaxation' else np.clip(rq[c,selected[:,c]]-q,-2,2))
    target=.5*b+.5*v if method=='relaxation' else soft(lb+.5*v)
    pn=.8*p+.2*target
   changes.append(np.stack([abs(pn-p).max((1,2)),abs(an-a).max(1)],axis=1));p=pn;a=an
   if method!='none':z=encode(p);q=decode(z);pr=probs(z)
   acts.append(a.copy());prs.append(pr.copy())
   if step in STEPS:ims.append(render(q))
   if step%100==0:progress(seed,f'{method}: {step}/500 iterations')
  ims=np.array(ims);acts=np.array(acts);prs=np.array(prs);ch=np.array(changes);wins=acts.argmax(2)
  assert np.isfinite(q).all();np.testing.assert_allclose(p.sum(1),1,atol=4e-6)
  if method in oldims:
   ae=float(abs(acts[:201]-oldacts[method]).max());ie=float(abs(ims[STEPS.index(200)]-oldims[method]).max());assert ae<3e-5 and ie<3e-5;np.testing.assert_array_equal(wins[:201],oldacts[method].argmax(2));checks.append(dict(method=method,source='original full mixtures',activity_error=ae,image_error=ie))
  if method=='none':np.testing.assert_array_equal(ims[-1],ims[0])
  if method=='relaxation':
   ae=float(abs(acts[:,known_indices]-knownact).max());ie=float(abs(ims[-1,known_indices]-knownim).max());assert ae<3e-5 and ie<3e-5;np.testing.assert_array_equal(wins[:,known_indices],knownact.argmax(2));checks.append(dict(method=method,source='49 known switches',activity_error=ae,image_error=ie))
  for j,case in enumerate(cases):
   sw=np.flatnonzero(np.diff(wins[:,j])!=0)+1;settled=bool(ch[-10:,j].max()<1e-5)
   rows.append(dict(seed=seed,case_index=j,pair_id=case['pair_id'],mix=case['mix'],method=method,original_winner=int(initial[j]),final_winner=int(wins[-1,j]),winner_at200=int(wins[200,j]),switch_iterations=sw.tolist(),switch_sequence=[int(initial[j])]+wins[sw,j].tolist(),settled=settled,settled_at200=bool(ch[190:200,j].max()<1e-5),max_last10_change=float(ch[-10:,j].max()),late_switches=int(sum(sw>400)),input_mse=float(((ims[-1,j]-x[j])**2).mean()),original_component_mse=float(((ims[-1,j]-components[j])**2).mean()) if component_mask[j] else None,pixel_drift_mse=float(((ims[-1,j]-ims[-2,j])**2).mean()),dominant_truth=int(truth[j]) if dom[j] else None,wrong_original=bool(wrong[j])))
  outputs.append(ims);allact.append(acts);allpr.append(prs);allch.append(ch)
 progress(seed,'scoring reconstructed images')
 outputs=np.array(outputs);imagearray=outputs[:,[STEPS.index(200),STEPS.index(500)]].reshape(-1,1024);unique,rev=np.unique(imagearray,axis=0,return_inverse=True);pred=e.five_nearest_predictions(tp.reshape(60000,-1),labels,unique)[rev].reshape(3,2,220)
 metrics=[]
 for mi,method in enumerate(METHODS):
  rr=[r for r in rows if r['method']==method];final=np.array([r['final_winner'] for r in rr]);fw=pred[mi,1]==final;win200=np.array([r['winner_at200'] for r in rr]);switches=np.array([bool(r['switch_iterations']) for r in rr])
  for j,r in enumerate(rr):r['pixel_prediction']=int(pred[mi,1,j]);r['pixel_prediction200']=int(pred[mi,0,j]);r['pixel_winner_agreement']=bool(fw[j])
  wrongfinal=dom&(final!=truth)
  metrics.append(dict(seed=seed,method=method,final_winner_agreement=float(fw.mean()),original_winner_agreement=float((pred[mi,1]==initial).mean()),equal_winner_agreement=float(fw[eq].mean()),clean_recognition=float((pred[mi,1,clean]==truth[clean]).mean()),clean_category_selection=float((final[clean]==truth[clean]).mean()),dominant_recognition=float((pred[mi,1,dom]==truth[dom]).mean()),dominant_category_selection=float((final[dom]==truth[dom]).mean()),wrong_original_reinforcement=float((pred[mi,1,wrong]==initial[wrong]).mean()) if wrong.any() else None,wrong_original_cases=int(wrong.sum()),wrong_final_reinforcement=float(fw[wrongfinal].mean()) if wrongfinal.any() else None,wrong_final_cases=int(wrongfinal.sum()),settled=sum(r['settled'] for r in rr),settled_at200=sum(r['settled_at200'] for r in rr),ever_switched=int(switches.sum()),final_changed=int((final!=initial).sum()),multiple_switch_cases=sum(len(r['switch_iterations'])>1 for r in rr),late_switches=sum(r['late_switches'] for r in rr),input_mse=float(np.mean([r['input_mse'] for r in rr])),original_component_mse=float(np.mean([r['original_component_mse'] for r in rr if r['original_component_mse'] is not None])),pixel_drift_mse=float(np.mean([r['pixel_drift_mse'] for r in rr])),agreement_at200=float((pred[mi,0]==win200).mean()),winner_changes200to500=int((win200!=final).sum())))
 assert [hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]==hashes
 np.savez_compressed(OUT/f'seed{seed}.npz',input=x,snapshots=outputs,steps=STEPS,activities=np.array(allact),probabilities=np.array(allpr),changes=np.array(allch),pixel_predictions=pred)
 result=dict(seed=seed,metrics=metrics,cases=rows,checks=checks,weights_unchanged=True,checkpoint_sha256=hashes);dump(OUT/f'seed{seed}_results.json',result);progress(seed,'complete');return seed

def main():
 OUT.mkdir(exist_ok=True)
 protocol=dict(seeds=SEEDS,methods=METHODS,cases_per_seed=220,distinct_scenes=220,pairs=20,mixtures='0,.1,...,1 for each original3/8 pair',iterations=500,snapshots=STEPS,
 none='p=b exactly; category competition continues with static evidence.',historical='p_next=.8*p+.2*softmax(log(b)+.5*sum_c weight_c*clip(log(qref_c)-log(q),-2,2)).',relaxation='Q=sum_c weight_c*qref_c; p_next=.8*p+.2*(.5*b+.5*Q).',
 competition='a_next=.8*a+.2*relu(prob/max(prob)-1.5*sum_other(a)); normalize a_next to reference weights. Same readout, inhibition, damping and input-fixed nearest-of-eight references per category.',
 evaluation='Frozen inference;6600 runs. Pixel5NN agreement with own winner versus actual dominant label kept separate. Convergence requires max p/a change<1e-5 throughout final10; evaluate200and500, late switches and image drift400to500. Original-winner-component MSE uses fixed target across methods. Wrong-original reinforcement uses fixed cases; wrong-final reinforcement has condition-dependent cases.',
 statistics='Mean/SD across10 training seeds; paired t95% interval uses t9=2.262157. Stimuli reused, and49 selected cases plus seed1 diagnostics used during design. This is broader stimulus coverage within the existing exploratory set, not held-out confirmation. Seed intervals measure training variation, not stimulus uncertainty.',
 checks='Reproduce saved no-feedback and original-rule trajectories through200 on all220 cases/seed; reproduce prior relaxation trajectories on49 known switching cases through500. Verify immutable weights and normalized activity. No defaults changed.',
 figures='Seed71001 case0,5,10 (first pair endpoints/equal mixture) and37 (previous switch), fixed before results. Actual sensory input included.',workers=2)
 dump(OUT/'protocol.json',protocol);dump(OUT/'status.json',dict(stage='running',workers=2))
 with concurrent.futures.ProcessPoolExecutor(max_workers=2) as pool:
  futures=[pool.submit(run,s) for s in SEEDS]
  for future in concurrent.futures.as_completed(futures):print('finished seed',future.result(),flush=True)
 results=[json.loads((OUT/f'seed{s}_results.json').read_text()) for s in SEEDS];perseed=[v for r in results for v in r['metrics']];cases=[v for r in results for v in r['cases']]
 def stats(v):
  v=np.array(v,float);mean=float(v.mean());sd=float(v.std(ddof=1));half=2.262157*sd/np.sqrt(len(v));return dict(mean=mean,sd=sd,ci95=[mean-half,mean+half])
 metrics=['final_winner_agreement','original_winner_agreement','equal_winner_agreement','clean_recognition','clean_category_selection','dominant_recognition','dominant_category_selection','wrong_original_reinforcement','wrong_final_reinforcement','input_mse','original_component_mse']
 summary={m:{k:stats([r[k] for r in perseed if r['method']==m]) for k in metrics} for m in METHODS}
 paired={k:stats([next(r[k] for r in perseed if r['seed']==s and r['method']=='relaxation')-next(r[k] for r in perseed if r['seed']==s and r['method']=='historical') for s in SEEDS]) for k in metrics}
 dynamics={m:{k:sum(r[k] for r in perseed if r['method']==m) for k in ['settled','settled_at200','ever_switched','final_changed','multiple_switch_cases','late_switches','winner_changes200to500']} for m in METHODS}
 known={(v['seed'],v['case_index']) for v in json.loads((prior.OUT/'results.json').read_text())['cases']};rr=[v for v in cases if v['method']=='relaxation'];new=[v for v in rr if v['switch_iterations'] and (v['seed'],v['case_index']) not in known]
 comparison=dict(known_switch_cases=49,relaxation_any_switch_on_known=sum(bool(v['switch_iterations']) for v in rr if (v['seed'],v['case_index']) in known),new_switch_cases=len(new),new_switch_case_keys=[[v['seed'],v['case_index']] for v in new])
 dump(OUT/'results.json',dict(protocol=protocol,summary=summary,paired_relaxation_minus_historical=paired,dynamics=dynamics,switch_comparison=comparison,per_seed=perseed,cases=cases,checks=[r['checks'] for r in results],weights_unchanged=True))
 with np.load(OUT/'seed71001.npz') as z:
  panels=[[z['input'][j]]+[z['snapshots'][mi,-1,j] for mi in range(3)] for j in [0,5,10,37]]
  f.gallery(OUT/'representative_comparison.png','Fixed examples: sensory input and final reconstructions',panels,['first pair: 8','first pair: equal','first pair: 3','prior switch'],['input','no feedback','original','relaxation 50%'])
 lines=['# Relaxation on the broader mixture set','','Ten frozen models;220 fixed scenes each;500 iterations;three conditions. All scenes reused from earlier work.','', '| Method | Image/winner agreement | Equal-mixture agreement | Clean recognition | Input MSE | Settled | Any switch |','|---|---:|---:|---:|---:|---:|---:|']
 for m in METHODS:
  s=summary[m];d=dynamics[m];lines.append(f'| {m} | {s["final_winner_agreement"]["mean"]:.2%} | {s["equal_winner_agreement"]["mean"]:.2%} | {s["clean_recognition"]["mean"]:.2%} | {s["input_mse"]["mean"]:.6f} | {d["settled"]}/2200 | {d["ever_switched"]}/2200 |')
 lines+=['','Paired relaxation-minus-original differences with descriptive95% intervals are in results.json. They quantify variation across training seeds, not independent stimulus samples. Category consistency includes reinforcement of incorrect interpretations and is not classification accuracy. No default model has changed.','',json.dumps(comparison,indent=2)]
 (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');dump(OUT/'status.json',dict(stage='complete'));print('\n'.join(lines),flush=True)
if __name__=='__main__':main()
