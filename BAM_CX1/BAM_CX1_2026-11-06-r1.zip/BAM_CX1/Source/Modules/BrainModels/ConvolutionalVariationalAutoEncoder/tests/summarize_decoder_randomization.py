"""Create reviewer-facing decoder randomization summaries and fixed examples."""
import json,csv
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
import evaluate_decoder_randomization as exp
OUT=exp.OUT

def main():
 r=json.loads((OUT/'results.json').read_text());rows=[]
 metrics=['image_winner_agreement','category_correct','pixel_correct','input_mse','hidden_mse','visible_mse','clean_mse','settled','winner_changed_from_baseline','image_change_mse']
 tasks=[('mixture','all'),('mixture','equal')]+[('occlusion',v) for v in [0,8,12,16]]
 for decoder in ['patch','vae']:
  for fraction in exp.LEVELS:
   cc=[c for c in r['conditions'] if c['fraction']==fraction and (fraction==0 or c['decoder']==decoder)]
   assert len(cc)==(1 if fraction==0 else 5)
   for task,level in tasks:
    for key in metrics:
     vv=[next(v for v in c['summary'] if v['task']==task and v['level']==level)[key] for c in cc]
     if any(v is None for v in vv):continue
     rows.append(dict(decoder=decoder,fraction=fraction,task=task,level=level,measure=key,n_randomizations=len(vv),mean=float(np.mean(vv)),sd=float(np.std(vv,ddof=1)) if len(vv)>1 else 0.,minimum=float(min(vv)),maximum=float(max(vv))))
 with (OUT/'summary.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 unsettled=[dict(decoder=c['decoder'],fraction=c['fraction'],realization=c['realization'],n_unsettled=sum(not a['settled'] for a in c['cases'])) for c in r['conditions']]
 exp.dump('summary.json',dict(rows=rows,convergence=unsettled,checks=r['checks']))
 def val(d,p,t,l,k):return next(a for a in rows if (a['decoder'],a['fraction'],a['task'],a['level'],a['measure'])==(d,p,t,l,k))
 lines=['# Decoder randomization: Reviewer 1, Comment 3','','## Procedure','','We progressively replaced 0%, 25%, 50%, 75% or 100% of scalar weights in one decoder at a time. Replacement values were independent Gaussian draws matched to that learned matrix\'s mean and population SD. Five fixed random realizations were used for each decoder. Within each realization, replacement positions and values were nested across levels. Each perturbed matrix remained fixed for all inference updates and all test cases. The zero-randomization condition is a shared baseline, not five independent observations.','','The local patch decoder is the 64-by-49 code-to-pixel matrix and has no bias term. It only renders images. The VAE decoder is the 128-by-43,264 latent-to-code matrix. Its bias was retained. VAE randomization affected BOTH reference predictions and current-state decoding, using the same perturbed matrix. Encoders, codebook, readout, original eight-reference bank, original-input reference selections, initial state and inference settings were unchanged.','','We used one frozen network, the same 220 mixture cases and 160 occlusion inputs, 500 updates, feedback fraction 0.5, alpha 0.2 and inhibition 1.5. These are reused 3/8 stimuli, not independent confirmation. The scalar weight statistics, random seeds, code hashes and checkpoint hashes are recorded in protocol.json and results.json.','','## Quantitative results','','Means across five random realizations at nonzero levels. Image agreement is measured by the same independent pixel-space 5NN. Category accuracy excludes equal mixtures. Hidden/visible MSE below refers to 12-pixel deletion.','','| Decoder | Replaced | Mixture agreement (%) | Category accuracy (%) | Hidden MSE | Visible MSE |','| --- | ---: | ---: | ---: | ---: | ---: |']
 for d in ['patch','vae']:
  for p in exp.LEVELS:
   v=[val(d,p,t,l,k)['mean'] for t,l,k in [('mixture','all','image_winner_agreement'),('mixture','all','category_correct'),('occlusion',12,'hidden_mse'),('occlusion',12,'visible_mse')]]
   lines.append(f'| {d} | {100*p:.0f}% | {100*v[0]:.2f} | {100*v[1]:.2f} | {v[2]:.6f} | {v[3]:.6f} |')
 lines+=['','The full mean/SD/range table, including every occlusion size, reconstruction recognition, input fidelity, category changes and settling, is in summary.csv. SD describes randomization variation on this one trained model. It is not uncertainty across trained models or independent images.','','## Verification and convergence','',json.dumps(r['checks'],indent=2),'',f"Unsettled endpoints: {sum(v['n_unsettled'] for v in unsettled)}/{len(r['conditions'])*380}. Endpoints were retained without extending runs. The same shared 0% baseline is counted once.",'','Patch-decoder perturbations reuse identical category trajectories because there is no pixel-to-category return path. A separate full simulation with a fully randomized patch decoder confirmed exact equality of the trajectories and rendered outputs to the cached calculation. The learned baseline reproduces saved category trajectories, final pixel labels and reconstruction images within the recorded numerical tolerance. All original checkpoints remain unchanged.','','## Interpretation','','Hidden-region MSE decreased with randomization in the reported 12-pixel deletion condition, while visible-region MSE increased and category-consistent rendering deteriorated. The examples show diffuse or generic outputs. This is consistent with pixel averaging reducing squared error without recovering meaningful missing structure, although that explanation was not separately isolated. Hidden-region MSE alone therefore does not establish improved completion. Unchanged category accuracy under patch-decoder perturbation follows from the absence of a pixel-to-category return path. Retained VAE biases and unchanged learned components mean that complete matrix randomization does not remove all learned information. This tests dependence on the learned decoder mappings. It does not isolate stored-reference dependence, and randomizing both VAE decoding pathways is not a selective removal of category feedback. Pixel clipping and categorical softmax remain active, so partially randomized outputs need not change linearly with the fraction of replaced weights.','','Examples are the previous mixture example and the first source image under 12- and 16-pixel deletion, using random realization 0. No examples were selected based on the new results. The manuscript and reviewer response have not been edited.']
 report='\n'.join(lines)+'\n';(OUT/'REPORT.md').write_text(report)
 man=Path(__file__).resolve().parents[5]/'Manuscript';(man/'decoder_randomization_source_notes.md').write_text(report)
 # Four comparison panels, means and ranges across perturbation realizations.
 can=canvas.Canvas(str(OUT/'decoder_randomization_summary.pdf'),pagesize=(760,620));can.setTitle('Decoder randomization sensitivity')
 panels=[('mixture','all','image_winner_agreement','Mixture image/winner agreement',100),('mixture','all','category_correct','Dominant-category accuracy',100),('occlusion',12,'hidden_mse','12-pixel deletion: hidden-region MSE',1),('occlusion',12,'visible_mse','12-pixel deletion: visible-region MSE',1)]
 for i,(t,l,k,title,scale) in enumerate(panels):
  x=65+(i%2)*375;y=350-(i//2)*245;w=290;h=155
  data={d:[val(d,p,t,l,k) for p in exp.LEVELS] for d in ['patch','vae']}
  vv=[a[v]*scale for rr in data.values() for a in rr for v in ['minimum','maximum']];lo=min(vv);hi=max(vv);pad=(hi-lo)*.12 or .01;lo=max(0,lo-pad);hi=hi+pad
  if scale==100:hi=min(100,hi)
  def yy(v):return y+h*(v*scale-lo)/(hi-lo)
  xx=[x+j*w/4 for j in range(5)];can.setFillColorRGB(0,0,0);can.setFont('Helvetica-Bold',10);can.drawString(x,y+h+20,title);can.setFont('Helvetica',9)
  for tick in np.linspace(lo,hi,5):
   py=y+h*(tick-lo)/(hi-lo);can.setStrokeColorRGB(.83,.83,.83);can.line(x,py,x+w,py);can.drawRightString(x-5,py-3,f'{tick:.1f}' if scale==100 else f'{tick:.3f}')
  for j,p in enumerate(exp.LEVELS):can.drawCentredString(xx[j],y-15,str(int(p*100)))
  can.drawCentredString(x+w/2,y-31,'Weights replaced (%)')
  for d,color,dash in [('patch','#2468a0',[]),('vae','#d56b18',[6,3])]:
   can.setStrokeColor(HexColor(color));can.setFillColor(HexColor(color));can.setLineWidth(1.5);can.setDash(dash);rr=data[d]
   for j in range(4):can.line(xx[j],yy(rr[j]['mean']),xx[j+1],yy(rr[j+1]['mean']))
   can.setDash()
   for j,a in enumerate(rr):
    can.circle(xx[j],yy(a['mean']),2.5,fill=1);can.line(xx[j],yy(a['minimum']),xx[j],yy(a['maximum']))
    for q in ['minimum','maximum']:can.line(xx[j]-3,yy(a[q]),xx[j]+3,yy(a[q]))
 can.setFillColorRGB(0,0,0);can.setFont('Helvetica-Bold',14);can.drawString(65,598,'Dependence on learned reconstruction weights')
 can.setFont('Helvetica',9);can.drawString(65,575,'Blue solid: local patch decoder. Orange dashed: shared VAE decoder (reference and current-state paths).');can.drawString(65,563,'Means and ranges across five fixed random realizations. One trained model. Shared 0% baseline.')
 can.setFont('Helvetica',8);can.drawString(65,28,'Gaussian weight replacement with matched matrix mean/SD. Bias retained. Reused stimuli. All endpoints retained.');can.save()
 # Predetermined example panels, no outcome-based selection.
 with np.load(bpath:=exp.b.OUT/'stimuli.npz') as a:inp=a['input'].copy()
 font=ImageFont.load_default(size=17)
 for d in ['patch','vae']:
  ims=[]
  for p in exp.LEVELS:
   name='baseline' if p==0 else f'{d}_r0_p{int(100*p):03d}'
   with np.load(OUT/(name+'.npz')) as a:ims.append(a['images'].copy())
  image=Image.new('RGB',(1440,650),'white');dr=ImageDraw.Draw(image)
  dr.text((12,12),f'{d.upper()} decoder: random realization 0. Fixed examples. 0% is the learned model.',fill='black',font=font)
  for j,label in enumerate(['Input']+[f'{int(p*100)}%' for p in exp.LEVELS]):dr.text((230+200*j,50),label,fill='black',font=font)
  for i,idx in enumerate([37,300,340]):
   y=90+180*i;dr.text((10,y+55),['Prior mixture example','12-pixel deletion','16-pixel deletion'][i],fill='black',font=font)
   for j,im in enumerate([inp[idx]]+[v[idx] for v in ims]):image.paste(Image.fromarray(np.uint8(np.clip(im,0,1)*255)).resize((150,150),Image.Resampling.NEAREST),(230+200*j,y))
  image.save(OUT/(d+'_randomization_examples.png'))
 print(report,flush=True)
if __name__=='__main__':main()
