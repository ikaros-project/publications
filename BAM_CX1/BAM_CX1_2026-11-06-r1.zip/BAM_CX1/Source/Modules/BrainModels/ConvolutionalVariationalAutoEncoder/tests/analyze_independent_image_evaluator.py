"""Paired cross-model/stimulus analysis of independent recognition and baselines."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import time,traceback
import numpy as np
from PIL import Image,ImageDraw
import qmnist_confirmation_common as q
import run_qmnist_retrieval_controls as ret
import run_qmnist_spatial_extension as ext
from run_independent_image_evaluator import OUT,read

def stats(rows,metric,control=None):
 seeds=[71001,71002,71003];clusters=sorted({r['cluster'] for r in rows});a=np.full((3,len(clusters)),np.nan);b=a.copy()
 for i,seed in enumerate(seeds):
  for j,c in enumerate(clusters):
   rr=[r for r in rows if r['seed']==seed and r['cluster']==c];vals=[];refs=[]
   for r in rr:
    value=r.get(metric)
    if value is None:continue
    if control is not None:
     key=(seed,r['case'],r.get('target'));ref=control[key].get(metric)
     if ref is None:continue
     refs.append(float(ref))
    vals.append(float(value))
   if vals:a[i,j]=np.mean(vals)
   if refs:b[i,j]=np.mean(refs)
 if np.isnan(a).all():return None
 delta=a if control is None else a-b;rng=np.random.default_rng(2026110607);ii=rng.integers(0,3,(2000,3));jj=rng.integers(0,len(clusters),(2000,len(clusters)));sample=delta[ii[:,:,None],jj[:,None,:]]
 with np.errstate(invalid='ignore'):boot=np.nanmean(sample,axis=(1,2))
 boot=boot[np.isfinite(boot)]
 return dict(mean=float(np.nanmean(a)),control=None if control is None else float(np.nanmean(b)),difference=None if control is None else float(np.nanmean(delta)),ci95=np.quantile(boot,[.025,.975]).tolist(),by_model=[None if np.isnan(v).all() else float(np.nanmean(v)) for v in delta],observations=len(rows),defined=sum(r.get(metric) is not None for r in rows),clusters=len(clusters),interpretation='CI for paired difference' if control is not None else 'CI for mean')

def analyze():
 focal=read(OUT/'focal_results.json');spatial=read(OUT/'spatial_results.json');assert len(focal)==18630 and len(spatial)==2100
 fs=[];ss=[]
 for task,levels in [('clean',[0]),('occlusion',[8,12]),('noise',[.25,.5]),('mixture',['all',.25,.5,.75])]:
  for level in levels:
   group=[r for r in focal if r['task']==task and (level=='all' or r['level']==level)];full=[r for r in group if r['mode']=='full']
   for mode in ret.MODES:
    rr=[r for r in group if r['mode']==mode];control={(r['seed'],r['case'],None):r for r in rr}
    for key in ['mlp_correct','pixel_correct','mlp_agreement','agreement','mlp_full_agreement','full_winner_agreement','mlp_initial_agreement','evaluator_accuracy_difference','evaluator_agreement_difference','clean_mse','hidden_mse','visible_mse']:
     value=stats(rr,key)
     if value:fs.append(dict(task=task,level=level,mode=mode,metric=key,estimate=value,full_minus_condition=stats(full,key,control)))
 for group,levels in [('completion',[0,8,12]),('overlap',[0,8,40]),('isolated',[None])]:
  for level in levels:
   rr=[r for r in spatial if r['group']==group and r['level']==level];full=[r for r in rr if r['mode']=='full']
   metrics=['target_mlp_correct','target_mlp_full_agreement','selected_mlp_correct','selected_mlp_full_agreement','target_hidden_mse','target_visible_mse','target_foreground_mse','target_all_mse','selected_hidden_mse','selected_visible_mse','selected_foreground_mse','selected_all_mse'] if group=='completion' else ['mlp_requested_agreement','union_mse','foreground_mse','own_unique_mean','other_unique_mean','joint_vs_input','joint_vs_none','cue_reversal']
   for mode in ['input','pixel_reference','decoded_reference','none','full']:
    aa=[r for r in rr if r['mode']==mode];control={(r['seed'],r['case'],r.get('target')):r for r in aa}
    for key in metrics:
     value=stats(aa,key)
     if value:ss.append(dict(group=group,level=level,mode=mode,metric=key,estimate=value,full_minus_condition=stats(full,key,control)))
 assert q.sha(OUT/'evaluator_weights.npz')==read(OUT/'evaluator_frozen.json')['sha256']
 assert all(q.sha(p)==q.protocol()['checkpoint_sha256'][str(p.relative_to(q.C))] for seed in [71001,71002,71003] for p in q.paths(seed))
 q.dump(OUT/'summary.json',dict(calibration=read(OUT/'calibration.json'),focal=fs,spatial=ss,evaluator_unchanged=True,generative_weights_unchanged=True))
 def fmt(v,kind='mean'):
  value=v[kind];return 'undefined' if value is None else f'{value:.5f}'
 cal=read(OUT/'calibration.json');selected=read(OUT/'selected_duration.json')['epochs'];lines=['# Independent image recognition and reconstruction baselines','','## Frozen external evaluator','',f'An independently trained1024–256–128–10pixelMLP was fitted by supervised backpropagation solely as an external measurement instrument. A stratified6000-image training-derived validation set selected{selected}training epochs by validation crossentropy from30prespecified epochs. It was then refitted on all60000training images and frozen before any test or reconstruction scoring.',f"OriginalMNIST test accuracy: {cal['mnist_accuracy']:.2%} (10000images). Clean focalQMNIST accuracy: {cal['qmnist_clean_accuracy']:.2%} (100images).",'', 'The evaluator shares the original training dataset but no learned components with the proposed model. It is not an independent writer population. Uncertainty is conditional on this one frozen evaluator. Neither classifier architecture nor training duration was selected using reconstruction results. The recurrent model was not changed or rerun.','','## Focal agreement and accuracy','','Each condition uses the same full-model winner as its common agreement target. Own-winner agreement and initial-winner agreement remain separate in summary.json. Equal mixtures have no category ground truth. All1035inputs per generative model were scored under six conditions.','','| Task | Level | Control | Measure | Control mean | Full mean | Full minus control [95% interval] |','|---|---|---|---|---:|---:|---|']
 for r in fs:
  if r['metric'] not in ['mlp_full_agreement','full_winner_agreement','mlp_correct'] or (r['task']=='mixture' and r['level']!='all'):continue
  v=r['full_minus_condition'];lines.append(f"| {r['task']} | {r['level']} | {r['mode']} | {r['metric']} | {v['control']:.5f} | {v['mean']:.5f} | {v['difference']:.5f} [{v['ci95'][0]:.5f}, {v['ci95'][1]:.5f}] |")
 lines+=['','## Completion and overlap','','The unchanged-input baseline is the actual observed input. Pixel-reference and decoded-reference baselines use the same bank entry and are placed at the externally supplied cue location. Completion selects reference category from initial local bottom-up evidence. Overlap uses its supplied category cue. No clean target or hidden pixels select references. Reference-only canvases are zero outside the template. Completion uses the original field-prediction rendering, while overlap uses the original uniform whole-canvas rendering. Cross-task metrics therefore should not be pooled.','','| Task | Level | Control | Measure | Control mean | Full mean | Full minus control [95% interval] |','|---|---|---|---|---:|---:|---|']
 for r in ss:
  keep=r['metric'] in ['target_mlp_correct','target_hidden_mse','target_visible_mse','target_foreground_mse','mlp_requested_agreement','union_mse','foreground_mse','joint_vs_input','joint_vs_none']
  if not keep:continue
  v=r['full_minus_condition'];lines.append(f"| {r['group']} | {r['level']} | {r['mode']} | {r['metric']} | {v['control']:.5f} | {v['mean']:.5f} | {v['difference']:.5f} [{v['ci95'][0]:.5f}, {v['ci95'][1]:.5f}] |")
 lines+=['','## Interpretation','','All paired intervals use2000crossed resamples of three generative models and source-image/pair clusters. Noise draws, mixture fractions and cue directions remain within their source cluster. By-model effects, undefined-mask counts and complete metrics are saved in summary.json. Degenerate intervals do not establish universal performance. Category agreement is not recovery of physical input. Pure reference retrieval can obtain high agreement without preserving input-specific features. Joint preservation/suppression is scored against both unchanged input and feedback-disabled reconstruction. Empty distinct-feature masks remain undefined. No recurrent inference has been rerun.','','## Figures','','Focal examples use the first12-pixel-deletion image in each category. Overlap examples use the first three pairs at full and8-pixel overlap, cueA. Every condition uses the same grayscale range; no outcome-based selection.']
 (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
 # Fixed-order focal grid.
 meta=read(q.OUT/'focal_stimuli.json');ids=[next(r['case'] for r in meta if r['task']=='occlusion' and r['level']==12 and r['truth']==c) for c in range(10)]
 with np.load(q.OUT/'focal_stimuli.npz') as z:inputs=z['input'][ids];clean=z['clean'][ids]
 ims=[inputs,clean]
 for mode in ['none','pixel_retrieval','reference_decoding','full']:
  with np.load(ret.OUT/f'model71001_{mode}.npz') as z:ims.append(z['images'][ids])
 canvas=Image.new('RGB',(6*110+85,10*90+45),'white');draw=ImageDraw.Draw(canvas)
 for c,label in enumerate(['Input','Clean target','No feedback','Pixel reference','Decoded ref.','Full']):draw.text((85+c*110,10),label,fill='black')
 for row in range(10):
  draw.text((5,60+row*90),f'Category{row}',fill='black')
  for col,images in enumerate(ims):canvas.paste(Image.fromarray((np.clip(images[row],0,1)*255).astype('uint8')).resize((72,72)),(85+col*110,40+row*90))
 canvas.save(OUT/'focal_baseline_examples.png')
 jobs=read(ext.OUT/'jobs.json');meta=read(ext.OUT/'stimuli.json');chosen=[]
 for pair in range(3):
  for sep in [0,8]:chosen.append(next(j for j in jobs if meta[j['case']]['group']=='overlap' and meta[j['case']]['cluster']==str(pair) and meta[j['case']]['separation']==sep and j['target']==0 and j['feedback']))
 canvas=Image.new('RGB',(6*195+95,6*95+40),'white');draw=ImageDraw.Draw(canvas)
 for c,label in enumerate(['Input','Pixel reference','Decoded ref.','No feedback','Full','Target (scoring)']):draw.text((95+c*195,10),label,fill='black')
 for row,j in enumerate(chosen):
  with np.load(OUT/f'overlap_71001_{j["job"]:03d}.npz') as z:images=list(z['scenes'])+[z['components'][0]]
  draw.text((2,60+row*95),f"Pair{row//2}, offset{[0,8][row%2]}",fill='black')
  for col,im in enumerate(images):canvas.paste(Image.fromarray((np.clip(im[:,112:208],0,1)*255).astype('uint8')).resize((192,64)),(95+col*195,35+row*95))
 canvas.save(OUT/'overlap_baseline_examples.png');q.dump(OUT/'complete.json',dict(complete=True,focal=18630,spatial=2100,evaluator_and_model_weights_unchanged=True));print('Independent evaluation analysis complete',flush=True)
if __name__=='__main__':
 try:
  while not (OUT/'spatial_results.json').exists():
   if (OUT/'scoring_error.json').exists():raise RuntimeError('Scoring error recorded')
   time.sleep(30)
  analyze()
 except Exception:q.dump(OUT/'analysis_error.json',dict(error=traceback.format_exc()));raise
