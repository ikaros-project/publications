import json,csv
from pathlib import Path
from collections import Counter
import numpy as np
import evaluate_shared_stroke_bias as e
out=e.OUT;M=Path(__file__).resolve().parents[5]/'Manuscript'
r=json.loads((out/'results.json').read_text())['cases'];selection=json.loads((e.SOURCE/'results.json').read_text())['selected'][:6]
def get(seed,j,mode):return next(x for x in r if x['seed']==seed and x['candidate']==j and x['mode']==mode)
perseed=[];percase=[]
for seed in range(71001,71011):
 rr=[x for x in r if x['seed']==seed and x['mode']!='none'];both=sum(get(seed,j,'bias_a')['final_winner']==get(seed,j,'bias_a')['a'] and get(seed,j,'bias_b')['final_winner']==get(seed,j,'bias_b')['b'] for j in range(1,7))
 perseed.append(dict(seed=seed,cue_wins_at_release=sum(x['winner_at_release']==x['cue'] for x in rr),cue_wins_final=sum(x['final_winner']==x['cue'] for x in rr),bidirectional=both))
for j in range(1,7):
 rr=[x for x in r if x['candidate']==j];row=dict(candidate=j,a=rr[0]['a'],b=rr[0]['b'])
 for mode in ['none','bias_a','bias_b']:
  ss=[x for x in rr if x['mode']==mode];row[mode]=dict(final_counts=dict(Counter(x['final_winner'] for x in ss)),release_counts=dict(Counter(x['winner_at_release'] for x in ss)),image_winner_agreement=sum(x['image_winner_agreement'] for x in ss))
 row['bidirectional']=sum(get(seed,j,'bias_a')['final_winner']==row['a'] and get(seed,j,'bias_b')['final_winner']==row['b'] for seed in range(71001,71011));percase.append(row)
biased=[x for x in r if x['cue'] is not None];captured=[x for x in biased if x['winner_at_release']==x['cue']]
summary=dict(per_seed=perseed,per_candidate=percase,biased_trials=len(biased),captured_at_release=len(captured),cue_final=sum(x['final_winner']==x['cue'] for x in biased),retained_after_capture=sum(x['final_winner']==x['cue'] for x in captured),bidirectional=sum(x['bidirectional'] for x in perseed),settled=sum(x['settled'] for x in r),total=len(r),late_switches=sum(x['late_switches'] for x in r),biased_image_winner_agreement=sum(x['image_winner_agreement'] for x in biased),biased_pixel_cue_agreement=sum(x['final_pixel']==x['cue'] for x in biased))
# Stronger endpoint: both conditions select and visibly depict their respective cues.
summary['bidirectional_category_and_pixel']=sum(all(get(s,j,mode)['final_winner']==get(s,j,mode)['cue'] and get(s,j,mode)['final_pixel']==get(s,j,mode)['cue'] for mode in ['bias_a','bias_b']) for s in range(71001,71011) for j in range(1,7))
summary['changed_from_unbiased']=sum(x['final_winner']!=get(x['seed'],x['candidate'],'none')['final_winner'] for x in biased)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with (M/'shared_stroke_bias_statistics.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(r[0]));w.writeheader();w.writerows(r)
lines=['# Transient category bias on shared-stroke stimuli','','## Protocol','','First6 candidates selected by the user before bias testing; all ten frozen models. Three conditions on each identical input: ordinary feedback without bias, category-A bias, category-B bias. Bias adds0.5 to the normalized cued category drive before rectification for50 updates; the next500 updates have no bias and preserve ongoing state. No hard clamp. Inhibition1.5 and both update rates0.2 unchanged; sensory/top-down mixture50/50 throughout. Same initial state and input-selected reference per category across conditions. No originals supplied as additional input, no training or tuning. All models retained regardless of initial balance or third-category preference.','','## Results','',json.dumps(summary,indent=2),'','## Interpretation limits','','This is an exploratory test on six deliberately ambiguous, preselected images. Counts across60 model–stimulus pairs are not independent stimulus samples. Cued winner at release distinguishes immediate bias effects from persistence. Bidirectional means both cues select their own categories for the same pixels in the same model. Pixel5NN against60000 training images evaluates depiction separately; generated images need not reproduce either original exemplar. The no-bias control also includes feedback. Thus this isolates category bias within the feedback architecture, not feedback versus its absence. No parameter search or bias-outcome-based stimulus exclusion was performed. Frozen checkpoint hashes and initial readout parity verified.','','Full activity/readout/change traces, snapshots at0/8/32/50/58/82/178/250/550, reference choices and per-case outcomes are saved. Manuscript text is unchanged pending review.']
(M/'shared_stroke_bias_source_notes.md').write_text('\n'.join(lines)+'\n');(out/'REPORT.md').write_text('\n'.join(lines)+'\n')
with np.load(out/'seed71001/arrays.npz') as z:
 panels=[];labels=[]
 for j in range(6):
  panels.append([z['input'][j],z['snapshots'][-1,j],z['snapshots'][-1,6+j],z['snapshots'][-1,12+j]])
  wins=[get(71001,j+1,m)['final_winner'] for m in ['none','bias_a','bias_b']];labels.append(f"#{j+1} {selection[j]['a']}/{selection[j]['b']}\nfinal: {wins[0]}/{wins[1]}/{wins[2]}")
 e.f.gallery(M/'shared_stroke_bias_first_seed.png','Same pixels, different brief category biases:500 updates after release',panels,labels,['shared input','no bias','bias A','bias B'])
print(json.dumps(summary,indent=2),flush=True)
