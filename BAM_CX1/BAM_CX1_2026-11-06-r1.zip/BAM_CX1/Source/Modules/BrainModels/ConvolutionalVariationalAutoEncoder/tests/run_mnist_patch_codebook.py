"""Run an Ikaros competitive patch layer feeding the existing direct CVAE."""
import argparse
import json
from pathlib import Path
import sys
import time
import xml.etree.ElementTree as ET
import numpy as np
import run_mnist_two_layer as e


def initialize(images, seed, code_count=16, kernel=7, prepared_images=False):
    side=33-kernel
    rng=np.random.default_rng(seed+1000)
    padded=np.stack([x if prepared_images else e.full.center_and_pad(x) for x in images]).astype(np.float32)/255
    ids=rng.integers(len(images),size=10000)
    ys=rng.integers(side,size=10000); xs=rng.integers(side,size=10000)
    pool=np.stack([padded[i,y:y+kernel,x:x+kernel].ravel() for i,y,x in zip(ids,ys,xs)])
    centers=[pool[rng.integers(len(pool))].copy()]
    distances=np.full(len(pool),np.inf)
    for _ in range(code_count-1):
        distances=np.minimum(distances,np.sum((pool-centers[-1])**2,axis=1))
        centers.append(pool[rng.choice(len(pool),p=distances/distances.sum())].copy())
    return np.stack(centers)


def graph(path, dataset, output, count, seed, training, args, initial, final):
    e.write_model(path,dataset,output,count,seed,True,training,args.agent,
                  gates=False,upper_beta=.003,upper_latent_size=128,lower_kernel_size=7,lower_padding='valid')
    tree=ET.parse(path);root=tree.getroot();lower=root.find("module[@name='Lower']")
    root.find("module[@name='Upper']").set('reconstruction_loss',args.upper_loss)
    lower.attrib.clear()
    lower.attrib.update({'class':'PatchCodebook','name':'Lower','train':'yes' if training else 'no',
                        'code_count':str(args.code_count),'patch_side':str(33-args.kernel),'learning_rate':'0.01','temperature':str(args.temperature),'load_file':str(initial if training else final),
                        'save_file':str(final) if training else '', 'use_global_names':'false','timeout_ms':'10000'})
    for c in root.findall('connection'):
        if c.get('target')=='Upper.INPUT': c.set('source',f'Lower.ACTIVITY[0:{args.code_count}][0:{33-args.kernel}][0:{33-args.kernel}]')
    tree.write(path,encoding='unicode')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset',choices=['mnist','cifar10'],default='mnist')
    p.add_argument('--code-count',type=int,default=16)
    p.add_argument('--kernel',type=int,default=7)
    p.add_argument('--ticks',type=int,default=60000)
    p.add_argument('--seed',type=int,required=True)
    p.add_argument('--agent',required=True)
    p.add_argument('--temperature',type=float,default=0)
    p.add_argument('--upper-loss',choices=['mse','categorical'],default='mse')
    p.add_argument('--train-count', type=int, default=2000)
    p.add_argument('--test-count', type=int, default=1000)
    args=p.parse_args()
    if args.dataset=='cifar10' and (args.train_count,args.test_count)!=(2000,1000):
        p.error('CIFAR-10 currently supports only the existing 2000/1000 split')
    assert 1 <= args.train_count <= 60000 and 1 <= args.test_count <= 10000
    assert args.ticks > 0
    assert args.code_count >= 2 and 1 <= args.kernel <= 32
    assert np.isfinite(args.temperature) and args.temperature>=0
    args.ikaros=e.ROOT/'Bin/ikaros';args.python_executable=sys.executable
    if args.upper_loss=='categorical':args.ikaros=e.ROOT/'Bin/ikaros_categorical'
    if args.dataset=='cifar10':
        import prepare_cifar10
        train_images,test_images,train_labels,test_labels=prepare_cifar10.prepare()
        dataset_root=prepare_cifar10.ROOT
        output_root=e.DATA/'output/cvae_cifar10_two_layer'
    else:
        train_images,test_images,train_labels,test_labels=e.prepare_data(args)
        dataset_root=e.full.FULL_DATA_ROOT
        output_root=e.OUTPUT
    campaign=output_root/f'n{args.train_count}_test{args.test_count}_ticks{args.ticks}_patch_codebook{args.code_count}_kernel{args.kernel}_valid_upper128'
    if args.temperature:
        campaign=campaign.with_name(campaign.name+'_soft_tau_'+format(args.temperature,'.8g').replace('.','p'))
    if args.upper_loss!='mse':campaign=campaign.with_name(campaign.name+'_upper_'+args.upper_loss)
    d=campaign/f'hierarchy_s{args.seed}';d.mkdir(parents=True,exist_ok=True)
    if (d/'result_knn5.json').exists():
        print(f'Seed {args.seed}: existing result retained.',flush=True)
        return
    initial=d/'codebook_initial.npz';final=d/'codebook_final.npz'
    prototypes=initialize(train_images,args.seed,args.code_count,args.kernel,prepared_images=args.dataset=='cifar10')
    np.savez(initial,prototypes=prototypes,usage=np.zeros(args.code_count,dtype=np.int64),updates=0)
    dataset=dataset_root.relative_to(e.DATA);output=d.relative_to(e.DATA)
    graph(d/'train.ikg',dataset/'train',output/'metrics.csv',args.train_count,args.seed,True,args,initial,final)
    print(f'Seed {args.seed}: simultaneous patch-codebook/CVAE training, {args.ticks} updates',flush=True)
    duration=e.run_ikaros(args,d/'train.ikg',d/'training.log',args.ticks,save=d/'model.state')
    with np.load(final) as book:
        assert int(book['updates'])==args.ticks
        assert book['usage'].sum()==args.ticks*(33-args.kernel)**2
        assert np.isfinite(book['prototypes']).all()
        assert not np.array_equal(prototypes,book['prototypes'])
    state=json.loads((d/'model.state').read_text());assert state['tick']==args.ticks
    assert state['items']['CVAE_TwoLayer.Upper.DIRECT_MEAN_WEIGHTS']['shape']==[args.code_count*(33-args.kernel)**2,128]
    for item in state['items'].values():
        if item.get('type')=='matrix': assert np.isfinite(np.asarray(item['value'])).all()
    for split,count in [('train',args.train_count),('test',args.test_count)]:
        graph(d/f'extract_{split}.ikg',dataset/split,output/f'{split}_codes.csv',count,args.seed,False,args,initial,final)
        e.run_ikaros(args,d/f'extract_{split}.ikg',d/f'extract_{split}.log',count,load=d/'model.state')
    train,_,_=e.read_codes(d/'train_codes.csv',train_images,train_labels,128,prepared_images=args.dataset=='cifar10')
    test,_,metrics=e.read_codes(d/'test_codes.csv',test_images,test_labels,128,prepared_images=args.dataset=='cifar10')
    prediction=e.five_nearest_predictions(train,train_labels,test)
    np.save(d/'predictions_knn5.npy',prediction)
    result=dict(dataset=args.dataset,seed=args.seed,ticks=args.ticks,train_count=args.train_count,test_count=args.test_count,
                classifier_accuracy=float(np.mean(prediction==test_labels)),training_seconds=duration,
                lower_type='patch codebook',prototypes=args.code_count,kernel=args.kernel,padding='valid',
                competitive_learning_rate=.01,initialization='train-only kmeans++ seed selection from 10000 sampled patches',
                temperature=args.temperature,coding='soft' if args.temperature else 'hard',
                upper_reconstruction_loss=args.upper_loss,
                upper_latent_size=128,upper_beta=.003,preprocessing='none',latent_gating=False,
                classifier='knn5',simultaneous_training=True,**metrics)
    (d/'result_knn5.json').write_text(json.dumps(result,indent=2)+'\n')
    print(f"Seed {args.seed}: accuracy={result['classifier_accuracy']:.2%}, image MAE={metrics['lower_mae']:.5f}",flush=True)


if __name__=='__main__': main()
