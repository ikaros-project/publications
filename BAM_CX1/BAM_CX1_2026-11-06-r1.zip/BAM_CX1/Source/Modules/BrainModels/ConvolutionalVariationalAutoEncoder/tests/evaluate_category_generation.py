"""Category-driven image generation without a sensory input; frozen seed71001."""
import json,hashlib
from argparse import Namespace
import numpy as np
import evaluate_local_patch_decoder as local
n=local.n;f=n.f;e=n.e
OUT=n.CAMPAIGN/'category_generation_seed1'
STEPS=[0,1,2,4,8,16,32,64,128,200]
def write(name,r):(OUT/name).write_text(json.dumps(r,indent=2)+'\n')
def status(s):write('status.json',dict(stage=s));print(s,flush=True)
def soft(v):
 v=v-v.max(1,keepdims=True);v=np.exp(v);return v/v.sum(1,keepdims=True)
def main():
 OUT.mkdir(exist_ok=True);status('loading frozen model')
 protocol=dict(seed=71001,category_count=10,references_per_category=8,noise_repeats=3,cases=240,steps=200,gain=.5,damping=.2,noise_seed=20260921,
  direct='Clamp category to one-hot; select each of its eight stored training references in turn; decode stored latent mean to64x676 code probabilities, then learned64x49 patch decoder and overlap average, clipping pixels after overlap. No input image.',
  initial_state='Three independent standard-normal64x676 logit arrays, channel softmax at each position. Identical three starting states across all categories and references. Noise initializes lower internal activity, not a sensory image.',
  recurrent='Category held externally clamped; reference fixed independently of noise. q_t=upper_decode(upper_mean(p_t)); delta=clip(log(q_ref)-log(q_t),-2,2); target=softmax_channels(log(p_t)+.5*delta); p_next=.8*p_t+.2*target. No sensory anchor. The evolving p_t replaces original-input anchor in prior rule.',
  control='Zero feedback leaves internal activity at noisy initialization; direct decoding gives target rendering. Both are scored independently.',
  metrics='Independent pixel5NN against60000 centered training images, reference-image MSE, distance to direct rendering, KL(qref||qcurrent), activity change and late behavior; final category readout agreement reported separately from clamped category.',
  limits='Single frozen seed; stored-exemplar reconstruction, not novel class-conditional sampling or evidence of stable autonomous category selection. Same references used in earlier work. Noise amplitude, gain and iteration count fixed before evaluation. No retraining or permanent model-default change.')
 write('protocol.json',protocol)
 train,test,labels,tl=e.prepare_data(Namespace(train_count=60000,test_count=10000));tp=np.stack([e.full.center_and_pad(x) for x in train]).astype(np.float32)/255
 folder=n.CAMPAIGN/'hierarchy_s71001';rd=n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit/grouped_softmax_s71001.npz';dp=n.CAMPAIGN/'local_linear_patch_decoder_seed1/local_decoder.npz';paths=[folder/'model.state',folder/'codebook_final.npz',rd,dp];hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 state=json.loads(paths[0].read_text())['items']
 def w(key):
  a=state['CVAE_TwoLayer.Upper.'+key];return np.array(a['value'],np.float32).reshape(a['shape'])
 enc=w('DIRECT_MEAN_WEIGHTS');eb=w('DIRECT_MEAN_BIAS');dec=w('DIRECT_DECODER_WEIGHTS');db=w('DIRECT_DECODER_BIAS');del state
 with np.load(rd) as z:rw=z['weights'];rb=z['bias']
 with np.load(dp) as z:d=z['decoder'].astype(np.float32)
 codes,_,_=e.read_codes(folder/'train_codes.csv',train,labels,128)
 refs=json.loads((n.CAMPAIGN/'category_feedback_diagnostic/reference_indices.json').read_text())['71001'];ids=np.array([refs[str(c)] for c in range(10)]).reshape(-1);cats=np.repeat(np.arange(10),8);assert np.all(labels[ids]==cats)
 def encode(p):return p.reshape(len(p),-1)@enc+eb
 def decode(z):
  v=(z@dec+db).reshape(-1,64,676);v-=v.max(1,keepdims=True);return v-np.log(np.exp(v).sum(1,keepdims=True))
 def render(q):return np.clip(local.overlap(np.exp(q).transpose(0,2,1)@d),0,1)
 def probs(z):return n.softmax(z@rw+rb).reshape(-1,10,20).sum(2)
 rq=decode(codes[ids].astype(np.float32));direct=render(rq);refq=np.repeat(rq,3,axis=0);refp=np.exp(refq);target=np.repeat(cats,3);N=len(target)
 starts=soft(np.random.default_rng(20260921).normal(size=(3,64,676)).astype(np.float32));p=np.tile(starts,(80,1,1));q=decode(encode(p));initial=render(q);snapshots=[initial];prs=[probs(encode(p))];initial_p=p.copy();changes=[];kls=[(refp*(refq-q)).sum(1).mean(1)];two=[];previous=None;noise_distance=[]
 np.testing.assert_allclose(p.sum(1),1,atol=2e-6)
 status('running 240 clamped-category trials from internal noise')
 for step in range(1,201):
  delta=np.clip(refq-q,-2,2);pn=.8*p+.2*soft(np.log(np.maximum(p,1e-30))+.5*delta)
  changes.append(abs(pn-p).max((1,2)));two.append(abs(pn-previous).max((1,2)) if previous is not None else np.full(N,np.nan));previous=p;p=pn;z=encode(p);q=decode(z);prs.append(probs(z));kls.append((refp*(refq-q)).sum(1).mean(1))
  if step in STEPS:snapshots.append(render(q))
  if step%25==0:status(f'completed {step}/200 iterations')
 assert np.isfinite(p).all();np.testing.assert_allclose(p.sum(1),1,atol=3e-6)
 final=render(q);snapshots=np.array(snapshots);kls=np.array(kls);changes=np.array(changes);prs=np.array(prs)
 # Score all saved frames to show development as well as final category agreement.
 status('scoring direct images and iterative snapshots')
 images=np.concatenate([direct,snapshots.reshape(-1,32,32)]);unique,reverse=np.unique(images.reshape(len(images),-1),axis=0,return_inverse=True);pred=e.five_nearest_predictions(tp.reshape(60000,-1),labels,unique)[reverse];directpred=pred[:80];spred=pred[80:].reshape(len(STEPS),N)
 refimages=np.repeat(tp[ids],3,axis=0);directtarget=np.repeat(direct,3,axis=0);settled=changes[-10:].max(0)<1e-5
 metrics=dict(direct_category_agreement=float((directpred==cats).mean()),initial_category_agreement=float((spred[0]==target).mean()),final_category_agreement=float((spred[-1]==target).mean()),final_readout_category_agreement=float((prs[-1].argmax(1)==target).mean()),direct_reference_mse=float(((direct-tp[ids])**2).mean()),initial_reference_mse=float(((initial-refimages)**2).mean()),final_reference_mse=float(((final-refimages)**2).mean()),initial_direct_mse=float(((initial-directtarget)**2).mean()),final_direct_mse=float(((final-directtarget)**2).mean()),initial_code_kl=float(kls[0].mean()),final_code_kl=float(kls[-1].mean()),settled=int(settled.sum()),cases=N,late_readout_switches=int((np.diff(prs[-20:].argmax(2),axis=0)!=0).sum()),two_cycle_flags=int(((np.max(two[-10:],axis=0)<1e-5)&~settled).sum()),median_last10_activity_change=float(np.median(changes[-10:].max(0))),final_noise_variability=float(final.reshape(80,3,32,32).var(1).mean()),initial_noise_variability=float(initial.reshape(80,3,32,32).var(1).mean()))
 rows=[]
 for i in range(N):rows.append(dict(category=int(target[i]),reference_slot=int(i//3%8),reference_train_index=int(ids[i//3]),noise_repeat=i%3,pixel_prediction=int(spred[-1,i]),readout_prediction=int(prs[-1,i].argmax()),settled=bool(settled[i]),direct_mse=float(((final[i]-directtarget[i])**2).mean()),code_kl=float(kls[-1,i])))
 percat=[dict(category=c,direct_agreement=float((directpred[cats==c]==c).mean()),iterative_agreement=float((spred[-1,target==c]==c).mean()),settled=int(settled[target==c].sum())) for c in range(10)]
 trajectory=[dict(iteration=step,pixel_agreement=float((spred[j]==target).mean()),mean_direct_mse=float(((snapshots[j]-directtarget)**2).mean()),code_kl=float(kls[step].mean())) for j,step in enumerate(STEPS)]
 assert all(hashlib.sha256(p.read_bytes()).hexdigest()==hashes[p.name] for p in paths)
 write('results.json',dict(protocol=protocol,metrics=metrics,per_category=percat,trajectory=trajectory,cases=rows,checks=dict(weights_unchanged=True,checkpoint_sha256=hashes,probabilities_normalized=True)))
 np.savez_compressed(OUT/'arrays.npz',reference_ids=ids,direct_images=direct,direct_predictions=directpred,snapshots=snapshots,snapshot_steps=STEPS,snapshot_predictions=spred,category_probabilities=prs,changes=changes,code_kl=kls,initial_lower_activity=starts)
 # Show all references, without selecting for successful classification.
 f.gallery(OUT/'direct_all_references.png','Direct category-driven decoding: all eight references per category',[[direct[c*8+j] for j in range(8)] for c in range(10)],[str(c) for c in range(10)],[f'ref {j+1}' for j in range(8)])
 f.gallery(OUT/'direct_overview.png','Activate category -> select first stored reference -> decode to pixels',[[direct[c*8] for c in range(10)]],['generated'],[str(c) for c in range(10)])
 selected=[0,3,5,7,8];steps=[0,4,16,64,200]
 f.gallery(OUT/'noise_iterations.png','No sensory input: fixed first reference; same noise initialization for every category',[[snapshots[STEPS.index(s),c*24] for s in steps]+[direct[c*8]] for c in selected],[f'category {c}' for c in selected],[f't={s}' for s in steps]+['direct target'])
 lines=['# Category-driven reconstruction without sensory input','','One frozen seed; all80 stored category references and3 shared noise starts/reference. Category externally clamped. Noise initializes lower internal activities; there is no sensory image.','',json.dumps(metrics,indent=2),'','| Category | Direct agreement (8) | Iterative agreement (24) | Settled (24) |','|---|---:|---:|---:|']
 for v in percat:lines.append(f'| {v["category"]} | {v["direct_agreement"]:.2%} | {v["iterative_agreement"]:.2%} | {v["settled"]} |')
 lines+=['','| Iteration | Pixel category agreement | MSE to direct rendering | Mean code KL |','|---|---:|---:|---:|']
 for v in trajectory:lines.append(f'| {v["iteration"]} | {v["pixel_agreement"]:.2%} | {v["mean_direct_mse"]:.6f} | {v["code_kl"]:.6f} |')
 lines+=['','Direct decoding reconstructs stored category-associated training exemplars. It does not demonstrate novel imagery from category identity alone. The iterative condition uses a changed no-input rule (current-activity anchor) with the category clamped, not autonomous competition. The displayed t=0 image is the rendering of internal noise through the upper model, not an input image. Pixel5NN is an independent category proxy and is separate from the clamped node.']
 (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');status('complete');print('\n'.join(lines),flush=True)
if __name__=='__main__':main()
