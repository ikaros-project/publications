"""Frozen independent pixel evaluator for Reviewer2/comment5. NumPy-only training."""
import os
os.environ['OPENBLAS_NUM_THREADS']='4';os.environ['VECLIB_MAXIMUM_THREADS']='4'
import json,time,datetime
from pathlib import Path
import numpy as np
import qmnist_confirmation_common as q
OUT=q.C/'independent_image_evaluation_20261106'
def read(p):return json.loads(p.read_text())
def freeze():
 OUT.mkdir(exist_ok=True)
 if (OUT/'protocol.json').exists():
  assert q.sha(OUT/'protocol.json')==(OUT/'protocol.sha256').read_text().strip();return
 p=dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Reviewer2/comment5 evaluation-only follow-up. Frozen recurrent model and previously saved outputs. No new recurrent runs. No claim of new independent test stimuli.',models=[71001,71002,71003],checkpoint_sha256=q.protocol()['checkpoint_sha256'],evaluator=dict(architecture='Independent supervised pixel MLP1024->256ReLU->128ReLU->10softmax. No CVAE weights, codes, references or predictions used in training.',data='Original60000MNIST training images only. Existing integer center_and_pad32x32 preprocessing, intensities0..1. No centering or normalization of reconstructed images at scoring.',validation='Fixed stratified600examples/category from training only, RNG2026110605. Remaining54000 for training.30epochs fixed, select earliest epoch attaining minimum validation crossentropy. No test or reconstruction result used to select architecture, hyperparameters, checkpoint or duration.',optimizer='AdamW lr0.001,beta1.9,beta2.999,epsilon1e-8,decoupled weightdecay1e-4 on weights only. Batch256, final partial batch included. He normal hidden initialization, output normal sqrt(1/128). RNG2026110606 for initialization and shuffle.',refit='Reinitialize with same RNG and train all60000training images for selected epoch count. Freeze evaluator weights before ANY original-test,QMNIST or reconstruction scoring.',checks='Finite-difference gradient check on synthetic small network before training. Evaluate frozen classifier on original10000MNIST test images and100 clean focalQMNIST images. Report accuracy regardless of outcome; no retraining based on these checks.',independence='Independent learned evaluator and architecture, not independent training images or writers. One evaluator shared across all conditions; uncertainty does not estimate evaluator-training variability. Supervised backpropagation is used solely for the external measurement instrument, not the proposed model.'),focal=dict(inputs=1035,models=3,conditions=['none','pixel_retrieval','reference_decoding','single_step','fixed','full'],source='qmnist_retrieval_controls_20261105 saved images and rows',metrics='MLP category, true-label accuracy where defined, own-winner agreement, agreement with SAME full-model winner and same initial winner. Retain5NN scores for matched comparison. Equal mixtures have no ground-truth category. Report by task/level; average noise repetitions and mixture fractions within source cluster.'),spatial=dict(completion='All60firstQMNIST spatial cases,20pairs at deletion0,8,12, spatiallycued. Use saved feedback-on/off results.',overlap='All secondQMNIST overlap pairs at separations0,8,40, bothcue directions, plus isolatedcontrols. Use saved feedback-on/off results.',baselines=['unchanged observed input','original training pixels of selected reference','directly decoded selected reference'],reference_rule='Completion: category chosen by initial bottom-up readout at externally supplied spatial-cue field, then nearest original-bank reference slot saved at that field. Overlap/isolated: externally supplied category and location choose saved reference slot at cue field. No true label or clean target used to select completion category or reference. Same reference identity for pixel and decoded controls.',render='Reference baselines are single32x32templates placed at supplied cue location on otherwise zero32x320canvas. Unchanged baseline is actual input. Saved model completion is scored using local field prediction at cue field. Saved overlap uses original uniform whole-canvas rendering cropped at cue field for recognition. Do not change original output rendering.',metrics='Independent classifier at supplied cue field, true/requested category accuracy, agreement with common full-model winner for completion. Completion hidden/visible/all/foregroundMSE at cue field and full-model-selected field with identical crop coordinates across controls. Overlap target MSE over unionforeground, targetforegroundMSE, own/other unique-feature intensities, cue reversal and joint preservation/suppression against unchanged input AND matched feedback-off baseline. Thresholds unchanged:unique own>=.25 other<=.05;foreground>.05. Empty masks yield undefined counts, never zero.',reference_provenance='Save category, slot and training imageid for every baseline. Baselines use supplied cues but not model-selected spatial positions to retrieve references.'),statistics='2000crossed bootstrap resamples of3generative models and source image/pair clusters RNG2026110607. All draws,mixture proportions,cue directions,matched conditions staywithincluster. Paired contrasts full-minus-eachcontrol. Also paired MLP-minus5NN effect estimates for keyagreement/accuracy measures. Reportmodel-specificvalues and undefinedcounts. No pooledindependenttrial intervals. Intervals conditionalononefrozenscoringMLP.',examples='First sampled12-deletion image ofeachcategory;firstthreeoverlap pairs forfulland8pxoffset,firstmodel,cueA. Nooutcome-screening.',outputs='Frozenprotocol,traininglogs,validationselection,finalevaluatorweights/hash,allpredictions,baselinerenders,metrics,clusteredintervals,reportandfigures. No manuscript/reply edits until results reviewed.')
 q.dump(OUT/'protocol.json',p);(OUT/'protocol.sha256').write_text(q.sha(OUT/'protocol.json')+'\n');(q.STUDY/'Manuscript/independent_image_evaluation_protocol.md').write_text('# Frozen independent reconstruction evaluation protocol\n\n```json\n'+json.dumps(p,indent=2)+'\n```\n')
 print('Frozen evaluation protocol',p['frozen_utc'],flush=True)
def init(rng,dims=(1024,256,128,10),dtype=np.float32):
 p={}
 for i,(a,b) in enumerate(zip(dims[:-1],dims[1:])):p[f'w{i}']=(rng.normal(size=(a,b))*np.sqrt((2 if i<2 else 1)/a)).astype(dtype);p[f'b{i}']=np.zeros(b,dtype)
 return p
def forward(p,x):
 h1=np.maximum(x@p['w0']+p['b0'],0);h2=np.maximum(h1@p['w1']+p['b1'],0);logits=h2@p['w2']+p['b2'];z=logits-logits.max(1,keepdims=True);exp=np.exp(z);pr=exp/exp.sum(1,keepdims=True);return pr,(x,h1,h2,z)
def lossgrad(p,x,y):
 pr,(x,h1,h2,z)=forward(p,x);loss=np.mean(np.log(np.exp(z).sum(1))-z[np.arange(len(x)),y]);g=pr.copy();g[np.arange(len(x)),y]-=1;g/=len(x);gr={}
 gr['w2']=h2.T@g;gr['b2']=g.sum(0);g=(g@p['w2'].T)*(h2>0);gr['w1']=h1.T@g;gr['b1']=g.sum(0);g=(g@p['w1'].T)*(h1>0);gr['w0']=x.T@g;gr['b0']=g.sum(0);return float(loss),gr

def predict(p,x):
 return np.concatenate([forward(p,x[i:i+512].reshape(-1,1024).astype(np.float32))[0] for i in range(0,len(x),512)])
def evaluate(p,x,y):
 loss=0;correct=0
 for i in range(0,len(x),512):
  pr,(_,_,_,z)=forward(p,x[i:i+512]);yy=y[i:i+512];loss+=np.sum(np.log(np.exp(z).sum(1))-z[np.arange(len(yy)),yy]);correct+=np.sum(pr.argmax(1)==yy)
 return dict(loss=float(loss/len(y)),accuracy=float(correct/len(y)))
def gradient_check():
 rng=np.random.default_rng(99);p=init(rng,(5,7,6,3),np.float64);x=rng.normal(size=(8,5));y=rng.integers(0,3,8);_,gr=lossgrad(p,x,y);errors=[]
 for k in p:
  for j in range(min(5,p[k].size)):
   index=np.unravel_index(j,p[k].shape);old=p[k][index];p[k][index]=old+1e-6;hi=lossgrad(p,x,y)[0];p[k][index]=old-1e-6;lo=lossgrad(p,x,y)[0];p[k][index]=old;errors.append(abs((hi-lo)/2e-6-gr[k][index]))
 assert max(errors)<1e-7;q.dump(OUT/'gradient_check.json',dict(max_absolute_error=float(max(errors))))
def train(x,y,epochs,stage,vx=None,vy=None):
 rng=np.random.default_rng(2026110606);p=init(rng);m={k:np.zeros_like(v) for k,v in p.items()};v={k:np.zeros_like(a) for k,a in p.items()};tick=0;history=[];start=time.time()
 for ep in range(1,epochs+1):
  order=rng.permutation(len(x));total=0
  for st in range(0,len(x),256):
   ix=order[st:st+256];loss,gr=lossgrad(p,x[ix],y[ix]);total+=loss*len(ix);tick+=1
   for k in p:
    m[k]=.9*m[k]+.1*gr[k];v[k]=.999*v[k]+.001*gr[k]**2
    if k.startswith('w'):p[k]*=1-.001*.0001
    p[k]-=.001*(m[k]/(1-.9**tick))/(np.sqrt(v[k]/(1-.999**tick))+1e-8)
  row=dict(epoch=ep,training_loss=total/len(x),seconds=time.time()-start)
  if vx is not None:row['validation']=evaluate(p,vx,vy)
  history.append(row);q.dump(OUT/(stage+'_history.json'),history);q.dump(OUT/'status.json',dict(stage=stage,epoch=ep,total_epochs=epochs,**{k:v for k,v in row.items() if k!='epoch'}));print(stage,row,flush=True)
 return p,history

def main():
 freeze();gradient_check()
 if (OUT/'evaluator_frozen.json').exists():return
 raw=q.b.E.full.RAW_ROOT;images=q.b.E.full.read_idx_images(raw/'train-images-idx3-ubyte.gz',60000);y=q.b.E.full.read_idx_labels(raw/'train-labels-idx1-ubyte.gz',60000).astype(int);x=np.stack([q.b.E.full.center_and_pad(im) for im in images]).astype(np.float32).reshape(60000,1024)/255
 rng=np.random.default_rng(2026110605);valid=np.concatenate([rng.permutation(np.flatnonzero(y==c))[:600] for c in range(10)]);trainids=np.setdiff1d(np.arange(60000),valid);assert len(valid)==6000 and len(trainids)==54000
 np.savez_compressed(OUT/'training_split.npz',training_ids=trainids,validation_ids=valid)
 _,history=train(x[trainids],y[trainids],30,'selection',x[valid],y[valid]);epochs=min(history,key=lambda r:r['validation']['loss'])['epoch'];q.dump(OUT/'selected_duration.json',dict(epochs=epochs,criterion='minimum training-derived validation crossentropy',history=history))
 p,history=train(x,y,epochs,'refit');np.savez_compressed(OUT/'evaluator_weights.npz',**p)
 q.dump(OUT/'evaluator_frozen.json',dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),sha256=q.sha(OUT/'evaluator_weights.npz'),epochs=epochs,protocol_sha256=q.sha(OUT/'protocol.json')));q.dump(OUT/'status.json',dict(stage='evaluator_frozen',scoring_pending=True));print('Evaluator frozen before test/reconstruction scoring',flush=True)
if __name__=='__main__':main()
