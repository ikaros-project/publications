"""Validation-selected grouped readout capacity; frozen sensory models."""
import hashlib
import json
from argparse import Namespace
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import evaluate_label_smoothing as baseline

g=baseline.g
n=g.n
OLD=baseline.OUT
OUT=n.CAMPAIGN/'neural_readout_regularized_capacity'
SEEDS=list(range(71001,71011))
CAPACITIES=(50,100,200)

def objective(logits,y,gradient=False,smoothing=.05):
    grouped=logits.reshape(len(y),10,-1)
    group_lse=g.lse(grouped,2)
    target=np.full((len(y),10),smoothing/10,dtype=logits.dtype)
    target[np.arange(len(y)),y]+=1-smoothing
    loss=float(np.mean(g.lse(logits,1)-(target*group_lse).sum(1)))
    if not gradient:return loss
    d=n.softmax(logits).reshape(grouped.shape)-target[:,:,None]*np.exp(grouped-group_lse[:,:,None])
    return loss,d.reshape(logits.shape)/len(y)

def evaluate(x,y,w,b):
    logits=x@w+b
    pred=g.lse(logits.reshape(len(y),10,-1),2).argmax(1)
    return dict(accuracy=float(np.mean(pred==y)),cross_entropy=objective(logits,y,smoothing=0)),pred

def initialize(seed,units):
    w=np.random.default_rng(seed+2000).normal(0,.01,(128,units)).astype(np.float32)
    # Preserve the original 50-unit run's shuffle sequence at every capacity.
    rng=np.random.default_rng(seed+2000);rng.normal(0,.01,(128,50))
    return w,np.zeros(units,np.float32),rng

def checks():
    rng=np.random.default_rng(392);y=np.array([0,4,9])
    for units in CAPACITIES:
        logits=rng.normal(size=(3,units));_,d=objective(logits,y,True)
        for i,j in [(0,0),(0,units-1),(1,4*(units//10)),(2,units-1)]:
            p=logits.copy();m=logits.copy();p[i,j]+=1e-5;m[i,j]-=1e-5
            numeric=(objective(p,y)-objective(m,y))/2e-5
            np.testing.assert_allclose(numeric,d[i,j],atol=1e-8,rtol=1e-6)
        np.testing.assert_allclose(d.sum(1),0,atol=1e-14)
        probabilities=n.softmax(logits).reshape(3,10,-1).sum(2)
        target=np.full_like(probabilities,.005);target[np.arange(3),y]+=.95
        np.testing.assert_allclose(objective(logits,y),-(target*np.log(probabilities)).sum(1).mean())
        if units==50:
            np.testing.assert_array_equal(d,baseline.objective(logits,y,.05,True)[1])
            np.testing.assert_equal(objective(logits,y),baseline.objective(logits,y,.05))
        w,b,r=initialize(71001,units)
        ref=np.random.default_rng(73001);ref.normal(0,.01,(128,50))
        np.testing.assert_array_equal(r.permutation(54000),ref.permutation(54000))
    x=rng.normal(size=(13,128));w,b,_=initialize(71001,50);labels=np.arange(13)%10
    a,p=evaluate(x,labels,w,b);old,q=g.evaluate(x,labels,w,b)
    np.testing.assert_array_equal(p,q)
    np.testing.assert_allclose(a['cross_entropy'],old['cross_entropy'],atol=1e-14)

def run(seed,full=False,verify_previous=True):
    folder=n.CAMPAIGN/f'hierarchy_s{seed}'
    hashes={k:hashlib.sha256((folder/k).read_bytes()).hexdigest() for k in ['model.state','codebook_final.npz']}
    if verify_previous:
        assert hashes==json.loads((OLD/f'validation_s{seed}.json').read_text())['sensory_checkpoint_sha256']
    images,test,labels,test_labels=n.e.prepare_data(Namespace(train_count=60000,test_count=10000))
    x,_,_=n.e.read_codes(folder/'train_codes.csv',images,labels,128);x=x.astype(np.float32)
    if full:
        setting=json.loads((OUT/'selection.json').read_text())['selected']
        capacities=[setting['units']];epochs=setting['passes'];dest=OUT/'full_refit';fit=np.arange(len(x))
    else:
        capacities=CAPACITIES[1:];epochs=300;dest=OUT
        with np.load(OUT/'split_indices.npz') as s:fit=s['fit'];val=s['validation']
        xv=x[val];yv=labels[val]
    xf=x[fit];yf=labels[fit];rows=[]
    for units in capacities:
        w,b,rng=initialize(seed,units)
        mw=np.zeros_like(w);vw=np.zeros_like(w);mb=np.zeros_like(b);vb=np.zeros_like(b);step=0
        for epoch in range(1,epochs+1):
            order=rng.permutation(len(fit))
            for start in range(0,len(fit),256):
                ids=order[start:start+256];batch=xf[ids]
                _,d=objective(batch@w+b,yf[ids],True);gw=batch.T@d;gb=d.sum(0);step+=1
                mw=.9*mw+.1*gw;vw=.999*vw+.001*gw*gw
                mb=.9*mb+.1*gb;vb=.999*vb+.001*gb*gb
                w*=1-.001*.1
                w-=.001*(mw/(1-.9**step))/(np.sqrt(vw/(1-.999**step))+1e-8)
                b-=.001*(mb/(1-.9**step))/(np.sqrt(vb/(1-.999**step))+1e-8)
            if epoch%10==0:
                (dest/f'status_s{seed}.json').write_text(json.dumps(dict(stage='training',units=units,passes=epoch))+'\n')
                if not full:
                    score,_=evaluate(xv,yv,w,b)
                    rows.append(dict(seed=seed,units=units,passes=epoch,validation_accuracy=score['accuracy'],validation_ce=score['cross_entropy']))
                    np.savez(dest/f'softmax_s{seed}_units{units}_passes{epoch}.npz',weights=w,bias=b)
        assert np.isfinite(w).all() and np.isfinite(b).all()
        if not full:
            best=min([r for r in rows if r['units']==units],key=lambda r:(-r['validation_accuracy'],r['validation_ce'],r['passes']))
            print(f'Seed {seed}, units {units}: best validation {best["validation_accuracy"]:.3%} at {best["passes"]} passes',flush=True)
    assert all(hashlib.sha256((folder/k).read_bytes()).hexdigest()==v for k,v in hashes.items())
    if full:
        z,_,_=n.e.read_codes(folder/'test_codes.csv',test,test_labels,128);z=z.astype(np.float32)
        tr,_=evaluate(x,labels,w,b);te,pred=evaluate(z,test_labels,w,b)
        np.savez(dest/f'grouped_softmax_s{seed}.npz',weights=w,bias=b,predictions=pred,adam_mw=mw,adam_vw=vw,adam_mb=mb,adam_vb=vb,step=step)
        row=dict(seed=seed,units=units,smoothing=.05,decay=.1,passes=epochs,train=tr,test=te,sensory_checkpoint_sha256=hashes,rng_state=rng.bit_generator.state,optimizer_steps=step)
        (dest/f'result_s{seed}.json').write_text(json.dumps(row,indent=2)+'\n')
        print(f'Seed {seed}: full-data test {te["accuracy"]:.3%}',flush=True)
    else:
        row=dict(rows=rows,sensory_checkpoint_sha256=hashes)
        (dest/f'validation_s{seed}.json').write_text(json.dumps(row,indent=2)+'\n')
    (dest/f'status_s{seed}.json').write_text(json.dumps(dict(stage='complete'))+'\n')
    return row if full else rows

def run_full(seed):return run(seed,True)

def main():
    OUT.mkdir(exist_ok=True);checks()
    with np.load(OLD/'split_indices.npz') as s:np.savez(OUT/'split_indices.npz',fit=s['fit'],validation=s['validation'])
    protocol=dict(seeds=SEEDS,units=list(CAPACITIES),smoothing=.05,decay=.1,checkpoints=list(range(10,301,10)),
        architecture='Frozen raw128 sensory means -> 50/100/200 affine scores -> global softmax -> sum equal groups of 5/10/20 per category. No extra layers.',
        targets='Category targets .95*onehot(y)+.05/10. No targets within each category group. Readout-local gradients only.',
        learning='AdamW lr .001 beta1 .9 beta2 .999 epsilon1e-8; weight-only decay .1; batch256; fresh N(0,.01) weights and zero biases, seed+2000. Identical shuffle sequences across capacities by advancing shuffle RNG past the reference 128x50 initialization. No inhibition or z-scores.',
        split='Exact saved stratified 54000/6000 split. Reuse prior 50-unit epsilon .05 trajectories; generalized loss, gradient and scoring checked against original implementation.',
        selection='Shared capacity and duration maximizing ten-seed mean validation accuracy; ties lower unsmoothed CE, shorter duration, smaller capacity. Selection frozen before test scoring.',
        refit='Fresh all60000 refit at selected setting; score only final checkpoint. Reuse prior full fit if 50 units and 220 passes selected.',
        caveat='Validation images seen during unsupervised sensory learning. Test reused during exploration. Seed t intervals are descriptive for this fixed test set.')
    (OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    (OUT/'status.json').write_text(json.dumps(dict(stage='validation_fitting',workers=2))+'\n')
    rows=[dict(r,units=50) for seed in SEEDS for r in json.loads((OLD/f'validation_s{seed}.json').read_text())['rows'] if r['smoothing']==.05]
    assert len(rows)==300
    with ProcessPoolExecutor(max_workers=2) as pool:rows += [r for group in pool.map(run,SEEDS) for r in group]
    grid=[]
    for units in CAPACITIES:
        for epoch in protocol['checkpoints']:
            sub=[r for r in rows if r['units']==units and r['passes']==epoch];assert len(sub)==10
            grid.append(dict(units=units,passes=epoch,decay=.1,smoothing=.05,mean_validation_accuracy=float(np.mean([r['validation_accuracy'] for r in sub])),mean_validation_ce=float(np.mean([r['validation_ce'] for r in sub]))))
    key=lambda r:(-r['mean_validation_accuracy'],r['mean_validation_ce'],r['passes'],r['units'])
    chosen=min(grid,key=key);best=[min([r for r in grid if r['units']==u],key=key) for u in CAPACITIES]
    (OUT/'selection.json').write_text(json.dumps(dict(selected=chosen,best_per_capacity=best,grid=grid),indent=2)+'\n')
    print('Frozen selection: '+json.dumps(chosen),flush=True)
    previous=json.loads((OLD/'results.json').read_text());reused=chosen['units']==50 and chosen['passes']==220
    if reused:full=previous['per_seed']
    else:
        (OUT/'full_refit').mkdir(exist_ok=True)
        (OUT/'status.json').write_text(json.dumps(dict(stage='full_refit',selected=chosen))+'\n')
        with ProcessPoolExecutor(max_workers=2) as pool:full=list(pool.map(run_full,SEEDS))
    assert [r['seed'] for r in full]==[r['seed'] for r in previous['per_seed']]==SEEDS
    a=np.array([r['test']['accuracy'] for r in full]);b=np.array([r['test']['accuracy'] for r in previous['per_seed']]);d=a-b;h=2.2621571628540993*d.std(ddof=1)/np.sqrt(10)
    summary=dict(accuracy_mean=float(a.mean()),accuracy_sd=float(a.std(ddof=1)),paired_difference=float(d.mean()),paired_ci95=None if reused else [float(d.mean()-h),float(d.mean()+h)],baseline_reused=reused)
    (OUT/'results.json').write_text(json.dumps(dict(protocol=protocol,selection=chosen,best_per_capacity=best,summary=summary,per_seed=full),indent=2)+'\n')
    lines=['# Regularized grouped readout capacity','', '| Units | Units/category | Selected passes | Mean validation accuracy |', '| ---: | ---: | ---: | ---: |']
    for r in best:lines.append(f'| {r["units"]} | {r["units"]//10} | {r["passes"]} | {r["mean_validation_accuracy"]:.3%} |')
    lines+=['',f'Selected {chosen["units"]} units, {chosen["passes"]} passes; decay .1 and smoothing .05.',f'Full-data test accuracy {a.mean():.3%}; sample SD {100*a.std(ddof=1):.3f} percentage points.']
    if reused:lines+=['Reused the identical completed 50-unit full fit; not a new replication.']
    else:lines+=[f'Paired change versus 50 units: {100*d.mean():+.3f} pp, descriptive 95% CI [{100*(d.mean()-h):+.3f}, {100*(d.mean()+h):+.3f}].']
    lines+=['','Both sensory layers unchanged. Same split, matched shuffle order, fixed regularization. Validation images were previously seen during sensory learning. Test reused; not independent confirmation.']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
    (OUT/'status.json').write_text(json.dumps(dict(stage='complete',seeds=10))+'\n')
    print('\n'.join(lines),flush=True)

if __name__=='__main__':main()
