"""Frozen full-hierarchy reconstruction with independent bottom-up and decoder temperatures."""
import argparse
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import run_mnist_two_layer as e
sys.path.insert(0,str(e.ROOT/'Source/UserModules/PatchCodebook'))
from PatchCodebook import Codebook,reconstruct

BASE='n2000_test1000_ticks60000_patch_codebook16_kernel7_valid_upper128'


def probabilities(scores,temperature):
    """Temperature on recovered activity probabilities, not on patch distances."""
    if temperature==0:
        result=np.zeros_like(scores)
        result[np.arange(len(scores)),scores.argmax(axis=1)]=1
        return result
    values=np.maximum(scores,0)
    totals=values.sum(axis=1,keepdims=True)
    values=np.divide(values,totals,out=np.full_like(values,1/16),where=totals>0)
    logits=np.log(np.maximum(values,1e-30))/temperature
    values=np.exp(logits-logits.max(axis=1,keepdims=True))
    return values/values.sum(axis=1,keepdims=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--agent',required=True)
    args=parser.parse_args();args.train_count=2000;args.test_count=1000
    args.ikaros=e.ROOT/'Bin/ikaros';args.python_executable=sys.executable
    _,images,_,labels=e.prepare_data(args)
    pixels=np.stack([e.full.center_and_pad(x) for x in images]).astype(np.float32)/255
    rows=[];panels={}
    for tau in (.02,.08):
        campaign=e.OUTPUT/(BASE+'_soft_tau_'+format(tau,'.8g').replace('.','p'))
        for seed in (71001,71002,71003):
            d=campaign/f'hierarchy_s{seed}'
            codes,_,_=e.read_codes(d/'test_codes.csv',images,labels,128)
            state=json.loads((d/'model.state').read_text())['items']
            def weights(name):
                item=state['CVAE_TwoLayer.Upper.'+name]
                return np.array(item['value'],dtype=np.float32).reshape(item['shape'])
            decoder=weights('DIRECT_DECODER_WEIGHTS');bias=weights('DIRECT_DECODER_BIAS')
            encoder=weights('DIRECT_MEAN_WEIGHTS');encoder_bias=weights('DIRECT_MEAN_BIAS')
            topdown=codes.astype(np.float32)@decoder+bias
            # Validate the offline decoder against a small native Ikaros export.
            tree=ET.parse(d/'extract_test.ikg');root=tree.getroot()
            root.find("module[@name='Images']").set('filecount','8')
            root.find("module[@name='Record']").set('filename','topdown_parity.csv')
            ET.SubElement(root,'connection',source='Upper.OUTPUT',target='Record.INPUT',delay='0',label='topdown')
            tree.write(d/'topdown_parity.ikg',encoding='unicode')
            e.run_ikaros(args,d/'topdown_parity.ikg',d/'topdown_parity.log',8,load=d/'model.state')
            path=d/'topdown_parity.csv'
            names=path.open().readline().strip().split(',')
            values=np.loadtxt(path,delimiter=',',skiprows=1,ndmin=2)
            actual=values[:,[i for i,n in enumerate(names) if n.startswith('topdown:')]]
            np.testing.assert_allclose(actual,topdown[:8],atol=2e-5,rtol=2e-5)
            parity=float(np.max(np.abs(actual-topdown[:8])))
            book=np.load(d/'codebook_final.npz');model=Codebook(book['prototypes'])
            errors={k:[] for k in ('local_soft','local_hard','upper_raw','upper_T1','upper_T0.5','upper_T0.25','upper_hard')}
            squared={k:[] for k in errors};agreement=[];feature_mae=[];encoder_error=0
            selected=[int(np.flatnonzero(labels==n)[0]) for n in range(8)]
            for i,x in enumerate(pixels):
                activities,local_soft=model.process(x,False,.01,tau)
                _,local_hard=model.process(x,False,.01,0)
                encoder_error=max(encoder_error,float(np.max(np.abs(activities.ravel()@encoder+encoder_bias-codes[i]))))
                scores=topdown[i].reshape(16,676).T
                feature_mae.append(float(np.mean(np.abs(scores-activities.reshape(16,676).T))))
                agreement.append(float(np.mean(scores.argmax(axis=1)==activities.reshape(16,676).argmax(axis=0))))
                decoded={'local_soft':local_soft,'local_hard':local_hard,
                         'upper_raw':reconstruct(scores@model.prototypes)}
                for t,key in [(1,'upper_T1'),(.5,'upper_T0.5'),(.25,'upper_T0.25'),(0,'upper_hard')]:
                    decoded[key]=reconstruct(probabilities(scores,t)@model.prototypes)
                for key,y in decoded.items():
                    errors[key].append(float(np.mean(np.abs(y-x))))
                    squared[key].append(float(np.mean((y-x)**2)))
                if seed==71001 and i in selected:
                    panels[(tau,i)]=dict(original=x,**decoded)
            assert encoder_error<1e-4
            old=json.loads((d/'result_knn5.json').read_text())
            assert abs(np.mean(errors['local_soft'])-old['lower_mae'])<1e-6
            assert abs(np.mean(feature_mae)-old['upper_mae'])<2e-5
            for key in errors:
                rows.append(dict(bottom_up_temperature=tau,seed=seed,decoder=key,
                                 mae=float(np.mean(errors[key])),mse=float(np.mean(squared[key])),
                                 upper_winner_agreement=float(np.mean(agreement)),
                                 ikaros_decoder_max_error=parity,encoder_max_error=encoder_error))
            print(f'Validated bottom-up tau={tau}, seed={seed}; decoder parity {parity:.2g}',flush=True)
    aggregate=[]
    for tau in (.02,.08):
        for key in errors:
            subset=[r for r in rows if r['bottom_up_temperature']==tau and r['decoder']==key]
            aggregate.append(dict(bottom_up_temperature=tau,decoder=key,
                                  mae_mean=float(np.mean([r['mae'] for r in subset])),
                                  mae_sd=float(np.std([r['mae'] for r in subset],ddof=1)),
                                  mse_mean=float(np.mean([r['mse'] for r in subset]))))
    result=dict(per_seed=rows,aggregate=aggregate,training_changed=False,
                definition='For soft top-down decoding, clip negative reconstructed activities, normalize per location, then raise probabilities to 1/T and renormalize; T=0 takes argmax on raw scores.')
    (e.OUTPUT/'topdown_codebook_comparison.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=['# Frozen top-down codebook reconstruction','',result['definition'],'','| Bottom-up tau | Decoder | Pixel MAE mean | SD | Pixel MSE |','| --- | --- | ---: | ---: | ---: |']
    for r in aggregate:lines.append(f"| {r['bottom_up_temperature']} | {r['decoder']} | {r['mae_mean']:.5f} | {r['mae_sd']:.5f} | {r['mse_mean']:.5f} |")
    (e.OUTPUT/'topdown_codebook_comparison.md').write_text('\n'.join(lines)+'\n')
    for tau in (.02,.08):
        keys=['original','local_soft','local_hard','upper_T1','upper_T0.25','upper_hard']
        canvas=Image.new('RGB',(1100,740),'white');draw=ImageDraw.Draw(canvas);font=ImageFont.load_default(size=17)
        draw.text((15,10),f'Bottom-up temperature {tau}; seed 71001; frozen reconstruction',fill='black',font=font)
        for row,key in enumerate(keys):
            y=45+row*114;draw.text((10,y+35),key,fill='black',font=font)
            for col,i in enumerate(selected):
                values=panels[(tau,i)][key]
                canvas.paste(Image.fromarray(np.uint8(np.clip(values,0,1)*255)).resize((96,96),Image.Resampling.NEAREST),(165+col*114,y))
        canvas.save(e.OUTPUT/f'topdown_reconstruction_tau_{str(tau).replace(".","p")}.png')
    print('\n'.join(lines),flush=True)


if __name__=='__main__':main()
