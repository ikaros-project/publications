"""Two separated objects: sensory spotlight, fixed spatial competition, cue switching."""
import os
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['VECLIB_MAXIMUM_THREADS']='2'
import json,hashlib,time,itertools
import numpy as np
from evaluate_spatial_single_stimulus import CAMPAIGN,e,prior,softmax
from evaluate_spatial_competition import step
OUT=CAMPAIGN/'spatial_two_objects_seed1'
SIGMA=24.;FLOOR=.2;PEAK=1.2
STEPS=[0,1,5,10,20,50,100,200,500,1000]

def dump(p,x):p.write_text(json.dumps(x,indent=2,default=lambda v:v.item())+'\n')

class FrozenModel:
    def __init__(self):
        self.paths=[CAMPAIGN/'hierarchy_s71001/model.state',CAMPAIGN/'hierarchy_s71001/codebook_final.npz',CAMPAIGN/'neural_readout_regularized_capacity/full_refit/grouped_softmax_s71001.npz',CAMPAIGN/'local_linear_patch_decoder_seed1/local_decoder.npz']
        self.hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in self.paths]
        state=json.loads(self.paths[0].read_text())['items']
        def w(k):
            v=state['CVAE_TwoLayer.Upper.'+k];return np.array(v['value'],np.float32).reshape(v['shape'])
        self.enc=w('DIRECT_MEAN_WEIGHTS');self.eb=w('DIRECT_MEAN_BIAS');self.dec=w('DIRECT_DECODER_WEIGHTS');self.db=w('DIRECT_DECODER_BIAS')
        with np.load(self.paths[1]) as z:self.book=prior.Codebook(z['prototypes'])
        with np.load(self.paths[2]) as z:self.rw=z['weights'];self.rb=z['bias']
        with np.load(self.paths[3]) as z:self.decoder=z['decoder'].astype(np.float32)
        self.counts=np.zeros((32,32),np.float32)
        for dy in range(7):
            for dx in range(7):self.counts[dy:dy+26,dx:dx+26]+=1
    def infer(self,windows):
        probs=[];qualities=[]
        for start in range(0,len(windows),64):
            x=windows[start:start+64];n=len(x)
            patch=np.lib.stride_tricks.sliding_window_view(x,(7,7),axis=(1,2)).reshape(-1,49)
            b=self.book.prototypes
            dist=(patch*patch).sum(1)[:,None]+(b*b).sum(1)[None]-2*patch@b.T
            act=softmax(-dist/(49*.08)).reshape(n,676,64).transpose(0,2,1).copy()
            latent=act.reshape(n,-1)@self.enc+self.eb
            p=softmax(latent@self.rw+self.rb).reshape(n,10,20).sum(2)
            top=softmax((latent@self.dec+self.db).reshape(n,64,676).transpose(0,2,1))
            patches=(top@self.decoder).reshape(n,26,26,7,7);y=np.zeros_like(x)
            for dy in range(7):
                for dx in range(7):y[:,dy:dy+26,dx:dx+26]+=patches[:,:,:,dy,dx]
            y=np.clip(y/self.counts,0,1)
            probs.append(p);qualities.append((2*x*y-y*y).sum((1,2)))
        return np.concatenate(probs),np.concatenate(qualities)
    def scene(self,x):
        windows=np.lib.stride_tricks.sliding_window_view(x,32,axis=1).transpose(1,0,2).copy()
        # Exact reuse of blank windows, not removal of their competition units.
        unique,inverse=np.unique(windows.reshape(289,-1),axis=0,return_inverse=True)
        p,q=self.infer(unique.reshape(-1,32,32))
        return p[inverse],q[inverse]
    def unchanged(self):return self.hashes==[hashlib.sha256(p.read_bytes()).hexdigest() for p in self.paths]

def drive(prob,quality):
    q=quality.astype(np.float64);p=prob.astype(np.float64)
    raw=q/np.maximum(q.max(-1,keepdims=True),1e-30)+.1*np.log(np.maximum(p.max(-1),1e-30))
    v=np.maximum(raw,0);return v/np.maximum(v.max(-1,keepdims=True),1e-30)

def compete(ev,prob,initial=None):
    a=np.zeros_like(ev) if initial is None else initial.copy();traces=[a.copy()];stable=np.zeros(len(a),int);settled=np.full(len(a),-1,int)
    for t in range(1,1001):
        nxt=step(a,ev);change=abs(nxt-a).max(1);a=nxt
        dom=a.max(1)/np.maximum(a.sum(1),1e-30)
        stable=np.where((change<1e-7)&(dom>=.9999),stable+1,0)
        done=(stable>=10)&(settled<0);settled[done]=t
        if t in STEPS:traces.append(a.copy())
    pooled=np.einsum('nw,nwc->nc',a,prob)/np.maximum(a.sum(1,keepdims=True),1e-30)
    return a,pooled,np.array(traces),settled

def main():
    OUT.mkdir(exist_ok=True)
    raw=e.full.read_idx_images(e.full.RAW_ROOT/'t10k-images-idx3-ubyte.gz',3000)[2000:]
    lab=e.full.read_idx_labels(e.full.RAW_ROOT/'t10k-labels-idx1-ubyte.gz',3000)[2000:]
    pools={c:list(np.flatnonzero(lab==c)[:9]) for c in range(10)}
    pairs=[]
    for ca,cb in itertools.combinations(range(10),2):pairs.append((ca,cb,pools[ca].pop(0),pools[cb].pop(0)))
    rng=np.random.default_rng(92021);meta=[];scenes=[];gains=[];inputs=[]
    conditions=['none','left','right','isolated_left','isolated_right']
    for pair,(ca,cb,ia,ib) in enumerate(pairs):
        shift=int(rng.integers(-16,17));left=64+shift;right=224+shift
        A=e.full.center_and_pad(raw[ia]).astype(np.float32)/255;B=e.full.center_and_pad(raw[ib]).astype(np.float32)/255
        for swap in [False,True]:
            la,lb=(cb,ca) if swap else (ca,cb);aa,bb=(B,A) if swap else (A,B)
            parts=np.zeros((2,32,320),np.float32);parts[0,:,left:left+32]=aa;parts[1,:,right:right+32]=bb
            scene=parts.sum(0);scene_gains=[];scene_inputs=[]
            for name in conditions:
                if name=='none':g=np.ones(320)
                else:
                    center=(left if 'left' in name else right)+15.5
                    g=FLOOR+(PEAK-FLOOR)*np.exp(-.5*((np.arange(320)-center)/SIGMA)**2)
                original=parts[0] if name=='isolated_left' else parts[1] if name=='isolated_right' else scene
                scene_gains.append(g);scene_inputs.append(np.clip(original*g[None],0,1).astype(np.float32))
            scenes.append(scene);gains.append(scene_gains);inputs.append(scene_inputs)
            meta.append(dict(pair=pair,swap=swap,left_category=la,right_category=lb,left_index=2000+(ib if swap else ia),right_index=2000+(ia if swap else ib),left=left,right=right))
    scenes=np.array(scenes);inputs=np.array(inputs);gains=np.array(gains)
    dump(OUT/'protocol.json',dict(seed=71001,pairs=45,scenes=90,unique_digits=90,selection='First9 digits per category in MNIST test indices2000:3000, assigned once each across45 unordered category pairs. Each pair presented in both left/right orders; no performance selection.',positions='Tile left edges64+jitter and224+jitter, shared uniform integer jitter[-16,16], RNG92021. Center separation160 pixels; both objects fully visible and no receptive field sees both.',conditions=conditions,spotlight=dict(sigma=SIGMA,floor=FLOOR,peak=PEAK,formula='g(x)=.2+exp(-.5*((x-cue_center)/24)^2); effective input=clip(original*g,0,1). Gain identical across vertical rows.'),parameters='Fixed before evaluation; no tuning, retraining, category cue, or full-test-set run.',competition='Locked Q-normalized plus0.1log confidence drive; synchronous inhibition1.5, update.2,1000 updates. Category output pools local probabilities by spatial activity.',switches='Warm left->right and right->left runs start from converged opposite-cue activities; sensory evidence recomputed under new cue, no activity reset.',controls='No cue and both object orders; matched target-alone controls with identical spotlight. Original scene unchanged across cue conditions.',scope='First separated-object pilot, one frozen seed,45 pairs. Trials sharing digits/pairs are not independent. No category feedback or overlap tested. Gain directly modulates pixel-valued sensory representation; biological circuit and endogenous cue generation unspecified.'))
    model=FrozenModel();probs=[];quality=[];t0=time.time()
    for j in range(len(scenes)):
        pp=[];qq=[]
        for inp in inputs[j]:
            p,q=model.scene(inp);pp.append(p);qq.append(q)
        probs.append(pp);quality.append(qq)
        if (j+1)%15==0:print(f'Sensory inference {j+1}/90 scenes',flush=True);dump(OUT/'status.json',dict(stage='sensory inference',completed=j+1,total=90))
    probs=np.array(probs);quality=np.array(quality);ev=drive(probs,quality)
    N=len(scenes);final,pool,trace,settled=compete(ev.reshape(-1,289),probs.reshape(-1,289,10))
    final=final.reshape(N,5,289);pool=pool.reshape(N,5,10);trace=trace.reshape(len(STEPS),N,5,289);settled=settled.reshape(N,5)
    switch_acts=[];switch_probs=[];switch_traces=[];switch_settled=[]
    for old,new in [(1,2),(2,1)]:
        a,p,tr,st=compete(ev[:,new],probs[:,new],final[:,old]);switch_acts.append(a);switch_probs.append(p);switch_traces.append(tr);switch_settled.append(st)
    all_final=np.concatenate([final,np.stack(switch_acts,1)],1);all_pool=np.concatenate([pool,np.stack(switch_probs,1)],1)
    all_settled=np.concatenate([settled,np.stack(switch_settled,1)],1)
    all_conditions=conditions+['left_to_right','right_to_left']
    rows=[];centers=np.arange(289)+15.5
    for j,m in enumerate(meta):
        bands=np.array([abs(centers-(m[side]+15.5))<=31 for side in ['left','right']])
        for k,name in enumerate(all_conditions):
            pred=int(all_pool[j,k].argmax());pos=int(all_final[j,k].argmax());position_center=pos+15.5
            chosen='left' if abs(position_center-(m['left']+15.5))<=16 else 'right' if abs(position_center-(m['right']+15.5))<=16 else 'neither'
            target=None if name=='none' else 'right' if name in ['right','isolated_right','left_to_right'] else 'left'
            t=0 if target=='left' else 1;op=1-t
            weights=all_final[j,k]/all_final[j,k].sum()
            row=dict(scene=j,**m,condition=name,prediction=pred,selected_left_edge=pos,selected_object=chosen,target=target,target_correct=None if target is None else pred==m[target+'_category'],location_correct=None if target is None else chosen==target,settled_at=int(all_settled[j,k]),left_activity_fraction=float(weights[bands[0]].sum()),right_activity_fraction=float(weights[bands[1]].sum()))
            if name in ['left','right']:
                row['unattended_drive_ratio']=float(ev[j,k,bands[op]].sum()/max(ev[j,0,bands[op]].sum(),1e-30))
                row['attended_drive_ratio']=float(ev[j,k,bands[t]].sum()/max(ev[j,0,bands[t]].sum(),1e-30))
                region=slice(m[['left','right'][op]],m[['left','right'][op]]+32)
                row['unattended_sensory_energy_ratio']=float((inputs[j,k,:,region]**2).sum()/(scenes[j,:,region]**2).sum())
            rows.append(row)
    summary={}
    for k,name in enumerate(all_conditions):
        rr=[v for v in rows if v['condition']==name]
        summary[name]=dict(trials=len(rr),target_accuracy=None if name=='none' else float(np.mean([v['target_correct'] for v in rr])),location_accuracy=None if name=='none' else float(np.mean([v['location_correct'] for v in rr])),either_object_category_accuracy=float(np.mean([v['prediction'] in [v['left_category'],v['right_category']] for v in rr])),left_selected=sum(v['selected_object']=='left' for v in rr),right_selected=sum(v['selected_object']=='right' for v in rr),neither_selected=sum(v['selected_object']=='neither' for v in rr),unsettled=sum(v['settled_at']<0 for v in rr),median_settling=float(np.median([v['settled_at'] for v in rr])),max_settling=max(v['settled_at'] for v in rr))
        if name in ['left','right']:
            summary[name].update(unattended_drive_ratio_median=float(np.median([v['unattended_drive_ratio'] for v in rr])),unattended_sensory_energy_ratio_mean=float(np.mean([v['unattended_sensory_energy_ratio'] for v in rr])))
    both=np.array([[v['target_correct'] for v in rows if v['condition']==c] for c in ['left','right']])
    leftpos=all_final[:,1].argmax(1);rightpos=all_final[:,2].argmax(1)
    result=dict(summary=summary,both_cued_categories_correct=int(both.all(0).sum()),category_changes_with_cue=int((all_pool[:,1].argmax(1)!=all_pool[:,2].argmax(1)).sum()),location_moves_right=int((rightpos>leftpos).sum()),warm_right_matches_cold=float((all_pool[:,5].argmax(1)==all_pool[:,2].argmax(1)).mean()),warm_left_matches_cold=float((all_pool[:,6].argmax(1)==all_pool[:,1].argmax(1)).mean()),checkpoint_sha256=model.hashes,elapsed_seconds=time.time()-t0)
    assert model.unchanged();assert np.isfinite(all_final).all()
    # Saved probabilities sum to1 at every position, including blank windows.
    np.testing.assert_allclose(probs.sum(-1),1,atol=2e-6)
    np.savez_compressed(OUT/'arrays.npz',scenes=scenes,inputs=inputs,gains=gains,probabilities=probs,quality=quality,evidence=ev,final_activity=all_final,category_probabilities=all_pool,traces=trace,switch_traces=np.array(switch_traces),steps=STEPS,settled=all_settled)
    dump(OUT/'cases.json',rows);dump(OUT/'results.json',result);dump(OUT/'status.json',dict(stage='complete',completed=90,total=90));print(json.dumps(result,indent=2),flush=True)
if __name__=='__main__':main()
