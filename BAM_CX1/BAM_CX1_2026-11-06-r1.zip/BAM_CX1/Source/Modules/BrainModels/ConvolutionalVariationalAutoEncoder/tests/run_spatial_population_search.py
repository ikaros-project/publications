"""Category-guided spatial selection with no external spatial cue."""
import concurrent.futures,json,time,hashlib,shutil,argparse
from pathlib import Path
import numpy as np
import run_spatial_overlap_pilot as r
from run_spatial_population_feedback import PopulationFeedback,InitialAttentionCircuit,ROOT as CUED,BASE,CodeAlignedFeedback
from neural_spatial_rate_model import Circuit
ROOT=CUED.parent/'population_search_pilot'
class SearchCircuit(Circuit):
    profile='neutral'
    object_positions=[124,164]
    last=None
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);type(self).last=self
        if self.profile=='broad':
            midpoint=(self.x.shape[-1]-32)/2
            a=np.maximum(0,49-abs(self.positions-midpoint)).astype(np.float32);self.a[0]=a/a.sum()
        elif self.profile=='divided':
            for pos in self.object_positions:self.a[0,pos+31]+=.5
        self.initial_attention=self.a[0].copy();self.max_external_spatial_input=0.
    def update(self,prob,prediction=None,u=None,v=None,residual_means=None):
        if u is not None:
            self.max_external_spatial_input=max(self.max_external_spatial_input,float(abs(u).max()))
            assert not np.any(u),'Autonomous search received a spatial cue'
        return super().update(prob,prediction,u,v,residual_means)

def init():r.init()

def prepare():
    ROOT.mkdir(exist_ok=True)
    if (ROOT/'protocol.json').exists():return
    meta=json.loads((BASE/'independent'/'stimuli.json').read_text());jobs=[]
    for condition in [p+'_'+m for p in ['neutral','broad','divided'] for m in ['winner','population']]+['cued_parity']:
        folder=ROOT/condition;folder.mkdir(exist_ok=True)
        for name in ['stimuli.json','stimuli.npz']:shutil.copyfile(BASE/'independent'/name,folder/name)
        for m in meta:
            if m['kind']!='pair' or m['separation']!=40:continue
            for cue in ['A','B']:
                if condition!='cued_parity' or (m['case']==2 and cue=='A'):jobs.append([condition,m['case'],'combined_category_'+cue])
    jobs.sort(key=lambda j:j[0]!='cued_parity');assert len(jobs)==61
    r.r.dump(ROOT/'jobs.json',jobs)
    names=['run_spatial_population_search.py','run_spatial_population_feedback.py','run_spatial_overlap_code_alignment.py','run_spatial_overlap_aligned_validation.py','run_spatial_overlap_pilot.py','cached_spatial_content_feedback.py','spatial_content_feedback.py','neural_spatial_rate_model.py']
    r.r.dump(ROOT/'protocol.json',dict(seed=71001,new_experiments=60,parity_runs=1,steps=600,early_stop=False,feedback=.65,selection='Reuse all five unfiltered separated pairs, both category directions. Same ten images as previous pilot; no tuning or screening.',conditions='Neutral, broad, divided initial spatial activity, each with winner or population code feedback:6 conditions x10 directions. Category cue2 is constant; spatial cue identically zero in every experimental update.',initialization='Neutral: all spatial activities zero. Broad: target-independent triangle max(0,49-|field_origin-144|),97 nonzero fields normalized to total1, centered between the two objects. Divided:0.5 at each of the two object origins124/164, identical for both category cues. Divided initialization supplies both locations and is not an unseeded search. Neither neutral nor broad uses target location, category or foreground masks. All nonspatial states retain their original initialization.',controls='One rerun of the earlier focused-population case2/category_A with its original spatial cue must reproduce all saved arrays exactly. New search circuit derives directly from Circuit, not TargetCuedCircuit, and asserts u==0 at every update. Initial spatial arrays must match across cue directions and routing variants within profile.',fixed='Only external spatial cue and declared initial attention change relative to earlier cued tests. Same frozen weights, reference bank, input-selected reference slots, population/winner mechanisms, blank patch boundaries, mismatch, normalization, alpha0.1, sigma24, category cue2 and uniform pooling. No gradients, additional learning, inhibition or threshold tuning.',scoring='Primary localization: spatial mass>1e-7 and selected field origin within16 pixels of the requested object origin, following prior category-search convention. Report signed offsets, exact-origin success, distractor capture within16 pixels, off-object or no response separately. Unforced selected-field category and dominant binding are secondary; externally supplied global category is never counted as recognition. Report target localization plus correct local category jointly, reconstructed target/loser features, whole-canvas union and target-only MSE, effective spatial breadth, target-vs-distractor basin activity, all600-step endpoints and final100 max normalized update<5e-6. No extensions or oscillation investigations.',scope='Five-pair/one-network paired pilot. Category cue remains, so this tests endogenous spatial selection guided by category, not fully uncued recognition. No absent-target trials or population prevalence estimate. No model adoption or manuscript-body changes.',source_sha256={n:hashlib.sha256(Path(__file__).with_name(n).read_bytes()).hexdigest() for n in names}))
    print('PREPARED 60 category-only search trials + 1 parity',flush=True)

def worker(job):
    condition,j,name=job;r.ROOT=ROOT/condition;folder=r.ROOT/f'case{j:02d}_{name}'
    if (folder/'routing.json').exists() and (folder/'result.json').exists():return dict(search_condition=condition,**json.loads((folder/'result.json').read_text()))
    m=json.loads((r.ROOT/'stimuli.json').read_text())[j];k=0 if name.endswith('_A') else 1
    if condition=='cued_parity':
        r.Circuit=InitialAttentionCircuit;InitialAttentionCircuit.profile='focused';InitialAttentionCircuit.cue_position=m['positions'][k];InitialAttentionCircuit.object_positions=m['positions'];r.CachedLocalFeedback=PopulationFeedback
    else:
        profile,route=condition.split('_');SearchCircuit.profile=profile;SearchCircuit.object_positions=m['positions'];r.Circuit=SearchCircuit
        r.CachedLocalFeedback=PopulationFeedback if route=='population' else CodeAlignedFeedback;CodeAlignedFeedback.mode='codes'
    row=r.worker((j,name))
    if condition=='cued_parity':
        with np.load(folder/'arrays.npz') as a,np.load(CUED/'focused_population'/folder.name/'arrays.npz') as b:
            assert set(a.files)==set(b.files)
            for key in a.files:np.testing.assert_array_equal(a[key],b[key],err_msg=key)
        r.r.dump(ROOT/'parity.json',dict(all_saved_arrays_bit_identical=True));routing=dict(parity=True)
    else:
        c=SearchCircuit.last;local=PopulationFeedback.last if route=='population' else CodeAlignedFeedback.last
        routing=dict(profile=profile,route=route,max_external_spatial_input=c.max_external_spatial_input,initial_attention=c.initial_attention.tolist(),diagnostics=local.diagnostics if route=='population' else [],anchor_trace=local.anchors if route=='winner' else [])
    r.r.dump(folder/'routing.json',routing)
    return dict(search_condition=condition,**row)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=12);args=ap.parse_args();prepare();rows=[];start=time.time()
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,initializer=init) as pool:
        fs=[pool.submit(worker,j) for j in json.loads((ROOT/'jobs.json').read_text())]
        for f in concurrent.futures.as_completed(fs):
            rows.append(f.result());r.r.dump(ROOT/'status.json',dict(completed=len(rows),total=61,seconds=time.time()-start))
    r.r.dump(ROOT/'results.json',dict(new_runs=rows,parity=json.loads((ROOT/'parity.json').read_text())))
    print('POPULATION SEARCH COMPLETE',flush=True)
if __name__=='__main__':main()
