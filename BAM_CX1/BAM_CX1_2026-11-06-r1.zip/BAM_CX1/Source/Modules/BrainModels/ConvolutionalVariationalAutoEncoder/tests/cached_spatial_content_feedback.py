"""Exact reuse of unchanged inputs; no tolerance, unit pruning or early stopping."""
import numpy as np
from spatial_content_feedback import ContentFrontend,LocalFeedback
from neural_spatial_rate_model import windows

class CachedFrontend(ContentFrontend):
    def _reuse(self,key,x,fn):
        previous=getattr(self,key,None)
        if previous is not None and np.array_equal(previous[0],x):return previous[1]
        out=fn(x)
        # Inputs are replaced, never edited in place, by this experiment runner.
        setattr(self,key,(x,out))
        return out
    def bottom(self,x):return self._reuse('_bottom_cache',x,super().bottom)
    def evidence(self,x):return self._reuse('_evidence_cache',x,super().evidence)
    def infer_pixels(self,x):return self._reuse('_pixels_cache',x,super().infer_pixels)

class CachedLocalFeedback(LocalFeedback):
    def propose(self,circuit):
        b=self.front.bottom(windows(circuit.s,31)[0])
        gate=np.ones(len(b),np.float32)
        if self.attention:gate=np.clip((circuit.a[0]@self.field_kernel)/max(1.,float(circuit.a.sum())),0,1)
        c=circuit.c[0];mass=float(c.sum())
        lam=.5*gate if self.feedback and mass>1e-7 else np.zeros_like(gate)
        target=b.copy()
        if np.any(lam):
            weights=c/mass
            if not hasattr(self,'_weights') or not np.array_equal(weights,self._weights):
                Q=np.zeros_like(b)
                for k in range(10):
                    if weights[k]!=0:Q+=weights[k]*self.front.rp[k,self.chosen[:,k]]
                self._weights=weights.copy();self._Q=Q
            target=(1-lam[:,None,None])*b+lam[:,None,None]*self._Q
        new=(1-circuit.par.alpha)*self.q+circuit.par.alpha*target
        return new,float(np.max(abs(new-self.q))),gate
