"""Select intersection stimuli from bottom-up evidence only; no feedback trials."""
import os
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['VECLIB_MAXIMUM_THREADS']='2'
from pathlib import Path
from argparse import Namespace
import json,hashlib
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import evaluate_local_patch_decoder as local
n=local.n;e=n.e
OUT=n.CAMPAIGN/'shared_stroke_candidates';OUT.mkdir(exist_ok=True)
M=Path(__file__).resolve().parents[5]/'Manuscript'
protocol=dict(pool='First30 MNIST test images per category; all45 unordered category pairs,900 source pairs each',construction='Pixelwise minimum after existing centering/padding; no alignment search, thresholding or dilation in stimulus',morphology='At least25 pixels>.25; retained intensity fraction for each original between.30 and.85. For each category pair keep20 highest minimum retained fractions.',screen='Seed71001 bottom-up only. Both originals must be correctly categorized. Intersection top two categories must be the intended pair, combined probability>=.70 and smaller/larger probability>=.5.',ranking='Rank passing intersections by probability ratio descending, then combined mass. Select at most one per category pair and no reused original, maximum12.',confirmation='Report initial probabilities for selected stimuli across all ten frozen models. No reselection based on confirmation.',scope='Exploratory bottom-up stimulus selection on reused test data, not an unbiased benchmark. No feedback, category bias or learning performed.')
(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
train,test,labels,tl=e.prepare_data(Namespace(train_count=60000,test_count=10000));ids=np.concatenate([np.flatnonzero(tl==c)[:30] for c in range(10)]);images=np.stack([e.full.center_and_pad(test[i]) for i in ids]).astype(np.float32)/255
candidates=[];shared=[]
for ca in range(10):
 for cb in range(ca+1,10):
  pool=[]
  for ia in range(ca*30,(ca+1)*30):
   for ib in range(cb*30,(cb+1)*30):
    v=np.minimum(images[ia],images[ib]);fa=float(v.sum()/images[ia].sum());fb=float(v.sum()/images[ib].sum());pixels=int((v>.25).sum())
    if .3<=min(fa,fb) and max(fa,fb)<=.85 and pixels>=25:pool.append((min(fa,fb),ia,ib,fa,fb,pixels))
  for _,ia,ib,fa,fb,pixels in sorted(pool,reverse=True)[:20]:
   candidates.append(dict(a=ca,b=cb,ia=ia,ib=ib,test_a=int(ids[ia]),test_b=int(ids[ib]),retained_a=fa,retained_b=fb,stroke_pixels=pixels));shared.append(np.minimum(images[ia],images[ib]))
shared=np.array(shared);print('Morphological candidates',len(shared),flush=True)
def predict(seed,x):
 folder=n.CAMPAIGN/f'hierarchy_s{seed}';rd=n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit'/f'grouped_softmax_s{seed}.npz';paths=[folder/'model.state',folder/'codebook_final.npz',rd];hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
 s=json.loads(paths[0].read_text())['items']
 def w(k):
  v=s['CVAE_TwoLayer.Upper.'+k];return np.array(v['value'],np.float32).reshape(v['shape'])
 enc=w('DIRECT_MEAN_WEIGHTS');eb=w('DIRECT_MEAN_BIAS');del s
 with np.load(paths[1]) as z:book=z['prototypes'].astype(np.float32)
 with np.load(rd) as z:rw=z['weights'];rb=z['bias']
 outputs=[]
 for start in range(0,len(x),32):
  xx=x[start:start+32];a=local.activities(local.patches(xx).reshape(-1,49),book).reshape(len(xx),676,64).transpose(0,2,1);z=a.reshape(len(xx),-1)@enc+eb;outputs.append(n.softmax(z@rw+rb).reshape(-1,10,20).sum(2))
 assert [hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]==hashes
 return np.concatenate(outputs),hashes
probs,hashes=predict(71001,np.concatenate([images,shared]));orig=probs[:300];pr=probs[300:]
for i,r in enumerate(candidates):
 pa=float(pr[i,r['a']]);pb=float(pr[i,r['b']]);r.update(index=i,pa=pa,pb=pb,ratio=min(pa,pb)/max(pa,pb),mass=pa+pb,top2=pr[i].argsort()[-2:].tolist(),originals_correct=bool(orig[r['ia']].argmax()==r['a'] and orig[r['ib']].argmax()==r['b']))
 r['passes']=r['originals_correct'] and set(r['top2'])=={r['a'],r['b']} and r['mass']>=.7 and r['ratio']>=.5
eligible=sorted([r for r in candidates if r['passes']],key=lambda r:(r['ratio'],r['mass']),reverse=True);selected=[];pairs=set();used=set()
for r in eligible:
 if (r['a'],r['b']) in pairs or r['test_a'] in used or r['test_b'] in used:continue
 selected.append(r.copy());pairs.add((r['a'],r['b']));used.update([r['test_a'],r['test_b']])
 if len(selected)==12:break
print('Passing',len(eligible),'Selected',len(selected),flush=True)
assert selected,'No candidate passed preset criteria; inspect screen before changing criteria'
chosen=shared[[r['index'] for r in selected]];allpr=[];checks={}
for seed in range(71001,71011):
 pp,hh=predict(seed,chosen);allpr.append(pp);checks[str(seed)]=hh;print('evaluated',seed,flush=True)
allpr=np.array(allpr)
for j,r in enumerate(selected):
 r['candidate']=j+1;r['mean_pa']=float(allpr[:,j,r['a']].mean());r['mean_pb']=float(allpr[:,j,r['b']].mean());r['pair_top2_models']=sum(set(v.argsort()[-2:])=={r['a'],r['b']} for v in allpr[:,j]);r['balanced_models']=sum(set(v.argsort()[-2:])=={r['a'],r['b']} and min(v[r['a']],v[r['b']])/max(v[r['a']],v[r['b']])>=.5 and v[r['a']]+v[r['b']]>=.7 for v in allpr[:,j]);r['balanced_models']=int(r['balanced_models']);r['probabilities_by_model']=allpr[:,j].tolist()
(OUT/'results.json').write_text(json.dumps(dict(protocol=protocol,candidates=candidates,selected=selected,checkpoint_sha256=checks),indent=2)+'\n');np.savez_compressed(OUT/'arrays.npz',original_images=images,source_test_indices=ids,all_shared=shared,screen_probabilities=pr,selected_shared=chosen,selected_probabilities=allpr)
font=ImageFont.load_default(size=18);small=ImageFont.load_default(size=15)
for page in range((len(selected)+5)//6):
 rr=selected[page*6:(page+1)*6];canvas=Image.new('RGB',(1030,85+len(rr)*145),'white');d=ImageDraw.Draw(canvas);d.text((12,10),'Shared-stroke candidates: bottom-up evidence only',fill='black',font=font)
 for x,label in [(100,'Original A'),(240,'Original B'),(380,'Shared pixels'),(535,'Initial category support')]:d.text((x,45),label,fill='black',font=small)
 for row,r in enumerate(rr):
  y=80+row*145;d.text((10,y+45),f"#{r['candidate']}\n{r['a']} / {r['b']}",fill='black',font=font)
  for x,v in [(100,images[r['ia']]),(240,images[r['ib']]),(380,shared[r['index']])]:canvas.paste(Image.fromarray(np.uint8(v*255)).resize((112,112),Image.Resampling.NEAREST).convert('RGB'),(x,y))
  d.text((535,y+4),f"Screen model: {r['a']} {r['pa']:.1%} | {r['b']} {r['pb']:.1%}",fill='black',font=font)
  d.text((535,y+33),f"Ten-model mean: {r['a']} {r['mean_pa']:.1%} | {r['b']} {r['mean_pb']:.1%}",fill='black',font=font)
  d.text((535,y+62),f"Balanced in {r['balanced_models']}/10 models; intended top two in {r['pair_top2_models']}/10",fill='black',font=small)
  d.text((535,y+87),f"Retained strokes (intensity): {r['retained_a']:.0%} / {r['retained_b']:.0%}",fill='black',font=small)
 canvas.save(M/f'shared_stroke_candidate_gallery_{page+1}.png')
lines=['# Shared-stroke candidate selection','','Prepared for joint visual review; no category-bias experiments performed.','','## Selection protocol','',json.dumps(protocol,indent=2),'',f'Morphological shortlist: {len(candidates)}. Passing bottom-up criteria: {len(eligible)}. Diverse candidates retained: {len(selected)}.','', '| Candidate | Categories | Screen probabilities | Mean across10 | Balanced models | Intended top two |','|---|---|---|---|---|---|']
for r in selected:lines.append(f"|{r['candidate']}|{r['a']}/{r['b']}|{r['pa']:.1%}/{r['pb']:.1%}|{r['mean_pa']:.1%}/{r['mean_pb']:.1%}|{r['balanced_models']}/10|{r['pair_top2_models']}/10|")
lines+=['','Probabilities are grouped-readout evidence before recurrent competition, not calibrated uncertainty or final category activity. Balanced means both intended categories are top two, their summed probability is at least.70, and smaller/larger probability is at least.5. A balanced mean can conceal individual-model imbalance; per-model counts are reported. Verification on nine other models is descriptive; no feedback outcome was used. The intersection is a fuzzy grayscale conjunction, not a binary thresholded stimulus. Retained intensity does not directly measure unique stroke count. No registration beyond existing preprocessing, no dilation, and no learned weights changed. All screen candidates and source indices are retained for reproducibility.','', 'The manuscript text is unchanged pending visual stimulus selection.']
(M/'shared_stroke_candidate_source_notes.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines[-len(selected)-5:]),flush=True)
if __name__=='__main__':pass
