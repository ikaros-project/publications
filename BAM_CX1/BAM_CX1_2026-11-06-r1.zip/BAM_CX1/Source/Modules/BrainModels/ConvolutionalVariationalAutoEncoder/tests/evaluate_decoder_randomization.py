"""Reviewer 1 comment 3: fixed, progressive randomization of each decoder separately."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','2');os.environ.setdefault('VECLIB_MAXIMUM_THREADS','2')
import json,csv,hashlib,time
from pathlib import Path
import numpy as np
import evaluate_reference_bank_sensitivity as b
OUT=b.C/'decoder_randomization_20261105'
LEVELS=[0,.25,.5,.75,1.];SEEDS=[2026110501+i for i in range(5)]
def dump(n,v):b.dump(OUT/n,v)
def status(s,**kw):dump('status.json',dict(stage=s,**kw));print(s,kw,flush=True)
def arrayhash(a):return hashlib.sha256(a.tobytes()).hexdigest()
def main():
 OUT.mkdir(exist_ok=True);status('loading frozen model')
 m=b.load();refs=json.loads((b.C/'category_feedback_diagnostic/reference_indices.json').read_text())['71001'];ids=np.array([refs[str(c)] for c in range(10)])
 protocol=dict(model_seed=71001,levels=LEVELS,random_seeds=SEEDS,decoders={'patch':'64 x 49 local code-to-pixel matrix, no bias; rendering only','vae':'128 x 43264 latent-to-code weight matrix; affects BOTH current-state decoding and reference predictions. Original VAE bias retained.'},randomization='For each decoder and realization, choose one random permutation of scalar weight positions and one independent Gaussian replacement array matched to the original matrix population mean and SD (ddof=0, computed in float64, samples cast to float32). Replace the first floor(fraction*N) positions. Masks and replacement values are nested across fractions. Each matrix is fixed for the entire test.',generator='numpy.random.default_rng; permutation followed by normal draw; VAE seeds as listed, patch seeds + 1000',numpy_version=np.__version__,inference=dict(alpha=.2,feedback_fraction=.5,inhibition=1.5,steps=500),stimuli='Existing 220 mixture cases and 160 occlusion inputs; all retained. No new selection or screening.',fixed='Encoders, codebook, supervised readout, original eight-reference bank, initial reference addresses, sensory input, initialization, all other weights and update settings unchanged. One decoder randomized at a time. Reference addresses chosen from original input before inference.',metrics='Same independent full-training-image pixel 5NN, winner agreement, category accuracy, input/clean/hidden/visible MSE, switching and settling. Additional image change and final winner change relative to the learned-decoder baseline.',replication='Five random realizations per decoder at nonzero fractions. Zero fraction is one shared learned-model baseline, not five independent runs.',scope='Descriptive sensitivity to learned weights, one trained network and reused 3/8 stimuli. Not a test of reference dependence or a biological lesion model.',examples='Existing mixture case 37 and first source image at 12/16-pixel deletions, realization 0. Selected before outcomes.',checkpoint_sha256=m['hashes'],script_sha256=b.sha(Path(__file__)),dependency_sha256=b.sha(Path(b.__file__)))
 pp=OUT/'protocol.json'
 if pp.exists():assert json.loads(pp.read_text())==protocol
 else:dump('protocol.json',protocol)
 status('validating learned baseline');baseline=b.simulate(m,ids)
 parity=dict(max_activity_error=float(abs(baseline['acts']-m['known_acts']).max()),max_pixel_error=float(abs(baseline['images']-m['known_images']).max()))
 assert max(parity.values())<3e-5;assert np.array_equal(baseline['acts'].argmax(2),m['known_acts'].argmax(2))
 original_hash={k:arrayhash(m[k]) for k in ['enc','eb','dec','db','rw','rb','decoder']}
 # The patch decoder is only used by render. Reuse the exact common dynamics.
 rc=m['codes'][ids].astype(np.float32);rp=b.decode(m,rc.reshape(-1,128)).reshape(10,8,64,676)
 rz=(rp.reshape(-1,64*676)@m['enc']+m['eb']).reshape(10,8,128)
 cz=np.stack([rz[c,baseline['chosen'][:,c]] for c in range(10)],axis=1)
 zfinal=baseline['base_coeff'][-1]*m['z0']+np.einsum('nc,ncd->nd',baseline['coeff'][-1],cz)
 qfinal=b.decode(m,zfinal)
 reconstructed=np.clip(b.original.local.overlap(qfinal.transpose(0,2,1)@m['decoder']),0,1)
 np.testing.assert_array_equal(reconstructed,baseline['images'])
 def save(name,res,decoder,level,rep,meta):
  rows=b.score(m,res,0,8)
  for j,row in enumerate(rows):
   row.pop('bank');row.pop('size');row.update(decoder=decoder,fraction=level,realization=rep,winner_changed_from_baseline=bool(row['final_winner']!=baseline['acts'][-1,j].argmax()),image_change_mse=float(((res['images'][j]-baseline['images'][j])**2).mean()))
  if level==0:assert all(x['pixel_prediction']==y['pixel_prediction'] for x,y in zip(rows,m['mixrows']+m['ocrows']))
  summary=b.summary(rows)
  for a in summary:
   rr=[v for v in rows if v['task']==a['task'] and (v['task']=='mixture' and (a['level']=='all' or v['mix']==.5) or v['task']=='occlusion' and v['occlusion_size']==a['level'])]
   for key in ['winner_changed_from_baseline','image_change_mse']:a[key]=float(np.mean([v[key] for v in rr]))
  result=dict(decoder=decoder,fraction=level,realization=rep,metadata=meta,cases=rows,summary=summary)
  dump(name+'.json',result)
  np.savez_compressed(OUT/(name+'.npz'),images=res['images'],activities=res['acts'],last10changes=res['changes'],chosen_reference_slots=res['chosen'],reference_ids=ids)
  return result
 conditions=[save('baseline',baseline,'learned',0,None,{})];checks={'baseline':parity};parameters={}
 for decoder,key in [('patch','decoder'),('vae','dec')]:
  weights=m[key];mean=float(weights.astype(np.float64).mean());sd=float(weights.astype(np.float64).std());parameters[decoder]=dict(shape=list(weights.shape),mean=mean,sd=sd)
  for rep,seed in enumerate(SEEDS):
   rng=np.random.default_rng(seed+(1000 if decoder=='patch' else 0));order=rng.permutation(weights.size);draw=rng.normal(mean,sd,size=weights.shape).astype(np.float32)
   for fraction in LEVELS[1:]:
    name=f'{decoder}_r{rep}_p{int(100*fraction):03d}';status('running',decoder=decoder,realization=rep,fraction=fraction)
    if (OUT/(name+'.json')).exists():conditions.append(json.loads((OUT/(name+'.json')).read_text()));continue
    start=time.monotonic();new=weights.copy();ix=order[:int(fraction*weights.size)];new.ravel()[ix]=draw.ravel()[ix];mm={**m,key:new}
    if decoder=='patch':
     res={**baseline,'images':np.clip(b.original.local.overlap(qfinal.transpose(0,2,1)@new),0,1)}
     if rep==0 and fraction==1:
      direct=b.simulate(mm,ids);np.testing.assert_array_equal(direct['acts'],baseline['acts']);np.testing.assert_array_equal(direct['images'],res['images']);checks['patch_full_randomization_direct_dynamics_parity']=True
    else:res=b.simulate(mm,ids)
    np.testing.assert_array_equal(res['chosen'],baseline['chosen'])
    assert arrayhash(new)==arrayhash(mm[key]);assert {k:arrayhash(m[k]) for k in original_hash}==original_hash
    meta=dict(random_seed=seed+(1000 if decoder=='patch' else 0),replaced_weights=len(ix),total_weights=weights.size,weight_sha256=arrayhash(new),unchanged_bias=True)
    conditions.append(save(name,res,decoder,fraction,rep,meta));status('condition complete',name=name,seconds=round(time.monotonic()-start,1))
 assert {str(p.relative_to(b.C)):b.sha(p) for p in m['paths']}==m['hashes']
 checks['original_checkpoint_hashes_unchanged']=True;checks['reference_addresses_unchanged']=True
 dump('results.json',dict(protocol=protocol,conditions=conditions,checks=checks,randomization_parameters=parameters))
 rows=[{**a,'decoder':c['decoder'],'fraction':c['fraction'],'realization':c['realization']} for c in conditions for a in c['summary']]
 with (OUT/'per_condition_summary.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 status('complete',unique_conditions=len(conditions),case_endpoints=len(conditions)*380)
if __name__=='__main__':main()
