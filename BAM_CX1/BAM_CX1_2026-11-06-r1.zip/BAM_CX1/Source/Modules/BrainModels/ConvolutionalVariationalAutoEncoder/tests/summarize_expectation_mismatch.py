import json,csv
from pathlib import Path
import numpy as np
import evaluate_expectation_mismatch as e
M=Path(__file__).resolve().parents[5]/'Manuscript';out=e.OUT;rows=json.loads((out/'results.json').read_text())['cases']
def stat(v):
 v=np.array(v,float);mean=v.mean();sd=v.std(ddof=1);h=2.262157*sd/np.sqrt(len(v));return dict(mean=float(mean),sd=float(sd),ci95=[float(mean-h),float(mean+h)])
def auc(pos,neg):
 d=np.asarray(pos)[:,None]-np.asarray(neg)[None];return float(((d>0)+.5*(d==0)).mean())
perseed=[]
for seed in range(71001,71011):
 rr=[v for v in rows if v['seed']==seed and v['mode']=='primed'];groups={rel:[v for v in rr if v['relation']==rel] for rel in ['matching','conflicting','shared']};s=dict(seed=seed)
 for rel,group in groups.items():
  s[rel]={key:float(np.mean([v[key] for v in group])) for key in ['initial_disagreement','disagreement50','disagreement550','sensory_js','internal_js50','internal_js550']};s[rel]['cue50']=sum(v['winner50']==v['cue'] for v in group);s[rel]['cue550']=sum(v['winner550']==v['cue'] for v in group)
 s['auc']={key:auc([v[key] for v in groups['conflicting']],[v[key] for v in groups['matching']]) for key in ['initial_disagreement','sensory_js']};s['paired_ordering']={key:sum(c[key]>m[key] for c,m in zip(groups['conflicting'],groups['matching'])) for key in ['initial_disagreement','sensory_js']};perseed.append(s)
summary={rel:{key:stat([s[rel][key] for s in perseed]) for key in ['initial_disagreement','disagreement50','disagreement550','sensory_js','internal_js50','internal_js550']} for rel in ['matching','conflicting','shared']}
result=dict(summary=summary,auc={key:stat([s['auc'][key] for s in perseed]) for key in ['initial_disagreement','sensory_js']},paired_ordering={key:sum(s['paired_ordering'][key] for s in perseed) for key in ['initial_disagreement','sensory_js']},per_seed=perseed,settled=sum(v['settled'] for v in rows),trials=len(rows),cue_counts={rel:{t:sum(v['winner'+t]==v['cue'] for v in rows if v['mode']=='primed' and v['relation']==rel) for t in ['50','550']} for rel in ['matching','conflicting','shared']})
# Matched control differences in internal mismatch.
result['cue_minus_control50']={rel:{key:stat([np.mean([v[key] for v in rows if v['seed']==seed and v['mode']=='primed' and v['relation']==rel])-np.mean([v[key] for v in rows if v['seed']==seed and v['mode']=='none' and v['relation']==rel]) for seed in range(71001,71011)]) for key in ['disagreement50','internal_js50']} for rel in ['matching','conflicting','shared']}
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
with (M/'expectation_mismatch_statistics.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
traces=[]
for seed in range(71001,71011):
 with np.load(out/f'seed{seed}/arrays.npz') as z:
  traces.append({rel:{key:z[key][:,36+ri:72:3].mean(1) for key in ['disagreement','internal_js']} for ri,rel in enumerate(['matching','conflicting','shared'])})
with (M/'expectation_mismatch_trace.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['step']+[rel+'_'+key for rel in ['matching','conflicting','shared'] for key in ['disagreement','internal_js','fixed_js']])
 for t in range(151):
  values=[]
  for rel in ['matching','conflicting','shared']:values.extend([np.mean([s[rel]['disagreement'][t] for s in traces]),np.mean([s[rel]['internal_js'][t] for s in traces]),summary[rel]['sensory_js']['mean']])
  w.writerow([t,*values])
with np.load(out/'seed71001/arrays.npz') as z:
 steps=z['steps'].tolist();panels=[[z['input'][j]]+[z['snapshots'][steps.index(t),j] for t in [0,50,550]] for j in [36,37,38]]
 e.f.gallery(M/'expectation_mismatch_examples.png','Category6 expectation: same cue, three sensory conditions',panels,['matching6','conflicting8','shared6/8'],['observed','initial','cue ends:50','unbiased:550'])
lines=['# Expectation-input mismatch demonstration','','Six preselected pairs; both source categories cued; matching, conflicting and shared inputs;10 frozen models; with/without additive category cue (720 runs). Cue amplitude2 for50 updates then500 without cue;50% prediction relaxation. No stimulus sequence or pre-stimulus imagery was simulated. This is a concurrent category expectation, not a timed anticipatory paradigm.','','Mismatch signals:1-P(cue) from grouped readout, and Jensen-Shannon divergence in nats between lower probabilities and selected category-reference probabilities, averaged across676 positions. Initial sensory code and reference remain fixed. Evolving lower code is compared with the same reference; fixed discrepancy is constant by construction, not a newly emerging persistent response. References selected once from each original observed input; differing references across inputs are part of the existing architecture. Signals logged only, no impact on inference.','','## Results','',json.dumps(result,indent=2),'','## Limits','','AUC compares12 conflicting against12 matching cases per model, not independent categories or held-out stimuli. Paired ordering compares the same pair and cue. Seed t intervals describe model variation on reused stimuli; bounded AUC should not be interpreted outside[0,1]. Shared stimuli were selected for bottom-up ambiguity in one model, while intact originals were required correct there; separation is therefore selection-conditioned. There is no calibrated mismatch threshold or learned mismatch detector, and within-category style differences contribute to code discrepancy. Externally provided category drive is not itself evidence that an input matches. All frozen hashes verified.','','Figure shows first pair/model fixed before inspecting outcomes. Trace means use12 cases per condition in each of10 models; error bars omitted for trajectory readability. Complete statistics and traces retained.']
(M/'expectation_mismatch_source_notes.md').write_text('\n'.join(lines)+'\n');(out/'REPORT.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='per_seed'},indent=2),flush=True)
