"""Release externally held category after stable no-input reconstruction."""
import json,hashlib
from argparse import Namespace
import numpy as np
import evaluate_local_patch_decoder as local
n=local.n;f=n.f;e=n.e
OUT=n.CAMPAIGN/'category_release_seed1'
STEPS=[0,1,2,4,8,16,32,64,128,256,500,1000]
def soft(v):
 v=v-v.max(1,keepdims=True);v=np.exp(v);return v/v.sum(1,keepdims=True)
def dump(name,v):(OUT/name).write_text(json.dumps(v,indent=2)+'\n')
def status(s):dump('status.json',dict(stage=s));print(f'{OUT.name}: {s}',flush=True)
def run(seed, output):
 global OUT
 OUT=output
 OUT.mkdir(exist_ok=True)
 protocol=dict(seed=seed,cases=80,warmup=500,after_release_iterations=1000,alpha=.2,topdown_fraction=1.,conditions=['held','released'],
 initialization='Same shared logistic-normal lower state and all80 references as the published single-seed no-input relaxation test. Warm up500 iterations with category one-hot.',
 release='Preserve p and one-hot a at release; stop clamping a and resume usual autonomous update a_next=.8*a+.2*relu(P/max(P)-1.5*sum_other(a)). Normalized a weights reference probabilities Q. p_next=.8*p+.2*Q. No sensory anchor, parameter changes, reset or new noise.',
 references='Original category retains exactly the reference that generated the image. For each other category choose its nearest reference to the latent mean at release, then hold fixed. This makes alternative predictions available without silently replacing the original exemplar.',
 control='Held category remains one-hot for1000 additional iterations; same lower activity and original reference.',
 evaluation='Competition winners, unnormalized category activity and precompetition readout kept separate; drift MSE and max pixel difference relative to release image; final10 p/a changes<1e-5; late switches; snapshot pixel5NN labels. Preserve full activity/readout/update traces.',
 scope='Single frozen seed; all80 stored references, one initial noise state. Tests persistence after release without perturbation; does not test robustness to disturbances or refreshed references. No learning or default changes.')
 dump('protocol.json',protocol);status('loading frozen model')
 train,test,labels,tl=e.prepare_data(Namespace(train_count=60000,test_count=10000))
 tp=np.stack([e.full.center_and_pad(v) for v in train]).astype(np.float32)/255
 vp=np.stack([e.full.center_and_pad(v) for v in test]).astype(np.float32)/255
 folder=n.CAMPAIGN/f'hierarchy_s{seed}'; rd=n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit'/f'grouped_softmax_s{seed}.npz'; prior=n.CAMPAIGN/'local_linear_patch_decoder_ten_seeds'/f'seed{seed}'; dp=prior/'local_decoder.npz'
 paths=[folder/'model.state',folder/'codebook_final.npz',rd,dp];hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 state=json.loads(paths[0].read_text())['items']
 def w(key):
  a=state['CVAE_TwoLayer.Upper.'+key];return np.array(a['value'],np.float32).reshape(a['shape'])
 enc=w('DIRECT_MEAN_WEIGHTS');eb=w('DIRECT_MEAN_BIAS');dec=w('DIRECT_DECODER_WEIGHTS');db=w('DIRECT_DECODER_BIAS');del state
 with np.load(rd) as z:rw=z['weights'];rb=z['bias']
 with np.load(dp) as z:d=z['decoder'].astype(np.float32)
 with np.load(paths[1]) as z:book=f.prior.Codebook(z['prototypes'])
 def encode(p):return p.reshape(len(p),-1)@enc+eb
 def decode(z):
  v=(z@dec+db).reshape(-1,64,676);v-=v.max(1,keepdims=True);return v-np.log(np.exp(v).sum(1,keepdims=True))
 def probs(z):return n.softmax(z@rw+rb).reshape(-1,10,20).sum(2)
 def render(q):return np.clip(local.overlap(np.exp(q).transpose(0,2,1)@d),0,1)
 codes,_,_=e.read_codes(folder/'train_codes.csv',train,labels,128)
 refs=json.loads((prior/'feedback_inference/reference_indices.json').read_text());ids=np.array([refs[str(c)] for c in range(10)])
 rc=codes[ids].astype(np.float32);rq=decode(rc.reshape(-1,128)).reshape(10,8,64,676);rp=np.exp(rq)
 cats=np.repeat(np.arange(10),8);direct=render(rq.reshape(80,64,676))
 starts=soft(np.random.default_rng(20260921).normal(size=(1,64,676)).astype(np.float32));noise=np.repeat(starts,80,axis=0)

 Q0=rp.reshape(80,64,676);p=noise.copy()
 warmup_changes=[]
 for _ in range(500):
  pn=.8*p+.2*Q0;warmup_changes.append(float(abs(pn-p).max()));p=pn
 assert max(warmup_changes[-10:])<1e-5
 z=encode(p);q=decode(z);pr=probs(z);release_image=render(q);a0=np.eye(10,dtype=np.float32)[cats];release_p=p.copy();release_z=z.copy();release_pr=pr.copy()
 image_parity=None;readout_parity=None
 chosen=((z[:,None,None,:]-rc[None])**2).sum(3).argmin(2);chosen[np.arange(80),cats]=np.tile(np.arange(8),10)
 summary=[];cases=[];bundles={};scores=[]
 for mode in ['held','released']:
  p=release_p.copy();a=a0.copy();pr=release_pr.copy();q=decode(release_z);images=[release_image];acts=[a.copy()];prs=[pr.copy()];changes=[]
  for step in range(1,1001):
   an=a0 if mode=='held' else .8*a+.2*np.maximum(pr/pr.max(1,keepdims=True)-1.5*(a.sum(1,keepdims=True)-a),0)
   if mode=='held':Q=Q0
   else:
    ww=an/an.sum(1,keepdims=True);Q=np.zeros_like(p)
    for c in range(10):Q+=ww[:,c,None,None]*rp[c,chosen[:,c]]
   pn=.8*p+.2*Q;changes.append(np.stack([abs(pn-p).max((1,2)),abs(an-a).max(1)],axis=1));p=pn;a=an
   z=encode(p);q=decode(z);pr=probs(z);acts.append(a.copy());prs.append(pr.copy())
   if step in STEPS:images.append(render(q))
   if step%250==0:status(f'{mode}: {step}/1000 after release time')
  images=np.array(images);acts=np.array(acts);prs=np.array(prs);changes=np.array(changes);wins=acts.argmax(2);drift=((images-release_image)**2).mean((2,3));pixelmax=abs(images-release_image).max((2,3));settled=changes[-10:].max((0,2))<1e-5
  assert np.isfinite(p).all();np.testing.assert_allclose(p.sum(1),1,atol=4e-6)
  summary.append(dict(condition=mode,retained_category=int((wins[-1]==cats).sum()),ever_switched=int((np.diff(wins,axis=0)!=0).any(0).sum()),settled=int(settled.sum()),late_switches=int((np.diff(wins[-100:],axis=0)!=0).sum()),final_readout_agreement=int((prs[-1].argmax(1)==cats).sum()),max_final_pixel_change=float(pixelmax[-1].max()),max_any_snapshot_pixel_change=float(pixelmax.max()),mean_final_image_mse=float(drift[-1].mean()),max_final_image_mse=float(drift[-1].max()),image_mse_above_1e6=int((drift[-1]>1e-6).sum()),final_local_change=float(changes[-10:,:,0].max()),final_competition_change=float(changes[-10:,:,1].max()),final_requested_activity_min=float(acts[-1,np.arange(80),cats].min()),final_requested_activity_mean=float(acts[-1,np.arange(80),cats].mean())))
  for j in range(80):
   sw=np.flatnonzero(np.diff(wins[:,j])!=0)+1
   cases.append(dict(condition=mode,category=int(cats[j]),reference_slot=j%8,reference_index=int(ids.reshape(-1)[j]),initial_readout_category=int(release_pr[j].argmax()),final_readout_category=int(prs[-1,j].argmax()),final_winner=int(wins[-1,j]),switch_iterations=sw.tolist(),switch_sequence=[int(cats[j])]+wins[sw,j].tolist(),settled=bool(settled[j]),final_mse=float(drift[-1,j]),max_snapshot_mse=float(drift[:,j].max()),final_requested_activity=float(acts[-1,j,cats[j]])))
  bundles[mode]=dict(images=images,activities=acts,probabilities=prs,changes=changes,image_mse=drift,pixel_max_change=pixelmax);np.savez_compressed(OUT/(mode+'.npz'),**bundles[mode]);scores.append(images)
 status('scoring snapshot images')
 images=np.array(scores);unique,rev=np.unique(images.reshape(-1,1024),axis=0,return_inverse=True);pred=e.five_nearest_predictions(tp.reshape(60000,-1),labels,unique)[rev].reshape(2,len(STEPS),80)
 for mi,row in enumerate(summary):
  row['initial_pixel_category_agreement']=int((pred[mi,0]==cats).sum());row['final_pixel_category_agreement']=int((pred[mi,-1]==cats).sum());row['final_pixel_winner_agreement']=int((pred[mi,-1]==bundles[row['condition']]['activities'][-1].argmax(1)).sum())
 for r in cases:r['final_pixel_prediction']=int(pred[['held','released'].index(r['condition']),-1,r['category']*8+r['reference_slot']])
 assert all(hashlib.sha256(p.read_bytes()).hexdigest()==hashes[p.name] for p in paths)
 dump('results.json',dict(protocol=protocol,summary=summary,cases=cases,checks=dict(warmup_max_last10_change=max(warmup_changes[-10:]),warmup_image_parity=image_parity,warmup_readout_parity=readout_parity,weights_unchanged=True,checkpoint_sha256=hashes),release_readout_disagreement_indices=np.flatnonzero(release_pr.argmax(1)!=cats).tolist()))
 np.savez_compressed(OUT/'setup.npz',reference_ids=ids,chosen_reference_slots=chosen,release_lower_activity=release_p,release_latent_mean=release_z,release_readout=release_pr,snapshot_steps=STEPS,pixel_predictions=pred)
 f.gallery(OUT/'release_overview.png','No sensory input: release category after image has settled',[[release_image[c*8] for c in range(10)],[bundles['released']['images'][-1,c*8] for c in range(10)]],['before release','1000 later'],[str(c) for c in range(10)])
 selected=np.flatnonzero(release_pr.argmax(1)!=cats).tolist()
 if not selected:selected=[24]
 f.gallery(OUT/'readout_disagreement_cases.png','Cases whose readout preferred a different category at release',[[bundles['released']['images'][STEPS.index(t),j] for t in [0,8,32,128,1000]] for j in selected],[f'cat {cats[j]} ref {j%8+1}' for j in selected],['release','+8','+32','+128','+1000'])
 lines=['# Release of category clamp after stable no-input imagery','','80 references;500 held iterations then1000 additional updates, with held control. References fixed, same mechanism and no new input.','',json.dumps(summary,indent=2),'','Release preserves the existing category activity rather than resetting it. Competing categories become available through the usual recurrent rule. Other-category references are selected once from the release representation; the original reference is preserved. Results describe persistence without perturbation, not basin-of-attraction robustness.']
 (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');status('complete');print(f'{OUT.name}: completed',flush=True)

