"""Fixed absent-target/blank pilot; observational diagnostics only."""
import concurrent.futures,json,time,hashlib,shutil
from pathlib import Path
import numpy as np
import run_spatial_overlap_pilot as r
from run_spatial_population_search import SearchCircuit,ROOT as PRESENT,BASE
from run_spatial_population_feedback import PopulationFeedback
ROOT=PRESENT.parent/'absent_category_pilot'

class DiagnosticCircuit(SearchCircuit):
    requested=0
    profile='neutral'
    last=None
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.records={k:[] for k in ['positive_error','negative_error','support','binding_requested','requested_probability','content_positive_error','content_negative_error']}
    def update(self,prob,prediction=None,u=None,v=None,residual_means=None):
        vv=np.zeros_like(v);vv[0,self.requested]=2
        # The worker evaluated this unchanged local code before proposing its next state.
        yy=r.FRONT._evidence_cache[1][1]
        values=dict(requested_probability=prob[0,:,self.requested].copy(),content_positive_error=np.maximum(self.xw[0]-yy,0).mean((1,2)),content_negative_error=np.maximum(yy-self.xw[0],0).mean((1,2)))
        change=super().update(prob,prediction,u,vv,residual_means)
        values.update(positive_error=self.ep[0].copy(),negative_error=self.em[0].copy(),support=self.m[0].copy(),binding_requested=self.t[0,:,self.requested].copy())
        for k,vv in values.items():self.records[k].append(vv)
        return change

def init():
    r.init();r.Circuit=DiagnosticCircuit;r.CachedLocalFeedback=PopulationFeedback

def prepare():
    ROOT.mkdir(exist_ok=True)
    if (ROOT/'protocol.json').exists():return
    meta=json.loads((BASE/'independent'/'stimuli.json').read_text());pairs=[m for m in meta if m['kind']=='pair' and m['separation']==40]
    with np.load(BASE/'independent'/'stimuli.npz') as z:xx=z['input'];cc=z['components']
    jobs=[]
    for condition in ['present','absent','blank']:
        d=ROOT/condition;d.mkdir(exist_ok=True);shutil.copyfile(BASE/'independent'/'stimuli.json',d/'stimuli.json')
        np.savez_compressed(d/'stimuli.npz',input=np.zeros_like(xx) if condition=='blank' else xx,components=np.zeros_like(cc) if condition=='blank' else cc)
        for i,m in enumerate(pairs):
            requested=m['categories'] if condition=='present' else pairs[(i+1)%len(pairs)]['categories']
            for k,cat in enumerate(requested):jobs.append(dict(condition=condition,case=m['case'],cue='A' if k==0 else 'B',requested=cat))
    r.r.dump(ROOT/'jobs.json',jobs)
    names=['run_spatial_absent_category.py','run_spatial_population_search.py','run_spatial_population_feedback.py','run_spatial_overlap_pilot.py','neural_spatial_rate_model.py','cached_spatial_content_feedback.py','spatial_content_feedback.py','run_spatial_overlap_feedback_strength.py']
    r.r.dump(ROOT/'protocol.json',dict(seed=71001,trials=30,steps=600,selection='Same five separated pairs, no screening. Absent categories are both categories from the next pair cyclically:0/6->1/7,1/7->2/5,2/5->3/8,3/8->4/9,4/9->0/6. Blank controls request each of these ten categories once. Ten target-present repeats collect diagnostics and must exactly reproduce prior neutral-population saved arrays.',fixed='Neutral zero spatial initialization; spatial input zero throughout; category input2; population routing; feedback0.65; frozen weights/references; unchanged sensory mismatch, normalization, alpha0.1,600updates. No early stops or extensions.',diagnostics='Current online Eplus/Eminus/support are shared across categories and remain unchanged. Separately decode each existing original-input-selected category reference directly from its predicted patch codes to pixels. Against immutable original sensory windows compute mean positive/negative mismatch, overlap=min(X,T), reference and sensory intensity, L1 and normalized L1=sum(abs(X-T))/sum(X+T). These fixed category-specific diagnostics are observational and do not drive the model. Record actual content prediction mismatch and requested local probability before each update; Eplus/Eminus/support/binding/spatial after each synchronous update. Final arrays and six original snapshots retained.',scoring='Do not count a clamped global category as recognition. Inactive spatial mass<=1e-7 has no selected location, irrespective of argmax. Absent trials: selected object A/B within16pixels, off-object or no spatial response; requested unforced local output is capture, not successful recognition. Report continuous category mismatch and all outcomes, no tuned acceptance threshold. Blank controls distinguish imagery from sensory support; blank-derived spatial position has no ground-truth target.',scope='Five reused pairs, one network; ten absent conditions and ten blank controls. No prevalence estimates, model-default change or manuscript-body edits.',source_sha256={n:hashlib.sha256(Path(__file__).with_name(n).read_bytes()).hexdigest() for n in names}))

def reference_images(front):
    patches=(front.rp.reshape(80,64,676).transpose(0,2,1)@front.decoder).reshape(80,26,26,7,7)
    y=np.zeros((80,32,32),np.float32)
    for dy in range(7):
        for dx in range(7):y[:,dy:dy+26,dx:dx+26]+=patches[:,:,:,dy,dx]
    return np.clip(y/front.counts,0,1).reshape(10,8,32,32)

def worker(job):
    condition=job['condition'];j=job['case'];name='combined_category_'+job['cue'];r.ROOT=ROOT/condition;folder=r.ROOT/f'case{j:02d}_{name}'
    if (folder/'diagnostics.npz').exists() and (folder/'diagnostic_result.json').exists():return json.loads((folder/'diagnostic_result.json').read_text())
    DiagnosticCircuit.requested=job['requested'];row=r.worker((j,name));c=DiagnosticCircuit.last;local=PopulationFeedback.last
    assert c.max_external_spatial_input==0 and not c.initial_attention.any()
    refs=reference_images(r.FRONT);templates=refs[np.arange(10)[None,:],local.chosen];x=c.xw[0,:,None,:,:]
    pos=np.maximum(x-templates,0).mean((2,3));neg=np.maximum(templates-x,0).mean((2,3));mass=x.mean((2,3))+templates.mean((2,3));overlap=np.minimum(x,templates).mean((2,3))
    diagnostic=dict(**{k:np.array(v) for k,v in c.records.items()},template_positive=pos,template_negative=neg,template_overlap=overlap,template_l1=pos+neg,template_normalized_l1=(pos+neg)/np.maximum(mass,1e-12),template_mean=templates.mean((2,3)),sensory_mean=c.mean_x[0],template_images_requested=templates[:,job['requested']],final_positive_error=c.ep[0],final_negative_error=c.em[0],final_support=c.m[0])
    assert all(np.isfinite(v).all() for v in diagnostic.values())
    np.savez_compressed(folder/'diagnostics.npz',**diagnostic)
    parity=None
    if condition=='present':
        with np.load(folder/'arrays.npz') as a,np.load(PRESENT/'neutral_population'/folder.name/'arrays.npz') as b:
            assert set(a.files)==set(b.files)
            for key in a.files:np.testing.assert_array_equal(a[key],b[key],err_msg=key)
        parity=True
    row=dict(**job,spatial_cue_zero=True,initial_spatial_zero=True,present_arrays_exact=parity,settled=row['settled'],seconds=row['seconds'],weights_unchanged=row['weights_unchanged'])
    r.r.dump(folder/'diagnostic_result.json',row);return row

def main():
    prepare();jobs=json.loads((ROOT/'jobs.json').read_text());start=time.time();rows=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=12,initializer=init) as pool:
        fs=[pool.submit(worker,j) for j in jobs]
        for f in concurrent.futures.as_completed(fs):
            row=f.result();rows.append(row);r.r.dump(ROOT/'status.json',dict(completed=len(rows),total=len(jobs),seconds=time.time()-start));print('DIAGNOSTICS',row['condition'],row['requested'],flush=True)
    r.r.dump(ROOT/'results.json',rows);print('ABSENT CATEGORY COMPLETE',flush=True)
if __name__=='__main__':main()
