"""Translate category-predicted patch codes without a pixel roundtrip."""
import concurrent.futures,json,time,hashlib,shutil,argparse
from pathlib import Path
import numpy as np
import run_spatial_overlap_pilot as r
from run_spatial_overlap_feedback_strength import StrengthFeedback
from run_spatial_overlap_aligned_validation import ROOT as BASE,TargetCuedCircuit
from neural_spatial_rate_model import windows
ROOT=BASE.parent/'code_alignment_pilot'

def project_codes(reference,blank,positions,anchor):
    """Patch origins define alignment; off-template patch origins use blank codes."""
    ref=reference.reshape(64,26,26);out=np.broadcast_to(blank.reshape(1,64,26,26),(len(positions),64,26,26)).copy()
    for i,pos in enumerate(positions):
        offset=int(pos-anchor);lo=max(0,-offset);hi=min(26,26-offset)
        if hi>lo:out[i,:,:,lo:hi]=ref[:,:,lo+offset:hi+offset]
    return out.reshape(len(positions),64,676)

class CodeAlignedFeedback(StrengthFeedback):
    maximum=.65
    mode='codes'
    last=None
    def __init__(self,*args):
        super().__init__(*args);type(self).last=self;self.anchors=[];self.templates={}
        if self.mode=='codes':self.blank=self.front.bottom(np.zeros((1,32,32),np.float32))[0]
    def propose(self,circuit):
        if self.mode=='parity':return super().propose(circuit)
        b=self.front.bottom(windows(circuit.s,31)[0])
        gate=np.clip((circuit.a[0]@self.field_kernel)/max(1.,float(circuit.a.sum())),0,1)
        c=circuit.c[0];mass=float(c.sum());anchor=int(circuit.a[0].argmax()) if circuit.a.sum()>1e-7 else -1
        self.anchors.append(int(circuit.positions[anchor]) if anchor>=0 else -999)
        lam=self.maximum*gate if self.feedback and mass>1e-7 else np.zeros_like(gate);target=b.copy()
        if np.any(lam):
            weights=c/mass;key=(anchor,weights.tobytes())
            if getattr(self,'_key',None)!=key:
                Q=np.zeros_like(b)
                for k in range(10):
                    if weights[k]==0:continue
                    assert anchor>=0
                    slot=int(self.chosen[anchor,k]);cache=(anchor,k,slot)
                    if cache not in self.templates:
                        ref=self.front.rp[k,slot]
                        self.templates[cache]=project_codes(ref,self.blank,circuit.positions,int(circuit.positions[anchor]))
                        np.testing.assert_array_equal(self.templates[cache][anchor],ref)
                    Q+=weights[k]*self.templates[cache]
                self._key=key;self._Q=Q
            target=(1-lam[:,None,None])*b+lam[:,None,None]*self._Q
        new=(1-circuit.par.alpha)*self.q+circuit.par.alpha*target
        return new,float(np.max(abs(new-self.q))),gate

def init():
    r.init();r.Circuit=TargetCuedCircuit;r.CachedLocalFeedback=CodeAlignedFeedback

def mechanism_checks():
    rng=np.random.default_rng(71001);ref=rng.random((64,26,26),dtype=np.float32);ref/=ref.sum(0)
    blank=rng.random(64,dtype=np.float32);blank/=blank.sum();blank=np.broadcast_to(blank[:,None,None],(64,26,26)).copy()
    positions=np.arange(-31,320)
    for anchor in [-31,0,124,144,164,288,319]:
        q=project_codes(ref,blank,positions,anchor).reshape(351,64,26,26)
        np.testing.assert_array_equal(q[anchor+31],ref)
        np.testing.assert_array_equal(q[:-1,:,:,1:],q[1:,:,:,:-1])
        np.testing.assert_allclose(q.sum(1),1,atol=1e-6)
        for i,pos in enumerate(positions):
            outside=(pos+np.arange(26)<anchor)|(pos+np.arange(26)>=anchor+26)
            np.testing.assert_array_equal(q[i][:,:,outside],blank[:,:,outside])
    return dict(selected_field_preserved_exactly=True,shared_patch_codes_exact=True,blank_extension_verified=True,probability_normalization=True,boundary_anchors_checked=True)

def prepare():
    ROOT.mkdir(exist_ok=True)
    if (ROOT/'protocol.json').exists():return
    checks=mechanism_checks();jobs=[]
    for mode in ['codes','parity']:
        dest=ROOT/mode;dest.mkdir(exist_ok=True)
        for name in ['stimuli.json','stimuli.npz']:shutil.copyfile(BASE/'independent'/name,dest/name)
        meta=json.loads((dest/'stimuli.json').read_text())
        for m in meta:
            for cue in (['A','B'] if m['kind']=='pair' else ['A']):
                if mode=='codes' or (m['case']==0 and cue=='A'):jobs.append([mode,m['case'],'combined_category_'+cue])
    jobs.sort(key=lambda x:x[0]!='parity')
    r.r.dump(ROOT/'jobs.json',jobs);r.r.dump(ROOT/'mechanism_checks.json',checks)
    names=['run_spatial_overlap_code_alignment.py','run_spatial_overlap_aligned_validation.py','run_spatial_overlap_feedback_strength.py','run_spatial_overlap_pilot.py','spatial_content_feedback.py','cached_spatial_content_feedback.py','neural_spatial_rate_model.py']
    r.r.dump(ROOT/'protocol.json',dict(seed=71001,experimental_runs=40,verification_runs=1,reused_runs=120,selection='Reuse all five unfiltered pairs / ten images of aligned_validation_pilot, all0/8/40 offsets and isolated controls, both category directions. No new screening or parameter tuning.',feedback=.65,steps=600,early_stop=False,mechanism='At each update use the winning spatial field. For each active category select its existing original-input nearest reference. Its64x26x26 upper-decoder probability tensor defines a shared horizontal patch-code map at that field origin. Copy each patch code into every field containing that same global patch origin. All other patch origins receive the existing lower-encoder code for blank input. Mix category maps by normalized category activity and retain the existing attention-gated0.65 code relaxation. No pixel decoding/re-encoding for feedback. The selected field is exactly the original category-reference tensor.',boundary='The template specifies26 horizontal valid7x7 patch origins across a32-pixel field. Patches outside those origins use blank codes, including the six origins just outside either end whose patches would partly overlap a pixel-rendered template. This differs from pixel-space alignment at boundaries and may affect suppression. No blending/tuning at boundaries in this test.',controls='Reuse independent, pixel-roundtrip control and pixel-aligned feedback from the120-run smaller pilot. Rerun one independent case through the new harness and require exact saved-array parity. Verify selected-field endpoint codes through predictions/probabilities and final gain equality for all40 cases.',cues='Same category cue2 and target-position spatial cue2 as previous pilot. Only full overlap has identical spatial cues under category reversal. Feedback uses model-selected location, not true object position; position enters only through the explicit external cue.',fixed='All weights, reference bank, per-field reference choices, sensory mismatch, binding normalization, alpha0.1, sigma24, uniform pooling and600updates unchanged. No backpropagation, inhibition or learning.',scores='Reuse all prior endpoints including local unforced category, selected-field equality to independent feedback, canvas union and target-only foreground MSE, requested/losing/shared feature intensity, background, cue contrasts, cross-field variance, isolated preservation, separated unattended visibility, settling and spatial gain. All40 outcomes retained; no population intervals from five pairs/one network.',scope='Candidate only. Hard spatial-winner routing and blank-background hypothesis remain. No model-default or manuscript-body change.',source_sha256={n:hashlib.sha256(Path(__file__).with_name(n).read_bytes()).hexdigest() for n in names}))

def worker(job):
    mode,j,name=job;r.ROOT=ROOT/mode;folder=r.ROOT/f'case{j:02d}_{name}'
    if (folder/'routing.json').exists() and (folder/'result.json').exists():return dict(code_mode=mode,**json.loads((folder/'result.json').read_text()))
    meta=json.loads((r.ROOT/'stimuli.json').read_text())[j];k=0 if name.endswith('_A') else 1
    TargetCuedCircuit.cue_position=meta['positions'][k];CodeAlignedFeedback.mode=mode
    row=r.worker((j,name));local=CodeAlignedFeedback.last
    if mode=='parity':
        with np.load(folder/'arrays.npz') as a,np.load(BASE/'independent'/folder.name/'arrays.npz') as b:
            assert set(a.files)==set(b.files)
            for key in a.files:np.testing.assert_array_equal(a[key],b[key],err_msg=key)
        r.r.dump(ROOT/'parity.json',dict(all_saved_arrays_bit_identical=True))
    r.r.dump(folder/'routing.json',dict(anchor_trace=local.anchors,external_spatial_cue=TargetCuedCircuit.cue_position,mode=mode))
    return dict(code_mode=mode,**row)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=12);args=ap.parse_args();prepare();rows=[];start=time.time()
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,initializer=init) as pool:
        fs=[pool.submit(worker,j) for j in json.loads((ROOT/'jobs.json').read_text())]
        for f in concurrent.futures.as_completed(fs):
            rows.append(f.result());r.r.dump(ROOT/'status.json',dict(completed=len(rows),total=41,seconds=time.time()-start))
    r.r.dump(ROOT/'results.json',dict(new_runs=rows,parity=json.loads((ROOT/'parity.json').read_text())))
    print('CODE ALIGNMENT COMPLETE',flush=True)
if __name__=='__main__':main()
