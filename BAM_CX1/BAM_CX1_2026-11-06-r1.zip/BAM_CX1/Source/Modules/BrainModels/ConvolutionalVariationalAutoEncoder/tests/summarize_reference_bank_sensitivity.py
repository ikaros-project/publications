"""Summarize the prespecified focal bank-size experiment without model changes."""
from pathlib import Path
import csv,json,math
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
import evaluate_reference_bank_sensitivity as ex
OUT=ex.OUT;MAN=Path(__file__).resolve().parents[5]/'Manuscript'
def main():
 r=json.loads((OUT/'results.json').read_text());conditions=r['conditions'];ss=ex.SIZES
 oldmix=json.loads((ex.original.OUT/'seed71001_results.json').read_text())['cases']
 oldoc=json.loads((ex.C/'relaxation_occlusion_ten_seeds/seed71001/results.json').read_text())['cases']
 def base(task,level,key):
  rr=[a for a in (oldmix if task=='mixture' else oldoc) if a['method']=='none' and (task=='mixture' and (level=='all' or a['mix']==.5) or task=='occlusion' and a['size']==level)]
  if key=='category_correct':return float(np.mean([a['final_winner']==(a['dominant_truth'] if task=='mixture' else a['truth']) for a in rr if task!='mixture' or a['dominant_truth'] is not None]))
  if key=='image_winner_agreement':return float(np.mean([a['pixel_prediction']==a['final_winner'] for a in rr]))
  return float(np.mean([a[key] for a in rr]))
 def v(bank,size,task,level,key):return next(a for a in next(c for c in conditions if c['bank']==bank and c['size']==size)['summary'] if a['task']==task and a['level']==level)[key]
 metrics=[('mixture','all','image_winner_agreement'),('mixture','equal','image_winner_agreement'),('mixture','all','category_correct'),('mixture','all','input_mse')]
 for size in [8,12,16]:metrics += [('occlusion',size,k) for k in ['image_winner_agreement','category_correct','hidden_mse','visible_mse']]
 rows=[]
 for task,level,key in metrics:
  baseline=base(task,level,key)
  for size in ss:
   a=np.array([v(b,size,task,level,key) for b in range(1,6)]);d=a-np.array([v(b,8,task,level,key) for b in range(1,6)])
   rows.append(dict(task=task,level=level,measure=key,size=size,original_bank=v(0,size,task,level,key),random_mean=float(a.mean()),random_sd=float(a.std(ddof=1)),random_min=float(a.min()),random_max=float(a.max()),paired_delta8_mean=float(d.mean()),paired_delta8_min=float(d.min()),paired_delta8_max=float(d.max()),no_feedback=baseline))
 with (OUT/'summary.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 with (OUT/'per_case.csv').open('w') as f:
  cases=[a for c in conditions for a in c['cases']];fields=sorted(set(k for a in cases for k in a));w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(cases)
 bankids=json.loads((OUT/'reference_banks.json').read_text());overlap={}
 for size in ss:
  scores=[]
  for a in range(6):
   for b in range(a+1,6):
    for c in range(10):scores.append(len(set(bankids[str(a)][c][:size])&set(bankids[str(b)][c][:size]))/size)
  overlap[str(size)]={'mean_fraction_shared':float(np.mean(scores)),'maximum_fraction_shared':float(np.max(scores))}
 detail=dict(total_conditions=len(conditions),total_feedback_cases=len(cases),settled=sum(a['settled'] for a in cases),unsettled_cases=[{k:a[k] for k in ['bank','size','case_index','task','final_winner']} for a in cases if not a['settled']],summaries=rows,bank_overlap=overlap,baseline_parity=r['parity'],weights_unchanged=r['weights_unchanged'])
 (OUT/'summary.json').write_text(json.dumps(detail,indent=2)+'\n')
 # Plot using ReportLab: original selection, random-start mean +/- SD, no-feedback.
 plot=OUT/'reference_bank_sensitivity.pdf';can=canvas.Canvas(str(plot),pagesize=(760,620))
 can.setTitle('Reference-bank size sensitivity: frozen focal model')
 panels=[('mixture','all','image_winner_agreement','Mixtures: image/winner agreement',100),('mixture','all','category_correct','Mixtures: dominant-category accuracy',100),('occlusion',12,'hidden_mse','12-pixel deletion: hidden-region MSE',1),('occlusion',12,'visible_mse','12-pixel deletion: visible-region MSE',1)]
 blue=HexColor('#2468a0');orange=HexColor('#d56b18')
 for pi,(task,level,key,title,scale) in enumerate(panels):
  x=65+(pi%2)*375;y=350-(pi//2)*245;w=290;h=155
  rr=[a for a in rows if a['task']==task and a['level']==level and a['measure']==key]
  vals=[t*scale for a in rr for t in [a['random_min'],a['random_max'],a['original_bank'],a['no_feedback']]]
  lo=min(vals);hi=max(vals);pad=(hi-lo)*.16 or .01;lo-=pad;hi+=pad
  if scale==100:lo=max(0,lo);hi=min(100,hi)
  def yy(v):return y+h*(v*scale-lo)/(hi-lo)
  xx=[x+i*w/5 for i in range(6)]
  can.setFillColorRGB(0,0,0);can.setFont('Helvetica-Bold',10);can.drawString(x,y+h+20,title)
  can.setFont('Helvetica',9);can.setStrokeColorRGB(.8,.8,.8)
  for tick in np.linspace(lo,hi,5):
   py=y+h*(tick-lo)/(hi-lo);can.line(x,py,x+w,py);can.drawRightString(x-6,py-3,f'{tick:.1f}' if scale==100 else f'{tick:.3f}')
  for j,size in enumerate(ss):can.drawCentredString(xx[j],y-15,str(size))
  can.drawCentredString(x+w/2,y-31,'References per category')
  if scale==100:can.drawString(x-37,y+h+2,'%')
  can.setStrokeColorRGB(.4,.4,.4);can.setDash(2,3);can.line(x,yy(rr[0]['no_feedback']),x+w,yy(rr[0]['no_feedback']));can.setDash()
  for field,color,dash in [('original_bank',orange,[6,3]),('random_mean',blue,[])]:
   can.setStrokeColor(color);can.setFillColor(color);can.setLineWidth(1.6);can.setDash(dash)
   for j in range(5):can.line(xx[j],yy(rr[j][field]),xx[j+1],yy(rr[j+1][field]))
   can.setDash()
   for j,a in enumerate(rr):
    can.circle(xx[j],yy(a[field]),2.5,stroke=1,fill=1)
    if field=='random_mean':
     low=yy(a['random_min']);high=yy(a['random_max']);can.line(xx[j],low,xx[j],high);can.line(xx[j]-3,low,xx[j]+3,low);can.line(xx[j]-3,high,xx[j]+3,high)
 can.setFillColorRGB(0,0,0);can.setFont('Helvetica-Bold',14);can.drawString(65,598,'Reference-bank sensitivity: final focal model')
 can.setFont('Helvetica',9);can.drawString(65,575,'Orange dashed: original selection rule. Blue: five random-start banks, mean and range.')
 can.drawString(65,563,'Grey dotted: no feedback. One frozen model; reused stimuli; 500 updates; feedback fraction 0.5.')
 can.setFont('Helvetica',8);can.drawString(65,28,'Bank variation is not trained-model uncertainty. Masks are used only for scoring. No tuning or early stopping.')
 can.save()
 # Fixed illustrative cases, not selected by the new outcomes.
 with np.load(OUT/'stimuli.npz') as a:inputs=a['input'];clean=a['occlusion_clean']
 indices=[37,220+80,220+120];labels=['Prior mixture example','12-pixel deletion, first image','16-pixel deletion, first image']
 for bank in [0,1]:
  ims=[]
  for size in ss:
   with np.load(OUT/f'bank{bank}_size{size}.npz') as a:ims.append(a['images'])
  image=Image.new('RGB',(1420,650),'white');draw=ImageDraw.Draw(image);font=ImageFont.load_default(size=17)
  draw.text((12,12),f'Bank {bank}: input and final reconstructions. Fixed examples selected by source order.',fill='black',font=font)
  for j,label in enumerate(['Input']+[str(s)+' refs' for s in ss]):draw.text((245+165*j,50),label,fill='black',font=font)
  for i,(idx,label) in enumerate(zip(indices,labels)):
   y=90+180*i;draw.text((10,y+45),label,fill='black',font=font)
   for j,vv in enumerate([inputs[idx]]+[a[idx] for a in ims]):
    tile=Image.fromarray(np.uint8(np.clip(vv,0,1)*255)).resize((145,145),Image.Resampling.NEAREST);image.paste(tile,(245+165*j,y))
  image.save(OUT/f'reference_bank_examples_bank{bank}.png')
 lines=['# Reference-bank size and selection sensitivity','','## Protocol','','One frozen final focal network, 500 updates, feedback fraction 0.5, update rate 0.2 and inhibition 1.5. No learning. Six sizes (1, 2, 4, 8, 16, 32) crossed with six nested banks: the original deterministic rule and five independently seeded random-start variants. Random starts are selected uniformly from the central 90% of each category in latent space, followed by the original farthest-point procedure. Each category uses its nearest reference to the original input, fixed throughout inference.','','All 220 existing 3/8 mixture cases and all 160 existing occlusion cases (40 images at four deletion sizes) were retained. This is a sensitivity analysis on reused stimuli, not independent confirmation. The five alternative banks vary the initial reference while retaining the diversity rule. They do not test every possible selection strategy.','','## Verification','',f"Original eight-reference baseline: maximum activity difference {r['parity']['max_activity_error']:.8g}, maximum pixel difference {r['parity']['max_pixel_error']:.8g}. Every category winner throughout the trajectory matched. Final independent pixel-classifier labels matched. All model checkpoint hashes were unchanged.",'','An affine coefficient representation accelerates the original fixed-reference recurrence without changing its equations. Numerical parity was required before varying the bank.','','## Results','','Values below are means across five random-start banks. SD and ranges, original-rule results, and paired changes relative to eight references are in summary.csv. Repeated images, mixture ratios and banks are dependent. Bank SD does not measure variation across trained models.','','| References/category | Mixture agreement (%) | Dominant-category accuracy (%) | 12-pixel hidden MSE | 12-pixel visible MSE |','| --- | ---: | ---: | ---: | ---: |']
 for size in ss:
  vals=[next(a for a in rows if a['task']==t and a['level']==l and a['measure']==k and a['size']==size)['random_mean'] for t,l,k,_,_ in panels]
  lines.append(f'| {size} | {100*vals[0]:.2f} | {100*vals[1]:.2f} | {vals[2]:.6f} | {vals[3]:.6f} |')
 lines+=['',f"Settled endpoints: {detail['settled']}/{len(cases)}. All endpoints were retained. See summary.json for any unsettled cases.",'','## Files','','- `protocol.json`: settings and hashes.','- `reference_banks.json`: exact training-image indices for all nested banks.','- `summary.csv`: all outcomes, bank SD/range and paired size-versus-eight differences.','- `per_case.csv`: individual observations.','- `reference_bank_sensitivity.pdf`: main comparison plots.','- `reference_bank_examples_bank0.png` and `reference_bank_examples_bank1.png`: predetermined illustrative cases.','','The existing article and frozen model were not modified. Spatial-search sensitivity has not yet been run.']
 lines += ['', '## Interpretation', '', 'There is no monotonic advantage of larger banks. Across the five alternative banks, increasing size from eight to 32 reduced mean mixture image/winner agreement by 3.36 percentage points. All five paired comparisons decreased, by 0.91 to 5.91 percentage points. Dominant-category accuracy remained close to 88-89% across sizes.', '', 'Selection matters. At eight references, alternative-bank mixture agreement ranged from 77.73% to 98.64%, compared with 91.82% for the original bank and 81.82% without feedback. One alternative bank had lower agreement than no feedback at every size. The result should not be described as reference-selection invariant.', '', 'Mean hidden-region MSE was lower than the no-feedback baseline in all 108 bank-size-by-deletion-size comparisons (36 conditions times three nonzero deletions). This is an aggregate result over 40 images per comparison, not improvement in every image. For 12-pixel deletion, larger banks reduced mean visible-region distortion but did not monotonically improve missing-region recovery. Visible-region error remained above no feedback.', '', 'The data support retaining eight as a practical existing configuration, not claiming that it is optimal or retrospectively justified by this new experiment. The original reason for choosing eight remains a separate historical question. Results concern one trained network and the reused 3/8 stimulus set.']
 (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
 (MAN/'reference_bank_sensitivity_source_notes.md').write_text('\n'.join(lines)+'\n')
 print('\n'.join(lines),flush=True)
if __name__=='__main__':main()
