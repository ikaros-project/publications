"""Full-overlap control: identical spatial cue during both category cues.

Adds the existing strength2 spatial cue, not a new gain mask or rate equation.
Verify gain equality from saved traces rather than assume the spotlight is fixed.
"""
import argparse,concurrent.futures,json,time,hashlib,shutil
from pathlib import Path
import numpy as np
import run_spatial_overlap_pilot as r
from neural_spatial_rate_model import Circuit
DATA=r.ROOT
ROOT=DATA/'fixed_spatial_cue'

class CuedCircuit(Circuit):
    def update(self,prob,prediction=None,u=None,v=None,residual_means=None):
        u=u.copy();u[0,144+31]=2
        return super().update(prob,prediction,u,v,residual_means)

def init():
    r.init();r.Circuit=CuedCircuit;r.ROOT=ROOT

def prepare():
    ROOT.mkdir(exist_ok=True)
    if (ROOT/'protocol.json').exists():return
    for name in ['stimuli.json','stimuli.npz']:shutil.copyfile(DATA/name,ROOT/name)
    meta=json.loads((ROOT/'stimuli.json').read_text())
    jobs=[[m['case'],method] for m in meta if m['kind']=='pair' and m['separation']==0 for method in ['category_A','category_B','combined_category_A','combined_category_B']]
    r.r.dump(ROOT/'jobs.json',jobs)
    r.r.dump(ROOT/'protocol.json',dict(purpose='Control for category-dependent shifts of spatial gain at full overlap. Apply the same spatial cue2 at field144 in all conditions; compare both category cue directions with content feedback off/on. This is an existing model input, not a forced state or changed equation. Verify actual gain equality over final100 updates before attributing differences to content feedback under matched spatial gain.',planned='Added after launching the main pilot, before inspecting overlapping-object outcomes; motivated by causal identifiability of object versus spatial selection.',trials=len(jobs),updates=600,early_stop=False,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),original_protocol='spatial_overlap_pilot/protocol.json'))
    print('PREPARED FIXED-CUE CONTROL',len(jobs),flush=True)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--workers',type=int,default=12);args=ap.parse_args();prepare()
    if args.prepare:return
    start=time.time();rows=[];jobs=json.loads((ROOT/'jobs.json').read_text())
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,initializer=init) as pool:
        futs=[pool.submit(r.worker,j) for j in jobs]
        for f in concurrent.futures.as_completed(futs):
            rows.append(f.result());r.r.dump(ROOT/'status.json',dict(completed=len(rows),total=len(jobs),seconds=time.time()-start))
    r.r.dump(ROOT/'results.json',dict(cases=sorted(rows,key=lambda x:(x['case'],x['method']))))
    print('FIXED-CUE CONTROL COMPLETE',flush=True)
if __name__=='__main__':main()
