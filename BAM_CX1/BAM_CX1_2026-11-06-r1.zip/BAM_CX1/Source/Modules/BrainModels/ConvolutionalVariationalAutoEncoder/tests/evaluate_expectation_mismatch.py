"""Mismatch diagnostics on intact and shared inputs; signals do not control inference."""
import os
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['VECLIB_MAXIMUM_THREADS']='2'
import json,hashlib,concurrent.futures
from pathlib import Path
from argparse import Namespace
import numpy as np
import evaluate_relaxation_full_mixtures as base
n=base.n;e=base.e;local=base.local;f=base.f
OUT=n.CAMPAIGN/'expectation_mismatch_ten_seeds';SOURCE=n.CAMPAIGN/'shared_stroke_candidates'
STEPS=[0,8,32,50,58,82,178,250,550]
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def js(p,q):
 p=np.maximum(p,1e-30);q=np.maximum(q,1e-30);mid=.5*(p+q)
 return (.5*(p*np.log(p/mid)+q*np.log(q/mid)).sum(1)).mean(1)
def run(seed):
 target=OUT/f'seed{seed}';target.mkdir(exist_ok=True)
 train,test,labels,tl=e.prepare_data(Namespace(train_count=60000,test_count=10000))
 selected=json.loads((SOURCE/'results.json').read_text())['selected'][:6]
 with np.load(SOURCE/'arrays.npz') as zz:originals=zz['original_images'];shared=zz['selected_shared'][:6]
 meta=[];inputs=[]
 for mode in ['none','primed']:
  for j,r in enumerate(selected):
   for cue,own,other in [(r['a'],r['ia'],r['ib']),(r['b'],r['ib'],r['ia'])]:
    for relation,im in [('matching',originals[own]),('conflicting',originals[other]),('shared',shared[j])]:
     meta.append(dict(mode=mode,candidate=j+1,cue=cue,relation=relation,a=r['a'],b=r['b']));inputs.append(im)
 x=np.array(inputs);N=len(x)
 folder=n.CAMPAIGN/f'hierarchy_s{seed}';rd=n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit'/f'grouped_softmax_s{seed}.npz';pd=n.CAMPAIGN/'local_linear_patch_decoder_seed1' if seed==71001 else n.CAMPAIGN/'local_linear_patch_decoder_ten_seeds'/f'seed{seed}'
 paths=[folder/'model.state',folder/'codebook_final.npz',rd,pd/'local_decoder.npz'];hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
 state=json.loads(paths[0].read_text())['items']
 def weight(k):
  v=state['CVAE_TwoLayer.Upper.'+k];return np.array(v['value'],np.float32).reshape(v['shape'])
 enc=weight('DIRECT_MEAN_WEIGHTS');eb=weight('DIRECT_MEAN_BIAS');dec=weight('DIRECT_DECODER_WEIGHTS');db=weight('DIRECT_DECODER_BIAS');del state
 with np.load(rd) as z:rw=z['weights'];rb=z['bias']
 with np.load(paths[1]) as z:book=f.prior.Codebook(z['prototypes'])
 with np.load(paths[3]) as z:decoder=z['decoder'].astype(np.float32)
 codes,_,_=e.read_codes(folder/'train_codes.csv',train,labels,128)
 refs=json.loads((n.CAMPAIGN/'category_feedback_diagnostic/reference_indices.json').read_text())['71001'] if seed==71001 else json.loads((pd/'feedback_inference/reference_indices.json').read_text())
 ids=np.array([refs[str(c)] for c in range(10)]);rc=codes[ids].astype(np.float32)
 def encode(p):return p.reshape(len(p),-1)@enc+eb
 def decode(z):
  v=(z@dec+db).reshape(-1,64,676);v-=v.max(1,keepdims=True);return v-np.log(np.exp(v).sum(1,keepdims=True))
 def probs(z):return n.softmax(z@rw+rb).reshape(-1,10,20).sum(2)
 def render(z):return np.clip(local.overlap(np.exp(decode(z)).transpose(0,2,1)@decoder),0,1)
 rp=np.exp(decode(rc.reshape(80,128))).reshape(10,8,64,676)
 b=np.stack([book.process(v,False,.01,.08)[0].reshape(64,676) for v in x]);z0=encode(b);pr0=probs(z0);a0=pr0/pr0.max(1,keepdims=True);chosen=((z0[:,None,None]-rc[None])**2).sum(3).argmin(2);im0=render(z0)
 cue=np.array([v['cue'] for v in meta]);qcue=rp[cue,chosen[np.arange(N),cue]]
 fixed=js(b,qcue);p=b.copy();a=a0.copy();pr=pr0.copy();acts=[a.copy()];prs=[pr.copy()];ims=[im0.copy()];changes=[];discrepancy=[fixed.copy()]
 bias=np.zeros((N,10),np.float32);bias[np.arange(36,72),cue[36:]]=2.
 for step in range(1,551):
  drive=pr/pr.max(1,keepdims=True)-1.5*(a.sum(1,keepdims=True)-a)
  if step<=50:drive=drive+bias
  an=.8*a+.2*np.maximum(drive,0);ww=an/an.sum(1,keepdims=True);Q=np.zeros_like(p)
  for c in range(10):Q+=ww[:,c,None,None]*rp[c,chosen[:,c]]
  pn=.8*p+.2*(.5*b+.5*Q);changes.append(np.stack([abs(pn-p).max((1,2)),abs(an-a).max(1)],1));p=pn;a=an;z=encode(p);pr=probs(z);acts.append(a.copy());prs.append(pr.copy());discrepancy.append(js(p,qcue))
  if step in STEPS:ims.append(render(z))
 acts=np.array(acts);prs=np.array(prs);ims=np.array(ims);ch=np.array(changes);discrepancy=np.array(discrepancy);wins=acts.argmax(2);disagree=1-prs[:,np.arange(N),cue]
 np.testing.assert_array_equal(pr0[:36],pr0[36:]);np.testing.assert_array_equal(chosen[:36],chosen[36:]);np.testing.assert_allclose(p.sum(1),1,atol=5e-6);assert np.isfinite(p).all()
 rows=[]
 for j,m in enumerate(meta):
  rows.append(dict(**m,seed=seed,case=j,initial_disagreement=float(disagree[0,j]),disagreement50=float(disagree[50,j]),disagreement550=float(disagree[-1,j]),sensory_js=float(fixed[j]),internal_js50=float(discrepancy[50,j]),internal_js550=float(discrepancy[-1,j]),initial_winner=int(wins[0,j]),winner50=int(wins[50,j]),winner550=int(wins[-1,j]),settled=bool(ch[-10:,j].max()<1e-5),post_release_switches=int((np.diff(wins[50:,j])!=0).sum())))
 assert [hashlib.sha256(q.read_bytes()).hexdigest() for q in paths]==hashes
 np.savez_compressed(target/'arrays.npz',input=x,snapshots=ims,activities=acts,probabilities=prs,disagreement=disagree,sensory_js=fixed,internal_js=discrepancy,steps=STEPS,changes=ch,reference_ids=ids,chosen_reference_slots=chosen)
 dump(target/'results.json',dict(cases=rows,weights_unchanged=True,checkpoint_sha256=hashes));print(seed,'complete',flush=True);return seed

def main():
 OUT.mkdir(exist_ok=True)
 dump(OUT/'protocol.json',dict(seeds=list(range(71001,71011)),candidates=list(range(1,7)),trials=720,conditions='Both category cues for each pair, matching original / conflicting original / shared pixels, with or without additive cue',cue='Concurrent category expectation represented by additive2 normalized drive for updates1–50, then500 without bias. No pre-stimulus imagery period or hard clamp.',topdown=.5,alpha=.2,inhibition=1.5,reference='Nearest of8 category references selected from original input once per trial and held fixed. Reference may differ between matching/conflicting/shared inputs; no true stimulus label supplied.',signals='1 minus grouped readout probability of the cued category; Jensen-Shannon divergence (natural logs) between lower code and cued reference probabilities, averaged across676 positions. Fixed sensory/reference discrepancy is constant by construction; evolving-code discrepancy tracked separately.',detector='ROC AUC conflicting vs matching per trained model; paired matching/conflicting comparisons. No fitted detector, threshold, new learning, automatic reliability control or biological calibration.',scope='Six previously selected pairs, same stimuli across10 models; descriptive seed variation, not held-out stimulus validation. Signals are offline diagnostics, not new model control pathways.'))
 with concurrent.futures.ProcessPoolExecutor(max_workers=2) as pool:list(pool.map(run,range(71001,71011)))
 dump(OUT/'results.json',dict(cases=[v for seed in range(71001,71011) for v in json.loads((OUT/f'seed{seed}/results.json').read_text())['cases']]));print('ALL COMPLETE',flush=True)
if __name__=='__main__':main()
