"""Frozen first-seed gain sweep, same 220 scenes and learned pixel decoder."""
import json,hashlib
from argparse import Namespace
import numpy as np
import evaluate_local_patch_decoder as local
n=local.n;f=n.f;e=n.e
OUT=n.CAMPAIGN/'feedback_gain_sweep_seed1'
GAINS=[0.,.25,.5]
SNAPS=[0,1,2,4,8,16,32,64,128,200]
def write(name,value):(OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def status(s):write('status.json',dict(stage=s));print(s,flush=True)
def soft(v):
    v=v-v.max(1,keepdims=True);v=np.exp(v);return v/v.sum(1,keepdims=True)
def run(seed,output):
    global OUT
    OUT=output
    OUT.mkdir(exist_ok=True);status('loading frozen model')
    train,test,labels,tl=e.prepare_data(Namespace(train_count=60000,test_count=10000))
    tp=np.stack([e.full.center_and_pad(v) for v in train]).astype(np.float32)/255
    vp=np.stack([e.full.center_and_pad(v) for v in test]).astype(np.float32)/255
    folder=n.CAMPAIGN/f'hierarchy_s{seed}';readout=n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit'/f'grouped_softmax_s{seed}.npz';prior=n.CAMPAIGN/'local_linear_patch_decoder_ten_seeds'/f'seed{seed}';dp=prior/'local_decoder.npz'
    paths=[folder/'model.state',folder/'codebook_final.npz',readout,dp];hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    state=json.loads(paths[0].read_text())['items']
    def w(name):
        a=state['CVAE_TwoLayer.Upper.'+name];return np.array(a['value'],np.float32).reshape(a['shape'])
    enc=w('DIRECT_MEAN_WEIGHTS');eb=w('DIRECT_MEAN_BIAS');dec=w('DIRECT_DECODER_WEIGHTS');db=w('DIRECT_DECODER_BIAS');del state
    with np.load(readout) as z:rw=z['weights'];rb=z['bias']
    with np.load(paths[1]) as z:book=f.prior.Codebook(z['prototypes'])
    with np.load(dp) as z:decoder=z['decoder'].astype(np.float32)
    codes,_,_=e.read_codes(folder/'train_codes.csv',train,labels,128)
    tc,_,_=e.read_codes(folder/'test_codes.csv',test,tl,128)
    def encode(p):return p.reshape(len(p),-1)@enc+eb
    def decode(z):
        v=(z@dec+db).reshape(-1,64,676);v-=v.max(1,keepdims=True);return v-np.log(np.exp(v).sum(1,keepdims=True))
    def probs(z):return n.softmax(z@rw+rb).reshape(-1,10,20).sum(2)
    def render(q):return np.clip(local.overlap(np.exp(q).transpose(0,2,1)@decoder),0,1)
    old=json.loads((n.OUT/'results.json').read_text());selection=json.loads((n.OUT/'representative_input_selection.json').read_text())
    cases=[dict(pair_id=k,i=i,j=j,mix=m,illustration=False) for k,(i,j) in enumerate(old['protocol']['pairs']) for m in old['protocol']['mixtures']]
    cases += [dict(pair_id=-1,i=selection['test_index3'],j=selection['test_index8'],mix=m,illustration=True) for m in [.4,.5,.6]]
    write('protocol.json',dict(seed=seed,gains=GAINS,steps=200,cases=cases,snapshots=SNAPS,
        update='a_next=.8*a+.2*relu(prob/max(prob)-1.5*sum_other(a)); weights=a_next/sum(a_next); delta=sum_c weights_c*clip(log(qref_c)-log(q),-2,2); p_next=.8*p+.2*softmax_channels(log(p0)+gain*delta). Re-encode p and update decoder/readout. At zero gain keep p=p0 exactly, updating competition only.',
        references='Existing training-only eight per category; nearest in raw128 code to original input selected once per category.',
        decoder='Retained learned64x49 local decoder; overlap average, then clip[0,1]. Frozen200-unit readout and all sensory weights.',
        evaluation='Same220 uncorrupted 3/8 scenes; three thinner-three illustrations excluded. Independent pixel5NN against60000 training images. Final and original winner agreement separate from ground truth. MSE to actual mixture, original-winner component (when3/8) and other component. All gains prespecified; no default selection from test results.',
        convergence='All200 iterations. Settled if max activity and lower-probability changes below1e-5 throughout final10 cycles. Also check two-step distances and late winner switching.',
        scope='First-seed exploratory comparison on reused scenes; no noise/occlusion, no training, no gates. Gain changes only.'))
    refs=json.loads((prior/'feedback_inference/reference_indices.json').read_text());ids=np.array([refs[str(c)] for c in range(10)])
    refcodes=codes[ids].astype(np.float32);refq=decode(refcodes.reshape(-1,128)).reshape(10,8,64,676)
    x=np.stack([c['mix']*vp[c['i']]+(1-c['mix'])*vp[c['j']] for c in cases]);N=len(x)
    p0=np.stack([book.process(v,False,.01,.08)[0].reshape(64,676) for v in x]);logp0=np.log(np.maximum(p0,1e-30));z0=encode(p0);q0=decode(z0);pr0=probs(z0);a0=pr0/pr0.max(1,keepdims=True);win0=pr0.argmax(1)
    chosen=((z0[:,None,None,:]-refcodes[None])**2).sum(3).argmin(2)
    err=max(float(abs(z0[k]-tc[c['i'] if c['mix']==1 else c['j']]).max()) for k,c in enumerate(cases) if c['mix'] in (0,1));assert err<1e-4
    np.testing.assert_allclose(soft(logp0),p0,atol=2e-7)
    outputs=[];winners=[];diagnostics=[];snapshots=[];allactivity=[];allchanges=[];parity={}
    with np.load(prior/'feedback_inference/upper_decoder_probabilities.npz') as z:oldq0=z['no_feedback'];oldq25=z['feedback_during']
    for gain in GAINS:
        status(f'running gain {gain:g}');p=p0.copy();a=a0.copy();q=q0.copy();pr=pr0.copy();changes=[];acts=[a.copy()];saved=[render(q)];previous_p=None;previous_a=None
        for t in range(1,201):
            evidence=pr/pr.max(1,keepdims=True);an=.8*a+.2*np.maximum(evidence-1.5*(a.sum(1,keepdims=True)-a),0)
            if gain:
                weights=an/an.sum(1,keepdims=True);delta=np.zeros_like(p)
                for c in range(10):delta+=weights[:,c,None,None]*np.clip(refq[c,chosen[:,c]]-q,-2,2)
                pn=.8*p+.2*soft(logp0+gain*delta)
            else:pn=p0
            one=np.maximum(abs(an-a).max(1),abs(pn-p).max((1,2)))
            two=np.maximum(abs(an-previous_a).max(1),abs(pn-previous_p).max((1,2))) if previous_p is not None else np.full(N,np.nan)
            changes.append(np.stack([one,two],axis=1));previous_p=p;previous_a=a;p=pn;a=an
            if gain:z=encode(p);q=decode(z);pr=probs(z)
            acts.append(a.copy())
            if t in SNAPS:saved.append(render(q))
            if t%50==0:status(f'gain {gain:g}: {t}/200 cycles')
        np.testing.assert_allclose(p.sum(1),1,atol=3e-6);assert np.isfinite(q).all()
        if gain in [0.,.25]:
            expected=oldq0 if gain==0 else oldq25;parity[str(gain)]=float(abs(np.exp(q)-expected).max());np.testing.assert_allclose(np.exp(q),expected,atol=2e-6)
        ch=np.array(changes);act=np.array(acts);settled=ch[-10:,:,0].max(0)<1e-5
        # First cycle from which changes stay under tolerance through the end.
        tail=np.maximum.accumulate(ch[::-1,:,0],axis=0)[::-1];settling=np.where(settled,np.argmax(tail<1e-5,axis=0)+1,-1)
        diagnostics.append(dict(gain=gain,settled=int(settled[:220].sum()),cases=220,two_cycle_flags=int(((ch[-10:,:,1].max(0)<1e-5)&~settled)[:220].sum()),last20_winner_switches=int((np.diff(act[-20:,:220].argmax(2),axis=0)!=0).sum()),final_winner_changes=int((a.argmax(1)[:220]!=win0[:220]).sum()),median_settling_cycle=float(np.median(settling[:220][settled[:220]])) if settled[:220].any() else None,max_last10_change=float(ch[-10:,:220,0].max())))
        outputs.append(render(q));winners.append(a.argmax(1));snapshots.append(saved);allactivity.append(act);allchanges.append(ch)
    status('scoring reconstructions with independent pixel5NN')
    outputs=np.array(outputs);winners=np.array(winners);pix=e.five_nearest_predictions(tp.reshape(60000,-1),labels,outputs.reshape(-1,1024)).reshape(len(GAINS),N)
    rows=[];aggregate=[];mask=np.arange(N)<220;eq=mask&np.array([c['mix']==.5 for c in cases]);cl=mask&np.array([c['mix'] in (0,1) for c in cases]);dom=mask&~eq;truth=np.array([3 if c['mix']>.5 else 8 for c in cases]);component=mask&np.isin(win0,[3,8]);wrong=dom&(win0!=truth)
    ref=np.stack([vp[c['i'] if win0[k]==3 else c['j']] for k,c in enumerate(cases)]);other=np.stack([vp[c['j'] if win0[k]==3 else c['i']] for k,c in enumerate(cases)])
    for gi,g in enumerate(GAINS):
        mse=((outputs[gi]-x)**2).mean((1,2));rmse=((outputs[gi]-ref)**2).mean((1,2));omse=((outputs[gi]-other)**2).mean((1,2))
        aggregate.append(dict(gain=g,final_winner_agreement=float((pix[gi,mask]==winners[gi,mask]).mean()),original_winner_agreement=float((pix[gi,mask]==win0[mask]).mean()),equal_final_winner_agreement=float((pix[gi,eq]==winners[gi,eq]).mean()),dominant_recognition=float((pix[gi,dom]==truth[dom]).mean()),clean_recognition=float((pix[gi,cl]==truth[cl]).mean()),dominant_category_selection=float((winners[gi,dom]==truth[dom]).mean()),wrong_original_winner_agreement=float((pix[gi,wrong]==win0[wrong]).mean()),input_mse=float(mse[mask].mean()),clean_input_mse=float(mse[cl].mean()),original_winner_component_mse=float(rmse[component].mean()),other_component_mse=float(omse[component].mean()),component_case_count=int(component.sum())))
        for k,c in enumerate(cases):rows.append(dict(**c,gain=g,initial_winner=int(win0[k]),final_winner=int(winners[gi,k]),pixel_prediction=int(pix[gi,k]),input_mse=float(mse[k]),original_winner_component_mse=float(rmse[k]) if component[k] else None))
    assert all(hashlib.sha256(p.read_bytes()).hexdigest()==hashes[p.name] for p in paths)
    write('results.json',dict(aggregate=aggregate,dynamics=diagnostics,per_case=rows,checks=dict(encoder_max_error=err,prior_decoder_probability_max_errors=parity,checkpoint_sha256=hashes,weights_unchanged=True)))
    np.savez_compressed(OUT/'arrays.npz',gains=GAINS,input=x,outputs=outputs,pixel_predictions=pix,winners=winners,initial_winners=win0,snapshot_steps=SNAPS,snapshots=snapshots,activities=allactivity,changes=allchanges)
    f.gallery(OUT/'gain_comparison.png','Same input; increasing feedback gain; thinner-three illustrations',[[x[220+k]]+[outputs[i,220+k] for i in range(len(GAINS))] for k in range(3)],['3 fraction .4','.5','.6'],['input']+[f'gain {g:g}' for g in GAINS])
    lines=['# Continuous-feedback gain sweep','','Frozen model; same220 uncorrupted mixtures;200 iterations; learned local pixel decoder. Three thinner-three illustrations excluded from statistics.','', '| Gain | Final-winner agreement | Original-winner agreement | Equal-mixture agreement | Input MSE | Winner-component MSE | Settled | Winner changes |','|---|---:|---:|---:|---:|---:|---:|---:|']
    for r,d in zip(aggregate,diagnostics):lines.append(f'| {r["gain"]:g} | {r["final_winner_agreement"]:.2%} | {r["original_winner_agreement"]:.2%} | {r["equal_final_winner_agreement"]:.2%} | {r["input_mse"]:.6f} | {r["original_winner_component_mse"]:.6f} | {d["settled"]}/220 | {d["final_winner_changes"]} |')
    lines+=['','Winner-component MSE uses the original winner when it is3 or8, so cases and targets remain fixed across gains. Input MSE compares to the actual mixture and can increase during successful category resolution. Ground-truth accuracy and incorrect-winner reinforcement are separate metrics in results.json.','', 'All parameters other than gain were held fixed. Zero and.25 decoder probabilities reproduced previous outputs. Endpoint encoder parity and unchanged checkpoint hashes passed. Single-seed reused-scene results are exploratory; no new default is selected here.','', '## Dynamics','',json.dumps(diagnostics,indent=2)]
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');status('complete');print('\n'.join(lines),flush=True)

