"""Frozen single-object spatial pilot: shared 32x32 model at stride one.

All positions are independent and conceptually simultaneous. Translation caching
avoids recomputing identical windows; no object location enters the pooling rule.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='2'
os.environ['VECLIB_MAXIMUM_THREADS']='2'
import json, hashlib, time, argparse
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import evaluate_topdown_codebook as prior
from run_full_mnist_feedback import CAMPAIGN

e=prior.e
OUT=CAMPAIGN/'spatial_single_stimulus_seed1'
SEED=71001
METHODS=['mean','max','mean_minus_blank','positive_excess_sum']

def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def softmax(x):
    v=np.exp(x-x.max(-1,keepdims=True));return v/v.sum(-1,keepdims=True)

def main():
    global OUT, METHODS
    parser=argparse.ArgumentParser();parser.add_argument('--extended',action='store_true');args=parser.parse_args()
    if args.extended:
        OUT=CAMPAIGN/'spatial_single_stimulus_reconstruction_seed1'
        METHODS=METHODS+['reconstruction_winner','reconstruction_weighted_mean']
    OUT.mkdir(exist_ok=True)
    folder=CAMPAIGN/f'hierarchy_s{SEED}'
    paths=[folder/'model.state',folder/'codebook_final.npz',CAMPAIGN/'neural_readout_regularized_capacity/full_refit'/f'grouped_softmax_s{SEED}.npz']
    if args.extended:paths.append(CAMPAIGN/'local_linear_patch_decoder_seed1/local_decoder.npz')
    hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
    state=json.loads(paths[0].read_text())['items']
    def weight(k):
        v=state['CVAE_TwoLayer.Upper.'+k];return np.array(v['value'],np.float32).reshape(v['shape'])
    enc=weight('DIRECT_MEAN_WEIGHTS');eb=weight('DIRECT_MEAN_BIAS')
    if args.extended:
        dec=weight('DIRECT_DECODER_WEIGHTS');db=weight('DIRECT_DECODER_BIAS')
        with np.load(paths[3]) as z:pixel_decoder=z['decoder'].astype(np.float32)
    del state
    with np.load(paths[1]) as z:book=prior.Codebook(z['prototypes'])
    with np.load(paths[2]) as z:rw=z['weights'];rb=z['bias']
    def infer(images):
        patches=np.lib.stride_tricks.sliding_window_view(images,(7,7),axis=(1,2)).reshape(-1,49)
        dist=(patches*patches).sum(1)[:,None]+(book.prototypes**2).sum(1)[None]-2*patches@book.prototypes.T
        a=softmax(-dist/(49*.08)).reshape(len(images),676,64).transpose(0,2,1).copy()
        lat=a.reshape(len(images),-1)@enc+eb
        return softmax(lat@rw+rb).reshape(-1,10,20).sum(2),lat
    blank,blanklat=infer(np.zeros((1,32,32),np.float32));blank=blank[0]
    test=e.full.read_idx_images(e.full.RAW_ROOT/'t10k-images-idx3-ubyte.gz',1000)
    labels=e.full.read_idx_labels(e.full.RAW_ROOT/'t10k-labels-idx1-ubyte.gz',1000)
    ids=np.concatenate([np.flatnonzero(labels==c)[:10] for c in range(10)])
    pilot_ids=ids.copy()
    if args.extended:ids=np.arange(1000)
    images=np.stack([e.full.center_and_pad(test[i]) for i in ids]).astype(np.float32)/255
    truth=labels[ids]
    # A digit tile can begin at any integer x in 0..288. Windows likewise.
    positions=np.arange(289);rel=positions[:,None]-positions[None,:]
    lookup=np.where(abs(rel)<=31,rel+31,63)
    responses=[];predictions=[];confidences=[];scores_all=[];parity=0.;baseline=[];qualities=[];selected_positions=[];reconstruction_examples=[]
    start=time.time()
    dump(OUT/'protocol.json',dict(seed=SEED,display_shape=[32,320],receptive_field=[32,32],stride=1,processing_positions=289,stimulus_positions=289,test_indices=ids.tolist(),selection='First1000 test images' if args.extended else 'First ten examples of each category among first1000 MNIST test examples; no selection by correctness.',preprocessing='Existing digit centering/padding before placement only; never recenter a processing window.',methods=METHODS,learning=False,feedback=False,scope='Exploratory one-model pilot. Translations are repeated measurements, not independent samples. Extended run separates original100 pilot images from remaining900.',reconstruction_rule='Choose location maximizing sum(2*x*y-y*y), where y is its VAE plus local-linear-decoder reconstruction. Equivalent to minimizing whole-display squared reconstruction error with all other pixels zero. Weighted alternative pools category probabilities with positive explained-energy weights. No new fitted parameters.',cache='Exact reuse of equal local pixel arrays across translated displays; all processing positions present. No location oracle in pooling.',checkpoint_sha256=hashes))
    for j,im in enumerate(images):
        local=np.zeros((64,32,32),np.float32)
        for k,d in enumerate(range(-31,32)):
            lo=max(0,d);hi=min(32,32+d);local[k,:,lo:hi]=im[:,lo-d:hi-d]
        probs,latent=infer(local)
        if j==0:
            for k in [0,17,31,46,62,63]:
                a,_=book.process(local[k],False,.01,.08)
                expected=a.ravel()@enc+eb
                parity=max(parity,float(abs(expected-latent[k]).max()))
                np.testing.assert_allclose(expected,latent[k],atol=3e-5,rtol=3e-5)
            # Actual wide-display extraction validates the translation cache.
            for x in [0,17,144,288]:
                scene=np.zeros((32,320),np.float32);scene[:,x:x+32]=im
                for w in [0,1,127,144,257,288]:np.testing.assert_array_equal(scene[:,w:w+32],local[lookup[x,w]])
            np.testing.assert_allclose(probs[63],blank,atol=2e-6)
        spatial=probs[lookup] # stimulus position, receptive-field position, category
        scores=np.stack([spatial.mean(1),spatial.max(1),(spatial-blank).mean(1),np.maximum(spatial-blank,0).sum(1)])
        if args.extended:
            q=softmax((latent@dec+db).reshape(-1,64,676).transpose(0,2,1))
            patch=(q@pixel_decoder).reshape(-1,26,26,7,7)
            reconstructed=np.zeros((64,32,32),np.float32);counts=np.zeros((32,32),np.float32)
            for dy in range(7):
                for dx in range(7):
                    reconstructed[:,dy:dy+26,dx:dx+26]+=patch[:,:,:,dy,dx];counts[dy:dy+26,dx:dx+26]+=1
            reconstructed=np.clip(reconstructed/counts,0,1)
            quality=(2*local*reconstructed-reconstructed**2).sum((1,2))
            sq=quality[lookup];selected=sq.argmax(1)
            positive=np.maximum(sq,0)
            pooled=(spatial*positive[:,:,None]).sum(1)/np.maximum(positive.sum(1)[:,None],1e-30)
            scores=np.concatenate([scores,spatial[np.arange(289),selected][None],pooled[None]])
            qualities.append(quality);selected_positions.append(selected)
            if j in pilot_ids[:10]:reconstruction_examples.append(reconstructed)
        predictions.append(scores.argmax(2));confidences.append(spatial.max((1,2)));scores_all.append(scores)
        responses.append(probs);baseline.append(int(probs[31].argmax()))
        if (j+1)%100==0 or (not args.extended and (j+1)%10==0):
            print(f'{j+1}/{len(images)} images evaluated at all289 placements; {time.time()-start:.1f}s',flush=True)
            dump(OUT/'status.json',dict(completed_images=j+1,total_images=len(images),elapsed_seconds=time.time()-start))
    pred=np.array(predictions);responses=np.array(responses);correct=pred==truth[:,None,None]
    interior=(positions>=31)&(positions<=257)
    summary={}
    for m,name in enumerate(METHODS):
        summary[name]=dict(accuracy=float(correct[:,m].mean()),interior_accuracy=float(correct[:,m,interior].mean()),edge_accuracy=float(correct[:,m,~interior].mean()),correct_at_every_position=int(correct[:,m].all(1).sum()),same_category_at_every_position=int(np.all(pred[:,m]==pred[:,m,:1],axis=1).sum()),per_category_accuracy=[float(correct[truth==c,m].mean()) for c in range(10)],accuracy_by_position=correct[:,m].mean(0).tolist())
        # Away from display boundaries spatial pooling must be translation invariant.
        assert np.all(pred[:,m,31:258]==pred[:,m,31:32])
    if args.extended:
        holdout=~np.isin(ids,pilot_ids)
        for m,name in enumerate(METHODS):
            summary[name]['nonpilot900_accuracy']=float(correct[holdout,m].mean())
            summary[name]['nonpilot900_interior_accuracy']=float(correct[holdout,m,31:258].mean())
        np.savez_compressed(OUT/'reconstruction_diagnostics.npz',quality=np.array(qualities),selected_positions=np.array(selected_positions))
    assert hashes==[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
    result=dict(summary=summary,centered_accuracy=float(np.mean(np.array(baseline)==truth)),blank_probabilities=blank.tolist(),blank_winner=int(blank.argmax()),encoder_parity_max_error=parity,weights_unchanged=True,elapsed_seconds=time.time()-start)
    np.savez_compressed(OUT/'arrays.npz',images=images,labels=truth,test_indices=ids,relative_probabilities=responses,relative_offsets=np.r_[np.arange(-31,32),999],predictions=pred,scores=np.array(scores_all),centered_predictions=baseline,positions=positions,methods=METHODS,pilot_indices=pilot_ids)
    dump(OUT/'results.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='summary'},indent=2),flush=True)
    print(json.dumps({k:{a:b for a,b in v.items() if a!='accuracy_by_position'} for k,v in summary.items()},indent=2),flush=True)
if __name__=='__main__':main()
