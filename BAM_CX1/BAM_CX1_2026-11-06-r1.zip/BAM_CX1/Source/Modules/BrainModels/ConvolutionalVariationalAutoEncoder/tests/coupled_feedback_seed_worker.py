"""Interleave category competition with anchored feedback; first-seed diagnostic."""
import json,hashlib
from argparse import Namespace
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import evaluate_neural_feedback as n
f=n.f;e=n.e
OUT=n.CAMPAIGN/'neural_readout_coupled_feedback_seed1'
STEPS=200
SNAPS=[0,1,2,4,8,16,32,64,128,200]

def status(stage):
    (OUT/'status.json').write_text(json.dumps(dict(stage=stage))+'\n');print(stage,flush=True)

def run(seed,output,save_decoder_probabilities=False):
    global OUT
    OUT=output
    OUT.mkdir(exist_ok=True);status('loading frozen model')
    train,test,labels,test_labels=e.prepare_data(Namespace(train_count=60000,test_count=10000))
    tp=np.stack([e.full.center_and_pad(x) for x in train]).astype(np.float32)/255
    vp=np.stack([e.full.center_and_pad(x) for x in test]).astype(np.float32)/255
    folder=n.CAMPAIGN/f'hierarchy_s{seed}';readout=n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit'/f'grouped_softmax_s{seed}.npz'
    paths=[folder/'model.state',folder/'codebook_final.npz',readout];hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    state=json.loads((folder/'model.state').read_text())['items']
    def w(name):
        a=state['CVAE_TwoLayer.Upper.'+name];return np.array(a['value'],np.float32).reshape(a['shape'])
    enc=w('DIRECT_MEAN_WEIGHTS');eb=w('DIRECT_MEAN_BIAS');dec=w('DIRECT_DECODER_WEIGHTS');db=w('DIRECT_DECODER_BIAS');del state
    with np.load(readout) as a:rw=a['weights'];rb=a['bias']
    with np.load(folder/'codebook_final.npz') as a:book=f.prior.Codebook(a['prototypes'])
    codes,_,_=e.read_codes(folder/'train_codes.csv',train,labels,128)
    testcodes,_,_=e.read_codes(folder/'test_codes.csv',test,test_labels,128)
    def channel_softmax(v):
        v=v-v.max(1,keepdims=True);v=np.exp(v);return v/v.sum(1,keepdims=True)
    def decode(z):
        v=(z@dec+db).reshape(-1,64,676);v=v-v.max(1,keepdims=True);return v-np.log(np.exp(v).sum(1,keepdims=True))
    def probs(z):return n.softmax(z@rw+rb).reshape(-1,10,20).sum(2)
    def images(logq):return np.stack([f.prior.reconstruct(book.prototypes[q.argmax(0)]) for q in logq])
    old=json.loads((n.OUT/'results.json').read_text());pairs=old['protocol']['pairs'];mixtures=old['protocol']['mixtures']
    selection=json.loads((n.OUT/'representative_input_selection.json').read_text())
    cases=[dict(pair_id=k,i=i,j=j,mix=m,illustration=False) for k,(i,j) in enumerate(pairs) for m in mixtures]
    cases += [dict(pair_id=-1,i=selection['test_index3'],j=selection['test_index8'],mix=m,illustration=True) for m in [.4,.5,.6]]
    protocol=dict(seed=seed,matched_cases=220,illustration_cases=3,cases=cases,steps=STEPS,snapshots=SNAPS,gain=.25,competition_damping=.2,sensory_damping=.2,
        initialization='p0 = lower soft code of fixed input; z0=encode(p0); e0=category probabilities/max probability; a0=e0.',
        update='At t: e_t=readout(encode(p_t))/max; a_next=.8*a_t+.2*relu(e_t-1.5*sum_other(a_t)); weights=a_next/sum(a_next). delta=sum_c weights_c*clip(log(q_ref_c)-log(q_t),-2,2). target=softmax_channels(log(p0)+.25*delta); p_next=.8*p_t+.2*target. Re-encode p_next to update category evidence. References fixed per category from original z0. All ten categories participate.',
        references='Existing training-only eight-reference bank per category; nearest raw128 reference in each category to original z0. No reference reselection during iterations.',
        controls='Competition with fixed original evidence and no feedback; same competition followed by one winner-reference update, matching prior category8. Coupled condition uses soft activity-weighted feedback and damping as well as interleaving; this is a mechanism comparison, not an isolated timing ablation.',
        convergence='Run all200 cycles. Settled if maximum absolute activity change and lower-probability change are both below1e-5 for last10 cycles. Flag approximate two-cycle if last10 two-step distances<1e-5 while one-step distances are not. Also record winner changes.',
        evaluation='Independent pixel5NN, same all60000 centered train images. Report agreement with original winner and final competition winner separately, ground-truth measures separately. Only220 original scenes enter statistics; thinner-three illustration excluded.',
        scope='Frozen sensory/readout weights, static inputs, no training, no gates, no spatial attention. Single seed and reused 3/8 pairs. Constants fixed before evaluation; no gain search.')
    (OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    refs={}
    for c in range(10):
        ids=np.flatnonzero(labels==c);v=codes[ids];dist=((v-v.mean(axis=0))**2).sum(axis=1)
        ids=ids[dist<=np.quantile(dist,.9)]
        first=ids[np.argmin(((codes[ids]-v.mean(axis=0))**2).sum(axis=1))];selected=[int(first)];minimum=np.full(len(ids),np.inf)
        for _ in range(7):
            minimum=np.minimum(minimum,((codes[ids]-codes[selected[-1]])**2).sum(axis=1))
            selected.append(int(ids[np.argmax(minimum)]))
        assert len(set(selected))==8 and np.all(labels[selected]==c)
        refs[c]=selected
    if seed==71001:
        oldrefs=json.loads((n.CAMPAIGN/'category_feedback_diagnostic/reference_indices.json').read_text())['71001']
        assert {str(k):v for k,v in refs.items()}==oldrefs
    (OUT/'reference_indices.json').write_text(json.dumps(refs,indent=2)+'\n')
    refids=np.array([refs[c] for c in range(10)]);refcodes=codes[refids].astype(np.float32)
    refq=decode(refcodes.reshape(-1,128)).reshape(10,8,64,676)
    x=np.stack([c['mix']*vp[c['i']]+(1-c['mix'])*vp[c['j']] for c in cases])
    p0=np.stack([book.process(v,False,.01,.08)[0].reshape(64,676) for v in x]);logp0=np.log(np.maximum(p0,1e-30))
    z0=p0.reshape(len(cases),-1)@enc+eb;q0=decode(z0);prob0=probs(z0);e0=prob0/prob0.max(1,keepdims=True);a0=e0.copy();win0=prob0.argmax(1)
    chosen=np.argmin(((z0[:,None,None,:]-refcodes[None,:,:,:])**2).sum(3),axis=2)
    fixed=a0.copy()
    for _ in range(STEPS):fixed=.8*fixed+.2*np.maximum(e0-1.5*(fixed.sum(1,keepdims=True)-fixed),0)
    np.testing.assert_array_equal(fixed.argmax(1),win0)
    selected_q=refq[win0,chosen[np.arange(len(cases)),win0]]
    single=channel_softmax(logp0+.25*np.clip(selected_q-q0,-2,2))
    singleq=decode(single.reshape(len(cases),-1)@enc+eb)
    # Synthetic limiting cases: zero correction preserves anchor; one-hot mixing recovers existing update.
    np.testing.assert_allclose(channel_softmax(logp0),p0,atol=2e-7)
    onehot=np.eye(10,dtype=np.float32)[win0];delta=np.zeros_like(p0)
    for c in range(10):delta+=onehot[:,c,None,None]*np.clip(refq[c,chosen[:,c]]-q0,-2,2)
    np.testing.assert_allclose(channel_softmax(logp0+.25*delta),single,atol=2e-7)
    native=folder/'categorical_parity.csv';native_error=None
    if native.exists():
        names=native.open().readline().strip().split(',');actual=np.loadtxt(native,delimiter=',',skiprows=1)[:,[k for k,v in enumerate(names) if v.startswith('topdown:')]]
        native_error=float(abs(actual-np.exp(decode(testcodes[:8].astype(np.float32))).reshape(8,-1)).max());assert native_error<2e-5
    with np.load(readout) as saved:
        predictions=probs(testcodes.astype(np.float32)).argmax(1)
        np.testing.assert_array_equal(predictions,saved['predictions'])
    encoder_error=max(float(abs(z0[k]-testcodes[c['i'] if c['mix']==1 else c['j']]).max()) for k,c in enumerate(cases) if c['mix'] in (0,1));assert encoder_error<1e-4
    p=p0.copy();a=a0.copy();q=q0;prob=prob0
    activities=[a.copy()];probabilities=[prob.copy()];changes=[];snapshots={0:images(q0)};previous_p=None;previous_a=None
    status('running interleaved competition and feedback')
    for step in range(1,STEPS+1):
        evidence=prob/prob.max(1,keepdims=True)
        anew=.8*a+.2*np.maximum(evidence-1.5*(a.sum(1,keepdims=True)-a),0)
        weights=anew/anew.sum(1,keepdims=True);delta=np.zeros_like(p)
        for c in range(10):delta+=weights[:,c,None,None]*np.clip(refq[c,chosen[:,c]]-q,-2,2)
        target=channel_softmax(logp0+.25*delta);pnew=.8*p+.2*target
        np.testing.assert_allclose(pnew.sum(1),1,atol=3e-6);assert np.isfinite(pnew).all()
        da=abs(anew-a).max(1);dp=abs(pnew-p).max((1,2))
        two=np.maximum(abs(anew-previous_a).max(1),abs(pnew-previous_p).max((1,2))) if previous_p is not None else np.full(len(cases),np.nan)
        changes.append(np.stack([da,dp,two],axis=1));previous_p=p;previous_a=a;p=pnew;a=anew
        z=p.reshape(len(cases),-1)@enc+eb;q=decode(z);prob=probs(z)
        activities.append(a.copy());probabilities.append(prob.copy())
        if step in SNAPS:snapshots[step]=images(q)
        if step%25==0:status(f'completed {step}/200 inference cycles')
    activities=np.asarray(activities);probabilities=np.asarray(probabilities);changes=np.asarray(changes)
    if save_decoder_probabilities:
        np.savez_compressed(OUT/'upper_decoder_probabilities.npz',no_feedback=np.exp(q0),feedback_after=np.exp(singleq),feedback_during=np.exp(q))
    finalwin=a.argmax(1);outputs=np.concatenate([images(q0),images(singleq),images(q)],axis=0)
    status('scoring final reconstructions')
    pix=e.five_nearest_predictions(tp.reshape(60000,-1),labels,outputs.reshape(-1,1024)).reshape(3,len(cases))
    if seed==71001:
        oldrows={(r['pair_id'],r['mix'],r['mode']):r for r in old['per_case']}
        for k,c in enumerate(cases[:220]):
            for mi,mode in enumerate(['no_feedback','category8']):
                r=oldrows[(c['pair_id'],c['mix'],mode)];assert int(pix[mi,k])==r['pixel_knn_prediction'] and int(win0[k])==r['winner']
    aggregate=[];rows=[]
    for mi,mode in enumerate(['competition_only','feedback_after','feedback_during']):
        winners=finalwin if mi==2 else win0
        for k,c in enumerate(cases):
            rows.append(dict(**c,mode=mode,initial_winner=int(win0[k]),final_winner=int(winners[k]),pixel_prediction=int(pix[mi,k]),input_mse=float(((outputs[mi*len(cases)+k]-x[k])**2).mean())))
        mask=np.arange(len(cases))<220;equal=mask & np.array([c['mix']==.5 for c in cases]);clean=mask & np.array([c['mix'] in (0,1) for c in cases]);dom=mask & ~equal
        truth=np.array([3 if c['mix']>.5 else 8 for c in cases]);wrong=dom&(win0!=truth)
        aggregate.append(dict(mode=mode,initial_winner_agreement=float(np.mean(pix[mi,mask]==win0[mask])),final_winner_agreement=float(np.mean(pix[mi,mask]==winners[mask])),equal_final_winner_agreement=float(np.mean(pix[mi,equal]==winners[equal])),dominant_selection=float(np.mean(winners[dom]==truth[dom])),dominant_reconstruction=float(np.mean(pix[mi,dom]==truth[dom])),clean_reconstruction=float(np.mean(pix[mi,clean]==truth[clean])),wrong_initial_winner_agreement=float(np.mean(pix[mi,wrong]==win0[wrong]))))
    one=np.maximum(changes[-10:,:,0],changes[-10:,:,1]).max(0);two=changes[-10:,:,2].max(0);settled=one<1e-5
    diagnostics=dict(settled_count=int(settled[:220].sum()),case_count=220,max_last10_one_step=float(one[:220].max()),two_cycle_flags=int(((two[:220]<1e-5)&~settled[:220]).sum()),final_winner_changes=int((finalwin[:220]!=win0[:220]).sum()),winner_switches_last20=int((activities[-20:, :220].argmax(2)[1:]!=activities[-20:, :220].argmax(2)[:-1]).sum()),final_readout_competition_disagreements=int((probabilities[-1,:220].argmax(1)!=finalwin[:220]).sum()))
    assert all(hashlib.sha256(p.read_bytes()).hexdigest()==hashes[p.name] for p in paths)
    result=dict(protocol=protocol,aggregate=aggregate,dynamics=diagnostics,per_case=rows,checks=dict(encoder_error=encoder_error,native_decoder_error=native_error,controls_match_prior=(seed==71001),saved_test_readout_matches=True,checkpoint_sha256=hashes))
    (OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    np.savez_compressed(OUT/'activity_traces.npz',activities=activities,category_probabilities=probabilities,changes=changes,final_images=outputs,snapshot_steps=SNAPS,snapshot_images=np.stack([snapshots[t] for t in SNAPS]))
    steps=[0,1,2,4,8,16,32,200]
    f.gallery(OUT/'representative_iterations.png','Coupled feedback: fixed input per row; columns are inference iterations',[[snapshots[t][220+k] for t in steps] for k in range(3)],['3 fraction .4','.5','.6'],[str(t) for t in steps])
    f.gallery(OUT/'representative_controls.png','Thinner three: same inputs and fixed gain .25',[[x[220+k],outputs[220+k],outputs[len(cases)+220+k],outputs[2*len(cases)+220+k]] for k in range(3)],['3 fraction .4','.5','.6'],['input','no feedback','feedback after','feedback during'])
    # Static activity traces; show all categories, label 3 and 8.
    canvas=Image.new('RGB',(1000,720),'white');draw=ImageDraw.Draw(canvas);font=ImageFont.load_default(size=16)
    draw.text((12,8),'Competition activity across inference cycles; same representative inputs',fill='black',font=font)
    colors=['#bbbbbb']*10;colors[3]='#d65f00';colors[8]='#006bb6'
    for k in range(3):
        y0=60+k*215;draw.text((12,y0),f'3 fraction {[.4,.5,.6][k]}',fill='black',font=font)
        draw.line((155,y0+160,955,y0+160),fill='black');draw.line((155,y0,155,y0+160),fill='black')
        values=activities[:,220+k];scale=max(1.,float(values.max()))
        for c in list(set(range(10))-{3,8})+[3,8]:
            pts=[(155+4*t,y0+160-150*float(v)/scale) for t,v in enumerate(values[:,c])];draw.line(pts,fill=colors[c],width=3 if c in (3,8) else 1)
        for t in [0,50,100,150,200]:draw.text((150+4*t,y0+167),str(t),fill='black',font=font)
        draw.text((18,y0+40),'3: orange',fill=colors[3],font=font);draw.text((18,y0+65),'8: blue',fill=colors[8],font=font)
    canvas.save(OUT/'representative_activity.png')
    lines=['# Feedback during category competition','', f'Frozen seed {seed}, same220 static mixtures as prior diagnostic. Additional thinner-three examples are illustrations only. Gain .25; all200 cycles executed; weights unchanged.','', '| Condition | Original-winner agreement | Final-winner agreement | Equal-mixture final agreement | Dominant reconstruction | Clean reconstruction |','| --- | ---: | ---: | ---: | ---: | ---: |']
    for r in aggregate:lines.append(f'| {r["mode"]} | {r["initial_winner_agreement"]:.2%} | {r["final_winner_agreement"]:.2%} | {r["equal_final_winner_agreement"]:.2%} | {r["dominant_reconstruction"]:.2%} | {r["clean_reconstruction"]:.2%} |')
    lines+=['',json.dumps(diagnostics,indent=2),'','This tests interleaving together with soft activity-weighted feedback, recurrent prediction error and damping; it is not an isolated timing manipulation. No winner-reference reselection, gates, training or spatial spotlight. Category confidence is not calibration. Winner reinforcement, including wrong winners, is a separate outcome from truth accuracy. Single-seed reused-scene results do not establish population-level effects. The two-cycle test does not rule out every oscillation pattern. See protocol.json for exact update and stability definitions.']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');status('complete');print('\n'.join(lines),flush=True)

