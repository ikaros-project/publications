"""Analyze saved overlap trials; no inference or outcome-based example selection."""
import argparse,json,subprocess
import numpy as np
from PIL import Image
from reportlab.lib.utils import ImageReader
from run_spatial_overlap_pilot import ROOT as DATA,masks
from generate_spatial_manuscript_figures import Figure,ROOT,BLUE,ORANGE,GREEN,GRAY


def draw(f,a,x,y,w,h=None):
    h=h or w*a.shape[0]/a.shape[1]
    f.c.drawImage(ImageReader(Image.fromarray(np.uint8(np.clip(a,0,1)*255))),x,f.h-y-h,width=w,height=h)

def finish(f):
    name=f.c._filename;f.save()
    result=subprocess.run(['pdftoppm','-r','150','-singlefile','-png',name,name[:-4]],capture_output=True)
    assert result.returncode==0

def read():
    meta=json.loads((DATA/'stimuli.json').read_text())
    z=np.load(DATA/'stimuli.npz');return meta,z['input'],z['components']

def stimuli():
    meta,xx,components=read();f=Figure('spatial_overlap_pilot_stimuli',390)
    f.text(12,10,'Overlap pilot: fixed inputs before outcome inspection',13,bold=True)
    f.text(12,31,'Maximum union; three digit pairs; same images in every condition',9)
    for k,label in enumerate(['Object A','Object B','Full: 0 px','Partial: 4 px','Partial: 8 px','Separate: 40 px']):f.text(47+k*86,63,label,8,align='center')
    for pair in range(3):
        group=[m for m in meta if m['pair']==pair and m['kind']=='pair'];m=group[0];ca,cb=m['categories'];y=94+pair*85
        for k in range(2):draw(f,components[m['case'],k,:,144:176],20+k*86,y,50)
        for k,m in enumerate(group):draw(f,xx[m['case'],:,112:208],182+k*86,y+12,80)
        f.text(20,y+58,f'{ca} + {cb}',9,bold=True)
    f.text(12,357,'Offsets describe tile displacement. Every 4/8-pixel pair has shared foreground.',8)
    f.text(12,372,'Images screened only for isolated recognition; no overlap performance screening.',8)
    finish(f)


def analyze():
    meta,xx,components=read()
    rows=json.loads((DATA/'results.json').read_text())['cases'];lookup={(x['case'],x['method']):x for x in rows}
    aliases=json.loads((DATA/'aliases.json').read_text())
    for a in aliases:lookup[a['case'],a['method']]=dict(lookup[a['case'],a['source']],method=a['method'],cued_object=1,reused=True)
    arrays={}
    def arr(case,method):
        source=next((a['source'] for a in aliases if a['case']==case and a['method']==method),method)
        key=case,source
        if key not in arrays:
            with np.load(DATA/f'case{case:02d}_{source}/arrays.npz') as z:arrays[key]={k:z[k] for k in ['final_render','final_field_predictions','final_probability','category_trace','spatial_trace','gain_trace','reference_slots','reference_ids','changes','t0_fields','t32_fields','t128_fields','t300_fields','t600_fields']}
        return arrays[key]
    pairmeta=[m for m in meta if m['kind']=='pair'];contrasts=[];recognition=[];feedback=[];uncued_effects=[]
    for m in pairmeta:
        j=m['case'];comp=components[j];mm=masks(comp);positions=m['positions'];cats=m['categories']
        for family in ['spatial','combined_spatial','category','combined_category']:
            aa=arr(j,family+'_A');bb=arr(j,family+'_B');ra=lookup[j,family+'_A'];rb=lookup[j,family+'_B']
            # Verify the matched conditions use exactly the same training references.
            np.testing.assert_array_equal(aa['reference_slots'],bb['reference_slots'])
            effects=[];local=[];direction=[]
            for k,label in enumerate(['A','B']):
                mask=mm[label+'_unique'];signed=aa['final_render']-bb['final_render'] if k==0 else bb['final_render']-aa['final_render']
                effects.append(float(signed[mask].mean()))
                pos=positions[k];masklocal=mask[:,pos:pos+32]
                dy=aa['final_field_predictions'][pos+31]-bb['final_field_predictions'][pos+31]
                if k==1:dy=-dy
                local.append(float(dy[masklocal].mean()))
                requested=ra if k==0 else rb
                direction.append(dict(object=label,requested=cats[k],global_category=None if 'category' in family else requested['category'],selected_field_readout=requested['selected_field_category'],aligned_field_readout=requested['field_categories'][k],location=requested['location'],settled=requested['settled']))
            contrasts.append(dict(pair=m['pair'],separation=m['separation'],family=family,render_A_unique=effects[0],render_B_unique=effects[1],render_mean=np.mean(effects).item(),local_A_unique=local[0],local_B_unique=local[1],local_mean=np.mean(local).item(),directions=direction))
        for cue in ['spatial','category']:
            for k,label in enumerate(['A','B']):
                on=arr(j,'combined_'+cue+'_'+label);off=arr(j,cue+'_'+label)
                np.testing.assert_array_equal(on['reference_slots'],off['reference_slots'])
                dy=on['final_render']-off['final_render'];pos=positions[k];fielddy=on['final_field_predictions'][pos+31]-off['final_field_predictions'][pos+31]
                targetmask=mm[label+'_unique'];losermask=mm[('B' if k==0 else 'A')+'_unique'];roi=mm['union'][:,pos:pos+32]
                def avg(a,mask):return float(a[mask].mean()) if mask.any() else None
                feedback.append(dict(pair=m['pair'],separation=m['separation'],cue=cue,target=label,render_target_change=avg(dy,targetmask),render_loser_change=avg(dy,losermask),render_shared_change=avg(dy,mm['shared']),field_shared_change=avg(fielddy,mm['shared'][:,pos:pos+32]),field_target_change=avg(fielddy,targetmask[:,pos:pos+32]),field_loser_change=avg(fielddy,losermask[:,pos:pos+32]),field_loser_pixels=int(losermask[:,pos:pos+32].sum()),field_target_mse_change=float((((on['final_field_predictions'][pos+31]-comp[k,:,pos:pos+32])**2-(off['final_field_predictions'][pos+31]-comp[k,:,pos:pos+32])**2)[roi]).mean())))
        bottom=lookup[j,'bottom_up'];combined=lookup[j,'uncued_combined'];winner=combined['category']
        ue=dict(pair=m['pair'],separation=m['separation'],winner=winner,winner_in_pair=winner in cats,settled=combined['settled'])
        if winner in cats:
            k=cats.index(winner);own='A' if k==0 else 'B';other='B' if k==0 else 'A'
            for endpoint,on,off in [('render',combined['render_scores'],bottom['render_scores']),('field',combined['field_scores'][k],bottom['field_scores'][k])]:
                for label,which in [('winner',own),('loser',other)]:
                    key=which+'_unique_mean';ue[endpoint+'_'+label+'_change']=on[key]-off[key] if on[key] is not None else None
        uncued_effects.append(ue)
        for method in ['bottom_up','uncued_combined']:
            rr=lookup[j,method];recognition.append(dict(pair=m['pair'],separation=m['separation'],method=method,category=rr['category'],in_pair=rr['category'] in cats,selected_field_category=rr['selected_field_category'],location=rr['location'],settled=rr['settled']))
    aggregates=[]
    for sep in [0,4,8,40]:
        for fam in ['spatial','combined_spatial','category','combined_category']:
            cc=[c for c in contrasts if c['separation']==sep and c['family']==fam];directions=sum([c['directions'] for c in cc],[])
            aggregates.append(dict(separation=sep,family=fam,render_mean=float(np.mean([c['render_mean'] for c in cc])),local_mean=float(np.mean([c['local_mean'] for c in cc])),render_positive_pairs=sum(c['render_A_unique']>1e-6 and c['render_B_unique']>1e-6 for c in cc),local_positive_pairs=sum(c['local_A_unique']>1e-6 and c['local_B_unique']>1e-6 for c in cc),global_correct=None if 'category' in fam else sum(d['global_category']==d['requested'] for d in directions),selected_readout_correct=sum(d['selected_field_readout']==d['requested'] for d in directions),aligned_readout_correct=sum(d['aligned_field_readout']==d['requested'] for d in directions),settled=sum(d['settled'] for d in directions)))
    isolated=[r for r in rows if r['kind']=='isolated'];iso={name:dict(n=len(rr:=[r for r in isolated if r['method']==name]),correct=sum(r['category']==r['categories'][0] for r in rr),settled=sum(r['settled'] for r in rr)) for name in ['bottom_up','spatial_A','combined_spatial_A']}
    output=dict(unique_trials=len(rows),settled=sum(r['settled'] for r in rows),isolated=iso,contrasts=contrasts,aggregates=aggregates,feedback_effects=feedback,uncued=recognition,uncued_effects=uncued_effects,scope='Three fixed screened pairs, one trained model; six cue directions are dependent. Positive feature contrast means the same distinctive pixels are stronger when their own object is cued than when the competitor is cued. Exact mask thresholds are fixed, all effects use common pixel coordinates. Render averages all351 fields; local compares each object-aligned field under opposite cues, using its unique pixels only. Category-cued global output is not recognition evidence.')
    (ROOT/'spatial_overlap_pilot_statistics.json').write_text(json.dumps(output,indent=2))
    return output,lookup,arr


def graphs(out):
    f=Figure('spatial_overlap_pilot_summary',680)
    f.text(12,10,'Overlapping objects: cue reversal and distinctive features',13,bold=True)
    f.text(12,31,'Positive contrast = more of an object\'s unique pixels when that object is cued',9)
    colors=[GRAY,BLUE,ORANGE,GREEN];families=['spatial','combined_spatial','category','combined_category']
    for i,(fam,col) in enumerate(zip(families,colors)):
        x=15+(i%2)*265;y=54+(i//2)*17;f.line(x,y+4,x+18,y+4,col,2);f.text(x+24,y,fam.replace('_',' '),9)
    values=[a[k] for a in out['aggregates'] for k in ['render_mean','local_mean']];lo=min(-.02,min(values)*1.2);hi=max(.1,np.ceil(max(values)*10)/10)
    ticks=[round(v,2) for v in np.arange(0,hi+.001,.1)]
    for panel,(key,title) in enumerate([('render_mean','A  All-field canvas reconstruction'),('local_mean','B  Object-aligned field reconstruction')]):
        y=123+panel*248;f.text(14,y-15,title,11,bold=True)
        xy=f.axes((63,y+17,443,155),(-.15,3.15),(lo,hi),[(0,'0 (full)'),(1,'4'),(2,'8'),(3,'40 (separate)')],ticks,'Separation condition (pixels)','Mean cue-reversal contrast, pixel intensity')
        f.line(*xy(-.15,0),*xy(3.15,0),'#777777',.7,[2,2])
        for fam,col in zip(families,colors):
            a=[next(a for a in out['aggregates'] if a['family']==fam and a['separation']==sep)[key] for sep in [0,4,8,40]]
            f.curve(xy,range(4),a,col)
    f.text(12,632,'Means over3 pairs; averages can hide failed directions. Input range0-1; no population intervals.',8)
    f.text(12,647,'Field contrasts compare fixed coordinates; pixels outside fields are never counted as suppressed.',8)
    f.text(12,662,'Full-overlap spatial cues are identical and therefore cannot distinguish the two objects.',8)
    finish(f)


def gallery(lookup,arr):
    meta,xx,comp=read()
    for sep in [0,4,8]:
        f=Figure(f'spatial_overlap_pilot_examples_sep{sep}',585)
        f.text(12,10,f'Object selection at {sep}-pixel separation',13,bold=True)
        f.text(12,31,'Fixed field at left edge144; all pairs shown; common grayscale0-1',9)
        labels=['Input','No cue, combined','Category A, no feedback','Category A, combined','Category B, no feedback','Category B, combined']
        methods=[None,'uncued_combined','category_A','combined_category_A','category_B','combined_category_B']
        for pair in range(3):
            m=next(m for m in meta if m['pair']==pair and m['kind']=='pair' and m['separation']==sep);j=m['case'];x=210+pair*106
            f.text(x+29,57,f'{m["categories"][0]} + {m["categories"][1]}',10,bold=True,align='center')
            for i,(label,method) in enumerate(zip(labels,methods)):
                y=85+i*76
                if pair==0:f.text(12,y+22,label,9)
                if method is None:im=xx[j,:,144:176];sub=''
                else:
                    a=arr(j,method);im=a['final_field_predictions'][175];sub=f'local readout {int(a["final_probability"][175].argmax())}'
                draw(f,im,x,y,58);f.text(x+29,y+62,sub,7,align='center')
        f.text(12,557,'Category nodes are externally cued. Labels show the unforced local readout, not the category clamp.',8)
        f.text(12,572,'Presentation crop only; inference uses every horizontal field of the full display.',8)
        finish(f)


def spatial_gallery(lookup,arr):
    meta,xx,components=read()
    f=Figure('spatial_overlap_pilot_spatial_examples',570)
    f.text(12,10,'Spatial cues: partial overlap versus separated objects',13,bold=True)
    f.text(12,31,'Whole-canvas reconstruction, cropped identically for display; all three pairs',9)
    columns=[('Input',None),('Spatial A','spatial_A'),('Spatial B','spatial_B'),('Combined A','combined_spatial_A'),('Combined B','combined_spatial_B')]
    for k,(title,_) in enumerate(columns):f.text(112+k*94,62,title,9,align='center')
    for row,(sep,pair) in enumerate((s,p) for s in [8,40] for p in range(3)):
        m=next(m for m in meta if m['kind']=='pair' and m['pair']==pair and m['separation']==sep);j=m['case'];y=88+row*70
        f.text(8,y+5,str(m['categories']).replace(', ','/'),9)
        f.text(8,y+20,f'{sep}px',8)
        for k,(_,method) in enumerate(columns):
            im=xx[j] if method is None else arr(j,method)['final_render']
            draw(f,im[:,112:208],70+k*94,y,84)
            if method is not None:f.text(112+k*94,y+35,'category '+str(lookup[j,method]['category']),7,align='center')
    f.text(12,524,'Original pixels have fixed intensities; reconstructions use the same0-1 scale.',8)
    f.text(12,539,'Category output is unforced in these spatial-cue trials. Full overlap has identical spatial cues.',8)
    f.text(12,554,'No selected-field masking is applied to the whole-canvas output.',8)
    finish(f)


def notes(out):
    lines=['# Overlapping-object pilot','',out['scope'],'','## Methods','',
    'Three pairs (3/8,4/9,1/7), six unique MNIST images, frozen seed71001. First isolated-feedforward-correct examples in test indices9000:10000; all first candidates passed. Maximum pixel union, horizontal offsets0,4,8,40. Pixel geometry was checked before inference: offset16 was replaced by4 because two pairs had no shared foreground at16. Protocol and draft geometry are retained.132 unique fixed600-update trials; six identical full-overlap spatial-cue conditions reused.18 isolated controls are included. Parameters match the adopted combined model; all conditions retain relative binding and separated instantaneous sensory mismatch. Bottom-up removes sensory gain, content feedback and outgoing category biases; other matched conditions differ only in content feedback/cue. Cues strength2. No parameter tuning or overlapping-outcome screening.','',
    'Category-cued global activity is imposed and never counted as recognition. Distinctive masks require own pixel>=0.25 and other<=0.05; shared requires both>=0.25. Whole-canvas output is the existing uniform average of all351 reconstructed fields; object-aligned outputs are evaluated separately without zeroing uncovered pixels. The key contrast compares identical pixel coordinates under opposite cues. Positive contrast for both objects supports reversible selective enhancement/suppression rather than generic reconstruction attenuation. Raw reconstruction loss relative to the input alone is insufficient.','',
    '## Controls','',json.dumps(out['isolated']),f"\nSettled: {out['settled']}/{out['unique_trials']} unique trials under the final100-update criterion. No runs were extended.",'',
    '## Paired cue reversal','',
    '| Offset | Condition | Whole-canvas contrast | Local-field contrast | Both objects positive, canvas/local (of3) | Global correct (of6) | Selected/local-aligned readout correct (of6) |',
    '|---:|---|---:|---:|---|---|---|']
    for a in out['aggregates']:
        lines.append(f"| {a['separation']} | {a['family']} | {a['render_mean']:+.5f} | {a['local_mean']:+.5f} | canvas {a['render_positive_pairs']}/3; local {a['local_positive_pairs']}/3 | {a['global_correct'] if a['global_correct'] is not None else 'externally cued'} | {a['selected_readout_correct']}/{a['aligned_readout_correct']} |")
    lines += ['','## Matched addition of content feedback','', '| Offset | Cue | Target pixels, canvas | Losing pixels, canvas | Target pixels, field | Losing pixels, field | Shared pixels, field | Target-image MSE change, field |','|---:|---|---:|---:|---:|---:|---:|---:|']
    for sep in [0,4,8,40]:
        for cue in ['spatial','category']:
            rows=[r for r in out['feedback_effects'] if r['separation']==sep and r['cue']==cue]
            keys=['render_target_change','render_loser_change','field_target_change','field_loser_change','field_shared_change','field_target_mse_change'];means=[]
            for key in keys:
                vals=[r[key] for r in rows if r[key] is not None];means.append(f'{np.mean(vals):+.5f}' if vals else 'not covered')
            lines.append(f"| {sep} | {cue} | "+' | '.join(means)+' |')
    lines += ['','## Uncued competition','', '| Offset | Pair | Uncued combined winner | Winner is an input category | Winner-feature change | Losing-feature change |','|---:|---:|---:|---|---:|---:|']
    for row in out['uncued_effects']:
        val=lambda key: f'{row[key]:+.5f}' if row.get(key) is not None else '--'
        lines.append(f"| {row['separation']} | {row['pair']} | {row['winner']} | {row['winner_in_pair']} | {val('render_winner_change')} | {val('render_loser_change')} |")
    lines += ['', 'Uncued feature changes compare the whole combined circuit with bottom-up processing, not a content-feedback-only ablation. Winner identity is the unforced global output; third-category outcomes remain explicit and are not assigned an object-specific suppression score.']
    lines+=['','Positive target change and negative losing-feature change are the desired joint pattern. Field losing-feature means exclude cases with zero coverage (the separated control has no losing object in the target field). Report counts and individual outcomes before generalizing.','', '## Provenance','', 'Protocol, screening indices, components/masks, full field predictions, category/spatial/gain traces, reference identities, code/checkpoint hashes and per-trial outputs are retained in the spatial_overlap_pilot experiment directory. Figures include every pair; no outcome-based example selection. The manuscript body is not changed by this exploratory pilot.']
    (ROOT/'spatial_overlap_pilot_notes.md').write_text('\n'.join(lines)+'\n')


def fixed_spotlight():
    source=DATA/'fixed_spatial_cue'
    if not (source/'results.json').exists():return None
    meta,xx,components=read();records=json.loads((source/'results.json').read_text())['cases'];lookup={(r['case'],r['method']):r for r in records};stats=[];cache={}
    def get(j,method):
        with np.load(source/f'case{j:02d}_{method}/arrays.npz') as z:return {k:z[k] for k in ['final_field_predictions','final_render','final_probability','gain_trace','spatial_trace','reference_slots']}
    for m in meta:
        if m['kind']!='pair' or m['separation']!=0:continue
        j=m['case'];mm=masks(components[j]);arrs={name:get(j,name) for name in ['category_A','category_B','combined_category_A','combined_category_B']};cache[j]=arrs
        gains=np.stack([a['gain_trace'][-100:] for a in arrs.values()])
        gain_difference=float(np.ptp(gains,axis=0).max())
        all_locations=[int(a['spatial_trace'][-1].argmax())-31 for a in arrs.values()]
        for k,label in enumerate(['A','B']):
            on=arrs['combined_category_'+label];off=arrs['category_'+label];other=arrs['combined_category_'+('B' if k==0 else 'A')]
            np.testing.assert_array_equal(on['reference_slots'],off['reference_slots'])
            mask=mm[label+'_unique'][:,144:176];loser=mm[('B' if k==0 else 'A')+'_unique'][:,144:176]
            dy=on['final_field_predictions'][175]-off['final_field_predictions'][175];rev=on['final_field_predictions'][175]-other['final_field_predictions'][175]
            stats.append(dict(pair=m['pair'],target=label,category=m['categories'][k],gain_difference_last100=gain_difference,locations=all_locations,field_target_change=float(dy[mask].mean()),field_loser_change=float(dy[loser].mean()),field_shared_change=float(dy[mm['shared'][:,144:176]].mean()),field_own_cue_advantage=float(rev[mask].mean()),local_readout_category=int(on['final_probability'][175].argmax()),settled=lookup[j,'combined_category_'+label]['settled']))
    out=dict(unique_trials=len(records),settled=sum(r['settled'] for r in records),cases=stats,max_gain_difference=max(r['gain_difference_last100'] for r in stats),joint_target_enhancement_loser_suppression=sum(r['field_target_change']>1e-6 and r['field_loser_change']<-1e-6 for r in stats),positive_cue_reversal_directions=sum(r['field_own_cue_advantage']>1e-6 for r in stats),local_readout_correct=sum(r['local_readout_category']==r['category'] for r in stats))
    (ROOT/'spatial_overlap_fixed_spotlight_statistics.json').write_text(json.dumps(out,indent=2))
    f=Figure('spatial_overlap_fixed_spotlight_examples',555)
    f.text(12,10,'Full overlap with an identical spatial cue',13,bold=True)
    f.text(12,31,'Category cue changes; the spatial cue stays at the shared object location',9)
    labels=[('Input',None),('Category A, no feedback','category_A'),('Category A, combined','combined_category_A'),('Category B, no feedback','category_B'),('Category B, combined','combined_category_B')]
    for m in meta:
        if m['kind']!='pair' or m['separation']!=0:continue
        j=m['case'];x=207+m['pair']*107;f.text(x+31,62,f'{m["categories"][0]} + {m["categories"][1]}',10,bold=True,align='center')
        for i,(label,method) in enumerate(labels):
            y=90+i*80
            if m['pair']==0:f.text(12,y+23,label,9)
            im=xx[j,:,144:176] if method is None else cache[j][method]['final_field_predictions'][175]
            draw(f,im,x,y,62)
            if method:f.text(x+31,y+66,'local readout '+str(int(cache[j][method]['final_probability'][175].argmax())),7,align='center')
    f.text(12,502,'Same fixed field and intensity scale0-1. All three pairs are shown.',8)
    f.text(12,518,f'Maximum gain-profile difference over final100 updates: {out["max_gain_difference"]:.3g}.',8)
    f.text(12,534,'Readout labels are unforced; the global category node is externally activated.',8)
    finish(f)
    with (ROOT/'spatial_overlap_pilot_notes.md').open('a') as handle:
        handle.write('\n## Identical-spatial-cue control at full overlap\n\nTwelve additional trials used the same existing spatial cue at field144 under either category cue, with feedback off/on. This control was planned after the main batch launched but before inspecting overlap outcomes. It does not fix a state by hand; actual spatial-gain equality is checked from saved traces. All12 settled, selected field144, and had bit-identical gain profiles across the final100 updates.\n\n| Requested | Target change | Losing change | Shared change | Own-cue advantage | Local readout |\n|---:|---:|---:|---:|---:|---:|\n')
        for row in stats:handle.write(f"| {row['category']} | {row['field_target_change']:+.5f} | {row['field_loser_change']:+.5f} | {row['field_shared_change']:+.5f} | {row['field_own_cue_advantage']:+.5f} | {row['local_readout_category']} |\n")
        handle.write('\nChanges compare content feedback on versus off at the same category cue. Own-cue advantage compares content-feedback reconstructions under opposite category cues. Requested-object unique pixels show an own-cue advantage in5/6 directions (both directions for2/3 pairs); the unforced local readout matches4/6 requests. Losing-feature intensity decreases in6/6 directions, but target-feature intensity decreases in5/6. Only1/6 directions combines absolute target enhancement with losing-feature suppression. Full values are in spatial_overlap_fixed_spotlight_statistics.json.\n')
    return out


def fixed_effect_graph():
    path=ROOT/'spatial_overlap_fixed_spotlight_statistics.json'
    if not path.exists():return
    data=json.loads(path.read_text());rr=data['cases'];f=Figure('spatial_overlap_fixed_spotlight_effects',610)
    f.text(12,10,'Feature changes under an identical spotlight',13,bold=True)
    f.text(12,31,'Full overlap; six cue directions from three fixed pairs; local reconstructed field',9)
    f.text(12,62,'A  Adding content feedback to the same category cue',11,bold=True)
    xy=f.axes((65,100,440,155),(-.4,5.4),(-.45,.15),[(i,str(r['category'])) for i,r in enumerate(rr)],[-.4,-.2,0,.1],'Requested category','Pixel intensity change: feedback on minus off')
    f.line(*xy(-.4,0),*xy(5.4,0),'#777777',.7,[2,2])
    for i,r in enumerate(rr):
        f.line(*xy(i,r['field_target_change']),*xy(i,r['field_loser_change']),GRAY,1)
        f.dot(*xy(i,r['field_target_change']),GREEN,3);f.dot(*xy(i,r['field_loser_change']),ORANGE,3)
    f.dot(80,300,GREEN,3);f.text(89,296,'Requested-object unique pixels',9)
    f.dot(308,300,ORANGE,3);f.text(317,296,'Losing-object unique pixels',9)
    f.text(12,338,'B  Reversing the category cue',11,bold=True)
    xy=f.axes((65,376,440,140),(-.4,5.4),(-.025,.35),[(i,str(r['category'])) for i,r in enumerate(rr)],[0,.1,.2,.3],'Object category','Unique pixels: own cue minus competing cue')
    f.line(*xy(-.4,0),*xy(5.4,0),'#777777',.7,[2,2])
    for i,r in enumerate(rr):f.dot(*xy(i,r['field_own_cue_advantage']),BLUE,3)
    f.text(12,565,'Input/output range0-1. Masks and coordinates are unchanged across comparisons.',8)
    f.text(12,581,'Both target and losing features can dim; only one direction enhances target pixels above no feedback.',8)
    finish(f)


def assessment():
    text="""
## Assessment and remaining objective

All144 experimental runs (132 main plus12 matched-spatial-cue controls) settled within the fixed600-update endpoint criterion. A separate parity run reproduced the adopted combined model's saved output arrays exactly. All original runner hashes, frozen-weight checks, finite saved arrays, complete durations and matched references were verified. No learning or parameter tuning occurred.

Spatially cued category output was6/6 with separated objects,5/6 at8-pixel overlap and2/6 at4-pixel overlap, identically with feedback off/on. Full overlap supplies identical spatial cues, so the3/6 directional score there does not represent successful discrimination between two locations. Category cues with content feedback gave selected-field readout matches5/6,6/6,5/6 at offsets0,4,8; these counts must not be substituted for the externally driven global category, or for reconstruction quality. Object-aligned fields have different readout scores, as reported in the table.

The identical-spotlight control supports category-dependent modification of object features: gain profiles match exactly over the final100 updates, while changing the category cue gives an own-feature advantage in5/6 directions (bidirectionally in2/3 pairs). The local readout matches4/6 requested categories. Adding content feedback reduces losing-object unique pixels in6/6 directions, but also reduces requested-object pixels in5/6. Mean pixel changes are-0.2212 for losing features,-0.0710 for requested features and-0.0833 for shared features. Preferential suppression is therefore more defensible than clean restoration of the requested original image. These raw intensity changes are not population estimates.

The whole-canvas result is substantially weaker than local-field effects. Under category cues with feedback, both objects have positive whole-canvas cue-reversal contrasts in2/3 fully overlapping pairs and only1/3 pairs at each partial-overlap level. Under spatial cues with feedback, no partially overlapping pair has positive whole-canvas contrasts in both directions. Positive aggregate means can hide these failures. Uncued competition selects an input category in11/12 displays; the4-pixel1/7 mixture instead selects8. Winning one input category does not consistently suppress the other object's particular pixels in the whole-canvas output.

The pilot demonstrates a local object-attention effect with a controlled spatial gain, but does not complete the stronger objective of reliable selection and selective suppression throughout the reconstructed scene. The difference between field-level and whole-canvas outcomes motivates examining how overlapping field predictions are combined; it does not by itself prove that averaging is the sole cause. The adopted model remains unchanged. These are exploratory results from three recognizable digit pairs and one trained seed, not a robustness benchmark. The article body has not been updated with a claim of completed overlap processing.
"""
    with (ROOT/'spatial_overlap_pilot_notes.md').open('a') as f:f.write(text)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--stimuli-only',action='store_true');args=ap.parse_args();stimuli()
    if args.stimuli_only:return
    out,lookup,arr=analyze();graphs(out);gallery(lookup,arr);spatial_gallery(lookup,arr);notes(out);fixed_spotlight();fixed_effect_graph();assessment()
    print(json.dumps(dict(trials=out['unique_trials'],settled=out['settled'],isolated=out['isolated'],aggregates=out['aggregates']),indent=2))
if __name__=='__main__':main()
