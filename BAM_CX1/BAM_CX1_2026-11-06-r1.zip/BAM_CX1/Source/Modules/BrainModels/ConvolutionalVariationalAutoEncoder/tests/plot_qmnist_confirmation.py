"""Fixed-order example panels and aggregate plots for confirmation tests."""
import json
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import qmnist_confirmation_common as q
OUT=q.OUT
FONT='/System/Library/Fonts/Supplemental/Arial.ttf'
def font(n):return ImageFont.truetype(FONT,n)
def panel(rows,columns,path,title,notes):
 scale=4;cellw=150;cellh=162;left=145;top=100
 im=Image.new('RGB',(left+cellw*len(columns)+30,top+cellh*len(rows)+75),'white');d=ImageDraw.Draw(im)
 d.text((20,15),title,font=font(24),fill='black')
 for j,c in enumerate(columns):d.text((left+j*cellw,65),c,font=font(16),fill='black')
 for i,(label,arrays) in enumerate(rows):
  y=top+i*cellh;d.text((15,y+45),label,font=font(16),fill='black')
  for j,a in enumerate(arrays):
   tile=Image.fromarray(np.uint8(np.clip(a,0,1)*255)).convert('RGB').resize((128,128),Image.Resampling.NEAREST);im.paste(tile,(left+j*cellw,y))
 d.text((20,im.height-55),notes,font=font(15),fill='black');im.save(path)
def main():
 with np.load(OUT/'focal_stimuli.npz') as z:x=z['input'];clean=z['clean']
 fm=json.loads((OUT/'focal_stimuli.json').read_text());frows=[]
 with np.load(OUT/'focal_model71001_0.npz') as z:off=z['images']
 with np.load(OUT/'focal_model71001_1.npz') as z:on=z['images']
 for cat in range(10):
  r=next(v for v in fm if v['task']=='occlusion' and v['level']==12 and v['truth']==cat);j=r['case']
  n=next(v['case'] for v in fm if v['task']=='noise' and v['level']==.5 and v['ids']==r['ids'] and v['realization']==0)
  frows.append((f'Category {cat}',[clean[j],x[j],off[j],on[j],x[n],off[n],on[n]]))
 panel(frows,['Clean','Deletion12','Off','On','Noise0.5','Off','On'],OUT/'focal_examples.png','QMNIST confirmation: completion and noise','First sampled image per category and first noise realization. First frozen model. No outcome screening.')
 mr=[]
 for pair in range(6):
  r=next(v for v in fm if v['task']=='mixture' and v['cluster']==str(pair) and v['level']==.5);j=r['case'];mr.append((str(r['categories']),[x[j],off[j],on[j]]))
 panel(mr,['Equal mixture','Feedback off','Feedback on'],OUT/'mixture_examples.png','QMNIST confirmation: equal mixtures','First six category pairs in fixed sampling order. First frozen model. No outcome screening.')
 with np.load(OUT/'spatial_stimuli.npz') as z:sx=z['input'];sc=z['clean']
 sm=json.loads((OUT/'spatial_stimuli.json').read_text());sj=json.loads((OUT/'spatial_jobs.json').read_text());sr=[]
 for cat in range(10):
  r=next(v for v in sm if v['target_category']==cat and v['deletion']==12);tp=r['target_position'];j=r['case'];pred=[]
  for fb in [False,True]:
   job=next(v for v in sj if v['case']==j and v['task']=='completion' and v['feedback']==fb)
   with np.load(OUT/'spatial'/f"model71001_job{job['job']:03d}"/'arrays.npz') as z:pred.append(z['final_field_predictions'][tp+31])
  sr.append((f'Category {cat}',[sc[j,:,tp:tp+32],sx[j,:,tp:tp+32],*pred]))
 panel(sr,['Clean target','Deletion12','Feedback off','Feedback on'],OUT/'spatial_examples.png','QMNIST confirmation: spatial completion','First pair per target category. First frozen model. Target-field predictions. No outcome screening.')
 # Paired effect figure. Use separate axes because units differ.
 summary=json.loads((OUT/'summary.json').read_text())['summaries'];choices=[('mixture','all','agreement','Mixture: image/winner agreement',100),('noise',.5,'clean_mse','Noise0.5: clean-image MSE',1),('occlusion',12,'hidden_mse','Focal deletion12: hidden MSE',1),('completion',12,'target_hidden_mse','Spatial deletion12: hidden MSE',1)]
 im=Image.new('RGB',(1200,800),'white');d=ImageDraw.Draw(im);d.text((25,12),'QMNIST: paired feedback effects across three frozen models',font=font(25),fill='black')
 for k,(task,level,metric,title,mult) in enumerate(choices):
  r=next(v for v in summary if (v['task'],v['level'],v['metric'])==(task,level,metric));x0=75+(k%2)*590;y0=100+(k//2)*350;w=460;h=230
  vals=[v['difference']*mult for v in r['by_model']]+[v*mult for v in r['ci95']]+[0];lo=min(vals);hi=max(vals);span=max(hi-lo,.001);lo-=span*.2;hi+=span*.2
  yy=lambda v:y0+h-(v-lo)/(hi-lo)*h
  d.text((x0-30,y0-38),title,font=font(19),fill='black');d.line((x0,y0,x0,y0+h),fill='black',width=2)
  for t in np.linspace(lo,hi,5):
   y=yy(t);d.line((x0,y,x0+w,y),fill='#dddddd',width=1);d.text((x0-60,y-8),f'{t:.3f}',font=font(14),fill='black')
  d.line((x0,yy(0),x0+w,yy(0)),fill='black',width=2)
  for j,v in enumerate(r['by_model']):
   xx=x0+70+65*j;y=yy(v['difference']*mult);d.ellipse((xx-6,y-6,xx+6,y+6),fill='#2266aa')
  xx=x0+365;yl,yh=[yy(v*mult) for v in r['ci95']];d.line((xx,yl,xx,yh),fill='#c55b17',width=4);y=yy(r['difference']*mult);d.rectangle((xx-6,y-6,xx+6,y+6),fill='#c55b17')
  d.text((x0+55,y0+h+15),'Individual models',font=font(15),fill='black');d.text((x0+305,y0+h+15),'Mean +95% CI',font=font(15),fill='black')
 d.text((25,765),'On minus off. Agreement: percentage points. MSE: squared intensity. Crossed model/stimulus bootstrap.',font=font(16),fill='black');im.save(OUT/'paired_effects.png')
 print('Saved four fixed-order scientific figures.')
if __name__=='__main__':main()
