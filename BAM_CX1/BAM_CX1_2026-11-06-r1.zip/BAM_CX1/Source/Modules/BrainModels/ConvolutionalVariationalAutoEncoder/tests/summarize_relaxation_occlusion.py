import json,csv
from pathlib import Path
import numpy as np
import evaluate_relaxation_occlusion as e
out=e.OUT;m=Path(__file__).resolve().parents[5]/'Manuscript'
rows=json.loads((out/'results.json').read_text())['cases']
def stats(v):
 v=np.array(v,float);mean=v.mean();sd=v.std(ddof=1);h=2.262157*sd/np.sqrt(len(v));return dict(mean=float(mean),sd=float(sd),ci95=[float(mean-h),float(mean+h)])
perseed=[]
for seed in range(71001,71011):
 for size in e.SIZES:
  for method in ['none','relaxation']:
   rr=[r for r in rows if r['seed']==seed and r['size']==size and r['method']==method]
   r=dict(seed=seed,size=size,method=method,n=len(rr),settled=sum(v['settled'] for v in rr),switches=sum(bool(v['switch_iterations']) for v in rr))
   for key in ['hidden_mse','visible_mse','full_mse','hidden_stroke_mse','hidden_background_mse','hidden_stroke_intensity']:
    vals=[v[key] for v in rr if v[key] is not None];r[key]=float(np.mean(vals)) if vals else None
   r['category_accuracy']=float(np.mean([v['final_winner']==v['truth'] for v in rr]));r['pixel_accuracy']=float(np.mean([v['pixel_prediction']==v['truth'] for v in rr]));r['image_winner_agreement']=float(np.mean([v['pixel_winner_agreement'] for v in rr]));perseed.append(r)
summary=[]
for size in e.SIZES:
 sr=dict(size=size,conditions={},paired={})
 for method in ['none','relaxation']:
  rr=[v for v in perseed if v['size']==size and v['method']==method]
  sr['conditions'][method]={key:stats([v[key] for v in rr]) for key in ['hidden_mse','visible_mse','hidden_stroke_mse','hidden_background_mse','category_accuracy','pixel_accuracy','image_winner_agreement'] if rr[0][key] is not None}
 for key in sr['conditions']['none']:
  diffs=[next(v[key] for v in perseed if v['seed']==s and v['size']==size and v['method']=='relaxation')-next(v[key] for v in perseed if v['seed']==s and v['size']==size and v['method']=='none') for s in range(71001,71011)]
  sr['paired'][key]=stats(diffs)
 if size:
  for group,condition in [('initially_correct',lambda v:v['initial_winner']==v['truth']),('initially_wrong',lambda v:v['initial_winner']!=v['truth'])]:
   rr=[v for v in rows if v['size']==size and v['method']=='relaxation' and condition(v)];sr[group]=dict(n=len(rr),final_correct=sum(v['final_winner']==v['truth'] for v in rr),image_agrees_winner=sum(v['pixel_winner_agreement'] for v in rr))
 summary.append(sr)
(out/'summary.json').write_text(json.dumps(dict(summary=summary,per_seed=perseed),indent=2)+'\n')
with (m/'occlusion_relaxation_statistics.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(perseed[0]));w.writeheader();w.writerows(perseed)
lines=['# Occlusion with current prediction relaxation','','Ten frozen models;40 reused digit3/8 images; central black squares0,8,12,16 pixels wide. Each input run500 updates with no feedback or50% prediction relaxation. Masks and clean targets enter scoring only. No new training. Same category competition and fixed references.','','| Square width | Hidden MSE: none / feedback | Visible MSE: none / feedback | Network correct: none / feedback | Pixel correct: none / feedback | Image/winner agreement: none / feedback |','|---|---|---|---|---|---|']
for s in summary:
 a=s['conditions']['none'];b=s['conditions']['relaxation']
 def pair(k,pct=False):return 'n/a' if k not in a else (f"{a[k]['mean']:.2%} / {b[k]['mean']:.2%}" if pct else f"{a[k]['mean']:.6f} / {b[k]['mean']:.6f}")
 lines.append(f"|{s['size']}|{pair('hidden_mse')}|{pair('visible_mse')}|{pair('category_accuracy',True)}|{pair('pixel_accuracy',True)}|{pair('image_winner_agreement',True)}|")
lines+=['','## Paired feedback-minus-control differences','','Descriptive95% t intervals across ten training seeds (df9), conditional on shared images. Negative MSE differences favor feedback.']
for s in summary:
 lines.append('\nSquare width '+str(s['size']))
 for key in ['hidden_mse','visible_mse','hidden_stroke_mse','hidden_background_mse','category_accuracy']:
  if key in s['paired']:lines.append(key+': '+json.dumps(s['paired'][key]))
lines+=['','## Dynamics and scope','',f"Settled at500: {sum(v['settled'] for v in rows)}/{len(rows)}; at200: {sum(v['settled_at200'] for v in rows)}/{len(rows)}.",'','A black occluder is treated by the unchanged model as observed black pixels, not explicitly unknown data. Thus50% sensory anchoring opposes filling in those locations. Hidden-region MSE is averaged per image before averaging models; separate hidden-stroke and background errors use clean intensity>.25 solely for evaluation. Added ink alone need not be correct completion. The model can retrieve a different exemplar, so pixel fidelity and category coherence are distinct outcomes. Only3/8 images and one centered mask geometry were tested; larger masks also remove different spatial features, not just more area. Seed intervals do not measure new-stimulus uncertainty. No article text or model defaults changed.','','Full protocol, per-case metrics, chosen references, images and competition traces are retained with the experiment. Clean endpoint network/pixel labels were checked against the preceding mixture experiment; all frozen weight hashes verified.']
(out/'REPORT.md').write_text('\n'.join(lines)+'\n');(m/'occlusion_relaxation_source_notes.md').write_text('\n'.join(lines)+'\n')
with np.load(out/'seed71001/arrays.npz') as z:
 # First pair, both categories, fixed before inspection.
 panels=[];labels=[]
 for sizeidx in [1,2,3]:
  for j in [0,1]:
   k=sizeidx*40+j;panels.append([z['clean'][k],z['input'][k],z['snapshots'][0,-1,k],z['snapshots'][1,-1,k]]);labels.append(f'{e.SIZES[sizeidx]}x{e.SIZES[sizeidx]}: digit '+('3' if j==0 else '8'))
 e.f.gallery(m/'occlusion_relaxation_examples.png','Occlusion: first pair, fixed examples',panels,labels,['clean target','observed','no feedback','feedback 50%'])
print('\n'.join(lines),flush=True)
