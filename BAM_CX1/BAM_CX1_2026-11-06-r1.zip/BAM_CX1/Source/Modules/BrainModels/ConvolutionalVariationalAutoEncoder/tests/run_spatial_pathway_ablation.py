"""Frozen Reviewer 2/4 controls. Original modules and checkpoints are untouched."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import json,time,datetime,hashlib,traceback,concurrent.futures
from pathlib import Path
from dataclasses import replace
import numpy as np
import qmnist_confirmation_common as q
import run_qmnist_confirmation as old
import run_qmnist_spatial_extension as ext
from neural_spatial_rate_model import Circuit,windows,phi
from run_spatial_population_feedback import PopulationFeedback
from run_spatial_overlap_pilot import PAR
from spatial_content_feedback import render_scene
OUT=q.C/'spatial_pathway_ablation_20261106'
MODES=['full','no_content','no_category_bias','no_spatial_competition','no_gain','no_mismatch','no_gain_no_content']
def read(p):return json.loads(p.read_text())
def freeze():
 OUT.mkdir(exist_ok=True)
 if (OUT/'protocol.json').exists():
  assert q.sha(OUT/'protocol.json')==(OUT/'protocol.sha256').read_text().strip();return
 p=dict(frozen_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),purpose='Reviewer2/comment4: pathway contributions and focal-spatial accuracy gap. Follow-up on reused images, not independent confirmation or model optimization.',models=[71001,71002,71003],weights=q.protocol()['checkpoint_sha256'],sampling='All20 translation images from secondQMNIST batch, at origin144 only. First original-QMNIST pair in source order per target category0..9 (10pairs). Each pair tested intact with spatial cue, deletion12 with spatial cue, intact with present category cue, intact with absent category cue. Absent category is first cyclic successor of target category not in the two-object array. No outcome screening.',cases_per_model=60,conditions=dict(full='Original retained model.',no_content='Set content feedback off only.',no_category_bias='Remove both direct category influences on spatial selection: k_C=0 in binding and category_spatial_eta=0 in spatial pooling. Category competition, external category cue, and category-weighted content feedback remain active.',no_spatial_competition='Remove only lateral inhibition between spatial units in A update. Binding and category inhibition unchanged. Preserve spatial populations, gain and routing.',no_gain='Set gamma_E=gamma_I=0, so sensory gain is identically1. Preserve spatial competition, pooling and content routing.',no_mismatch='Remove both mismatch influences on binding: replace support m by mean original input and remove k_F*negative-error penalty. Preserve error/support populations and their original updates as diagnostic readouts, but disconnect their outgoing binding influence. Do not remove positive sensory drive.',no_gain_no_content='Combined gain/content disconnection to complete2x2factorial for alignment analysis.'),updates=600,alpha=.1,category_cue=2,spatial_cue=2,feedback_maximum=.65,references='Selected once from original input with original8/category banks, fixed for every trial, identical across matched controls.',total_runs=1260,baseline_parity='All available full-model saved trials checked for exact equality of final field predictions, probabilities, category/spatial traces, normalized changes, and reference slots. Absent-category conditions have no prior counterpart.',unit_checks='Ablation circuit with full mode must match original Circuit in all seven population arrays under identical synthetic states, cues and predictions. One-step selective pathway checks verify unaffected synchronous updates.',metrics=['Global category when not externally clamped, unforced local category otherwise; exact-target field and selected-field readouts kept separate.','Localization within16px, signed offset and undefined/no-output events. In absent-target cases localization is undefined, not erroneous target-present localization.','Completion pixelMSE separately hidden/visible and foreground, both at known target and actual selected field. Clean targets and masks used only for scoring.','Target-absent mismatch from original diagnostic Eplus+Eminus weighted by spatial activity, spatial mass, cue-category agreement, AUROC across matched present/absent arrays. No fitted absence threshold.','Settling final100normalized maxchanges<5e-6, all endpoints retained.'],gap_analysis='For all20 identical single digits and three models: centered/exact-input readout, raw selected-field readout, gain-modulated exact and selected-field feedforward readout, recurrent local readout and global competition output. Compare gain/content2x2. Additionally score every condition at full-model-selected field to avoid conflating changed selection with changed field content. Oracle positions used solely for evaluation. No forced-attention inference condition.',statistics='Paired effects with2000crossed bootstrap resamples of3models and source image/pair clusters, RNG2026110604. Same arrays and allconditions retained within resampled clusters. Report per-model outcomes. Three models and ten pairs limit generalization; no pooled independent-trial confidence claims.',reporting='Save per-trial metrics/traces, source identities, reference slots, renderings and field readouts. Generate report and figures automatically. No manuscript or response edits until results reviewed.',retained_model='No changes to retained model, learned weights, reference banks or original reported endpoints.')
 q.dump(OUT/'protocol.json',p);(OUT/'protocol.sha256').write_text(q.sha(OUT/'protocol.json')+'\n');(q.STUDY/'Manuscript/spatial_pathway_ablation_protocol.md').write_text('# Frozen spatial pathway ablation protocol\n\n```json\n'+json.dumps(p,indent=2)+'\n```\n')
 print('Protocol frozen',p['frozen_utc'],flush=True)

class AblationCircuit(Circuit):
 def __init__(self,x,mode):
  par=PAR
  if mode=='no_category_bias':par=replace(par,k_C=0.,category_spatial_eta=0.)
  if mode in ['no_gain','no_gain_no_content']:par=replace(par,gamma_E=0.,gamma_I=0.)
  super().__init__(x,par,closed=True,padding=31);self.mode=mode
 def update(self,prob,prediction=None,u=None,v=None,residual_means=None):
  # Keep original implementation for all controls representable by parameters.
  if self.mode not in ['no_spatial_competition','no_mismatch']:return super().update(prob,prediction,u,v,residual_means)
  p=self.par;alpha=p.alpha
  # Compute the single altered population from OLD states before the original synchronous update.
  if self.mode=='no_spatial_competition':
   spatial_drive=self.t.sum(2)
   if p.category_spatial_eta:
    weight=(1+p.category_spatial_eta*self.c)/(1+p.category_spatial_eta*self.c.sum(1,keepdims=True));spatial_drive=(self.t*weight[:,None,:]).sum(2)
   old_a=self.a.copy();altered=(1-alpha)*self.a+alpha*phi(p.k_A*spatial_drive+(0 if u is None else u))
  else:
   evidence=prob/np.maximum(prob.max(2,keepdims=True),p.epsilon) if p.binding_relative_evidence else prob
   drive=p.k_M*self.mean_x[:,:,None]*evidence*(1+p.k_C*self.c[:,None,:])-p.theta_T
   old_t=self.t.copy();altered=(1-alpha)*self.t+alpha*phi(drive-p.inhibition*(self.t.sum(2,keepdims=True)-self.t))
  before=[getattr(self,k).copy() for k in ['s','ep','em','m','t','a','c']]
  super().update(prob,prediction,u,v,residual_means)
  if self.mode=='no_spatial_competition':self.a=altered
  else:self.t=altered
  return np.maximum.reduce([abs(getattr(self,k)-a).reshape(len(self.x),-1).max(1) for k,a in zip(['s','ep','em','m','t','a','c'],before)])

def checks():
 rng=np.random.default_rng(2026110604);x=rng.random((1,32,320)).astype(np.float32);prob=rng.random((1,351,10)).astype(np.float32);pred=rng.random((1,351,32,32)).astype(np.float32);u=rng.random((1,351)).astype(np.float32);v=rng.random((1,10)).astype(np.float32)
 base=Circuit(x,PAR,True,31)
 for k in ['s','ep','em','m','t','a','c']:getattr(base,k)[:]=rng.random(getattr(base,k).shape)*.05
 import copy
 expected=copy.deepcopy(base);expected.update(prob,pred,u,v)
 for mode in MODES:
  c=AblationCircuit(x,mode)
  for k in ['s','ep','em','m','t','a','c']:setattr(c,k,getattr(base,k).copy())
  c.update(prob,pred,u,v)
  changed={'no_spatial_competition':{'a'},'no_mismatch':{'t'},'no_category_bias':{'t','a'},'no_gain':{'s'},'no_gain_no_content':{'s'}}.get(mode,set())
  for k in ['s','ep','em','m','t','a','c']:
   if k not in changed:np.testing.assert_array_equal(getattr(c,k),getattr(expected,k))
  if mode in ['no_gain','no_gain_no_content']:np.testing.assert_array_equal(c.gain(),np.ones((1,320),np.float32))
 q.dump(OUT/'unit_checks.json',dict(full_exact_parity=True,unchanged_populations_verified=True,gain_disconnection_verified=True))

def prepare():
 freeze();checks()
 if (OUT/'cases.json').exists():return read(OUT/'cases.json')
 cases=[];inputs=[];cleans=[];masks=[]
 def add(x,clean,mask,**row):cases.append(dict(case=len(cases),**row));inputs.append(x);cleans.append(clean);masks.append(mask)
 jobs=read(ext.OUT/'jobs.json');meta=read(ext.OUT/'stimuli.json')
 with np.load(ext.OUT/'stimuli.npz') as z:
  for j in jobs:
   m=meta[j['case']]
   if m['group']=='translation' and m['positions'][0]==144:
    x=z['input'][j['case']];add(x,x,np.zeros_like(x,bool),task='recognition',cluster='single_'+m['cluster'],category=m['categories'][0],position=144,spatial=None,cue=None,present=True,source='extension',source_job=j['job'],ids=m['ids'])
 jobs=read(q.OUT/'spatial_jobs.json');meta=read(q.OUT/'spatial_stimuli.json')
 with np.load(q.OUT/'spatial_stimuli.npz') as z:
  for cat in range(10):
   m=next(m for m in meta if m['target_category']==cat and m['deletion']==0)
   for task in ['selection','completion','present','absent']:
    mm=next(mm for mm in meta if mm['pair']==m['pair'] and mm['deletion']==(12 if task=='completion' else 0));cue=next((cat+d)%10 for d in range(1,10) if (cat+d)%10!=m['distractor_category']) if task=='absent' else cat if task=='present' else None
    oldjob=next(j for j in jobs if j['case']==mm['case'] and j['feedback'] and j['task']==('category_search' if task in ['present','absent'] else 'completion'))
    add(z['input'][mm['case']],z['clean'][mm['case']],z['mask'][mm['case']],task=task,cluster='pair_'+str(mm['pair']),category=cat,position=mm['target_position'],spatial=mm['target_position'] if cue is None else None,cue=cue,present=task!='absent',source='original',source_job=None if task=='absent' else oldjob['job'],ids=[mm['target_id'],mm['distractor_id']],distractor_category=m['distractor_category'])
 assert len(cases)==60
 q.dump(OUT/'cases.json',cases);np.savez_compressed(OUT/'stimuli.npz',input=inputs,clean=cleans,mask=masks)
 q.dump(OUT/'implementation.json',dict(source_sha256={n:q.sha(Path(__file__).with_name(n)) for n in ['run_spatial_pathway_ablation.py','neural_spatial_rate_model.py','run_spatial_population_feedback.py']},stimulus_sha256=q.sha(OUT/'stimuli.npz')))
 return cases

def worker(item):
 seed,case,mode=item;dest=OUT/'trials'/f"{seed}_{case['case']:03d}_{mode}";dest.mkdir(parents=True,exist_ok=True)
 if (dest/'result.json').exists():return read(dest/'result.json')
 try:
  _,front=old.get_model(seed)
  with np.load(OUT/'stimuli.npz') as z:x=z['input'][case['case']];clean=z['clean'][case['case']];mask=z['mask'][case['case']]
  c=AblationCircuit(x[None],mode);local=PopulationFeedback(front,c,mode not in ['no_content','no_gain_no_content'],True);u=np.zeros_like(c.a);v=np.zeros_like(c.c)
  if case['spatial'] is not None:u[0,case['spatial']+31]=2
  if case['cue'] is not None:v[0,case['cue']]=2
  changes=[];at=[];ct=[];start=time.time()
  for t in range(600):
   prob,y=front.evidence(local.q);new,dq,_=local.propose(c);_,pred=front.infer_pixels(windows(c.s,31)[0]);delta=c.update(prob[None],pred[None],u=u,v=v);local.q=new
   changes.append(max(float(delta[0]),dq)/.1);ct.append(c.c[0].copy());at.append(c.a[0].copy())
   if (t+1)%100==0:q.dump(dest/'progress.json',dict(updates=t+1,total=600,seconds=time.time()-start))
  prob,y=front.evidence(local.q);rawp,_=front.infer_pixels(windows(c.x,31)[0]);gainp,_=front.infer_pixels(windows(c.s,31)[0]);render=render_scene(y,320)
  loc=int(c.a[0].argmax())-31 if c.a.sum()>1e-7 else None;cat=int(c.c[0].argmax()) if c.c.sum()>1e-7 else None;mass=float(c.a.sum());err=c.ep+c.em
  row=dict(seed=seed,**case,mode=mode,location=loc,category_output=cat,global_correct=None if case['cue'] is not None else cat==case['category'],located=None if not case['present'] else loc is not None and abs(loc-case['position'])<=16,offset=None if loc is None else loc-case['position'],local_category=None if loc is None else int(prob[loc+31].argmax()),spatial_mass=mass,mismatch=None if mass<=1e-7 else float((err*c.a).sum()/mass),settled=bool(max(changes[-100:])<5e-6),last100_rate=float(max(changes[-100:])),seconds=time.time()-start)
  for name,pos in [('target',case['position']),('selected',loc)]:
   row[name+'_raw_correct']=None if pos is None else bool(rawp[pos+31].argmax()==case['category']);row[name+'_gain_correct']=None if pos is None else bool(gainp[pos+31].argmax()==case['category']);row[name+'_recurrent_correct']=None if pos is None else bool(prob[pos+31].argmax()==case['category'])
   for region in ['hidden','visible','foreground','all']:row[name+'_'+region+'_mse']=None
   if pos is not None:
    cc=old.crop(clean,pos);mm=old.crop(mask,pos);error=(y[pos+31]-cc)**2
    for region,regionmask in [('hidden',mm),('visible',~mm),('foreground',cc>.05),('all',np.ones_like(mm))]:row[name+'_'+region+'_mse']=old.masked(error,regionmask)
  row['cue_local_agreement']=None if loc is None or case['cue'] is None else int(prob[loc+31].argmax())==case['cue']
  arrays=dict(final_field_predictions=y,final_render=render,final_probability=prob,raw_probability=rawp,gain_probability=gainp,category_trace=ct,spatial_trace=at,changes=changes,reference_slots=local.chosen,final_sensory=c.s[0],final_gain=c.gain()[0])
  if mode=='full' and case['source_job'] is not None:
   source=ext.OUT if case['source']=='extension' else q.OUT;sub='trials' if case['source']=='extension' else 'spatial'
   with np.load(source/sub/f"model{seed}_job{case['source_job']:03d}"/'arrays.npz') as z:errors={key:float(abs(np.asarray(arrays[key])-z[key]).max()) for key in ['final_field_predictions','final_render','final_probability','category_trace','spatial_trace','changes','reference_slots']}
   assert max(errors.values())==0,errors
   row['baseline_exact_match']=True
  assert np.isfinite(y).all() and front.unchanged();np.testing.assert_allclose(local.q.sum(1),1,atol=1e-5)
  np.savez_compressed(dest/'arrays.npz',**arrays);q.dump(dest/'result.json',row);return row
 except Exception:q.dump(dest/'error.json',dict(error=traceback.format_exc()));raise

def main():
 cases=prepare();start=time.time();rows=[];items=[(seed,c,mode) for seed in [71001,71002,71003] for c in cases for mode in MODES]
 # Check one saved full trajectory before releasing the main queue.
 row=worker((71001,cases[0],'full'));assert row['baseline_exact_match']
 with concurrent.futures.ProcessPoolExecutor(max_workers=20) as pool:
  for r in pool.map(worker,items,chunksize=1):
   rows.append(r);q.dump(OUT/'status.json',dict(completed=len(rows),total=1260,seconds=time.time()-start));print('completed',len(rows),flush=True)
 q.dump(OUT/'results.json',rows);q.dump(OUT/'status.json',dict(complete=True,completed=1260,total=1260,seconds=time.time()-start))
if __name__=='__main__':main()
