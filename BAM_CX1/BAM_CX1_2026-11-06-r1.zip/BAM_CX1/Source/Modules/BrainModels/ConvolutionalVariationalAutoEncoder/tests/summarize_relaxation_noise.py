import json,csv
from pathlib import Path
import numpy as np
import evaluate_relaxation_noise as e
out=e.OUT;m=Path(__file__).resolve().parents[5]/'Manuscript'
rows=json.loads((out/'results.json').read_text())['cases'];perseed=[]
def stats(v):
 v=np.asarray(v);mean=v.mean();sd=v.std(ddof=1);h=2.262157*sd/np.sqrt(len(v));return dict(mean=float(mean),sd=float(sd),ci95=[float(mean-h),float(mean+h)])
for seed in range(71001,71011):
 for sigma in e.SIZES:
  for method in ['none','relaxation']:
   rr=[v for v in rows if v['seed']==seed and v['size']==sigma and v['method']==method]
   perseed.append(dict(seed=seed,sigma=sigma,method=method,mse=float(np.mean([v['full_mse'] for v in rr])),category_accuracy=float(np.mean([v['final_winner']==v['truth'] for v in rr])),pixel_accuracy=float(np.mean([v['pixel_prediction']==v['truth'] for v in rr])),image_winner_agreement=float(np.mean([v['pixel_winner_agreement'] for v in rr])),settled=sum(v['settled'] for v in rr),switches=sum(bool(v['switch_iterations']) for v in rr)))
summary=[]
for sigma in e.SIZES:
 r=dict(sigma=sigma,conditions={},paired={})
 for method in ['none','relaxation']:
  rr=[v for v in perseed if v['sigma']==sigma and v['method']==method]
  r['conditions'][method]={k:stats([v[k] for v in rr]) for k in ['mse','category_accuracy','pixel_accuracy','image_winner_agreement']}
 for k in r['conditions']['none']:
  r['paired'][k]=stats([next(v[k] for v in perseed if v['seed']==s and v['sigma']==sigma and v['method']=='relaxation')-next(v[k] for v in perseed if v['seed']==s and v['sigma']==sigma and v['method']=='none') for s in range(71001,71011)])
 summary.append(r)
(out/'summary.json').write_text(json.dumps(dict(summary=summary,per_seed=perseed),indent=2)+'\n')
with (m/'noise_relaxation_statistics.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(perseed[0]));w.writeheader();w.writerows(perseed)
lines=['# Category feedback with Gaussian pixel noise','','Ten frozen models;40 reused digit3/8 images; noise SD0,.1,.25,.5 on normalized pixels, clipped to[0,1]. Noise RNG2026092001. One realization per image/level shared across methods and models. No feedback versus50% current prediction relaxation,500 updates, autonomous competition and fixed input-selected references. No clean target or label supplied during inference. No additional training.','','| Noise SD | Clean-target MSE: none / feedback | Category accuracy | Pixel accuracy | Image/winner agreement |','|---|---|---|---|---|']
for s in summary:
 a=s['conditions']['none'];b=s['conditions']['relaxation']
 def pair(k,pct=True):return f"{a[k]['mean']:.2%} / {b[k]['mean']:.2%}" if pct else f"{a[k]['mean']:.6f} / {b[k]['mean']:.6f}"
 lines.append(f"|{s['sigma']}|{pair('mse',False)}|{pair('category_accuracy')}|{pair('pixel_accuracy')}|{pair('image_winner_agreement')}|")
lines+=['','## Paired statistics','', 'Feedback-minus-control descriptive95% t intervals across ten model seeds (df9); these measure model variation on shared noisy inputs, not uncertainty across new images or noise realizations.']
for s in summary:lines.append('\nNoise SD '+str(s['sigma'])+'\n'+json.dumps(s['paired'],indent=2))
lines+=['','## Dynamics and checks','',f"Settled at500: {sum(v['settled'] for v in rows)}/{len(rows)}; at200: {sum(v['settled_at200'] for v in rows)}/{len(rows)}.",'Frozen weight hashes unchanged; clean endpoint network and pixel labels match the preceding mixture experiment. Probabilities normalized and finite.','','Only two categories,40 reused test images and one noisy realization per image/level were tested. Clipping changes the realized noise distribution, especially on background pixels. Category consistency does not establish ground-truth recovery. Legacy per-case size denotes noise SD; hidden metrics are undefined and visible_mse equals full_mse. Figures use first pair fixed by input order.']
(out/'REPORT.md').write_text('\n'.join(lines)+'\n');(m/'noise_relaxation_source_notes.md').write_text('\n'.join(lines)+'\n')
with np.load(out/'seed71001/arrays.npz') as z:
 panels=[];labels=[]
 for k in [40,41,80,81,120,121]:
  panels.append([z['clean'][k],z['input'][k],z['snapshots'][0,-1,k],z['snapshots'][1,-1,k]]);labels.append(f'SD{e.SIZES[k//40]}: digit '+('3' if k%40==0 else '8'))
 e.f.gallery(m/'noise_relaxation_examples.png','Noisy sensory input: first pair, fixed examples',panels,labels,['clean target','observed','no feedback','feedback 50%'])
print('\n'.join(lines),flush=True)
