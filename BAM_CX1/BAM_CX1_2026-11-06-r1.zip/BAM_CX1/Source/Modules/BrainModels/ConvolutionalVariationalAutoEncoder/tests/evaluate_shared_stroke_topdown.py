"""Transient additive category bias on six preselected shared-stroke inputs."""
import os
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['VECLIB_MAXIMUM_THREADS']='2'
import json,hashlib,concurrent.futures
from pathlib import Path
from argparse import Namespace
import numpy as np
import evaluate_relaxation_full_mixtures as base
n=base.n;e=base.e;local=base.local;f=base.f
OUT=n.CAMPAIGN/'shared_stroke_topdown_ten_seeds';SOURCE=n.CAMPAIGN/'shared_stroke_candidates'
CONDITIONS=[(td,mode) for td in [.5,.75,1.] for mode in ['none','bias_a','bias_b']]
STEPS=[0,8,32,50,58,82,178,250,550]
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def run(seed):
 target=OUT/f'seed{seed}';target.mkdir(exist_ok=True)
 train,test,labels,tl=e.prepare_data(Namespace(train_count=60000,test_count=10000))
 selected=json.loads((SOURCE/'results.json').read_text())['selected'][:6]
 with np.load(SOURCE/'arrays.npz') as zz:inputs=zz['selected_shared'][:6].copy();expected=zz['selected_probabilities'][seed-71001,:6].copy()
 x=np.tile(inputs,(9,1,1));N=len(x)
 folder=n.CAMPAIGN/f'hierarchy_s{seed}';rd=n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit'/f'grouped_softmax_s{seed}.npz';pd=n.CAMPAIGN/'local_linear_patch_decoder_seed1' if seed==71001 else n.CAMPAIGN/'local_linear_patch_decoder_ten_seeds'/f'seed{seed}'
 paths=[folder/'model.state',folder/'codebook_final.npz',rd,pd/'local_decoder.npz'];hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
 state=json.loads(paths[0].read_text())['items']
 def weight(k):
  v=state['CVAE_TwoLayer.Upper.'+k];return np.array(v['value'],np.float32).reshape(v['shape'])
 enc=weight('DIRECT_MEAN_WEIGHTS');eb=weight('DIRECT_MEAN_BIAS');dec=weight('DIRECT_DECODER_WEIGHTS');db=weight('DIRECT_DECODER_BIAS');del state
 with np.load(rd) as z:rw=z['weights'];rb=z['bias']
 with np.load(paths[1]) as z:book=f.prior.Codebook(z['prototypes'])
 with np.load(paths[3]) as z:decoder=z['decoder'].astype(np.float32)
 codes,_,_=e.read_codes(folder/'train_codes.csv',train,labels,128)
 refs=json.loads((n.CAMPAIGN/'category_feedback_diagnostic/reference_indices.json').read_text())['71001'] if seed==71001 else json.loads((pd/'feedback_inference/reference_indices.json').read_text())
 ids=np.array([refs[str(c)] for c in range(10)]);rc=codes[ids].astype(np.float32)
 def encode(p):return p.reshape(len(p),-1)@enc+eb
 def decode(z):
  v=(z@dec+db).reshape(-1,64,676);v-=v.max(1,keepdims=True);return v-np.log(np.exp(v).sum(1,keepdims=True))
 def probs(z):return n.softmax(z@rw+rb).reshape(-1,10,20).sum(2)
 def render(z):return np.clip(local.overlap(np.exp(decode(z)).transpose(0,2,1)@decoder),0,1)
 rp=np.exp(decode(rc.reshape(80,128))).reshape(10,8,64,676)
 b=np.stack([book.process(v,False,.01,.08)[0].reshape(64,676) for v in x]);z0=encode(b);pr0=probs(z0);a0=pr0/pr0.max(1,keepdims=True);chosen=((z0[:,None,None]-rc[None])**2).sum(3).argmin(2);im0=render(z0)
 np.testing.assert_allclose(pr0[:6],expected,atol=3e-5)
 p=b.copy();a=a0.copy();pr=pr0.copy();acts=[a.copy()];prs=[pr.copy()];ims=[im0.copy()];changes=[]
 bias=np.zeros((N,10),np.float32)
 for k,(topdown,mode) in enumerate(CONDITIONS):
  if mode!='none':
   for j,r in enumerate(selected):bias[k*6+j,r['a'] if mode=='bias_a' else r['b']]=2.
 fraction=np.repeat([c[0] for c in CONDITIONS],6).astype(np.float32)[:,None,None]
 for step in range(1,551):
  drive=pr/pr.max(1,keepdims=True)-1.5*(a.sum(1,keepdims=True)-a)
  if step<=50:drive=drive+bias
  an=.8*a+.2*np.maximum(drive,0)
  ww=an/an.sum(1,keepdims=True);Q=np.zeros_like(p)
  for c in range(10):Q+=ww[:,c,None,None]*rp[c,chosen[:,c]]
  pn=.8*p+.2*((1-fraction)*b+fraction*Q)
  changes.append(np.stack([abs(pn-p).max((1,2)),abs(an-a).max(1)],1));p=pn;a=an;z=encode(p);pr=probs(z);acts.append(a.copy());prs.append(pr.copy())
  if step in STEPS:ims.append(render(z))
 acts=np.array(acts);prs=np.array(prs);ims=np.array(ims);ch=np.array(changes);wins=acts.argmax(2)
 assert np.isfinite(p).all();np.testing.assert_allclose(p.sum(1),1,atol=5e-6)
 # Same initial evidence and reference choices across interventions.
 for k in range(1,9):np.testing.assert_array_equal(chosen[:6],chosen[k*6:(k+1)*6]);np.testing.assert_array_equal(pr0[:6],pr0[k*6:(k+1)*6])
 tp=np.stack([e.full.center_and_pad(v) for v in train]).astype(np.float32)/255
 pix=e.five_nearest_predictions(tp.reshape(60000,-1),labels,ims[[STEPS.index(50),-1]].reshape(-1,1024)).reshape(2,N)
 rows=[]
 for k,(topdown,mode) in enumerate(CONDITIONS):
  for j,r in enumerate(selected):
   i=k*6+j;cue=None if mode=='none' else r['a'] if mode=='bias_a' else r['b'];sw=(np.flatnonzero(np.diff(wins[:,i])!=0)+1).tolist()
   rows.append(dict(topdown=topdown,strength=0. if mode=='none' else 2.,seed=seed,candidate=r['candidate'],a=r['a'],b=r['b'],mode=mode,cue=cue,initial_winner=int(wins[0,i]),winner_at_release=int(wins[50,i]),final_winner=int(wins[-1,i]),pixel_at_release=int(pix[0,i]),final_pixel=int(pix[1,i]),image_winner_agreement=bool(pix[1,i]==wins[-1,i]),settled=bool(ch[-10:,i].max()<1e-5),switch_iterations=sw,late_switches=sum(t>450 for t in sw),input_mse=float(((ims[-1,i]-x[i])**2).mean()),mse_from_unbiased=float(((ims[-1,i]-ims[-1,(k//3)*18+j])**2).mean()),shared_stroke_mse=float(((ims[-1,i]-x[i])[x[i]>.25]**2).mean()),shared_stroke_mae=float(abs(ims[-1,i]-x[i])[x[i]>.25].mean()),shared_stroke_intensity=float(ims[-1,i][x[i]>.25].mean())))
 with np.load(n.CAMPAIGN/f'shared_stroke_bias_strength_ten_seeds/seed{seed}/arrays.npz') as old:
  np.testing.assert_array_equal(wins[:,:18],old['activities'][:,np.r_[0:6,30:42]].argmax(2))
  np.testing.assert_allclose(ims[:,:18],old['snapshots'][:,np.r_[0:6,30:42]],atol=3e-5)
 assert [hashlib.sha256(q.read_bytes()).hexdigest() for q in paths]==hashes
 np.savez_compressed(target/'arrays.npz',input=x,snapshots=ims,activities=acts,probabilities=prs,changes=ch,steps=STEPS,chosen_reference_slots=chosen,reference_ids=ids)
 dump(target/'results.json',dict(cases=rows,weights_unchanged=True,checkpoint_sha256=hashes,initial_readout_verified=True));print(seed,'complete',flush=True);return seed

def main():
 OUT.mkdir(exist_ok=True)
 dump(OUT/'protocol.json',dict(seeds=list(range(71001,71011)),candidates=list(range(1,7)),conditions=CONDITIONS,trials=540,bias_amplitude=2.,bias_updates=50,unbiased_followup=500,topdown_fractions=[.5,.75,1.],mechanism='Add2 to cued normalized category drive before rectification during1–50, remove at51; keep sensory/topdown fraction fixed throughout550. Inhibition1.5 and both damping rates.2 unchanged.',controls='Matched no-bias control at each fraction. Same input, initial state and input-selected fixed references in all9 conditions. At100% there is no ongoing sensory anchor, but initialization and references remain input dependent.',scoring='Category persistence, pixel5NN on reconstructed images, bidirectional category/image outcomes, MSE and MAE on shared-input pixels>.25. Threshold mask used only for scoring; full-input MSE secondary because adding missing strokes necessarily alters input.',scope='Six previously selected inputs, ten frozen models; no learning or change to defaults. Stronger topdown depiction is not necessarily more faithful completion. Shared-stroke preservation assesses source-image coordinates, not perceptual identity.'))
 with concurrent.futures.ProcessPoolExecutor(max_workers=2) as pool:list(pool.map(run,range(71001,71011)))
 cases=[v for s in range(71001,71011) for v in json.loads((OUT/f'seed{s}/results.json').read_text())['cases']];dump(OUT/'results.json',dict(cases=cases));print('ALL COMPLETE',flush=True)
if __name__=='__main__':main()
