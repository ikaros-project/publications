"""Reviewer 1: frozen-model reference-bank size/selection sensitivity, focal tests."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
os.environ.setdefault('VECLIB_MAXIMUM_THREADS','2')
import argparse,hashlib,json,time
from pathlib import Path
import numpy as np
import evaluate_relaxation_full_mixtures as original
E=original.e;C=original.n.CAMPAIGN
OUT=C/'reference_bank_sensitivity_20261026'
SIZES=[1,2,4,8,16,32];BANK_SEEDS=[2026102601+i for i in range(5)]
def dump(p,v):
 p.write_text(json.dumps(v,indent=2)+'\n')
def progress(stage,**kw):
 dump(OUT/'status.json',dict(stage=stage,**kw));print(stage,kw,flush=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def softmax(v,axis=-1):
 v=v-v.max(axis,keepdims=True);q=np.exp(v);return q/q.sum(axis,keepdims=True)
def load():
 paths=[C/'hierarchy_s71001/model.state',C/'hierarchy_s71001/codebook_final.npz',C/'neural_readout_regularized_capacity/full_refit/grouped_softmax_s71001.npz',C/'local_linear_patch_decoder_seed1/local_decoder.npz']
 hashes={str(p.relative_to(C)):sha(p) for p in paths}
 state=json.loads(paths[0].read_text())['items']
 def w(k):
  a=state['CVAE_TwoLayer.Upper.'+k];return np.array(a['value'],np.float32).reshape(a['shape'])
 model={k:w(v) for k,v in [('enc','DIRECT_MEAN_WEIGHTS'),('eb','DIRECT_MEAN_BIAS'),('dec','DIRECT_DECODER_WEIGHTS'),('db','DIRECT_DECODER_BIAS')]};del state
 with np.load(paths[1]) as a:model['book']=original.f.prior.Codebook(a['prototypes'])
 with np.load(paths[2]) as a:model['rw']=a['weights'].copy();model['rb']=a['bias'].copy()
 with np.load(paths[3]) as a:model['decoder']=a['decoder'].astype(np.float32)
 raw=E.full.RAW_ROOT;train=E.full.read_idx_images(raw/'train-images-idx3-ubyte.gz',60000);labels=E.full.read_idx_labels(raw/'train-labels-idx1-ubyte.gz',60000)
 codes,_,_=E.read_codes(C/'hierarchy_s71001/train_codes.csv',train,labels,128)
 model['codes']=codes;model['labels']=labels
 model['trainpixels']=np.stack([E.full.center_and_pad(v) for v in train]).astype(np.float32).reshape(60000,1024)/255
 with np.load(original.OUT/'seed71001.npz') as a:
  mix=a['input'].copy();mi=list(original.METHODS).index('relaxation');known_mix=a['snapshots'][mi,-1].copy();known_act=a['activities'][mi].copy()
 mixrows=[v for v in json.loads((original.OUT/'seed71001_results.json').read_text())['cases'] if v['method']=='relaxation']
 ocdir=C/'relaxation_occlusion_ten_seeds/seed71001'
 with np.load(ocdir/'arrays.npz') as a:
  oc=a['input'].copy();clean=a['clean'].copy();mask=a['mask'].copy();known_oc=a['snapshots'][1,-1].copy();known_oa=a['activities'][1].copy()
 ocrows=[v for v in json.loads((ocdir/'results.json').read_text())['cases'] if v['method']=='relaxation']
 model.update(x=np.concatenate([mix,oc]),occlean=clean,mask=mask,mixrows=mixrows,ocrows=ocrows,known_images=np.concatenate([known_mix,known_oc]),known_acts=np.concatenate([known_act,known_oa],axis=1),paths=paths,hashes=hashes)
 b=np.stack([model['book'].process(v,False,.01,.08)[0].reshape(64,676) for v in model['x']]);model['b']=b
 model['z0']=b.reshape(len(b),-1)@model['enc']+model['eb']
 return model

def banks(m):
 saved=json.loads((C/'category_feedback_diagnostic/reference_indices.json').read_text())['71001']
 result=[]
 for bank in range(6):
  rng=np.random.default_rng(BANK_SEEDS[bank-1]) if bank else None;ids_all=[]
  for c in range(10):
   ids=np.flatnonzero(m['labels']==c);v=m['codes'][ids];mu=v.mean(0);dist=((v-mu)**2).sum(1);ids=ids[dist<=np.quantile(dist,.9)]
   first=int(ids[np.argmin(((m['codes'][ids]-mu)**2).sum(1))]) if bank==0 else int(rng.choice(ids))
   selected=[first];minimum=np.full(len(ids),np.inf)
   for _ in range(31):
    minimum=np.minimum(minimum,((m['codes'][ids]-m['codes'][selected[-1]])**2).sum(1));selected.append(int(ids[np.argmax(minimum)]))
   assert len(set(selected))==32
   if bank==0:assert selected[:8]==saved[str(c)],'Original selection parity failed'
   ids_all.append(selected)
  result.append(np.array(ids_all))
 return result

def decode(m,z):return softmax((z.astype(np.float32)@m['dec']+m['db']).reshape(-1,64,676),1)
def render(m,z):return np.clip(original.local.overlap(decode(m,z).transpose(0,2,1)@m['decoder']),0,1)
def probs(m,z):return softmax(z.astype(np.float32)@m['rw']+m['rb']).reshape(-1,10,20).sum(2)

def simulate(m,ids,feedback=True):
 """Exact affine-state reduction in real arithmetic; checked against stored full-state runs.
 p_t = s_t*b + sum_c h_tc*q_ref,c, s_t+sum_c h_tc=1.
 Thus z_t=s_t*z0+sum_c h_tc*encode(q_ref,c). No changing reference addresses.
 """
 rc=m['codes'][ids].astype(np.float32);rp=decode(m,rc.reshape(-1,128)).reshape(10,ids.shape[1],64,676)
 rz=rp.reshape(-1,64*676)@m['enc']+m['eb'];rz=rz.reshape(10,ids.shape[1],128)
 chosen=((m['z0'][:,None,None]-rc[None])**2).sum(3).argmin(2)
 chosen_z=np.stack([rz[c,chosen[:,c]] for c in range(10)],axis=1)
 pr=probs(m,m['z0']);a=pr/pr.max(1,keepdims=True);N=len(a)
 h=np.zeros((N,10),np.float64);s=1.;act=[a.copy()];coeff=[h.copy()];ss=[s];lastchanges=[]
 for step in range(1,501):
  an=.8*a+.2*np.maximum(pr/pr.max(1,keepdims=True)-1.5*(a.sum(1,keepdims=True)-a),0)
  hn=.8*h+.1*(an/an.sum(1,keepdims=True)) if feedback else h
  sn=.8*s+.1 if feedback else s
  if step>490:
   dc=hn-h;dp=np.empty(N)
   # Compute actual local-code change, not merely a latent-space proxy.
   for j in range(N):
    change=(sn-s)*m['b'][j].astype(np.float64)
    for c in range(10):change+=dc[j,c]*rp[c,chosen[j,c]]
    dp[j]=np.abs(change).max()
   lastchanges.append(np.maximum(dp,np.abs(an-a).max(1)))
  a=an;h=hn;s=sn
  z=s*m['z0']+np.einsum('nc,ncd->nd',h,chosen_z)
  if feedback:pr=probs(m,z)
  act.append(a.copy());coeff.append(h.copy());ss.append(s)
 im=render(m,z);act=np.array(act);ch=np.array(lastchanges)
 assert np.isfinite(im).all() and np.isfinite(act).all()
 assert np.max(np.abs(s+h.sum(1)-1))<2e-6
 return dict(images=im,acts=act,changes=ch,chosen=chosen,ids=ids,coeff=np.array(coeff),base_coeff=np.array(ss))

def score(m,res,bank,size):
 pred=E.five_nearest_predictions(m['trainpixels'],m['labels'],res['images'].reshape(-1,1024))
 wins=res['acts'].argmax(2);rows=[]
 for j in range(len(pred)):
  row=dict(bank=bank,size=size,case_index=j,initial_winner=int(wins[0,j]),final_winner=int(wins[-1,j]),pixel_prediction=int(pred[j]),image_winner_agreement=bool(pred[j]==wins[-1,j]),changed_winner=bool(wins[0,j]!=wins[-1,j]),switch_count=int(np.sum(np.diff(wins[:,j])!=0)),settled=bool(res['changes'][:,j].max()<1e-5),input_mse=float(((res['images'][j]-m['x'][j])**2).mean()))
  if j<220:
   old=m['mixrows'][j];truth=old['dominant_truth'];row.update(task='mixture',pair_id=old['pair_id'],mix=old['mix'],truth=truth,category_correct=bool(wins[-1,j]==truth) if truth is not None else None,pixel_correct=bool(pred[j]==truth) if truth is not None else None)
  else:
   k=j-220;old=m['ocrows'][k];mask=m['mask'][k];err=(res['images'][j]-m['occlean'][k])**2
   row.update(task='occlusion',test_index=old['test_index'],occlusion_size=old['size'],truth=old['truth'],category_correct=bool(wins[-1,j]==old['truth']),pixel_correct=bool(pred[j]==old['truth']),hidden_mse=float(err[mask].mean()) if mask.any() else None,visible_mse=float(err[~mask].mean()),clean_mse=float(err.mean()))
  rows.append(row)
 return rows

def summary(rows):
 out=[]
 for task,level in [('mixture','all'),('mixture','equal')]+[('occlusion',x) for x in [0,8,12,16]]:
  rr=[r for r in rows if r['task']==task and (task=='mixture' and (level=='all' or r['mix']==.5) or task=='occlusion' and r['occlusion_size']==level)]
  keys=['image_winner_agreement','category_correct','pixel_correct','changed_winner','settled','input_mse','hidden_mse','visible_mse','clean_mse']
  v=dict(task=task,level=level,n=len(rr))
  for k in keys:
   values=[r[k] for r in rr if r.get(k) is not None]
   v[k]=float(np.mean(values)) if values else None
  out.append(v)
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--prepare-only',action='store_true');args=ap.parse_args()
 OUT.mkdir(exist_ok=True);progress('loading')
 m=load();bb=banks(m)
 protocol=dict(model_seed=71001,sizes=SIZES,bank_rng_seeds=BANK_SEEDS,banks=6,construction='Bank 0: original nearest-category-mean first reference. Banks 1-5: uniform random first reference among central 90% by squared latent distance from class mean. All banks then use original deterministic farthest-point selection. Nested prefixes define sizes. No outcome screening.',inputs='All 220 original 3/8 mixtures and all 160 occlusion inputs (40 fixed source digits at central deletion sizes 0,8,12,16). Same inputs in every condition.',steps=500,alpha=.2,inhibition=1.5,feedback_fraction=.5,reference_addressing='Nearest latent reference in each category from original input, fixed throughout inference.',learning=False,scope='Focal sensitivity experiment, one trained model. Reused stimuli, not independent confirmation. Spatial extension is a subsequent stage.',evaluation='Independent pixel Euclidean 5NN on full 60000 training images, original stable tie-breaking. Image/winner agreement, category correctness, input/clean/hidden/visible MSE, switches and final-ten-update settling at 1e-5. No early stopping.',statistics='Five random-start banks paired across sizes. Original deterministic bank reported separately. Bank variation is not trained-model variation. Report descriptive mean/SD/range and within-bank differences relative to size 8.',implementation='Affine coefficient reduction of the original fixed-reference local-state update. No scientific parameters changed. Requires saved 8-reference baseline trajectory/image parity before additional conditions run.',checkpoint_sha256=m['hashes'],script_sha256=sha(Path(__file__)))
 pp=OUT/'protocol.json'
 if pp.exists():assert json.loads(pp.read_text())==protocol,'Protocol changed during resumption'
 else:dump(pp,protocol)
 dump(OUT/'reference_banks.json',{str(i):b.tolist() for i,b in enumerate(bb)})
 np.savez_compressed(OUT/'stimuli.npz',input=m['x'],occlusion_clean=m['occlean'],occlusion_mask=m['mask'])
 progress('validating original eight-reference condition')
 r=simulate(m,bb[0][:,:8]);ae=float(np.abs(r['acts']-m['known_acts']).max());ie=float(np.abs(r['images']-m['known_images']).max());same=np.array_equal(r['acts'].argmax(2),m['known_acts'].argmax(2))
 parity=dict(max_activity_error=ae,max_pixel_error=ie,all_trajectory_winners_match=bool(same),tolerance=3e-5)
 dump(OUT/'parity.json',parity)
 assert ae<3e-5 and ie<3e-5 and same,parity
 progress('baseline parity passed',**parity)
 if args.prepare_only:return
 for bank in range(6):
  for size in SIZES:
   target=OUT/f'bank{bank}_size{size}.json'
   if target.exists():continue
   start=time.monotonic();progress('running',bank=bank,size=size)
   res=r if bank==0 and size==8 else simulate(m,bb[bank][:,:size])
   rows=score(m,res,bank,size)
   if bank==0 and size==8:
    olds=m['mixrows']+m['ocrows'];assert all(a['pixel_prediction']==b['pixel_prediction'] for a,b in zip(rows,olds))
   np.savez_compressed(OUT/f'bank{bank}_size{size}.npz',images=res['images'],activities=res['acts'],last10changes=res['changes'],chosen_reference_slots=res['chosen'],reference_ids=res['ids'])
   dump(target,dict(bank=bank,size=size,summary=summary(rows),cases=rows,seconds=time.monotonic()-start))
   progress('condition complete',bank=bank,size=size,seconds=round(time.monotonic()-start,1))
 assert {str(p.relative_to(C)):sha(p) for p in m['paths']}==m['hashes']
 dump(OUT/'results.json',dict(protocol=protocol,parity=parity,conditions=[json.loads((OUT/f'bank{b}_size{k}.json').read_text()) for b in range(6) for k in SIZES],weights_unchanged=True))
 progress('complete',conditions=36,feedback_cases=36*380)
if __name__=='__main__':main()
