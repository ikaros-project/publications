"""Reduced new-image pilot of spatially aligned category feedback."""
import concurrent.futures,json,time,hashlib,shutil,argparse
from pathlib import Path
import numpy as np
import run_spatial_overlap_pilot as r
from run_spatial_overlap_aligned_feedback import AlignedFeedback,ROOT as PILOT
from neural_spatial_rate_model import Circuit
ROOT=PILOT.parent/'aligned_validation_pilot'
MODES=['independent','roundtrip','aligned']
class TargetCuedCircuit(Circuit):
    cue_position=144
    def update(self,prob,prediction=None,u=None,v=None,residual_means=None):
        u=u.copy();u[0,self.cue_position+31]=2
        return super().update(prob,prediction,u,v,residual_means)
def init():
    r.init();r.Circuit=TargetCuedCircuit;r.CachedLocalFeedback=AlignedFeedback

def prepare():
    ROOT.mkdir(exist_ok=True)
    if (ROOT/'protocol.json').exists():return
    init()
    raw=r.r.e.full.read_idx_images(r.r.e.full.RAW_ROOT/'t10k-images-idx3-ubyte.gz',10000)
    lab=r.r.e.full.read_idx_labels(r.r.e.full.RAW_ROOT/'t10k-labels-idx1-ubyte.gz',10000)
    category_pairs=[(0,6),(1,7),(2,5),(3,8),(4,9)]
    chosen={c:(np.flatnonzero(lab[9100:10000]==c)+9100)[:1].tolist() for c in range(10)}
    rows=[];comps=[];scenes=[];jobs=[]
    for group,(ca,cb) in enumerate(category_pairs):
        for repeat in range(1):
            pair=group+repeat;ids=[chosen[ca][repeat],chosen[cb][repeat]]
            images=[r.r.e.full.center_and_pad(raw[i]).astype(np.float32)/255 for i in ids]
            # Descriptive isolated recognition only; never screen or replace images.
            prob,_=r.FRONT.infer_pixels(np.stack(images));recognized=prob.argmax(1).tolist()
            for sep in [0,8,40]:
                positions=[144-sep//2,144+sep//2];comp=np.zeros((2,32,320),np.float32)
                for k,pos in enumerate(positions):comp[k,:,pos:pos+32]=images[k]
                row=dict(case=len(rows),pair=pair,category_pair_group=group,categories=[ca,cb],test_indices=ids,positions=positions,separation=sep,kind='pair',isolated_feedforward_categories=recognized)
                rows.append(row);comps.append(comp);scenes.append(np.maximum(*comp))
                for mode in MODES:
                    for cue in ['A','B']:jobs.append([mode,row['case'],'combined_category_'+cue])
            for k in range(2):
                comp=np.zeros((2,32,320),np.float32);comp[0,:,144:176]=images[k]
                row=dict(case=len(rows),pair=pair,category_pair_group=group,categories=[[ca,cb][k],-1],test_indices=[ids[k],-1],positions=[144,144],separation=None,kind='isolated',isolated_feedforward_categories=[recognized[k]])
                rows.append(row);comps.append(comp);scenes.append(comp[0])
                for mode in MODES:jobs.append([mode,row['case'],'combined_category_A'])
    assert len(jobs)==120 and len({i for row in rows for i in row['test_indices'] if i>=0})==10
    for mode in MODES:
        dest=ROOT/mode;dest.mkdir(exist_ok=True);np.savez_compressed(dest/'stimuli.npz',input=scenes,components=comps);r.r.dump(dest/'stimuli.json',rows)
    dest=ROOT/'parity';dest.mkdir(exist_ok=True)
    for n in ['stimuli.json','stimuli.npz']:shutil.copyfile(PILOT/'aligned'/n,dest/n)
    jobs.insert(0,['parity',0,'combined_category_A'])
    r.r.dump(ROOT/'jobs.json',jobs)
    source_names=['run_spatial_overlap_aligned_validation.py','run_spatial_overlap_aligned_feedback.py','run_spatial_overlap_pilot.py','run_spatial_overlap_feedback_strength.py','spatial_content_feedback.py','cached_spatial_content_feedback.py','neural_spatial_rate_model.py']
    r.r.dump(ROOT/'protocol.json',dict(seed=71001,experimental_trials=120,verification_trials=1,image_pairs=5,distinct_images=10,category_pairs=category_pairs,chosen_indices=chosen,selection='First MNIST test example per category from indices9100:10000, in dataset order. No recognition screening, replacement or parameter selection. None are the prior six pilot images.',conditions=MODES,feedback=.65,steps=600,early_stop=False,geometry='32x320, all351 stride-one fields, max pixel union, separations0/8/40; both target directions. Ten isolated controls at144. Tile origins symmetric about144. Partial overlap refers to8-pixel tile offset; actual feature masks measured.',cues='Category cue2 plus spatial cue2 at the requested object tile origin, same across modes. Full overlap has identical cue location for both categories. At8/40 pixels category cue reversal also changes the spatial cue, so contrasts there are combined spatial/category selection, not isolated object attention.',mechanism='Use unchanged AlignedFeedback from the pilot. Independent mode bypasses alignment and pixel-code roundtrip. Roundtrip mode reconstructs/re-encodes independent category references. Aligned mode projects the selected-field category reconstruction onto an otherwise empty canvas and encodes its overlapping fields. No clean image/mask/label/ground-truth position is used by feedback; known position enters only as explicit external spatial cue.',fixed='Weights, seed, reference bank and per-field original-input nearest reference choices, sensory mismatch routing, relative binding, alpha0.1, sigma24, feedback0.65, uniform rendering and600updates. No extra inhibition, learning or backpropagation.',primary='Paired aligned-minus-independent and aligned-minus-roundtrip contrasts, separately by separation: whole-canvas requested-original foreground MSE over union mask, requested unique-pixel intensity, losing unique-pixel intensity; whole-canvas cue-reversal contrast and cross-field variance. Isolated reconstruction error and feature intensity test loss of target information; separated controls quantify changes to both target and unattended-object features. Report all cases, local unforced category, settling, numerical changes and actual gain equality. Never score imposed category population as recognition.',uncertainty='Reduced pilot requested by user: five pairs, one per category-pair group. Report all paired outcomes and descriptive averages; no population confidence intervals from this small heterogeneous sample. No seed/population claims. No extra oscillation exploration.',scope='Confirmation diagnostic; no automatic adoption, parameter tuning or manuscript-body change. Hard winner routing and empty-canvas assumptions remain limitations.',source_sha256={n:hashlib.sha256(Path(__file__).with_name(n).read_bytes()).hexdigest() for n in source_names},checkpoint_hashes=r.FRONT.hashes))
    print('PREPARED 120 trials + 1 parity',flush=True)

def worker(job):
    mode,j,name=job;r.ROOT=ROOT/mode
    folder=r.ROOT/f'case{j:02d}_{name}'
    if (folder/'result.json').exists() and (folder/'routing.json').exists():return dict(validation_mode=mode,**json.loads((folder/'result.json').read_text()))
    meta=json.loads((r.ROOT/'stimuli.json').read_text())[j];k=0 if name.endswith('_A') else 1
    TargetCuedCircuit.cue_position=meta['positions'][k]
    AlignedFeedback.mode='parity' if mode=='independent' else 'aligned' if mode=='parity' else mode
    row=r.worker((j,name));local=AlignedFeedback.last
    if mode=='parity':
        with np.load(folder/'arrays.npz') as a,np.load(PILOT/'aligned'/folder.name/'arrays.npz') as b:
            assert set(a.files)==set(b.files)
            for key in a.files:np.testing.assert_array_equal(a[key],b[key],err_msg=key)
        r.r.dump(ROOT/'parity.json',dict(all_saved_arrays_bit_identical=True))
    r.r.dump(folder/'routing.json',dict(anchor_trace=local.anchors,external_spatial_cue=TargetCuedCircuit.cue_position,mode=mode))
    return dict(validation_mode=mode,**row)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--workers',type=int,default=12);args=ap.parse_args();prepare()
    if args.prepare:return
    rows=[];start=time.time()
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,initializer=init) as pool:
        fs=[pool.submit(worker,j) for j in json.loads((ROOT/'jobs.json').read_text())]
        for f in concurrent.futures.as_completed(fs):
            rows.append(f.result());r.r.dump(ROOT/'status.json',dict(completed=len(rows),total=121,seconds=time.time()-start))
    r.r.dump(ROOT/'results.json',dict(new_runs=rows,parity=json.loads((ROOT/'parity.json').read_text())))
    print('ALIGNED VALIDATION COMPLETE',flush=True)
if __name__=='__main__':main()
