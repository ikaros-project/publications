"""Vector manuscript figures from saved alpha=0.1 spatial regressions; no inference."""
import json
from pathlib import Path
import numpy as np
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from reportlab.lib.colors import HexColor
from evaluate_neural_spatial_architecture import OUT

ROOT=Path(__file__).resolve().parents[5]/'Manuscript'
BASE=OUT/'focused_step_boundary_checks'
BLUE='#2669a8';ORANGE='#cc6426';GREEN='#238568';GRAY='#9b9b9b';INK='#20252a'

class Figure:
    def __init__(self,name,h):
        self.h=h;self.c=canvas.Canvas(str(ROOT/(name+'.pdf')),pagesize=(540,h))
        self.c.setTitle(name.replace('_',' '));self.c.setAuthor('')
    def text(self,x,y,s,size=10,color=INK,bold=False,align='left'):
        c=self.c;c.setFillColor(HexColor(color));c.setFont('Helvetica-Bold' if bold else 'Helvetica',size)
        {'left':c.drawString,'center':c.drawCentredString,'right':c.drawRightString}[align](x,self.h-y-size*.8,str(s))
    def line(self,x1,y1,x2,y2,color=INK,width=.7,dash=None):
        c=self.c;c.setStrokeColor(HexColor(color));c.setLineWidth(width);c.setDash(dash or [])
        c.line(x1,self.h-y1,x2,self.h-y2);c.setDash([])
    def rect(self,x,y,w,h,color,fill=True,width=.7):
        c=self.c;c.setFillColor(HexColor(color));c.setStrokeColor(HexColor(color));c.setLineWidth(width)
        c.rect(x,self.h-y-h,w,h,fill=int(fill),stroke=int(not fill))
    def dot(self,x,y,color,r=2):
        self.c.setFillColor(HexColor(color));self.c.circle(x,self.h-y,r,stroke=0,fill=1)
    def strip(self,a,x,y,w,location=None):
        h=w/10
        self.c.drawImage(ImageReader(Image.fromarray(np.uint8(np.clip(a,0,1)*255))),x,self.h-y-h,width=w,height=h)
        if location is not None:
            lo=max(0,location);hi=min(320,location+32)
            self.rect(x+lo*w/320,y,(hi-lo)*w/320,h,'#efbd44',False,1.1)
    def axes(self,box,xlim,ylim,xticks,yticks,xlabel,ylabel):
        x,y,w,h=box
        def xy(a,b):return x+(a-xlim[0])/(xlim[1]-xlim[0])*w,y+h-(b-ylim[0])/(ylim[1]-ylim[0])*h
        for v in yticks:
            _,yy=xy(0,v);self.line(x,yy,x+w,yy,'#dddddd',.5);self.text(x-7,yy-4,f'{v:g}',8.5,align='right')
        self.line(x,y,x,y+h);self.line(x,y+h,x+w,y+h)
        for v,label in xticks:
            xx,_=xy(v,0);self.line(xx,y+h,xx,y+h+3);self.text(xx,y+h+7,label,8.5,align='center')
        self.text(x+w/2,y+h+25,xlabel,9,align='center');self.text(x,y-17,ylabel,9)
        return xy
    def curve(self,xy,xx,yy,color,markers=True,width=1.4):
        for i in range(1,len(xx)):self.line(*xy(xx[i-1],yy[i-1]),*xy(xx[i],yy[i]),color,width)
        if markers:
            for a,b in zip(xx,yy):self.dot(*xy(a,b),color,2)
    def save(self):self.c.showPage();self.c.save()

def read(name):return json.loads((BASE/name/'cases.json').read_text())

def translation():
    rows=read('padded');valid=[r for r in read('valid') if r['condition']=='single']
    ex=json.loads((BASE/'padded'/'single_000'/'cases.json').read_text())
    z=np.load(BASE/'padded'/'single_000'/'arrays.npz')
    assert all(r['test_index']==1001 for r in ex)
    f=Figure('spatial_translation_figure',580)
    f.text(8,8,'A  Same digit at five horizontal positions',12,bold=True)
    f.text(95,31,'Original input; outline = selected receptive field',9)
    f.text(486,31,'Category',9,align='center')
    for j,r in enumerate(ex):
        y=51+j*48
        f.text(8,y+13,f'x = {r["position"]}',10)
        f.strip(z['t0_sensory'][j],95,y,360,r['location'])
        f.text(486,y+12,str(r['prediction']),13,bold=True,align='center')
    f.text(8,306,'B  Categorization across position',12,bold=True)
    f.text(294,306,'C  Selected location follows the object',12,bold=True)
    xy=f.axes((39,354,213,150),(-.6,4.6),(0,100),[(j,str(p)) for j,p in enumerate([0,16,144,272,288])],[0,25,50,75,100],'Stimulus tile left edge (pixels)','Correct (%)')
    values={}
    for k,(rr,col) in enumerate([(valid,ORANGE),(rows,GREEN)]):
        values[col]=[]
        for j,pos in enumerate([0,16,144,272,288]):
            a=[r for r in rr if r['position']==pos];v=100*np.mean([r['correct'] for r in a]);values[col].append(float(v))
            left,top=xy(j+(-.32 if k==0 else .04),v);right,bottom=xy(j+(-.04 if k==0 else .32),0)
            f.rect(left,top,right-left,bottom-top,col)
            f.text((left+right)/2,top-12,f'{v:.0f}',7.5,align='center')
    f.rect(39,551,9,9,ORANGE);f.text(53,550,'Internal fields',8.5)
    f.rect(151,551,9,9,GREEN);f.text(165,550,'Zero extension',8.5)
    xy=f.axes((331,354,194,150),(-16,304),(-16,304),[(0,'0'),(144,'144'),(288,'288')],[0,144,288],'Stimulus tile left edge (pixels)','Selected field left edge (pixels)')
    f.line(*xy(-16,-16),*xy(304,304),'#bbbbbb',.8,[3,3])
    for r in rows:f.dot(*xy(r['position'],r['location']),BLUE,1.5)
    f.text(331,550,'500 trials; coincident points overlap',8.5)
    f.save()
    return dict(example_test_index=1001,example_rule='First recorded single-object case, not selected for accuracy.',trials=len(rows),accuracy_by_position=values)

def attention():
    rows=read('valid');two=[r for r in rows if r['condition']!='single']
    ex={r['condition']:r for r in two if r['scene']==0}
    path=BASE/'valid'/'two_000'
    left=np.load(path/'left.npz');right=np.load(path/'right.npz');sw=np.load(path/'left_to_right.npz')
    f=Figure('spatial_attention_figure',675)
    f.text(8,8,'A  Spatial cues select between two visible objects',12,bold=True)
    for j,(label,im,loc,out) in enumerate([
        ('Input',left['t0_sensory'][0],None,None),
        ('Left cue',left['final_sensory'][0],ex['left']['location'],ex['left']['prediction']),
        ('Right cue',right['final_sensory'][0],ex['right']['location'],ex['right']['prediction'])]):
        y=34+j*48;f.text(8,y+13,label,10);f.strip(im,95,y,360,loc)
        f.text(470,y+8,'Output',8.5);f.text(486,y+22,'--' if out is None else out,12,bold=True,align='center')
    f.text(95,175,'Cued rows show final sensory activity; outline = selected field.',9)
    f.text(8,206,'B  Spatial activity during a cue switch',12,bold=True)
    f.text(292,206,'C  Category competition',12,bold=True)
    ts=sorted(int(k.split('_')[0][1:]) for k in sw.files if k.startswith('t') and k.endswith('_category'))
    final=ex['left_to_right']['updates'];ticks=ts+[final]
    spatial=np.array([sw[f't{t}_spatial'][0] for t in ts]+[sw['final_spatial'][0]])
    category=np.array([sw[f't{t}_category'][0] for t in ts]+[sw['final_category'][0]])
    for k,(vals,label) in enumerate([(spatial,'Spatial rate'),(category,'Category rate')]):
        x=40+285*k;xy=f.axes((x,258,204,126),(0,final),(0,1),[(0,'0'),(100,'100'),(200,'200')],[0,.5,1],'Updates after switching cue',label)
        if k==0:
            series=[(vals[:,ex['none']['left']],BLUE,'Left location'),(vals[:,ex['none']['right']],ORANGE,'Right location')]
        else:
            for c in range(2,10):f.curve(xy,ticks,vals[:,c],GRAY,False,.5)
            series=[(vals[:,0],BLUE,'Category 0'),(vals[:,1],ORANGE,'Category 1')]
        for j,(v,col,lab) in enumerate(series):
            f.curve(xy,ticks,v,col);f.line(x+j*106,236,x+12+j*106,236,col,1.5);f.text(x+16+j*106,232,lab,8)
    f.text(40,431,'Cue changes from left to right at update 0; all internal state is retained.',9)
    f.text(8,463,'D  Spatial attention gain',12,bold=True)
    xy=f.axes((40,525,204,95),(0,319),(0,1.25),[(0,'0'),(160,'160'),(319,'319')],[0,.2,1,1.2],'Horizontal pixel coordinate','Sensory gain G(x)')
    f.line(*xy(0,1),*xy(319,1),'#777777',.7,[3,3])
    gain_profiles={}
    for j,(arr,col,lab) in enumerate([(left,BLUE,'Left cue'),(right,ORANGE,'Right cue')]):
        g=arr['final_gain'][0];f.curve(xy,np.arange(320),g,col,False)
        f.line(40+j*106,489,52+j*106,489,col,1.5);f.text(56+j*106,485,lab,8)
        gain_profiles[lab]=dict(minimum=float(g.min()),maximum=float(g.max()))
    f.text(292,463,'E  Selection and recognition',12,bold=True)
    xy=f.axes((325,525,204,95),(-.6,2.6),(0,100),[(0,'Cue'),(1,'Switch'),(2,'Alone')],[0,50,100],'Condition (directions pooled)','')
    f.text(325,499,'Correct (%)',9)
    stats={}
    groups=[['left','right'],['left_to_right','right_to_left'],['isolated_left','isolated_right']]
    for j,conds in enumerate(groups):
        rr=[r for r in two if r['condition'] in conds]
        stats[','.join(conds)]=dict(n=len(rr),location=sum(r['location_correct'] for r in rr),category=sum(r['correct'] for r in rr))
        for k,(key,col) in enumerate([('location_correct',BLUE),('correct',ORANGE)]):
            n=sum(r[key] for r in rr);pct=100*n/len(rr)
            x,y=xy(j+(-.28 if k==0 else .04),pct);right,bottom=xy(j+(-.04 if k==0 else .28),0)
            f.rect(x,y,right-x,bottom-y,col);f.text((x+right)/2,y-12,f'{pct:.0f}' if pct==100 else f'{pct:.1f}',8,align='center')
    f.rect(325,485,8,8,BLUE);f.text(339,484,'Location',8)
    f.rect(430,485,8,8,ORANGE);f.text(444,484,'Category',8)
    f.text(40,664,'Dashed line: unity gain',8)
    f.text(325,664,'180 trials per group; repeated observations',8)
    f.save()
    return dict(example_scene=0,example_rule='First recorded two-object display, not selected for accuracy.',left_test_index=ex['none']['left_index'],right_test_index=ex['none']['right_index'],trajectory_updates=ticks,trajectory_source='alpha0.1 left_to_right; saved snapshots plus actual final state; no resimulation or smoothing.',gain_profiles=gain_profiles,summary=stats)

if __name__=='__main__':
    metadata=dict(configuration='Saved focused checks at alpha0.1. Single-object zero extension; interior two-object valid fields.',translation=translation(),attention=attention())
    (ROOT/'spatial_experiment_figure_data.json').write_text(json.dumps(metadata,indent=2)+'\n')
    print(json.dumps(metadata,indent=2))
