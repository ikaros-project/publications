import json,csv
from pathlib import Path
import numpy as np
import evaluate_shared_stroke_bias_strength as e
out=e.OUT;M=Path(__file__).resolve().parents[5]/'Manuscript';rows=json.loads((out/'results.json').read_text())['cases']
def get(seed,j,strength,mode):return next(r for r in rows if r['seed']==seed and r['candidate']==j and r['strength']==strength and r['mode']==mode)
summary=[];bycase=[]
for strength in [.5,1.,2.]:
 rr=[v for v in rows if v['strength']==strength];captured=[v for v in rr if v['winner_at_release']==v['cue']]
 both=[];depict=[]
 for seed in range(71001,71011):
  for j in range(1,7):
   ab=[get(seed,j,strength,m) for m in ['bias_a','bias_b']]
   both.append(all(v['final_winner']==v['cue'] for v in ab));depict.append(all(v['final_winner']==v['cue'] and v['final_pixel']==v['cue'] for v in ab))
 s=dict(strength=strength,captured=len(captured),cue_final=sum(v['final_winner']==v['cue'] for v in rr),retained=sum(v['final_winner']==v['cue'] for v in captured),bidirectional=sum(both),bidirectional_category_and_image=sum(depict),pixel_cue=sum(v['final_pixel']==v['cue'] for v in rr),image_winner=sum(v['image_winner_agreement'] for v in rr),settled=sum(v['settled'] for v in rr),changed_from_unbiased=sum(v['final_winner']!=get(v['seed'],v['candidate'],0.,'none')['final_winner'] for v in rr),post_release_switch_cases=sum(any(t>50 for t in v['switch_iterations']) for v in rr),late_switches=sum(v['late_switches'] for v in rr))
 summary.append(s)
 for j in range(1,7):
  ss=[v for v in rr if v['candidate']==j];bycase.append(dict(strength=strength,candidate=j,a=ss[0]['a'],b=ss[0]['b'],cue_final=sum(v['final_winner']==v['cue'] for v in ss),both=sum(all(get(seed,j,strength,m)['final_winner']==get(seed,j,strength,m)['cue'] for m in ['bias_a','bias_b']) for seed in range(71001,71011))))
result=dict(summary=summary,per_candidate=bycase,total_settled=sum(v['settled'] for v in rows),total=len(rows))
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
with (M/'shared_stroke_bias_strength_statistics.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
lines=['# Shared-stroke bias strength comparison','','Same six user-selected stimuli,ten frozen models; strengths0.5,1,2 in both cue directions plus no-bias control (420 runs). Additive drive bias for50 updates then500 without bias. Category competition and50% sensory/top-down mixture unchanged. No hard clamping. Source references selected from original shared input and fixed across all conditions. No retraining.','','| Strength | Cue at release /120 | Cue at final /120 | Retained / captured | Both directions /60 | Both directions and images /60 | Image/winner /120 | Changed from no bias /120 |','|---|---|---|---|---|---|---|']
for s in summary:lines.append(f"|{s['strength']}|{s['captured']}|{s['cue_final']}|{s['retained']}/{s['captured']}|{s['bidirectional']}|{s['bidirectional_category_and_image']}|{s['image_winner']}|{s['changed_from_unbiased']}|")
lines+=['','## Complete summary','',json.dumps(result,indent=2),'','## Interpretation and limitations','','Cue following includes cases that already favor that category without bias; changed-from-unbiased and bidirectional counts isolate altered decisions. Bidirectional denotes two separate runs of the same model with identical pixels, one per cue. The image criterion requires the independent pixel5NN classifier to agree with the cue in both runs; it does not establish reproduction of the two originals. Stronger additive drives may dominate competition while active, so post-release results are essential. These deliberately selected ambiguous stimuli and repeated model evaluations do not represent independent stimulus samples. No-feedback is not a condition here: all conditions use the same ordinary50% feedback, including the no-bias control. All first18 conditions reproduce the previous0.5/no-bias winner trajectories and images; all weight hashes unchanged, probabilities normalized and initial/reference parity verified.','','No defaults or article text changed. Full traces, snapshots, per-case results, protocol and hash checks are retained.']
(M/'shared_stroke_bias_strength_source_notes.md').write_text('\n'.join(lines)+'\n');(out/'REPORT.md').write_text('\n'.join(lines)+'\n')
with np.load(out/'seed71001/arrays.npz') as z:
 panels=[];labels=[]
 for j in range(6):
  panels.append([z['input'][j]]+[z['snapshots'][-1,k*6+j] for k in range(1,7)])
  r=get(71001,j+1,.5,'bias_a');labels.append(f"#{j+1}: {r['a']} / {r['b']}")
 e.f.gallery(M/'shared_stroke_bias_strength_first_seed.png','Bias strength: reconstructions500 updates after bias removal',panels,labels,['shared input','0.5: A','0.5: B','1: A','1: B','2: A','2: B'])
print('\n'.join(lines),flush=True)
