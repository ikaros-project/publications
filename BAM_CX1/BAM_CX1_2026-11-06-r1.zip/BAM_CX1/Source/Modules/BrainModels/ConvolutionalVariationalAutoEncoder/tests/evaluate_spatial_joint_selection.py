"""Calibrate joint spatial selection on test0:1000; evaluate fixed rule on1000:2000.
Frozen model; independent parallel positions; neither recentering nor feedback.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['VECLIB_MAXIMUM_THREADS']='2'
import json,hashlib,time,csv
import numpy as np
from evaluate_spatial_single_stimulus import CAMPAIGN,e,prior,softmax
OUT=CAMPAIGN/'spatial_joint_selection_seed1'
GRID=[.1,.25,.5,1.,2.,4.]

def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')

def predict(prob,quality,methods):
    # 63 distinct availability configurations, weighting the interior 227 times.
    # Full289 placement predictions expanded after evaluating these configurations.
    xs=np.r_[np.arange(31),31,np.arange(258,289)]
    rel=xs[:,None]-np.arange(289)[None,:]
    lookup=np.where(abs(rel)<=31,rel+31,63)
    expansion=np.r_[np.arange(31),np.full(227,31),np.arange(32,63)]
    out=np.empty((len(prob),len(methods),289),np.int16)
    loc=np.empty_like(out)
    for j,(p,q) in enumerate(zip(prob,quality)):
        confidence=p.max(1);sp=p[lookup];sq=q[lookup];cp=confidence[lookup]
        for m,(family,beta) in enumerate(methods):
            if family=='confidence':score=cp
            elif family=='reconstruction':score=sq
            elif family=='product':score=np.maximum(sq,0)*cp**beta
            elif family=='log_add':score=sq/np.maximum(sq.max(1,keepdims=True),1e-30)+beta*np.log(np.maximum(cp,1e-30))
            else:raise ValueError(family)
            chosen=score.argmax(1)
            out[j,m]=sp[np.arange(len(xs)),chosen].argmax(1)[expansion]
            # Interior availability is translated from representative placement31.
            assert np.all(abs(rel[np.arange(len(xs)),chosen])<=31), "Winning blank location needs explicit tie handling"
            loc[j,m]=chosen[expansion]+np.arange(289)-xs[expansion]
    return out,loc

def stats(pred,y):
    correct=pred==y[:,None,None]
    return [dict(accuracy=float(v.mean()),interior_accuracy=float(v[:,31:258].mean()),edge_accuracy=float(np.concatenate([v[:,:31],v[:,258:]],1).mean()),correct_at_every_position=int(v.all(1).sum()),invariant_at_every_position=int((pp==pp[:,:1]).all(1).sum()),per_category=[float(v[y==c].mean()) for c in range(10)]) for v,pp in zip(correct.transpose(1,0,2),pred.transpose(1,0,2))]

def main():
    OUT.mkdir(exist_ok=True)
    methods=[('reconstruction',0),('confidence',0)]+[(f,b) for f in ['product','log_add'] for b in GRID]
    dump(OUT/'protocol.json',dict(seed=71001,selection_indices=[0,999],evaluation_indices=[1000,1999],placements=289,display=[32,320],stride=1,methods=methods,selection_metric='Mean category accuracy across calibration images and all289 placements. Tie broken by grid order. Selection saved before loading evaluation responses.',product='max(Q,0) * max_category_probability ** beta',log_add='Q/max_position(Q) + beta*log(max_category_probability)',scope='One frozen seed; 1000 calibration images and1000 additional evaluation images. Evaluation images not used to select this spatial rule; entire test set previously used for original object-model evaluation. No fresh full-test run.',competition='Feedforward joint score and hard winner selection across positions; not a implemented recurrent spatial circuit. One category from winning location; no category-label input or cue.'))
    source=CAMPAIGN/'spatial_single_stimulus_reconstruction_seed1'
    with np.load(source/'arrays.npz') as a:cp=a['relative_probabilities'];cy=a['labels'];old=a['predictions']
    with np.load(source/'reconstruction_diagnostics.npz') as a:cq=a['quality']
    calpred,_=predict(cp,cq,methods)
    np.testing.assert_array_equal(calpred[:,0],old[:,4]);np.testing.assert_array_equal(calpred[:,1],old[:,1])
    cs=stats(calpred,cy);best=max(range(2,len(methods)),key=lambda i:cs[i]['accuracy'])
    selection=dict(methods=methods,statistics=cs,selected_index=best,selected_method=methods[best])
    dump(OUT/'selection.json',selection)
    print('Locked selection:',methods[best],cs[best]['accuracy'],flush=True)
    selected=[methods[0],methods[1],methods[best]]
    # Only now load and evaluate the separate1000-image set.
    folder=CAMPAIGN/'hierarchy_s71001'
    paths=[folder/'model.state',folder/'codebook_final.npz',CAMPAIGN/'neural_readout_regularized_capacity/full_refit/grouped_softmax_s71001.npz',CAMPAIGN/'local_linear_patch_decoder_seed1/local_decoder.npz']
    hashes=[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
    state=json.loads(paths[0].read_text())['items']
    def w(k):
        v=state['CVAE_TwoLayer.Upper.'+k];return np.array(v['value'],np.float32).reshape(v['shape'])
    enc=w('DIRECT_MEAN_WEIGHTS');eb=w('DIRECT_MEAN_BIAS');dec=w('DIRECT_DECODER_WEIGHTS');db=w('DIRECT_DECODER_BIAS');del state
    with np.load(paths[1]) as a:book=prior.Codebook(a['prototypes'])
    with np.load(paths[2]) as a:rw=a['weights'];rb=a['bias']
    with np.load(paths[3]) as a:decoder=a['decoder'].astype(np.float32)
    raw=e.full.read_idx_images(e.full.RAW_ROOT/'t10k-images-idx3-ubyte.gz',2000)[1000:]
    y=e.full.read_idx_labels(e.full.RAW_ROOT/'t10k-labels-idx1-ubyte.gz',2000)[1000:]
    images=np.stack([e.full.center_and_pad(im) for im in raw]).astype(np.float32)/255
    probs=[];quality=[];latents=[];t=time.time()
    for j,im in enumerate(images):
        local=np.zeros((64,32,32),np.float32)
        for k,d in enumerate(range(-31,32)):
            lo=max(0,d);hi=min(32,32+d);local[k,:,lo:hi]=im[:,lo-d:hi-d]
        patch=np.lib.stride_tricks.sliding_window_view(local,(7,7),axis=(1,2)).reshape(-1,49)
        dist=(patch*patch).sum(1)[:,None]+(book.prototypes**2).sum(1)[None]-2*patch@book.prototypes.T
        activity=softmax(-dist/(49*.08)).reshape(64,676,64).transpose(0,2,1).copy()
        latent=activity.reshape(64,-1)@enc+eb
        p=softmax(latent@rw+rb).reshape(64,10,20).sum(2)
        top=softmax((latent@dec+db).reshape(64,64,676).transpose(0,2,1))
        patches=(top@decoder).reshape(64,26,26,7,7);recon=np.zeros_like(local);counts=np.zeros((32,32),np.float32)
        for dy in range(7):
            for dx in range(7):
                recon[:,dy:dy+26,dx:dx+26]+=patches[:,:,:,dy,dx];counts[dy:dy+26,dx:dx+26]+=1
        recon=np.clip(recon/counts,0,1)
        probs.append(p);quality.append((2*local*recon-recon**2).sum((1,2)));latents.append(latent[31])
        if (j+1)%200==0:
            print('Evaluation images',j+1,'/1000',flush=True);dump(OUT/'status.json',dict(stage='evaluating',completed=j+1,total=1000))
    probs=np.array(probs);quality=np.array(quality)
    pred,loc=predict(probs,quality,selected);ss=stats(pred,y)
    # Native Ikaros compatibility on every centered evaluation image.
    with (folder/'test_codes.csv').open() as f:names=next(csv.reader(f))
    cols=[i for i,n in enumerate(names) if n=='code' or n.startswith('code:')]
    native=np.loadtxt(folder/'test_codes.csv',delimiter=',',skiprows=1,max_rows=2000,usecols=cols,dtype=np.float32)[1000:]
    np.testing.assert_allclose(native,latents,atol=3e-5,rtol=3e-5)
    assert np.all(pred[:,:,31:258]==pred[:,:,31:32])
    # Reversing the spatial axis reverses unique winning positions, not categories.
    # Predict recomputes independent scores; no sequential activity updates exist.
    centered=probs[:,31].argmax(1)
    correct=(pred==y[:,None,None]);delta=correct[:,2].mean(1)-correct[:,0].mean(1)
    rng=np.random.default_rng(9120)
    boot=np.array([delta[rng.integers(0,1000,1000)].mean() for _ in range(5000)])
    # Count paired cases for the repeated interior condition separately.
    before=correct[:,0,144];after=correct[:,2,144]
    results=dict(methods=selected,statistics=ss,centered_accuracy=float((centered==y).mean()),gain_vs_reconstruction=float(delta.mean()),paired_image_bootstrap95=np.quantile(boot,[.025,.975]).tolist(),interior_corrections=int((~before&after).sum()),interior_regressions=int((before&~after).sum()),native_centered_latent_max_error=float(abs(native-np.array(latents)).max()),checkpoint_sha256=hashes,elapsed_seconds=time.time()-t)
    assert hashes==[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
    np.savez_compressed(OUT/'arrays.npz',images=images,labels=y,test_indices=np.arange(1000,2000),relative_probabilities=probs,quality=quality,predictions=pred,selected_positions=loc,centered_predictions=centered)
    dump(OUT/'results.json',results);dump(OUT/'status.json',dict(stage='complete',completed=1000,total=1000))
    print(json.dumps(results,indent=2),flush=True)
if __name__=='__main__':main()
