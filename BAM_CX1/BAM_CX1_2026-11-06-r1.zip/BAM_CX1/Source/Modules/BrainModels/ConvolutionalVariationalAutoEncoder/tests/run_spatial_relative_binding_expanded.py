"""Prespecified new-image validation of relative spatial binding, one fixed network."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import json,concurrent.futures,hashlib,argparse,shutil,time
from dataclasses import asdict
from pathlib import Path
import numpy as np
import run_spatial_content_feedback as r
from cached_spatial_content_feedback import CachedFrontend,CachedLocalFeedback
from run_spatial_relative_binding import NORMAL,BASE,CONTROL
DATA=r.ROOT
ROOT=DATA/'relative_binding_expanded'
SPATIAL='spatial_only_600'
SEED=9222602

def init():
    r.FRONT=CachedFrontend();r.FRONT.ids=r.FRONT.references()
    assert r.FRONT.hashes==json.loads((r.OUT/'checkpoint_hashes.json').read_text())
    r.LocalFeedback=CachedLocalFeedback

def parity_job(job):
    source,j,name=job
    original=DATA if source=='main' else CONTROL
    dest=ROOT/'cache_parity'/source;dest.mkdir(parents=True,exist_ok=True)
    r.ROOT=dest;row=r.worker((j,name))
    with np.load(original/f'case{j:02d}_{name}'/'arrays.npz') as a,np.load(dest/f'case{j:02d}_{name}'/'arrays.npz') as b:
        for key in a.files:np.testing.assert_array_equal(a[key],b[key],err_msg=key)
    return dict(source=source,case=j,method=name,seconds=row['seconds'],all_saved_arrays_bit_identical=True)

def parity():
    ROOT.mkdir(exist_ok=True)
    for source,original in [('main',DATA),('control',CONTROL)]:
        dest=ROOT/'cache_parity'/source;dest.mkdir(parents=True,exist_ok=True)
        for file in ['stimuli.json','stimuli.npz']:
            if not (dest/file).exists():shutil.copyfile(original/file,dest/file)
    jobs=[('main',10,NORMAL),('main',0,NORMAL),('control',5,BASE),('control',5,NORMAL)]
    with concurrent.futures.ProcessPoolExecutor(max_workers=4,initializer=init) as pool:rows=list(pool.map(parity_job,jobs))
    r.dump(ROOT/'cache_parity.json',rows);print('CACHE PARITY PASSED',flush=True)

def prepare():
    ROOT.mkdir(exist_ok=True)
    if (ROOT/'protocol.json').exists():return
    rng=np.random.default_rng(SEED)
    raw=r.e.full.read_idx_images(r.e.full.RAW_ROOT/'t10k-images-idx3-ubyte.gz',10000)
    labels=r.e.full.read_idx_labels(r.e.full.RAW_ROOT/'t10k-labels-idx1-ubyte.gz',10000)
    pools={c:list(rng.permutation(np.flatnonzero(labels[7000:10000]==c)+7000)) for c in range(10)}
    meta=[];clean=[];inputs=[];masks=[];pairs=[]
    for cat in range(10):
        distractors=rng.choice([c for c in range(10) if c!=cat],2,replace=False)
        for side in [0,1]:
            pair=len(pairs);dc=int(distractors[side]);rc=int(rng.choice([c for c in range(10) if c not in [cat,dc]]))
            ids=[int(pools[c].pop()) for c in [cat,dc,rc]]
            positions=[64+int(rng.integers(-24,25)),224+int(rng.integers(-24,25))];tp=positions[side];dp=positions[1-side]
            imgs=[r.e.full.center_and_pad(raw[i]).astype(np.float32)/255 for i in ids]
            original=np.zeros((32,320),np.float32);original[:,tp:tp+32]=imgs[0];original[:,dp:dp+32]=imgs[1]
            pm=dict(pair=pair,target_category=cat,distractor_category=dc,replacement_category=rc,test_indices=ids[:2],replacement_test_index=ids[2],target_position=tp,distractor_position=dp,target_side=side)
            pairs.append(pm)
            for condition in ['spatial0','spatial8','spatial12','present','absent']:
                x=original.copy();truth=original.copy();mask=np.zeros_like(x,bool);size=int(condition[7:]) if condition.startswith('spatial') else 0
                if size:
                    start=(32-size)//2;mask[start:start+size,tp+start:tp+start+size]=True;x[mask]=0
                if condition=='absent':x[:,tp:tp+32]=imgs[2];truth=x.copy()
                m=dict(pm,case=len(meta),condition=condition,occlusion=size,cue_mode='spatial' if condition.startswith('spatial') else 'category',target_present=condition!='absent',physical_target_category=rc if condition=='absent' else cat)
                meta.append(m);inputs.append(x);clean.append(truth);masks.append(mask)
    assert len(meta)==100 and len({i for p in pairs for i in p['test_indices']+[p['replacement_test_index']]})==60
    np.savez_compressed(ROOT/'stimuli.npz',input=inputs,clean=clean,mask=masks)
    r.dump(ROOT/'stimuli.json',meta);r.dump(ROOT/'pairs.json',pairs)
    r.dump(ROOT/'protocol.json',dict(network_seed=71001,sampling_seed=SEED,pairs=20,new_unique_images=60,target_categories='All ten categories, two independent target images each: one left and one right. Distinct distractor categories per target category; replacement differs from both visible original categories.',selection='Uniform sampling without replacement within category from test indices7000:10000. No performance screening; disjoint from the preceding four-pair pilot. These images may occur in other earlier spatial studies: this is new-image validation of this binding experiment, not an untouched test set.',positions='Independent integer jitter[-24,24] around tile left edges64 and224. 32x320 canvas,351 stride-one fields including zero extension. Two nonoverlapping objects.',conditions='Per pair: spatial cue2 on intact/8x8/12x12 deletion, each under spatial-only, separated feedback, normalized separated feedback (9 trials); category cue2/no spatial cue with target present or replaced, each under separated/normalized feedback (4 trials). Total260 runs.',parameters=asdict(r.PAR),normalization='Binding excitation only: P/max-category(P), floor epsilon. Optional flag defaults off. No parameter tuning, training, overlap or oscillation follow-up.',updates=600,early_stop=False,settling='Last100 and last20 normalized maximum changes across seven circuit populations and local code activity below5e-6. No extensions beyond600.',scoring='Spatial trials: category activity/correctness, localization, clean hidden/visible target-field MSE, distractor changes. Category-cued trials: location and binding at selected field; externally clamped global category is not scored as recognition. False binding convention: absent requested category is largest selected-field binding with binding and spatial mass>1e-7. Report raw amplitudes; no not-found threshold calibration.',uncertainty='Paired differences with 95% stratified bootstrap intervals: resample the two independent image pairs within each target category, retaining all repeated conditions of each pair; 10000 resamples with fixed seed9222603. Conditional on this trained model and balanced design, no training-seed generalization. Also report per-category outcomes and paired discordances.',optimization='Exact array-equality caches only; no tolerance, omission of spatial units, reduced precision, or early stopping. Skip exactly zero terms in the reference mixture. Before new runs, all saved arrays in four original600-update trials must be bit-identical.',checkpoint_hashes=r.FRONT.hashes if r.FRONT is not None else json.loads((r.OUT/'checkpoint_hashes.json').read_text()),source_sha256={name:hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest() for name in ['neural_spatial_rate_model.py','spatial_content_feedback.py','cached_spatial_content_feedback.py','run_spatial_content_feedback.py','run_spatial_relative_binding_expanded.py']}))

def worker(job):
    r.ROOT=ROOT
    return r.worker(job)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--parity',action='store_true');ap.add_argument('--workers',type=int,default=16);args=ap.parse_args()
    if args.parity:parity();return
    assert (ROOT/'cache_parity.json').exists(), 'Exact parity must pass first'
    prepare();meta=json.loads((ROOT/'stimuli.json').read_text())
    jobs=[(m['case'],name) for m in meta for name in ([SPATIAL,BASE,NORMAL] if m['cue_mode']=='spatial' else [BASE,NORMAL])]
    # Interleave categories, rather than completing one category before another.
    order=np.random.default_rng(SEED+10).permutation(len(jobs));jobs=[jobs[i] for i in order]
    start=time.time();rows=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,initializer=init) as pool:
        futures=[pool.submit(worker,j) for j in jobs]
        for fut in concurrent.futures.as_completed(futures):
            rows.append(fut.result());r.dump(ROOT/'status.json',dict(completed=len(rows),total=len(jobs),seconds=time.time()-start,workers=args.workers))
    r.dump(ROOT/'results.json',dict(cases=sorted(rows,key=lambda m:(m['case'],m['method']))));print('EXPANDED VALIDATION COMPLETE',flush=True)
if __name__=='__main__':main()
