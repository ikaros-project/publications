"""Nine new frozen-seed release replications plus the original seed; cluster by seed."""
import json,concurrent.futures,collections,csv
from pathlib import Path
import numpy as np
import category_release_seed_worker as w
OUT=w.n.CAMPAIGN/'category_release_ten_seeds';SEEDS=list(range(71001,71011))
def dump(name,v):(OUT/name).write_text(json.dumps(v,indent=2)+'\n')
def source(seed):return w.n.CAMPAIGN/'category_release_seed1' if seed==71001 else OUT/f'seed{seed}'
def worker(seed):w.run(seed,source(seed));return seed

def aggregate():
 perseed=[];cases=[];transitions=collections.Counter();allchecks=[]
 for seed in SEEDS:
  src=source(seed);r=json.loads((src/'results.json').read_text());assert r['checks']['weights_unchanged'];allchecks.append(dict(seed=seed,**r['checks']))
  with np.load(src/'setup.npz') as z:pr=z['release_readout'];cats=np.repeat(np.arange(10),8);e=pr/pr.max(1,keepdims=True);other=e.copy();other[np.arange(80),cats]=-np.inf;margin=1.5*e[np.arange(80),cats]-other.max(1)
  for mode in ['held','released']:
   rr=[dict(v,seed=seed) for v in r['cases'] if v['condition']==mode]
   with np.load(src/(mode+'.npz')) as z:
    changes=z['changes'];tail=np.maximum.accumulate(changes.max(2)[::-1],axis=0)[::-1];settled=tail[-10]<1e-5;first=np.where(settled,np.argmax(tail<1e-5,axis=0)+1,-1)
    late_image=((z['images'][-1]-z['images'][-2])**2).mean((1,2));maxpix=z['pixel_max_change'].max(0);image_mse=z['image_mse']
    for j,v in enumerate(rr):
     v.update(readout_disagrees=bool(v['initial_readout_category']!=v['category']),ever_switched=bool(v['switch_iterations']),retained_category=bool(v['final_winner']==v['category']),image_exactly_unchanged=bool(maxpix[j]==0),material_image_change=bool(v['final_mse']>1e-6),max_snapshot_pixel_change=float(maxpix[j]),max_lower_activity_change=float(changes[:,j,0].max()),late_image_mse=float(late_image[j]),persistent_threshold_crossing=int(first[j]),settling_criterion_completed=int(first[j]+9) if first[j]>=0 else None,relative_requested_evidence=float(e[j,cats[j]]),initial_inhibition_margin=float(margin[j]),predicted_competitor_can_grow=bool(margin[j]<0))
     if mode=='released':
      for a,b in zip(v['switch_sequence'],v['switch_sequence'][1:]):transitions[f'{a}->{b}']+=1
   dis=np.array([v['readout_disagrees'] for v in rr]);sw=np.array([v['ever_switched'] for v in rr]);ret=np.array([v['retained_category'] for v in rr]);pred=np.array([v['predicted_competitor_can_grow'] for v in rr]);mse=np.array([v['final_mse'] for v in rr]);tp=int((dis&sw).sum());fp=int((dis&~sw).sum());fn=int((~dis&sw).sum());tn=int((~dis&~sw).sum())
   perseed.append(dict(seed=seed,condition=mode,cases=80,retained_category=int(ret.sum()),retention_fraction=float(ret.mean()),ever_switched=int(sw.sum()),switch_fraction=float(sw.mean()),exactly_unchanged=sum(v['image_exactly_unchanged'] for v in rr),unchanged_fraction=float(np.mean([v['image_exactly_unchanged'] for v in rr])),material_image_changes=sum(v['material_image_change'] for v in rr),settled=sum(v['settled'] for v in rr),multiple_switch_cases=sum(len(v['switch_iterations'])>1 for v in rr),late_switch_events=sum(sum(t>900 for t in v['switch_iterations']) for v in rr),readout_disagreements=int(dis.sum()),disagreement_fraction=float(dis.mean()),disagreement_and_switch=tp,disagreement_no_switch=fp,agreement_and_switch=fn,agreement_no_switch=tn,switch_given_disagreement=tp/(tp+fp) if tp+fp else None,switch_given_agreement=fn/(fn+tn) if fn+tn else None,initial_margin_predictor_matches=int((pred==sw).sum()),mean_image_mse=float(mse.mean()),mean_late_image_mse=float(np.mean([v['late_image_mse'] for v in rr])),initial_pixel_agreement=next(v['initial_pixel_category_agreement'] for v in r['summary'] if v['condition']==mode)/80,final_pixel_requested_agreement=sum(v['final_pixel_prediction']==v['category'] for v in rr)/80,final_pixel_winner_agreement=sum(v['final_pixel_prediction']==v['final_winner'] for v in rr)/80))
   cases+=rr
 def stats(v):
  a=np.array([x for x in v if x is not None],float);n=len(a)
  if not n:return None
  mean=float(a.mean());sd=float(a.std(ddof=1)) if n>1 else None
  tcrit={9:2.306004,10:2.262157}.get(n)
  return dict(n_seeds=n,mean=mean,sd=sd,ci95=[mean-tcrit*sd/np.sqrt(n),mean+tcrit*sd/np.sqrt(n)] if tcrit else None)
 def summarize(seeds):
  summary={}
  for mode in ['held','released']:
   rr=[v for v in perseed if v['seed'] in seeds and v['condition']==mode];cc=[v for v in cases if v['seed'] in seeds and v['condition']==mode]
   totals={key:sum(v[key] for v in rr) for key in ['cases','retained_category','ever_switched','exactly_unchanged','material_image_changes','settled','multiple_switch_cases','late_switch_events','readout_disagreements','disagreement_and_switch','disagreement_no_switch','agreement_and_switch','agreement_no_switch','initial_margin_predictor_matches']}
   metrics={key:stats([v[key] for v in rr]) for key in ['retention_fraction','switch_fraction','unchanged_fraction','disagreement_fraction','switch_given_disagreement','switch_given_agreement','mean_image_mse','initial_pixel_agreement','final_pixel_requested_agreement','final_pixel_winner_agreement']}
   first=[v['switch_iterations'][0] for v in cc if v['ever_switched']];cross=[v['persistent_threshold_crossing'] for v in cc if v['ever_switched'] and v['settled']]
   summary[mode]=dict(totals=totals,seed_statistics=metrics,pooled_switch_given_disagreement=totals['disagreement_and_switch']/totals['readout_disagreements'] if totals['readout_disagreements'] else None,pooled_switch_given_agreement=totals['agreement_and_switch']/(totals['cases']-totals['readout_disagreements']),first_switch_range=[min(first),max(first)] if first else None,first_switch_median=float(np.median(first)) if first else None,switch_case_settling_crossing_range=[min(cross),max(cross)] if cross else None,switch_case_settling_crossing_median=float(np.median(cross)) if cross else None,max_late_image_mse=max(v['late_image_mse'] for v in cc),max_final_image_mse=max(v['final_mse'] for v in cc))
  return summary
 result=dict(all_ten=summarize(SEEDS),nine_new=summarize(SEEDS[1:]),per_seed=perseed,cases=cases,transition_counts=dict(transitions),checks=allchecks,statistics_note='Cases clustered by model. Descriptive t95% intervals over ten independent training seeds (df9); separate nine-new-seed analysis (df8) excludes exploratory seed71001. References can overlap across seed banks; shared initialization. Seed variation intervals do not characterize novel images or initialization perturbations. All-success counts do not prove a zero population failure rate. Conditional probability intervals shown only if all9 or10 seeds contribute; pooled ratios remain descriptive.')
 dump('results.json',result)
 with (OUT/'per_seed.csv').open('w') as f:writer=csv.DictWriter(f,fieldnames=list(perseed[0]));writer.writeheader();writer.writerows(perseed)
 selected=[v for v in cases if v['condition']=='released' and v['ever_switched']]
 lines=['# Category release across ten frozen models','','500 category-held iterations followed by1000 held or autonomous iterations. Original seed71001 reused; nine additional seeds tested with unchanged settings. One shared random starting state;80 references/model.','', '| Seed | Category retained | Image unchanged | Switches | Readout disagreements | Disagreement without switch | Settled |','|---|---:|---:|---:|---:|---:|---:|']
 for v in perseed:
  if v['condition']=='released':lines.append(f'| {v["seed"]} | {v["retained_category"]}/80 | {v["exactly_unchanged"]}/80 | {v["ever_switched"]} | {v["readout_disagreements"]} | {v["disagreement_no_switch"]} | {v["settled"]}/80 |')
 lines+=['','## Aggregate statistics','',json.dumps(result['all_ten'],indent=2),'','## Nine newly tested seeds','',json.dumps(result['nine_new'],indent=2),'',result['statistics_note']]
 (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
 # All switching cases, with explicit transitions; no outcome-selected omission.
 for start in range(0,len(selected),8):
  group=selected[start:start+8];panels=[];labs=[]
  for v in group:
   j=v['category']*8+v['reference_slot']
   with np.load(source(v['seed'])/'released.npz') as z:panels.append([z['images'][w.STEPS.index(t),j] for t in [0,8,32,128,1000]])
   labs.append(f'{v["seed"]} {v["category"]}>{v["final_winner"]}')
  w.f.gallery(OUT/f'all_transitions_{start//8+1}.png','Release of external category activation: all switching cases',panels,labs,['release','+8','+32','+128','+1000'])
 print('\n'.join(lines[:16]),flush=True);dump('status.json',dict(stage='complete'))

def main():
 OUT.mkdir(exist_ok=True)
 dump('protocol.json',dict(seeds=SEEDS,new_seeds=SEEDS[1:],reused_seed=71001,cases_per_seed=80,warmup=500,after_release=1000,conditions=['held','released'],parameters='Unchanged first-seed protocol: alpha.2,lambda1,inhibition1.5,competition damping.2, same RNG20260921 starting noise. Preserve existing activity at release; original reference fixed, alternative references nearest release latent and then fixed.',primary='Retention, image persistence, switches, convergence; association between pre-release readout disagreement and switching. Estimate seed-level variation and report nine-new-seed sensitivity separately.',additional_diagnostic='Compute inhibition margin1.5*relative requested evidence-max other evidence at release, before observing outcomes. Negative margin predicts that a rival can become active once requested activity relaxes. This tests a mechanism-specific explanatory condition, not a trained predictor.',scope='Frozen weights, no perturbations, no reference reselection, no tests of robustness to disturbances or other noise starts. No default change.',workers=2))
 dump('status.json',dict(stage='running'))
 with concurrent.futures.ProcessPoolExecutor(max_workers=2) as pool:
  futures=[pool.submit(worker,s) for s in SEEDS[1:]]
  for future in concurrent.futures.as_completed(futures):print('finished',future.result(),flush=True)
 aggregate()
if __name__=='__main__':main()
