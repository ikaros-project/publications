"""Automatic completion analysis of the frozen stability campaign."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import time,json,html,traceback
from collections import defaultdict
import numpy as np
from PIL import Image,ImageDraw
import qmnist_confirmation_common as q
from run_final_stability import OUT,read,protocol,folder

def interval(rows,key,cluster):
 valid=[r for r in rows if r.get(key) is not None]
 if not valid:return None
 models=sorted(set(r['seed'] for r in valid));clusters=sorted(set(cluster(r) for r in valid));lookup={}
 for m in models:
  for c in clusters:
   vv=[float(r[key]) for r in valid if r['seed']==m and cluster(r)==c]
   if vv:lookup[m,c]=np.mean(vv)
 rng=np.random.default_rng(2026110514);vals=[]
 for _ in range(2000):
  mm=rng.choice(models,len(models));cc=rng.choice(clusters,len(clusters));v=[lookup[m,c] for m in mm for c in cc if (m,c) in lookup]
  if v:vals.append(np.mean(v))
 return dict(mean=float(np.mean([float(r[key]) for r in valid])),ci95=np.quantile(vals,[.025,.975]).tolist(),n=len(valid))

def svg_plot(path,series,title,ylabel,log=False):
 colors=['#0072B2','#D55E00','#009E73','#CC79A7','#E69F00','#444444'];w=1000;h=430;left=75;right=230;top=50;bottom=55
 values=[float(y) for _,_,yy in series for y in yy];xmin=0;xmax=max(float(max(xx)) for _,xx,_ in series)
 transform=lambda y:np.log10(max(y,1e-9)) if log else y
 ymin=min(transform(y) for y in values);ymax=max(transform(y) for y in values);span=max(ymax-ymin,1e-6);ymin-=span*.05;ymax+=span*.05
 X=lambda x:left+x/max(xmax,1e-9)*(w-left-right);Y=lambda y:top+(ymax-transform(y))/(ymax-ymin)*(h-top-bottom)
 parts=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}"><rect width="100%" height="100%" fill="white"/><g font-family="sans-serif" font-size="14">',f'<text x="{left}" y="25" font-size="19">{html.escape(title)}</text>']
 for i in range(6):
  v=ymin+(ymax-ymin)*i/5;y=top+(1-i/5)*(h-top-bottom);label=f'{10**v:.1e}' if log else f'{v:.3g}';parts.append(f'<path d="M {left} {y} H {w-right}" stroke="#ddd"/><text x="5" y="{y+5}">{label}</text>')
 for i in range(6):
  x=xmax*i/5;parts.append(f'<text x="{X(x)-8}" y="{h-30}">{x:.0f}</text>')
 for k,(name,xx,yy) in enumerate(series):
  pts=' '.join(f'{X(float(x)):.2f},{Y(float(y)):.2f}' for x,y in zip(xx,yy));color=colors[k%len(colors)];dash='' if k<3 else ' stroke-dasharray="7 4"';parts.append(f'<polyline points="{pts}" fill="none" stroke="{color}" stroke-width="2"{dash}/><text x="{w-right+15}" y="{65+25*k}" fill="{color}">{html.escape(name)}</text>')
 parts.append(f'<text x="{left}" y="{h-5}">Updates</text><text x="{w-right+15}" y="{h-15}">{html.escape(ylabel)}</text></g></svg>');path.write_text(''.join(parts))

def summarize():
 protocol();sp=read(OUT/'spatial_results.json');focal=read(OUT/'focal_results.json');assert len(sp)==993 and len(focal)==210
 assert all(q.sha(p)==q.protocol()['checkpoint_sha256'][str(p.relative_to(q.C))] for seed in protocol()['models'] for p in q.paths(seed))
 controls={(r['seed'],r['request']['name']):r for r in sp if r['stage']=='release' and r['amplitude']==0}
 for r in sp:
  r['nonsettled']=not r['settled'];r['wrong_location']=not r['located']
  if r['stage'] in ['endpoint','release']:
   r['same_baseline_category']=r['category']==r['baseline_category'];r['within1_baseline_location']=None if r['location'] is None or r['baseline_location'] is None else abs(r['location']-r['baseline_location'])<=1
  if r['stage']=='release':
   ctrl=controls[r['seed'],r['request']['name']];r['same_release_category']=r['category']==ctrl['category'];r['within1_release_location']=None if r['location'] is None or ctrl['location'] is None else abs(r['location']-ctrl['location'])<=1
   with np.load(folder(r)/'arrays.npz') as z:image=z['final_render']
   with np.load(folder(ctrl)/'arrays.npz') as z:r['release_control_image_mse']=float(np.mean((image-z['final_render'])**2))
 groups=defaultdict(list)
 for r in sp:
  if r['stage']=='diagnostic':continue
  task='search' if r['request']['spatial'] is None else 'overlap'
  key=(task,r['stage'],r['config']['name'] if r['stage']=='parameter' else str(r['amplitude']))
  groups[key].append(r)
 summaries=[]
 for key,rr in sorted(groups.items()):
  vals={metric:interval(rr,metric,lambda r:r['request']['name']) for metric in ['nonsettled','wrong_location','residual','same_baseline_category','within1_baseline_location','same_release_category','within1_release_location','release_control_image_mse']}
  summaries.append(dict(task=key[0],stage=key[1],configuration=key[2],n=len(rr),nonsettled=sum(not r['settled'] for r in rr),settling_time_median=None if not any(r['settling_time'] is not None for r in rr) else float(np.median([r['settling_time'] for r in rr if r['settling_time'] is not None])),censored=sum(r['settling_time'] is None for r in rr),metrics=vals,by_model=[dict(model=s,n=sum(r['seed']==s for r in rr),nonsettled=sum(not r['settled'] for r in rr if r['seed']==s)) for s in protocol()['models']]))
 fg=[]
 for amp in [0,.05,.1]:
  rr=[r for r in focal if r['amplitude']==amp]
  for r in rr:r['nonsettled']=not r['settled']
  fg.append(dict(amplitude=amp,n=len(rr),metrics={k:interval(rr,k,lambda r:r['category']) for k in ['nonsettled','retained_category','same_as_unperturbed','image_mse_unperturbed','image_mse_release']}))
 diagnostics=[r for r in sp if r['stage']=='diagnostic'];q.dump(OUT/'summary.json',dict(spatial=summaries,focal=fg,diagnostics=diagnostics,weights_unchanged=True));q.dump(OUT/'enriched_spatial_results.json',sp)
 lines=['# Frozen final-model stability follow-up','','The scientific protocol was frozen before these simulations. Original model weights, reference banks and reported endpoints were preserved. This is a follow-up on reused stimuli, not an independent confirmation sample.','','## Existing confirmation trajectories','',f"The existing analysis covers 6210 focal and 1350 spatial endpoints. Three spatial endpoints were nonsettled, all in feedback-on category search (3/60). No full focal settling-time trace was retained in that earlier campaign.",'','## Spatial sensitivity and local perturbations','','Failure means failure to meet the settling criterion. It does not mean incorrect selection. Stable wrong selections and stable alternative interpretations are reported separately. Intervals resample models and request clusters, keeping perturbation draws together. Three models and five requests per task provide limited uncertainty precision.','','| Task | Stage | Setting | Runs | Nonsettled | Median settling time* | Censored |','|---|---|---|---:|---:|---:|---:|']
 for r in summaries:lines.append(f"| {r['task']} | {r['stage']} | {r['configuration']} | {r['n']} | {r['nonsettled']} | {r['settling_time_median']} | {r['censored']} |")
 lines+=['','*Model-time units, among observed settling times only. Equal-time horizons are used in the update-rate comparison. Detailed paired endpoint comparisons, unit-step residuals and crossed-bootstrap intervals are in summary.json. Fixed-point probes include all seven spatial populations and lower codes.','','## Difficult-case continuations','']
 for r in diagnostics:lines.append(f"- Model {r['seed']}, original request {r['request']['job']}: {r['diagnosis']} at 3000 updates. Located: {r['located']}. Final normalized change: {r['last_window_rate']:.6g}.")
 lines+=['','These three outcome-selected cases are excluded from the sensitivity-sample failure rates. Every rerun was checked against its saved 600-update trajectory before continuation.','','## Autonomous focal release perturbations','','| Amplitude | Runs | Settled | Retained category | Matched unperturbed category |','|---|---:|---:|---:|---:|']
 for g in fg:
  mm=g['metrics'];lines.append(f"| {g['amplitude']} | {g['n']} | {1-mm['nonsettled']['mean']:.1%} | {mm['retained_category']['mean']:.1%} | {mm['same_as_unperturbed']['mean']:.1%} |")
 lines+=['','## Interpretation limits','','Post-endpoint perturbations starting from a nonsettled baseline do not establish attractor robustness. Spatial cue-release trials remove category cues only. Overlap retains its spatial cue. Fresh-state perturbations test initialization sensitivity. Stable alternative outcomes are not classified as nonconvergence. These finite perturbations and finite observation horizons cannot prove global stability. No parameters are selected or adopted from these results.','','## Figures','','- diagnostic_change.svg: normalized changes in the three diagnostic continuations.','- diagnostic_location.svg: location of maximal spatial activity over those continuations.','- focal_release_examples.png: first reference in each category, before release and final unperturbed / first 0.1-perturbation outcomes for all three models.']
 (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n')
 curves=[];locations=[]
 for r in diagnostics:
  with np.load(folder(r)/'arrays.npz') as z:
   label=f"Model {r['seed']}, case {r['request']['job']}";xx=np.arange(1,len(z['changes'])+1);curves.append((label,xx,z['changes']));locations.append((label,xx,z['spatial_trace'].argmax(1)-31))
 svg_plot(OUT/'diagnostic_change.svg',curves,'Diagnostic continuations: normalized state change','Change / alpha',True);svg_plot(OUT/'diagnostic_location.svg',locations,'Diagnostic continuations: selected location','Horizontal position')
 canvas=Image.new('RGB',(10*72+180,9*84+35),'white');draw=ImageDraw.Draw(canvas)
 for si,seed in enumerate(protocol()['models']):
  with np.load(OUT/f'focal_{seed}'/'arrays.npz') as z:ims=[z['release_images'],z['images'][::7],z['images'][np.arange(10)*7+4]]
  for k,arr in enumerate(ims):
   yy=35+(si*3+k)*84;draw.text((3,yy+20),f"{seed}: "+['before release','unperturbed','perturbation 0.1'][k],fill='black')
   for c,img in enumerate(arr):canvas.paste(Image.fromarray((np.clip(img,0,1)*255).astype('uint8')).resize((64,64)),(180+c*72,yy))
 for c in range(10):draw.text((205+c*72,10),str(c),fill='black')
 canvas.save(OUT/'focal_release_examples.png');q.dump(OUT/'complete.json',dict(complete=True,spatial=993,focal=210,weights_unchanged=True))
 print('Stability analysis and figures complete',flush=True)
if __name__=='__main__':
 try:
  while not ((OUT/'spatial_results.json').exists() and (OUT/'focal_results.json').exists()):
   errors=list((OUT/'spatial').glob('*/error.json'))+list(OUT.glob('focal_*/error.json'))
   if errors:raise RuntimeError('Simulation error recorded: '+', '.join(str(p.relative_to(OUT)) for p in errors))
   time.sleep(45)
  summarize()
 except Exception:q.dump(OUT/'analysis_error.json',dict(error=traceback.format_exc()));raise
