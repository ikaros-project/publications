"""Replicate local linear pixel decoding across ten frozen sensory seeds."""
import json,hashlib
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import local_patch_decoder_seed_worker as w
OUT=w.n.CAMPAIGN/'local_linear_patch_decoder_ten_seeds'
SEEDS=list(range(71001,71011))

def write(p,r):p.write_text(json.dumps(r,indent=2)+'\n')
def stats(v):
    a=np.asarray(v);sd=float(a.std(ddof=1));h=2.2621571628540993*sd/np.sqrt(10)
    return dict(mean=float(a.mean()),sd=sd,ci95=[float(a.mean()-h),float(a.mean()+h)])
def run(seed):
    dest=OUT/f'seed{seed}';w.run(seed,dest)
    return seed

def main():
    OUT.mkdir(exist_ok=True)
    first=w.n.CAMPAIGN/'local_linear_patch_decoder_seed1'
    protocol=json.loads((first/'protocol.json').read_text());protocol.pop('seed');protocol.update(seeds=SEEDS,
        selection='Repeat same per-seed validation selection over the fixed lambda grid; no test-based selection. One local decoder fitted per frozen sensory model. Same sampled positions and image split for every seed. Full refit on960000 patches.',
        scope='Replicate first-seed diagnostic across all ten frozen models; seed71001 results reused. Decoding only; latent dynamics and category winners unchanged. No native integration.',
        statistics='Paired seed comparisons on identical10000 test images and220 feedback scenes. Mean, sample SD, descriptive t(9) intervals. Fixed reused dataset, not independent confirmation or100000 independent test images.')
    write(OUT/'protocol.json',protocol);write(OUT/'status.json',dict(stage='running',completed_seeds=[71001],workers=2))
    completed=[71001]
    with ProcessPoolExecutor(max_workers=2) as pool:
        jobs={pool.submit(run,seed):seed for seed in SEEDS[1:]}
        for job in as_completed(jobs):
            completed.append(job.result());write(OUT/'status.json',dict(stage='running',completed_seeds=sorted(completed),workers=2));print(f'Completed {len(completed)}/10 decoder seeds',flush=True)
    records=[];checks=[]
    with np.load(first/'patch_sampling.npz') as z:positions=z['positions'];fit=z['fit_indices'];val=z['validation_indices']
    for seed in SEEDS:
        source=first if seed==71001 else OUT/f'seed{seed}'
        r=json.loads((source/'results.json').read_text());assert r['protocol']['seed']==seed and r['feedback_replay_matches']
        with np.load(source/'patch_sampling.npz') as z:
            np.testing.assert_array_equal(z['positions'],positions);np.testing.assert_array_equal(z['fit_indices'],fit);np.testing.assert_array_equal(z['validation_indices'],val)
        with np.load(source/'local_decoder.npz') as z:
            d=z['decoder'];g=z['gram'];c=z['cross'];count=int(z['patch_count']);lam=float(z['ridge'])
            assert d.shape==(64,49) and count==960000 and np.isfinite(d).all()
            residual=float(np.linalg.norm((g/count+lam*np.eye(64))@d-c/count)/np.linalg.norm(c/count));assert residual<1e-7
        for name,h in r['unchanged_checkpoint_sha256'].items():
            p=w.n.CAMPAIGN/f'hierarchy_s{seed}'/name if name in ['model.state','codebook_final.npz'] else w.n.CAMPAIGN/'neural_readout_regularized_capacity/full_refit'/name
            assert hashlib.sha256(p.read_bytes()).hexdigest()==h
        records.append(dict(seed=seed,source=str(source.relative_to(w.n.CAMPAIGN)),**r));checks.append(dict(seed=seed,normal_equation_relative_residual=residual,matched_patch_sampling=True,unchanged_checkpoints=True))
    def clean(r,src,method,key):return next(v[key] for v in r['clean'] if v['source']==src and v['decoder']==method)
    def feedback(r,mode,method,key):return next(v[key] for v in r['feedback'] if v['mode']==mode and v['decoder']==method)
    aggregate_clean=[];aggregate_feedback=[];comparisons={}
    for src in ['local','upper']:
        for method in ['hard','soft','linear']:
            aggregate_clean.append(dict(source=src,decoder=method,**{key:stats([clean(r,src,method,key) for r in records]) for key in ['raw_mse','clipped_mse','outside_fraction']}))
        delta=[clean(r,src,'linear','clipped_mse')-clean(r,src,'hard','clipped_mse') for r in records]
        relative=[1-clean(r,src,'linear','clipped_mse')/clean(r,src,'hard','clipped_mse') for r in records]
        comparisons[src]=dict(clipped_mse_linear_minus_hard=stats(delta),relative_reduction=stats(relative),improved_seeds=int(np.sum(np.array(delta)<0)),raw_mse_linear_minus_hard=stats([clean(r,src,'linear','raw_mse')-clean(r,src,'hard','raw_mse') for r in records]))
    for mode in ['no_feedback','feedback_after','feedback_during']:
        for method in ['hard','soft','linear']:
            aggregate_feedback.append(dict(mode=mode,decoder=method,**{key:stats([feedback(r,mode,method,key) for r in records]) for key in ['winner_agreement','equal_winner_agreement','dominant_reconstruction','clean_reconstruction','input_mse']}))
        comparisons[mode]=dict(winner_agreement_linear_minus_hard=stats([feedback(r,mode,'linear','winner_agreement')-feedback(r,mode,'hard','winner_agreement') for r in records]))
    write(OUT/'results.json',dict(protocol=protocol,clean=aggregate_clean,feedback=aggregate_feedback,paired_comparisons=comparisons,checks=checks,per_seed=records))
    lines=['# Local linear patch decoder: ten-seed replication','','Same sampled patch positions and54000/6000 image split across seeds. Per-seed local validation selection, full refit on960000 patches from60000 images. Evaluation uses all10000 test images per seed. All encoders, codebooks, upper decoders and200-unit readouts frozen.','', '| Source | Decoder | Clipped MSE mean ± SD | Raw MSE mean |','| --- | --- | ---: | ---: |']
    for r in aggregate_clean:lines.append(f'| {r["source"]} | {r["decoder"]} | {r["clipped_mse"]["mean"]:.6f} ± {r["clipped_mse"]["sd"]:.6f} | {r["raw_mse"]["mean"]:.6f} |')
    for src in ['local','upper']:
        c=comparisons[src];d=c['clipped_mse_linear_minus_hard'];rr=c['relative_reduction'];lines+=['',f'{src}: improved {c["improved_seeds"]}/10 seeds; mean within-seed relative error reduction {rr["mean"]:.2%}. Paired MSE change {d["mean"]:+.6f}, descriptive95% CI [{d["ci95"][0]:+.6f}, {d["ci95"][1]:+.6f}].']
    lines+=['','| Feedback condition | Decoder | Winner agreement mean ± SD (pp) | Dominant reconstruction |','| --- | --- | ---: | ---: |']
    for r in aggregate_feedback:lines.append(f'| {r["mode"]} | {r["decoder"]} | {r["winner_agreement"]["mean"]:.3%} ± {100*r["winner_agreement"]["sd"]:.3f} | {r["dominant_reconstruction"]["mean"]:.3%} |')
    for mode in ['no_feedback','feedback_after','feedback_during']:
        d=comparisons[mode]['winner_agreement_linear_minus_hard'];lines+=['',f'{mode}, linear minus hard winner agreement: {100*d["mean"]:+.3f} pp, descriptive95% CI [{100*d["ci95"][0]:+.3f}, {100*d["ci95"][1]:+.3f}].']
    lines+=['','Selected ridge per seed: '+', '.join(f'{r["seed"]}: {r["selection"]["ridge"]:g}' for r in records)+'.','','Decoder outputs are unbounded. Clipped metrics and recognition clip pixels after overlap averaging; raw errors are also reported. The learned map is fitted only to bottom-up activities, then applied to upper-decoded distributions without upper retraining. Latent feedback trajectories and winners are identical across renderers.','', 'These are paired-seed results on fixed reused images; ten seeds do not supply ten independent test datasets. Seed71001 is reused, not a new replication. This evaluates pixel fidelity and a pixel5NN category proxy separately. Improved fidelity need not improve category agreement. No native Ikaros decoder integration or new default adoption is implied.']
    (OUT/'REPORT.md').write_text('\n'.join(lines)+'\n');write(OUT/'status.json',dict(stage='complete',seeds=10));print('\n'.join(lines),flush=True)

if __name__=='__main__':main()
