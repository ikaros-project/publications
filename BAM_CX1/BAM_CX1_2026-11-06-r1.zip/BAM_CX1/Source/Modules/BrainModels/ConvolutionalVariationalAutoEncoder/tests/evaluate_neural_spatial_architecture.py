"""Staged evaluation of the proposed spatial circuit; frozen object weights."""
import os
os.environ['OPENBLAS_NUM_THREADS']='2';os.environ['VECLIB_MAXIMUM_THREADS']='2'
import json,time
from dataclasses import asdict,replace
import numpy as np
from neural_spatial_rate_model import Frontend,Parameters,Circuit,simulate,phi
from evaluate_spatial_single_stimulus import CAMPAIGN,e
OUT=CAMPAIGN/'neural_spatial_architecture_seed1'

def dump(p,x):p.write_text(json.dumps(x,indent=2,default=lambda v:v.item())+'\n')

def cache():
    OUT.mkdir(exist_ok=True);frontend=Frontend()
    path=OUT/'fixed_input_cache.npz'
    if path.exists():
        with np.load(path) as z:return {k:z[k] for k in z.files}
    raw=e.full.read_idx_images(e.full.RAW_ROOT/'t10k-images-idx3-ubyte.gz',2000)
    labels=e.full.read_idx_labels(e.full.RAW_ROOT/'t10k-labels-idx1-ubyte.gz',2000)
    imgs=np.stack([e.full.center_and_pad(x) for x in raw]).astype(np.float32)/255
    pp=[];plus=[];minus=[];xx=[]
    for j,im in enumerate(imgs):
        views=np.zeros((64,32,32),np.float32)
        for k,d in enumerate(range(-31,32)):
            lo=max(0,d);hi=min(32,32+d);views[k,:,lo:hi]=im[:,lo-d:hi-d]
        p,y=frontend.infer_pixels(views)
        pp.append(p);plus.append(np.maximum(views-y,0).mean((1,2)));minus.append(np.maximum(y-views,0).mean((1,2)));xx.append(views.mean((1,2)))
        if (j+1)%200==0:print('Frozen input cache',j+1,'/2000',flush=True)
    assert frontend.unchanged()
    data=dict(images=imgs,labels=labels,probabilities=np.array(pp),plus=np.array(plus),minus=np.array(minus),mean_x=np.array(xx))
    np.savez_compressed(path,**data);dump(OUT/'checkpoint_hashes.json',frontend.hashes)
    return data

def fixed_run(data,ids,par,placements=(144,),steps=300):
    # Exact omission of blank T/A units for uncued fixed-input inference.
    # Blank M=0 entails T=A=0. Error populations for those omitted units are irrelevant.
    idx=np.array(ids);xs=np.array(placements);offset=np.arange(-31,32)
    mask=((offset[None]<=xs[:,None])&(offset[None]>=xs[:,None]-288))[None]
    n=len(idx);J=len(xs);shape=(n,J,63)
    p=np.broadcast_to(data['probabilities'][idx,None,:63],(*shape,10))
    mx=np.broadcast_to(data['mean_x'][idx,None,:63],shape);plus=np.broadcast_to(data['plus'][idx,None,:63],shape);minus=np.broadcast_to(data['minus'][idx,None,:63],shape)
    ep=np.zeros(shape,np.float32);em=ep.copy();m=ep.copy();t=np.zeros((*shape,10),np.float32);a=ep.copy();c=np.zeros((n,J,10),np.float32)
    for it in range(steps):
        drive=par.k_M*m[...,None]*p*(1+par.k_C*c[:,:,None,:])-par.k_F*em[...,None]-par.theta_T
        nt=.8*t+.2*phi(drive-par.inhibition*(t.sum(-1,keepdims=True)-t));nt*=mask[...,None]
        na=.8*a+.2*phi(par.k_A*t.sum(-1)-par.inhibition*(a.sum(-1,keepdims=True)-a));na*=mask
        z=t.sum(2)/(par.epsilon+t.sum((2,3)))[...,None]
        nc=.8*c+.2*phi(par.k_Z*z-par.inhibition*(c.sum(-1,keepdims=True)-c))
        ne=.8*ep+.2*plus;nf=.8*em+.2*minus;nm=.8*m+.2*np.maximum(mx-ep,0)
        change=np.maximum.reduce([abs(nt-t).max((2,3)),abs(na-a).max(2),abs(nc-c).max(2),abs(ne-ep).max(2),abs(nf-em).max(2),abs(nm-m).max(2)])
        ep,em,m,t,a,c=ne,nf,nm,nt,na,nc
    return dict(category=c.argmax(-1),location=xs[None,:]-(a.argmax(-1)-31),dominance=a.max(-1)/np.maximum(a.sum(-1),1e-30),change=change,category_activity=c,spatial_activity=a)

def main():
    data=cache();par=Parameters()
    # A bounded development sweep, specified before inspecting evaluation outcomes.
    grid=[replace(par,k_F=par.k_M*ratio,k_C=feedback) for feedback in [0.,.25,.5] for ratio in [.5,1.,2.,4.]]
    dump(OUT/'protocol.json',dict(stage='development',development_indices=[0,999],evaluation_indices=[1000,1999],open_loop_grid=[asdict(p) for p in grid],selection='Open-loop development category accuracy; tie by grid order. Closed-loop feasibility then checked on development stimuli before evaluating retained parameters.',fixed_rates='alpha.2 inhibition1.5; kM12 kA1 kZ1 theta0 epsilon1e-6',gain='gammaE5 gammaI4 sigma24',scope='Proposed circuit with exact pooled mismatch populations. No Q/max-category/log-confidence drive or category backpropagation. Frozen existing seed71001.'))
    rows=[]
    for p in grid:
        v=fixed_run(data,range(1000),p)
        row=dict(parameters=asdict(p),accuracy=float((v['category'][:,0]==data['labels'][:1000]).mean()),settled_fraction=float((v['change']<1e-6).mean()),dominance99_fraction=float((v['dominance']>=.99).mean()))
        rows.append(row);print('Development',p.k_F,p.k_C,row['accuracy'],flush=True)
    best=max(range(len(rows)),key=lambda i:rows[i]['accuracy']);dump(OUT/'development.json',dict(rows=rows,selected=best,parameters=asdict(grid[best])))
    np.savez_compressed(OUT/'open_loop_development.npz',**fixed_run(data,range(1000),grid[best]))
    print('SELECTED',asdict(grid[best]),flush=True)
if __name__=='__main__':main()
