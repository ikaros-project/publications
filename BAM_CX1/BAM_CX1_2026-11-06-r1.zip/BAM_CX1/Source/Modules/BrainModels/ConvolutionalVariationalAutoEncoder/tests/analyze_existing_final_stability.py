"""Step1: reanalyse existing final-model trajectories without changing endpoints."""
import json
import numpy as np
from freeze_final_stability_protocol import OUT,C,main as freeze

def times(rate,hold=100):
 good=np.asarray(rate)<5e-6;n=len(good);runs=np.convolve(good.astype(int),np.ones(hold,dtype=int),'valid');ix=np.flatnonzero(runs==hold)
 first=int(ix[0]+hold) if len(ix) else None;bad=np.flatnonzero(~good);after=int(bad[-1]+1) if len(bad) else 0
 stable=after+hold if n-after>=hold else None
 return dict(first_sustained_window_end=first,lastingly_settled_by=stable,first_model_time=None if first is None else first*.1,lastingly_settled_model_time=None if stable is None else stable*.1)
def main():
 freeze();rows=[]
 for campaign,file,folder in [('qmnist_confirmation_20261105','spatial_results.json','spatial'),('qmnist_spatial_extension_20261105','results.json','trials')]:
  root=C/campaign
  for r in json.loads((root/file).read_text()):
   with np.load(root/folder/f"model{r['seed']}_job{r['job']:03d}"/'arrays.npz') as z:rate=z['changes']
   assert len(rate)==600 and bool(max(rate[-100:])<5e-6)==r['settled']
   rows.append(dict(source=campaign,model=r['seed'],job=r['job'],task=r.get('task',r.get('group')),feedback=r['feedback'],settled=r['settled'],correct=r.get('located'),**times(rate)))
 groups=[]
 for source,task,fb in sorted(set((r['source'],r['task'],r['feedback']) for r in rows)):
  rr=[r for r in rows if (r['source'],r['task'],r['feedback'])==(source,task,fb)];v=[r['lastingly_settled_model_time'] for r in rr if r['lastingly_settled_model_time'] is not None]
  groups.append(dict(source=source,task=task,feedback=fb,n=len(rr),nonsettled=sum(not r['settled'] for r in rr),median_settling_model_time=None if not v else float(np.median(v)),by_model=[dict(model=s,n=sum(r['model']==s for r in rr),nonsettled=sum(r['model']==s and not r['settled'] for r in rr)) for s in [71001,71002,71003]]))
 focal=json.loads((C/'qmnist_confirmation_20261105/focal_results.json').read_text())
 out=dict(spatial_n=len(rows),spatial_nonsettled=sum(not r['settled'] for r in rows),focal_n=len(focal),focal_nonsettled=sum(not r['settled'] for r in focal),focal_settling_times_available=False,groups=groups,rows=rows)
 (OUT/'existing_trajectory_analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='rows'},indent=2))
if __name__=='__main__':main()
