"""Matched overlap pilot. Frozen model, max-union stimuli, no outcome tuning."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['VECLIB_MAXIMUM_THREADS']='1'
import argparse,concurrent.futures,hashlib,json,time
from pathlib import Path
from dataclasses import replace,asdict
import numpy as np
import run_spatial_content_feedback as r
from cached_spatial_content_feedback import CachedFrontend,CachedLocalFeedback
from neural_spatial_rate_model import Circuit,windows
from spatial_content_feedback import render_scene
ROOT=r.OUT/'spatial_overlap_pilot'
PAR=replace(r.PAR,binding_relative_evidence=True)
FRONT=None
METHODS={'bottom_up':(False,False,None),'uncued_combined':(True,True,None),
         'spatial_A':(False,True,'spatial_A'),'spatial_B':(False,True,'spatial_B'),
         'combined_spatial_A':(True,True,'spatial_A'),'combined_spatial_B':(True,True,'spatial_B'),
         'category_A':(False,True,'category_A'),'category_B':(False,True,'category_B'),
         'combined_category_A':(True,True,'category_A'),'combined_category_B':(True,True,'category_B')}

def init():
    global FRONT
    FRONT=CachedFrontend();FRONT.ids=FRONT.references()
    assert FRONT.hashes==json.loads((r.OUT/'checkpoint_hashes.json').read_text())

def prepare():
    ROOT.mkdir(exist_ok=True)
    if (ROOT/'protocol.json').exists():return
    init()
    raw=r.e.full.read_idx_images(r.e.full.RAW_ROOT/'t10k-images-idx3-ubyte.gz',10000)
    lab=r.e.full.read_idx_labels(r.e.full.RAW_ROOT/'t10k-labels-idx1-ubyte.gz',10000)
    cats=[(3,8),(4,9),(1,7)];used={};screen=[]
    for cat in sum([list(p) for p in cats],[]):
        for i in np.flatnonzero(lab[9000:10000]==cat)+9000:
            im=r.e.full.center_and_pad(raw[i]).astype(np.float32)/255
            prob,_=FRONT.infer_pixels(im[None]);accepted=int(prob[0].argmax())==cat
            screen.append(dict(category=cat,index=int(i),predicted=int(prob[0].argmax()),accepted=accepted))
            if accepted:used[cat]=(int(i),im);break
        else:raise RuntimeError('No isolated recognizable image')
    rows=[];components=[];scenes=[];jobs=[];aliases=[]
    for pair,(ca,cb) in enumerate(cats):
        for separation in [0,4,8,40]:
            pa=144-separation//2;pb=144+separation//2
            comp=np.zeros((2,32,320),np.float32)
            for k,(cat,pos) in enumerate([(ca,pa),(cb,pb)]):comp[k,:,pos:pos+32]=used[cat][1]
            row=dict(case=len(rows),pair=pair,categories=[ca,cb],test_indices=[used[ca][0],used[cb][0]],positions=[pa,pb],separation=separation,kind='pair')
            rows.append(row);components.append(comp);scenes.append(np.maximum(*comp))
            for name in METHODS:
                if separation==0 and name in ['spatial_B','combined_spatial_B']:
                    aliases.append(dict(case=row['case'],method=name,source=name.replace('_B','_A')))
                else:jobs.append([row['case'],name])
        for k,cat in enumerate([ca,cb]):
            comp=np.zeros((2,32,320),np.float32);comp[0,:,144:176]=used[cat][1]
            row=dict(case=len(rows),pair=pair,categories=[cat,-1],test_indices=[used[cat][0],-1],positions=[144,144],separation=None,kind='isolated')
            rows.append(row);components.append(comp);scenes.append(comp[0])
            jobs += [[row['case'],name] for name in ['bottom_up','spatial_A','combined_spatial_A']]
    np.savez_compressed(ROOT/'stimuli.npz',input=scenes,components=components)
    r.dump(ROOT/'stimuli.json',rows);r.dump(ROOT/'jobs.json',jobs);r.dump(ROOT/'aliases.json',aliases)
    r.dump(ROOT/'protocol.json',dict(network_seed=71001,parameters=asdict(PAR),updates=600,early_stop=False,total_unique_runs=len(jobs),pairs=cats,selection='First correctly classified isolated example of each chosen digit in MNIST test indices9000:10000, in dataset order. Classification uses the frozen feedforward frontend, before any overlap outcomes. Demonstration sample, not an unbiased recognition estimate.',screening=screen,geometry='32x320,351 stride-one fields including zero extension; symmetric tile starts around144, separations0,4,8,40. Maximum pixelwise union (no blending or added intensity). Forty pixels is a separated-object control. Partial refers to tile overlap; actual shared foreground counts are reported.',methods=METHODS,controls='All conditions share within-field normalization, instantaneous sensory mismatch, local-code lag and fixed reference choices. Bottom-up: sensory gain disabled, content feedback disabled, category-to-binding and category-to-spatial weighting disabled (kC=eta=0); endogenous binding/spatial/category competitions remain for output pooling. All other conditions retain the adopted parameters. Spatial and category cues have strength2. Identical spatial cues at full overlap are run once and reused in both directions.',scoring='Global category is scored only without category cue. Under category cues report unforced local readout and reconstructions, with binding as a biased internal signal. Primary whole-canvas reconstruction is the existing uniform average of all field predictions, with no selected-location mask; measure intensities on A-unique, B-unique and shared pixels. Unique masks: own>=.25 and other<=.05; shared both>=.25. Also report fixed A/B-aligned field reconstructions with explicit mask coverage, never treat pixels outside a field as suppressed. Use paired cue reversals and matched feedback-off contrasts to distinguish selective effects from general reconstruction attenuation. Isolated targets provide reconstruction/recognition controls. No population confidence intervals from three pairs.',settling='All seven spatial populations plus code state: max update/alpha below5e-6 across final100 updates. Fixed600 endpoints including failures. No extended oscillation tests.',source_sha256={n:hashlib.sha256(Path(__file__).with_name(n).read_bytes()).hexdigest() for n in ['run_spatial_overlap_pilot.py','spatial_content_feedback.py','cached_spatial_content_feedback.py','neural_spatial_rate_model.py']},checkpoint_hashes=FRONT.hashes))
    print('PREPARED',len(jobs),'unique runs',flush=True)

def masks(comp):
    a,b=comp
    return {'A_unique':(a>=.25)&(b<=.05),'B_unique':(b>=.25)&(a<=.05),'shared':(a>=.25)&(b>=.25),'union':np.maximum(a,b)>.05}

def scores(y,comp,region=None):
    mm=masks(comp);out={}
    for key,mask in mm.items():
        if region is not None:mask=mask&region
        out[key+'_pixels']=int(mask.sum())
        out[key+'_mean']=float(y[mask].mean()) if mask.any() else None
    roi=mm['union'] if region is None else mm['union']&region
    for k,label in enumerate(['A','B']):out[label+'_mse']=float(((y-comp[k])**2)[roi].mean()) if roi.any() else None
    return out

def worker(job):
    j,name=job;folder=ROOT/f'case{j:02d}_{name}';folder.mkdir(exist_ok=True)
    if (folder/'result.json').exists():return json.loads((folder/'result.json').read_text())
    meta=json.loads((ROOT/'stimuli.json').read_text())[j]
    with np.load(ROOT/'stimuli.npz') as z:x=z['input'][j];comp=z['components'][j]
    feedback,attention,cue=METHODS[name]
    par=PAR if name!='bottom_up' else replace(PAR,k_C=0.,category_spatial_eta=0.)
    c=Circuit(x[None],par,closed=attention,padding=31);local=CachedLocalFeedback(FRONT,c,feedback,True)
    u=np.zeros_like(c.a);v=np.zeros_like(c.c)
    target=None
    if cue:
        target=0 if cue.endswith('A') else 1
        if cue.startswith('spatial'):u[0,meta['positions'][target]+31]=2
        else:v[0,meta['categories'][target]]=2
    changes=[];ct=[];at=[];gt=[];snap={};start=time.time()
    for tick in range(601):
        prob,y=FRONT.evidence(local.q)
        if tick in [0,8,32,128,300,600]:
            snap[f't{tick}_render']=render_scene(y,320)
            snap[f't{tick}_fields']=y[np.array(meta['positions'])+31].copy()
        if tick==600:break
        new,dq,gate=local.propose(c)
        _,sensory_prediction=FRONT.infer_pixels(windows(c.s,31)[0])
        change=c.update(prob[None],sensory_prediction[None],u=u,v=v);local.q=new
        changes.append(max(float(change[0]),dq)/par.alpha)
        ct.append(c.c[0].copy());at.append(c.a[0].copy());gt.append(c.gain()[0].copy())
        if (tick+1)%100==0:r.dump(folder/'progress.json',dict(tick=tick+1,seconds=time.time()-start,rate=changes[-1]))
    assert FRONT.unchanged()
    assert np.isfinite(local.q).all() and np.isfinite(y).all()
    np.testing.assert_allclose(local.q.sum(1),1,atol=1e-5)
    result=c.result();render=render_scene(y,320);fieldstats=[]
    for pos in meta['positions']:
        region=np.zeros_like(x,bool);region[:,pos:pos+32]=True
        yy=np.zeros_like(x);yy[:,pos:pos+32]=y[pos+31]
        fieldstats.append(scores(yy,comp,region))
    selected=int(result['location'][0]);selectedidx=selected+31
    row=dict(**meta,method=name,cued_object=target,category_cued=bool(cue and cue.startswith('category')),updates=600,seconds=time.time()-start,settled=bool(np.max(changes[-100:])<5e-6),last_rate=changes[-1],category=int(c.c[0].argmax()) if c.c.sum()>1e-7 else -1,category_mass=float(c.c.sum()),location=selected,spatial_mass=float(c.a.sum()),field_categories=prob[np.array(meta['positions'])+31].argmax(1).tolist(),selected_field_category=int(prob[selectedidx].argmax()),render_scores=scores(render,comp),input_scores=scores(x,comp),field_scores=fieldstats,weights_unchanged=True)
    np.savez_compressed(folder/'arrays.npz',**snap,final_render=render,final_field_predictions=y,final_probability=prob,final_sensory=c.s[0],final_binding=c.t[0],category_trace=ct,spatial_trace=at,gain_trace=gt,changes=changes,reference_slots=local.chosen,reference_ids=FRONT.ids)
    r.dump(folder/'result.json',row);print('DONE',j,name,round(row['seconds'],1),flush=True)
    return row

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--workers',type=int,default=12);args=ap.parse_args()
    prepare()
    if args.prepare:return
    jobs=json.loads((ROOT/'jobs.json').read_text());start=time.time();rows=[]
    # Run isolated and separated controls early, without changing the fixed sample.
    meta=json.loads((ROOT/'stimuli.json').read_text())
    jobs.sort(key=lambda j:(meta[j[0]]['kind']!='isolated',meta[j[0]]['separation']!=40,j[0]))
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers,initializer=init) as pool:
        futures=[pool.submit(worker,j) for j in jobs]
        for f in concurrent.futures.as_completed(futures):
            rows.append(f.result());r.dump(ROOT/'status.json',dict(completed=len(rows),total=len(jobs),seconds=time.time()-start,workers=args.workers))
    r.dump(ROOT/'results.json',dict(cases=sorted(rows,key=lambda x:(x['case'],x['method'])),aliases=json.loads((ROOT/'aliases.json').read_text())))
    print('OVERLAP PILOT COMPLETE',flush=True)
if __name__=='__main__':main()
