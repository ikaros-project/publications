"""Prespecified crossed model/stimulus bootstrap and confirmation report."""
import json,csv
import numpy as np
import qmnist_confirmation_common as q
OUT=q.OUT

def stats(rows,task,level,metric,spatial=False):
 rr=[r for r in rows if r['task']==task and (level=='all' or (r['deletion'] if spatial else r['level'])==level)]
 seeds=q.protocol()['models'];clusters=sorted(set(str(r['pair'] if spatial else r['cluster']) for r in rr));arr=np.full((len(seeds),len(clusters),2),np.nan)
 for a,s in enumerate(seeds):
  for j,c in enumerate(clusters):
   for on in [False,True]:
    vv=[float(r[metric]) for r in rr if r['seed']==s and str(r['pair'] if spatial else r['cluster'])==c and r['feedback']==on and r[metric] is not None]
    if vv:arr[a,j,int(on)]=np.mean(vv)
 valid=np.isfinite(arr).all((0,2));arr=arr[:,valid]
 if arr.shape[1]==0:return None
 delta=arr[:,:,1]-arr[:,:,0];rng=np.random.default_rng(2026110508);boots=[]
 for _ in range(2000):
  si=rng.integers(0,len(seeds),len(seeds));ci=rng.integers(0,arr.shape[1],arr.shape[1]);boots.append(float(delta[np.ix_(si,ci)].mean()))
 return dict(task=task,level=level,metric=metric,clusters=int(arr.shape[1]),models=len(seeds),off=float(arr[:,:,0].mean()),on=float(arr[:,:,1].mean()),difference=float(delta.mean()),ci95=np.quantile(boots,[.025,.975]).tolist(),by_model=[dict(model=s,off=float(arr[a,:,0].mean()),on=float(arr[a,:,1].mean()),difference=float(delta[a].mean())) for a,s in enumerate(seeds)])

def main():
 focal=json.loads((OUT/'focal_results.json').read_text());spatial=json.loads((OUT/'spatial_results.json').read_text());assert len(focal)==6210 and len(spatial)==480
 summaries=[]
 for task,levels in [('clean',[0]),('occlusion',[8,12]),('noise',[.25,.5]),('mixture',['all',.25,.5,.75])]:
  for level in levels:
   for metric in ['agreement','category_correct','pixel_correct','clean_mse','input_mse','hidden_mse','visible_mse','switched','settled']:
    r=stats(focal,task,level,metric)
    if r:summaries.append(r)
 for task,levels in [('completion',[0,8,12]),('category_search',[0])]:
  for level in levels:
   for metric in ['located','category_correct','local_category_correct','target_hidden_mse','target_visible_mse','selected_hidden_mse','selected_visible_mse','settled']:
    r=stats(spatial,task,level,metric,True)
    if r:summaries.append(r)
 checks={str(s):{str(p.relative_to(q.C)):q.sha(p)==q.protocol()['checkpoint_sha256'][str(p.relative_to(q.C))] for p in q.paths(s)} for s in q.protocol()['models']}
 assert all(all(v.values()) for v in checks.values())
 out=dict(protocol_sha256=q.sha(OUT/'protocol.json'),n_focal=len(focal),n_spatial=len(spatial),focal_settled=sum(r['settled'] for r in focal),spatial_settled=sum(r['settled'] for r in spatial),source_independence=json.loads((OUT/'stimuli_manifest.json').read_text()),checkpoint_checks=checks,summaries=summaries)
 q.dump(OUT/'summary.json',out)
 with (OUT/'summary.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['task','level','metric','clusters','models','off','on','difference','ci_low','ci_high']);w.writeheader()
  for r in summaries:w.writerow({**{k:r[k] for k in w.fieldnames if k in r},'ci_low':r['ci95'][0],'ci_high':r['ci95'][1]})
 lines=['# Independent-image QMNIST confirmation','', '## Frozen protocol and scope','', 'The scientific protocol was frozen before downloading or evaluating QMNIST. The additional test split (zero-based indices 10000–59999) supplied 230 distinct sampled images: 100 focal source digits, 90 digits in 45 category pairs and 40 digits in 20 spatial pairs. Source identifiers were disjoint from the original MNIST training and test samples. None of the selected raw images exactly matched those samples. This is new-image confirmation, not an independent writer population. Selection was label-stratified and outcome-independent.','', 'Three existing models were selected in training order, with their own unchanged eight-reference banks, encoders, decoders and readouts. There was no retraining, tuning or performance screening. All 6,210 focal and 480 spatial endpoints were retained. Each focal source image had three independent noise realizations per noise level, shared across models and feedback conditions. Spatial tests used the original320-pixel-wide display, stride-one processing and600 updates.','', f"Settled endpoints: {out['focal_settled']}/6210 focal and {out['spatial_settled']}/480 spatial. All checkpoint hashes remained unchanged.",'', '## Paired results','', 'Values are means across models and source-image/pair clusters. Differences are feedback on minus off. Intervals are 95% percentile intervals from 2,000 crossed bootstrap resamples of models and stimulus clusters. Noise realizations and mixture variants remain within their original cluster. With only three models, model-level uncertainty remains imprecisely estimated. These are not independent trial-level intervals.','', '| Task | Level | Measure | Off | On | Difference [95% interval] |','| --- | --- | --- | ---: | ---: | --- |']
 selected=[]
 for r in summaries:
  keep=(r['task']=='clean' and r['metric']=='category_correct') or (r['task']=='mixture' and r['level']=='all' and r['metric'] in ['agreement','category_correct','clean_mse']) or (r['task']=='noise' and r['metric'] in ['agreement','category_correct','clean_mse']) or (r['task']=='occlusion' and r['metric'] in ['agreement','hidden_mse','visible_mse']) or (r['task']=='completion' and r['metric'] in ['located','category_correct','target_hidden_mse','target_visible_mse']) or (r['task']=='category_search' and r['metric'] in ['located','local_category_correct'])
  if not keep:continue
  selected.append(r);israte=r['metric'] in ['agreement','category_correct','located','local_category_correct'];fac=100 if israte else 1;fmt=lambda v:f'{v*fac:.2f}'+('%' if israte else '') if israte else f'{v:.5f}'
  lines.append(f"| {r['task']} | {r['level']} | {r['metric']} | {fmt(r['off'])} | {fmt(r['on'])} | {fmt(r['difference'])} [{fmt(r['ci95'][0])}, {fmt(r['ci95'][1])}] |")
 lines+=['','Accuracy is undefined for equal mixtures. Category-cued search is scored by localization and unforced local recognition, not the externally driven global category. Mixture MSE compares with the physical mixture. Occlusion MSE separates hidden from visible regions. Selected-field metrics are in the full summary and use matching scene coordinates.','', '## Reproducibility','', 'The output folder contains the frozen protocol and hash, download checksums, source-image identifiers, stimulus files, per-case endpoints, model checks, confidence intervals and figures. The original manuscript and response letters were not changed.']
 text='\n'.join(lines)+'\n';(OUT/'REPORT.md').write_text(text);(q.STUDY/'Manuscript/qmnist_confirmation_source_notes.md').write_text(text)
 print(json.dumps(dict(focal_settled=out['focal_settled'],spatial_settled=out['spatial_settled'],main_results=selected),indent=2))
if __name__=='__main__':main()
