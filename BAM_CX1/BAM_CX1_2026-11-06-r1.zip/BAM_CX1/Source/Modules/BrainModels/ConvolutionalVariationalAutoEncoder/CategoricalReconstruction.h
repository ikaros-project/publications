#pragma once
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace categorical
{
    inline void softmax(float * values, float * log_probabilities, int channels, int positions)
    {
        for(int p = 0; p < positions; ++p)
        {
            float maximum = values[p];
            for(int c = 1; c < channels; ++c)
                maximum = std::max(maximum, values[c * positions + p]);
            double sum = 0;
            for(int c = 0; c < channels; ++c)
                sum += std::exp(double(values[c * positions + p] - maximum));
            const double log_sum = std::log(sum);
            for(int c = 0; c < channels; ++c)
            {
                const int i = c * positions + p;
                log_probabilities[i] = float(double(values[i] - maximum) - log_sum);
                values[i] = std::exp(log_probabilities[i]);
            }
        }
    }

    inline float cross_entropy(const float * logs, const float * target, float * terms, int channels, int positions)
    {
        double loss = 0;
        for(int p = 0; p < positions; ++p)
        {
            double mass = 0;
            for(int c = 0; c < channels; ++c)
            {
                const int i = c * positions + p;
                if(!std::isfinite(target[i]) || target[i] < 0)
                    throw std::runtime_error("Categorical target must be finite and nonnegative.");
                mass += target[i];
                terms[i] = -target[i] * logs[i];
                loss += terms[i];
            }
            if(std::abs(mass - 1.0) > 1e-5)
                throw std::runtime_error("Categorical target must sum to one at each location.");
        }
        return float(loss / positions);
    }
}
