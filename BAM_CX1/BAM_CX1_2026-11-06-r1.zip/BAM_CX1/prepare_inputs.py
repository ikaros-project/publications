"""Copy preserved selections and input arrays into an empty execution tree."""
from pathlib import Path
import shutil
ROOT=Path(__file__).resolve().parent
allowed={'stimuli.json','stimuli.npz','cases.json','reference_indices.json','selection.json','split_indices.npz'}
def main():
    source=ROOT/'reference_results'/'UserData';count=0
    for p in source.rglob('*'):
        if not p.is_file():continue
        keep=p.name in allowed or (p.name=='arrays.npz' and p.parent.name in {'shared_stroke_candidates','spatial_two_objects_seed1'})
        if not keep:continue
        dest=ROOT/'UserData'/p.relative_to(source)
        if dest.exists():
            if dest.read_bytes()!=p.read_bytes():raise RuntimeError('Existing input differs: '+dest.relative_to(ROOT).as_posix())
            continue
        dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);count+=1
    print('Prepared',count,'input/selection files. Historical result files remain separate.')
if __name__=='__main__':main()
