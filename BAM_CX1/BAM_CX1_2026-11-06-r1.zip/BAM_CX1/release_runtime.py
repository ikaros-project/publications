"""Portable inference using the released numerical arrays and original model equations."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('VECLIB_MAXIMUM_THREADS','1')
from pathlib import Path
import json,hashlib,sys
import numpy as np
ROOT=Path(__file__).resolve().parent
TEST=ROOT/'Source/Modules/BrainModels/ConvolutionalVariationalAutoEncoder/tests'
sys.path.insert(0,str(TEST))
EVIDENCE=ROOT/'reference_results/revision'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load_model(seed):
 from cached_spatial_content_feedback import CachedFrontend
 import evaluate_reference_bank_sensitivity as b
 path=ROOT/'weights'/f'model_{seed}.npz'
 if not path.exists():raise FileNotFoundError('Extract the separate trained-weights archive beside the code archive first.')
 assert sha(path)==read(ROOT/'WEIGHTS_MANIFEST.json')[path.name]['sha256'],'Weight checksum mismatch'
 with np.load(path,allow_pickle=False) as z:
  m={k:z['upper_'+v].copy() for k,v in [('enc','DIRECT_MEAN_WEIGHTS'),('eb','DIRECT_MEAN_BIAS'),('dec','DIRECT_DECODER_WEIGHTS'),('db','DIRECT_DECODER_BIAS')]}
  m.update(book=b.original.f.prior.Codebook(z['prototypes']),rw=z['readout_weights'],rb=z['readout_bias'],decoder=z['pixel_decoder'],ids=z['reference_ids'],paths=[path]);rc=z['reference_codes'];codes=np.zeros((60000,128),np.float32);codes[m['ids']]=rc;m['codes']=codes
  if 'reference_pixels' in z:m['reference_pixels']=z['reference_pixels']
 front=CachedFrontend.__new__(CachedFrontend)
 for k in ['enc','eb','dec','db','book','rw','rb','decoder']:setattr(front,k,m[k])
 front.paths=[path];front.hashes=[sha(path)];front.ids=m['ids'];front.rc=rc;front.rp=front.decode(rc.reshape(80,128)).reshape(10,8,64,676);front.counts=np.zeros((32,32),np.float32)
 for dy in range(7):
  for dx in range(7):front.counts[dy:dy+26,dx:dx+26]+=1
 return m,front

def focal(seed=71001,start=0,count=3,mode='full',dataset='qmnist',bank=0,size=8,random_decoder=None,fraction=0.,realization=0):
 import evaluate_reference_bank_sensitivity as b
 import evaluate_fixed_category_weights as fixed
 m,front=load_model(seed)
 source=EVIDENCE/('qmnist_confirmation_20261105/focal_stimuli.npz' if dataset=='qmnist' else 'reference_bank_sensitivity_20261026/stimuli.npz')
 with np.load(source,allow_pickle=False) as z:x=z['input'][start:start+count]
 m['b']=np.stack([m['book'].process(im,False,.01,.08)[0].reshape(64,676) for im in x]);m['z0']=m['b'].reshape(len(x),-1)@m['enc']+m['eb'];ids=m['ids']
 if size!=8 or bank:
  assert seed==71001,'Alternative banks were evaluated only for the first model.'
  with np.load(ROOT/'weights/alternative_reference_codes.npz',allow_pickle=False) as z:m['codes'][z['ids']]=z['codes']
  ids=np.array(read(EVIDENCE/'reference_bank_sensitivity_20261026/reference_banks.json')[str(bank)])[:,:size]
 if random_decoder:
  assert 0<=fraction<=1 and 0<=realization<5
  key='decoder' if random_decoder=='patch' else 'dec';a=m[key];rng=np.random.default_rng(2026110501+realization+(1000 if key=='decoder' else 0));order=rng.permutation(a.size);replacement=rng.normal(float(a.astype(np.float64).mean()),float(a.astype(np.float64).std()),a.size).astype(np.float32);new=a.copy().ravel();idx=order[:int(fraction*a.size)];new[idx]=replacement[idx];m[key]=new.reshape(a.shape)
 if mode in ['full','none']:res=b.simulate(m,ids,feedback=mode=='full')
 elif mode=='fixed':res=fixed.simulate(m,ids,'fixed')
 else:
  p=b.probs(m,m['z0']);winner=p.argmax(1);rc=m['codes'][ids];chosen=((m['z0'][:,None,None]-rc[None])**2).sum(3).argmin(2)
  if mode=='direct':images=b.render(m,rc[winner,chosen[np.arange(len(x)),winner]])
  elif mode=='pixel':
   assert size==8 and bank==0;images=m['reference_pixels'][winner,chosen[np.arange(len(x)),winner]]
  elif mode=='single':
   a=p/p.max(1,keepdims=True);an=.8*a+.2*np.maximum(p/p.max(1,keepdims=True)-1.5*(a.sum(1,keepdims=True)-a),0);w=an/an.sum(1,keepdims=True);rp=b.decode(m,rc.reshape(-1,128)).reshape(10,size,64,676);Q=np.zeros_like(m['b'])
   for c in range(10):Q+=w[:,c,None,None]*rp[c,chosen[:,c]]
   pn=.8*m['b']+.2*(.5*m['b']+.5*Q);images=b.render(m,pn.reshape(len(x),-1)@m['enc']+m['eb']);winner=an.argmax(1)
  else:raise ValueError(mode)
  res=dict(images=images,acts=winner[None,:,None],chosen=chosen)
 return res

def spatial(seed=71001,job=1,source='confirmation',mode='full',steps=600,config=None,perturb=None):
 from neural_spatial_rate_model import Circuit,windows
 from run_spatial_population_feedback import PopulationFeedback
 from run_spatial_overlap_pilot import PAR
 from run_spatial_pathway_ablation import AblationCircuit
 from spatial_content_feedback import render_scene
 from dataclasses import replace
 if source=='confirmation':
  directory=EVIDENCE/'qmnist_confirmation_20261105';jobs=read(directory/'spatial_jobs.json');j=jobs[job];meta=read(directory/'spatial_stimuli.json')[j['case']];sc=meta['target_position'] if j['task']=='completion' else None;cc=meta['target_category'] if j['task']=='category_search' else None;data='spatial_stimuli.npz'
 else:
  directory=EVIDENCE/'qmnist_spatial_extension_20261105';j=read(directory/'jobs.json')[job];meta=read(directory/'stimuli.json')[j['case']];sc=j['spatial_cue'];cc=j['category_cue'];data='stimuli.npz'
 with np.load(directory/data,allow_pickle=False) as z:x=z['input'][j['case']]
 _,front=load_model(seed);c=AblationCircuit(x[None],mode);cfg=config or {};c.par=replace(c.par,alpha=cfg.get('alpha',.1),inhibition=cfg.get('inhibition',1.5));local=PopulationFeedback(front,c,j['feedback'] and mode not in ['no_content','no_gain_no_content'],True);local.maximum=cfg.get('maximum',.65)
 u=np.zeros_like(c.a);v=np.zeros_like(c.c)
 if sc is not None:u[0,sc+31]=cfg.get('spatial_cue',2.)
 if cc is not None:v[0,cc]=cfg.get('category_cue',2.)
 changes=[];ct=[];at=[]
 for tick in range(steps):
  prob,y=front.evidence(local.q);new,dq,_=local.propose(c);_,pred=front.infer_pixels(windows(c.s,31)[0]);d=c.update(prob[None],pred[None],u=u,v=v);local.q=new;changes.append(max(float(d[0]),dq)/c.par.alpha);ct.append(c.c[0].copy());at.append(c.a[0].copy())
 prob,y=front.evidence(local.q)
 return dict(final_field_predictions=y,final_probability=prob,final_render=render_scene(y,320),category_trace=np.array(ct),spatial_trace=np.array(at),changes=np.array(changes),reference_slots=local.chosen)
