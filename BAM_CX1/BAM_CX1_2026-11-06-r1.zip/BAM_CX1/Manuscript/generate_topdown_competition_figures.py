"""Derive manuscript figures from frozen saved results; no new inference."""
from pathlib import Path
import sys,json,csv
import numpy as np
from PIL import Image,ImageDraw,ImageFont
M=Path(__file__).resolve().parent
sys.path.insert(0,str(M.parent/'Source/Modules/BrainModels/ConvolutionalVariationalAutoEncoder/tests'))
import evaluate_relaxation_full_mixtures as e
r=json.loads((e.OUT/'results.json').read_text());cases=r['cases']
with (M/'topdown_competition_mixture.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['fraction']+[f'{m}_{c}_{stat}' for m in ['none','relaxation'] for c in ['3','8','other'] for stat in ['mean','sd']])
 for frac in np.arange(11)/10:
  row=[frac]
  for method in ['none','relaxation']:
   for cat in [3,8,'other']:
    vals=[]
    for seed in range(71001,71011):
     rr=[x for x in cases if x['method']==method and x['seed']==seed and abs(x['mix']-frac)<1e-8];assert len(rr)==20
     vals.append(np.mean([x['final_winner']==cat if cat!='other' else x['final_winner'] not in [3,8] for x in rr]))
    row.extend([np.mean(vals)*100,np.std(vals,ddof=1)*100])
  w.writerow(row)
with np.load(e.OUT/'seed71001.npz') as z:
 a=z['activities'][:,:,37];snaps=z['snapshots'][:,:,37];inp=z['input'][37];steps=z['steps']
with (M/'topdown_competition_example_trace.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['step']+[f'{m}_{c}' for m in ['none','relaxation'] for c in range(10)])
 for t in range(65):w.writerow([t,*a[0,t],*a[2,t]])
font=ImageFont.load_default(size=22)
canvas=Image.new('RGB',(1180,370),'white');d=ImageDraw.Draw(canvas)
for row,mi in enumerate([0,2]):
 y=55+row*155;d.text((8,y+52),'No feedback' if row==0 else 'Feedback 50%',fill='black',font=font)
 for col,t in enumerate([None,0,8,32,500]):
  v=inp if t is None else snaps[mi,list(steps).index(t)]
  im=Image.fromarray(np.uint8(np.clip(v,0,1)*255)).resize((128,128),Image.Resampling.NEAREST).convert('RGB');x=220+col*186;canvas.paste(im,(x,y))
  if row==0:d.text((x,15),'Input' if t is None else f'Update {t}',fill='black',font=font)
canvas.save(M/'topdown_competition_example_images.png')
summary={}
for key in ['final_winner_agreement','equal_winner_agreement','dominant_category_selection']:
 ds=[next(x[key] for x in r['per_seed'] if x['seed']==s and x['method']=='relaxation')-next(x[key] for x in r['per_seed'] if x['seed']==s and x['method']=='none') for s in range(71001,71011)]
 half=2.262157*np.std(ds,ddof=1)/np.sqrt(10);summary[key]={'difference':float(np.mean(ds)),'ci95':[float(np.mean(ds)-half),float(np.mean(ds)+half)]}
(M/'topdown_competition_figure_metrics.json').write_text(json.dumps(summary,indent=2)+'\n')
