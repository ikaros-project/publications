"""Figures from saved no-input relaxation results; no inference or learning."""
from pathlib import Path
import json
import numpy as np
from PIL import Image,ImageDraw,ImageFont
MAN=Path(__file__).resolve().parent
BASE=MAN.parent/'UserData/output/cvae_mnist_two_layer/n60000_test10000_ticks1800000_patch_codebook64_kernel7_valid_upper128_soft_tau_0p08_upper_categorical'
with np.load(BASE/'category_generation_seed1/arrays.npz') as a:direct=a['direct_images'].copy()
with np.load(BASE/'feedback_stability_methods_seed1/noise_relaxation.npz') as a:snap=a['snapshots'].copy();ch=a['changes'][:,:,0].copy()
steps=[0,8,32,64,128,200,300,400,500]
font=ImageFont.load_default(size=25)
def grid(path,panels,rowlabels,collabels):
 cell=130;left=180;top=50;gap=32
 can=Image.new('RGB',(left+cell*len(collabels),top+(cell+gap)*len(panels)),'white');d=ImageDraw.Draw(can)
 for j,label in enumerate(collabels):d.text((left+cell*j+8,8),label,fill='black',font=font)
 for i,(row,label) in enumerate(zip(panels,rowlabels)):
  y=top+i*(cell+gap);d.text((10,y+45),label,fill='black',font=font)
  for j,img in enumerate(row):can.paste(Image.fromarray(np.uint8(np.clip(img,0,1)*255)).resize((118,118),Image.Resampling.NEAREST),(left+cell*j,y))
 can.save(MAN/path)
grid('category_imagery_overview.png',[[direct[c*8] for c in range(10)],[snap[-1,c*8] for c in range(10)]],['Direct','Relaxation'],[str(c) for c in range(10)])
grid('category_imagery_iterations.png',[[snap[steps.index(t),c*8] for t in [0,8,32,64,500]] for c in [3,5,8]],['Category 3','Category 5','Category 8'],['0','8','32','64','500'])
# Preserve measured zeros in raw data; clipping is only for logarithmic plotting.
err=((snap-snap[-1])**2).mean((2,3))
np.savetxt(MAN/'category_imagery_activity.csv',np.c_[np.arange(1,501),ch.mean(1),ch.max(1)],delimiter=',',header='iteration,mean_change,max_change',comments='')
np.savetxt(MAN/'category_imagery_image_error.csv',np.c_[steps,err.mean(1)],delimiter=',',header='iteration,mean_mse',comments='')
tail=np.maximum.accumulate(ch[::-1],axis=0)[::-1];first=np.argmax(tail<1e-5,axis=0)+1
(MAN/'category_imagery_figure_metrics.json').write_text(json.dumps(dict(settling_min=int(first.min()),settling_median=float(np.median(first)),settling_max=int(first.max()),snapshot_steps=steps,mean_image_mse_to_final=err.mean(1).tolist(),max_final_activity_change=float(ch[-1].max()),selection='First stored reference in each category; iteration rows3,5,8. No outcome-based exemplar selection. Stable relaxation only.',sources=['category_generation_seed1/arrays.npz:direct_images','feedback_stability_methods_seed1/noise_relaxation.npz:snapshots,changes']),indent=2)+'\n')
