"""Recompute all 120 selected-field completion scores from compact original endpoints."""
from pathlib import Path
import json
import numpy as np
ROOT=Path(__file__).resolve().parent

def main():
 p=ROOT/'reference_results/revision/selected_field_analysis_20261105'
 result=json.loads((p/'results.json').read_text());checked=0
 with np.load(p/'selected_field_endpoints.npz',allow_pickle=False) as z:
  for i,row in enumerate(result['rows']):
   assert int(z['spatial_activity'][i].argmax())-31==row['selected']
   for kind in ['target','selected']:
    pred=z[kind+'_predictions'][i];truth=z[kind+'_clean'][i];mask=z[kind+'_mask'][i].astype(bool)
    for region,subset in [('hidden',mask),('visible',~mask),('all',np.ones_like(mask,bool))]:
     expected=row[kind+'_'+region+'_mse']
     if subset.any():np.testing.assert_allclose(float(np.mean((pred[subset]-truth[subset])**2)),expected,rtol=1e-12,atol=1e-12)
     else:assert expected is None
     checked+=1
   assert float(abs(z['target_predictions'][i]-z['selected_predictions'][i]).max())==row['max_prediction_difference']
 print('Verified',len(result['rows']),'localizations and',checked,'target/selected-field scores.')
if __name__=='__main__':main()
