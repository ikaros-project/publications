"""Verify release files and optional trained weights/raw MNIST; never import experiment runners."""
from pathlib import Path
import argparse,hashlib,json,ast
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--weights',action='store_true');p.add_argument('--mnist',action='store_true');p.add_argument('--models',nargs='+',type=int,choices=range(71001,71011));p.add_argument('--shared-weights',action='store_true');a=p.parse_args();count=0
 for line in (ROOT/'SHA256SUMS').read_text().splitlines():
  expected,name=line.split('  ',1);f=ROOT/name;assert f.resolve().is_relative_to(ROOT) and f.is_file() and not f.is_symlink(),name;assert sha(f)==expected,'Checksum mismatch: '+name
  if f.suffix=='.py':ast.parse(f.read_text())
  count+=1
 manifest=json.loads((ROOT/'WEIGHTS_MANIFEST.json').read_text())
 selected=set(manifest) if a.weights else set()
 if a.models:selected.update(f'model_{model}.npz' for model in a.models)
 if a.shared_weights:selected.update(['evaluator_weights.npz','alternative_reference_codes.npz'])
 for name in sorted(selected):
  f=ROOT/'weights'/name
  assert f.is_file() and not f.is_symlink(),'Missing or unsafe weight file: '+name
  assert sha(f)==manifest[name]['sha256'],'Weight checksum mismatch: '+name
 if a.mnist:
  for name,v in json.loads((ROOT/'MNIST_SHA256.json').read_text()).items():assert sha(ROOT/'UserData/cvae_mnist/raw'/name)==v,'MNIST checksum mismatch: '+name
 print('Verified',count,'code/evidence files. Requested optional checks passed.')
if __name__=='__main__':main()
