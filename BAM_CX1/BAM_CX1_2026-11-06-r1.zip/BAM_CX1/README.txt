BAM_CX1 object and spatial processing — reproducibility release 2026-11-06-r1

INSTALLATION
Extract BAM_CX1_2026-11-06-r1.zip first. Then choose either:
- All models and shared arrays: BAM_CX1_trained_weights_2026-11-06-r1.zip.
- Individual models: BAM_CX1_weights_<model>_2026-11-06-r1.zip, with model IDs
  71001 through 71010. Each contains one complete model, approximately 61 MB.
  Add BAM_CX1_shared_weights_2026-11-06-r1.zip (approximately 1.8 MB) for the
  independent evaluator and alternative-reference-bank arrays.
All archives extract into the same BAM_CX1/ folder. The combined and individual
model files are identical. Shared arrays are already in the combined archive.
Ordinary focal/spatial inference needs only the selected model. Image rescoring
needs the shared evaluator. Alternative-bank controls need the shared codes.
Saved-result reanalysis needs no weights. WEIGHT_ARCHIVES.json lists the separate
weight archives and their checksums. SHA256 sidecars accompany every archive.
Use Python 3.12 and install requirements.txt. Tested environment: Python 3.12.14,
NumPy 2.3.5, Pillow 12.3.0 and ReportLab 4.4.9 on macOS ARM64.
All commands below are run from the extracted BAM_CX1 directory.

THREE REPRODUCTION LEVELS
1. Saved-result reanalysis (no model weights or raw dataset required):
   python3 verify_package.py
   python3 summarize_saved_results.py
   python3 score_selected_fields.py
   python3 reproduce.py statistics --output results/recomputed_statistics.json
   python3 reproduce.py figures --output results/figures
   The statistics command recomputes original crossed model/source-cluster
   bootstrap contrasts for QMNIST confirmation, retrieval controls, pathway
   ablations and independent evaluation, and verifies them against supplied
   summaries. Stability endpoint counts are checked separately. Original
   development-era numerical evidence and analysis source are also retained.
   score_selected_fields recomputes all 120 original completion localizations
   and target/selected-field reconstruction scores from compact endpoints.

2. Fresh inference with the supplied weights (no Ikaros build required):
   The following verification sequence assumes the combined weights archive:
   python3 verify_package.py --weights
   python3 reproduce.py verify-inference --spatial
   python3 reproduce.py verify-controls
   python3 reproduce.py rescore-images
   python3 reproduce.py focal --model 71001 --start 0 --count 3 --mode full --output results/focal.npz
   python3 reproduce.py spatial --model 71001 --job 1 --output results/spatial.npz
   These commands execute the original Python model equations using exported
   arrays. verify-inference evaluates three focal inputs and a full 600-update
   spatial completion trajectory for each of the three confirmation models.
   It checks images, activities, reference addresses and winners against saved
   outputs. A 3e-5 numerical tolerance allows platform differences. The release
   environment achieved exact equality. All ten trained models are supplied.
   rescore-images reproduces all 18,630 saved independent-classifier predictions.

   For a single model, for example 71001:
   python3 verify_package.py --models 71001
   python3 reproduce.py focal --model 71001 --output results/model71001.npz
   After adding the shared archive, check it with:
   python3 verify_package.py --models 71001 --shared-weights
   --weights verifies all ten models and both shared arrays. --models verifies
   only the listed models. verify-inference --models accepts 71001, 71002 and
   71003, for which saved verification fixtures are supplied. Its default checks
   all three. verify-controls needs model 71001 and the shared bank codes.
   rescore-images needs only the shared evaluator and the supplied saved images.

   Other supported focal conditions: --mode none, fixed, direct, pixel, single.
   --count 1035 processes all focal QMNIST inputs for one model.
   --dataset legacy selects all 380 original reference-bank/control stimuli.
   --bank 1 --size 32 selects an alternative bank (first model only).
   --random-decoder vae --fraction 0.5 --realization 0 reproduces a fixed VAE
   weight randomization. Use patch for the pixel decoder. All other components
   remain unchanged; VAE randomization affects reference predictions too.
   --source extension selects the second QMNIST spatial campaign's jobs.
   Spatial --mode supports no_content, no_category_bias,
   no_spatial_competition, no_gain, no_mismatch and no_gain_no_content.
   Spatial --config accepts a JSON file with alpha, inhibition, maximum,
   category_cue and spatial_cue. --steps sets the numerical horizon. Default
   settings match the retained model. Consult protocols before varying them.

3. Training from scratch:
   Obtain the standard four MNIST gzip IDX files, put them in
   UserData/cvae_mnist/raw/, and check them with verify_package.py --mnist.
   Raw datasets are not bundled. MNIST_SHA256.json lists exact checksums.
   python3 train_evaluator.py --output results/new_evaluator
   This repeats the external classifier’s 30-epoch training-derived validation
   selection and then refits all 60,000 training examples for the selected duration.
   No test examples or reconstructed images select its settings.

   For the original sensory/readout/decoder training:
   python3 prepare_inputs.py
   python3 train_retained_components.py sensory --seeds 71001
   python3 train_retained_components.py readout --seeds 71001
   python3 train_retained_components.py decoder --seeds 71001
   Sensory training requires a separately installed compatible Ikaros build.
   Set IKAROS_EXECUTABLE to that binary. The included CVAE and PatchCodebook
   sources define the retained module behavior. Framework integration and the
   full 1,800,000-update training campaign were NOT rerun for this release. The
   exact historical Ikaros framework commit was not recorded. We therefore do
   not claim a verified fresh-platform native build or bitwise retraining of
   the ten original models. These limitations do not affect the tested pure
   Python inference and statistical reproduction routes above. See
   LEGACY_README.txt for native integration and original training details.

CONTENTS AND PROVENANCE
weights/ (when the combined archive is installed): ten codebooks, VAE arrays (including log-variance parameters), readouts,
pixel decoders, exact stored reference codes, reference image indices/pixels,
alternative reference-bank codes, and the independent image evaluator. No
optimizer states, bulk training-code exports or full activity histories.
reference_results/: original numerical evidence plus revision/ campaigns.
Revision protocols and stimulus manifests identify original MNIST/QMNIST source
indices, pairings, noise realizations, layouts, masks and selections. Exact
prepared input arrays are included for the supported inference experiments.
QMNIST download code and upstream URLs are in download_qmnist_confirmation.py.
Its original download metadata and source identifiers accompany the evidence.
Source/: original experiment/dependency scripts and native module sources.
verification/: small saved endpoint/trajectory fixtures for numerical checks.
experiment_map.csv and revision_experiment_map.csv map results to scripts/data.
WEIGHTS_MANIFEST.json and SHA256SUMS identify the actual supplied files.
revision_provenance.json distinguishes original protocol hashes from sanitized
release-copy hashes. Identifying filesystem/runtime metadata were removed,
without changing numerical observations. String labels formerly stored in a
few NPZ files were moved to adjacent JSON metadata files. Arrays are numeric.
VALIDATION.json records checks actually performed for this release.

HISTORICAL DRIVERS VERSUS SUPPORTED COMMANDS
The Source/ files preserve the scientific implementation and development history.
Some historical main() drivers expect native states, full training-code CSVs,
earlier array histories or specific campaign outputs. They are not all standalone
programs against this compact archive. The supported reproduce.py commands above
avoid those dependencies. Do not assume that invoking every historical script
from an empty UserData tree will work. Full historical figure/trajectory replay
may require regenerating inputs and omitted histories. Historical checkpoint
hashes are provenance, not expected hashes for newly retrained models.
reference_results/ is read-only evidence. New computations go to the explicit
--output location and do not silently skip work because saved results exist.
Shared inputs, reused control endpoints and repeated model/image observations
must not be counted as independent replications. The external classifier was
trained independently of the generative model but uses the same MNIST training
population. Its bootstrap results are conditional on one frozen evaluator.

SIZE, PRIVACY AND DISTRIBUTION
The archives exclude manuscripts, review correspondence, private notes, shell
logs, local caches, raw downloaded datasets and machine-specific path metadata.
Run python3 audit_release.py to repeat the text/path/credential scan and numeric
array validation. Pattern scans are supplemented by explicit file selection.
No files are uploaded automatically. This is a local versioned release package,
not a claim of a deposited DOI or public repository tag.
Existing source notices and upstream Ikaros/MNIST/QMNIST terms remain applicable.
No new license is assigned by this archive.
