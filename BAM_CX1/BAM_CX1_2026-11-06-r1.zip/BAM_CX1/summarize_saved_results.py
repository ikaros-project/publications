"""Recompute key aggregate checks from supplied records, without model weights."""
from pathlib import Path
import json,statistics
R=Path(__file__).resolve().parent/'reference_results'
def get(suffix):
    matches=[p for p in R.rglob('*.json') if p.as_posix().endswith(suffix)]
    if len(matches)!=1:raise RuntimeError('Expected one record for '+suffix)
    return json.loads(matches[0].read_text())
def main():
    a=get('neural_readout_regularized_capacity/results.json')
    values=[x['test']['accuracy'] for x in a['per_seed']]
    mean=statistics.mean(values);sd=statistics.stdev(values)
    assert len(values)==10 and abs(mean-a['summary']['accuracy_mean'])<1e-12
    assert abs(sd-a['summary']['accuracy_sd'])<1e-12
    print('Categorization: %.3f%%; model SD %.3f percentage points; n=%d'%(100*mean,100*sd,len(values)))
    m=get('relaxation_full_mixtures_ten_seeds/results.json')
    for method in ['none','relaxation']:
        rr=[x for x in m['per_seed'] if x['method']==method]
        v=statistics.mean(x['final_winner_agreement'] for x in rr)
        assert abs(v-m['summary'][method]['final_winner_agreement']['mean'])<1e-12
        print('Mixtures, %s: image/winner agreement %.2f%%; changed winners %d'%(method,100*v,sum(x['final_changed'] for x in rr)))
    s=get('Manuscript/spatial_article_suite_statistics.json')
    print('Spatial experimental conditions:',s['experimental_n'])
    print('Spatial saved rows:',len(s['rows']))
    print('Spatial completion status:',s['complete'])
    print('The full per-trial records and all remaining summaries are under reference_results.')
if __name__=='__main__':main()
