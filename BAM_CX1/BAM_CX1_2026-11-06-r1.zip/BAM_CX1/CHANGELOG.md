# Release 2026-11-06-r1

- Added a separate compressed archive of all ten trained models and the frozen independent image evaluator.
- Preserved exact reference indices and representations, including alternative banks used in the sensitivity analysis.
- Added revision protocols, stimulus provenance, numerical endpoints and analysis source.
- Added portable commands for focal/spatial inference, reference-bank controls, decoder randomization, independent image rescoring, statistical verification and selected figure regeneration.
- Added external-evaluator retraining and retained the original native training adapters.
- Removed identifying runtime metadata and checked numeric array payloads.
- Preserved the2026-10-03package. No original scientific records or learned parameters were modified.
- Native framework compilation and full sensory retraining remain outside the performed validation. See README.txt and VALIDATION.json.

The release is named BAM_CX1. All archives extract into BAM_CX1/.
Individual model archives and a separate shared-weights archive are available.
Selective weight verification is supported through --models and --shared-weights.
