"""Retrain the retained configuration without repeating development sweeps."""
from pathlib import Path
import argparse,json,os,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parent
TEST=ROOT/'Source/Modules/BrainModels/ConvolutionalVariationalAutoEncoder/tests'
sys.path.insert(0,str(TEST))
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage',choices=['sensory','readout','decoder'])
    p.add_argument('--seeds',type=int,nargs='+',default=list(range(71001,71011)))
    a=p.parse_args()
    if a.stage=='sensory':
        binary=os.environ.get('IKAROS_EXECUTABLE')
        if not binary or not Path(binary).is_file():p.error('Set IKAROS_EXECUTABLE to a compatible locally built Ikaros executable.')
        for seed in a.seeds:
            subprocess.run([sys.executable,str(TEST/'run_mnist_patch_codebook.py'),'--train-count','60000','--test-count','10000','--ticks','1800000','--seed',str(seed),'--agent','reproduction','--code-count','64','--kernel','7','--temperature','.08','--upper-loss','categorical'],check=True)
        return
    import evaluate_regularized_capacity as readout
    dest=readout.OUT;dest.mkdir(parents=True,exist_ok=True)
    (dest/'full_refit').mkdir(exist_ok=True)
    rel=dest.relative_to(ROOT)
    for name in ['selection.json','split_indices.npz']:
        source=ROOT/'reference_results'/rel/name
        target=dest/name
        if not target.exists():shutil.copyfile(source,target)
    if a.stage=='readout':
        assert json.loads((dest/'selection.json').read_text())['selected']['units']==200
        for seed in a.seeds:readout.run(seed,full=True,verify_previous=False)
    else:
        import local_patch_decoder_seed_worker as decoder
        for seed in a.seeds:
            folder=readout.n.CAMPAIGN/('local_linear_patch_decoder_seed1' if seed==71001 else f'local_linear_patch_decoder_ten_seeds/seed{seed}')
            folder.mkdir(parents=True,exist_ok=True)
            decoder.run(seed,folder,fit_only=True)
if __name__=='__main__':main()
