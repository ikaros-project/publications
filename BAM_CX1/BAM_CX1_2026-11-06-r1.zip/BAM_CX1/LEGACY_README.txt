Historical training documentation. For current BAM_CX1 installation, archive
choices and verified commands, use README.txt.

  BAM_CX1 object and spatial processing: source and numerical results
Package assembled 2026-10-03 from the frozen 2026-09-23 experimental version.

PURPOSE AND CONTENTS
This compact package contains model source, training/evaluation/plotting scripts,
experimental input selections and saved numerical evidence. It excludes native
model states, learned weights, latent-code exports, raw MNIST archives, large
activity histories, manuscript drafts, private notes, logs and machine caches.
No full trained network is included. Running simulations requires retraining.

Source/ retains the module and experiment-script layout.
reference_results/ contains historical JSON/CSV measurements, trial protocols,
selected stimulus arrays and reference/split indices. These are kept separate
from UserData/, where new computations write their outputs. This prevents the
historical results from making a new runner silently skip training or inference.
Manuscript/ contains only figure-generation code, not the manuscript text.
assembly_provenance.json identifies frozen sources and extra dependencies.
SHA256SUMS covers the files actually supplied in this release.

QUICK CHECK (Python standard library only)
From the extracted package root:
    python3 verify_package.py
    python3 summarize_saved_results.py
The second command recomputes categorization mean/SD and mixture-agreement
summaries from per-model records. Expected values include 97.637% accuracy,
0.117 percentage-point SD, and image/winner agreement 80.41% without feedback
versus 96.86% with relaxation feedback. It also reports the spatial-suite record
counts. The main suite has 1,091 experimental cases and two verification cases.
Another 90 compatible cases were reused in the article, giving 1,181 experimental
conditions in total. Keep the verification cases outside experimental denominators.

ENVIRONMENT
The recorded experimental environment was Python 3.12.14, NumPy 2.3.5,
Pillow 12.3.0 and ReportLab 4.4.9, on macOS ARM64. requirements.txt records these
Python package versions and the optional Matplotlib plotting dependency.
Create a Python environment and install with:
    python3 -m pip install -r requirements.txt
The runners use POSIX fcntl locks. Use macOS or Linux, not native Windows.
Python packages are not bundled. An Ikaros build is needed for sensory training.
The package does not contain the complete Ikaros framework or a binary.

IKAROS INTEGRATION
Use an Ikaros checkout compatible with the included CVAE .cc/.ikc files and
CategoricalReconstruction.h. The PatchCodebook Python module and its .ikc file
are supplied under Source/UserModules/PatchCodebook. Register these modules in
your separate Ikaros installation using its normal module/build mechanism.
The build must support categorical reconstruction, Python modules, native
state loading/saving, and the command-line options used by run_mnist_two_layer.py.
Set IKAROS_EXECUTABLE to your locally built executable before training. This
is an environment variable, not a machine-specific path embedded in the code.
The historical framework commit was not recorded in the frozen snapshot. This
package therefore does not claim a verified exact Ikaros build pin or a tested
fresh-platform installation. Installing and compiling a compatible framework
remains a prerequisite. The included model source defines the experimental
module behavior and is preferable to assuming the latest framework is identical.

DATA AND TRAINING
Obtain the four standard gzip MNIST IDX files and place them in:
    UserData/cvae_mnist/raw/
The required filenames and exact SHA-256 digests are in MNIST_SHA256.json.
verify_package.py --mnist verifies them after installation. The existing training
scripts generate centered, padded images. Raw MNIST is not included here.

Preserve the supplied experiment inputs and selections:
    python3 prepare_inputs.py
Retrain the retained architecture, beginning with one model if desired:
    python3 train_retained_components.py sensory --seeds 71001
    python3 train_retained_components.py readout --seeds 71001
    python3 train_retained_components.py decoder --seeds 71001
Omit --seeds to process all ten recorded initializations (71001 through 71010).
These commands are substantial computation, not packaging checks.

The sensory command uses 60,000 training images, 10,000 test images, 1,800,000
updates, 64 local codes, 7x7 valid patches, soft temperature 0.08, 128 upper latent
dimensions and categorical reconstruction. It also regenerates code exports.
The readout command uses the retained 200-unit, 260-pass configuration with
smoothing 0.05 and decay 0.1, without repeating the development capacity search.
The decoder command uses the original per-model local fit and ridge-selection
procedure, stopping after the decoder is saved. Its historical downstream
comparison experiments are not prerequisites for obtaining a trained decoder.
Stored reference indices identify particular MNIST training images. Keeping them
fixes the experimental selections, not newly trained network predictions.

EXPERIMENTS AND ANALYSIS
experiment_map.csv maps the retained experiment families to their runners and
saved evidence. Scripts are in:
    Source/Modules/BrainModels/ConvolutionalVariationalAutoEncoder/tests/
Focal models and spatial models have different recorded update settings. Do not
substitute development-script defaults for the protocols saved with the results.
The final spatial entry point is run_spatial_article_suite.py. Content feedback
is implemented by run_spatial_population_feedback.py and the rate circuit by
neural_spatial_rate_model.py. The article suite also uses earlier compatible
search, overlap and blank-display trials. Their source and numerical records are
included. Their omitted array histories must be recomputed to rerun the original
full spatial validator or all original figure-generation commands.

The original experimental drivers are retained with their dependency chains.
Some run methods compare against earlier saved stages or reuse their arrays.
They are not independent single-command programs. Read their preparation stages
and the saved protocol/jobs files before running a campaign. In particular,
run_spatial_final_confirmation.py, run_spatial_population_feedback.py and
run_spatial_absent_category.py generate reused spatial evidence. Historical
checkpoint hash checks describe the original trained models and must not be
interpreted as expected hashes of freshly retrained models.

All stored numerical summaries can be inspected without model states. Selected
CSV plot data are supplied. Generating every original image panel requires
rerunning the corresponding simulation because large image/activity arrays were
intentionally omitted. Fresh training can differ numerically across compilers,
libraries and hardware, even with fixed random seeds.

PACKAGING CHANGES AND VALIDATION LIMITS
Numerical observations are retained. Identifying machine metadata fields were
excluded during serialization. Three system-font references were replaced by a
portable Pillow font. Sensory execution accepts IKAROS_EXECUTABLE. The readout
function has an explicit option to omit comparison with the historical validation
checkpoint when fitting a new model. Decoder fitting has a fit-only option.
These adaptations do not change the learning or inference equations.

Package checks cover archive integrity, file hashes, Python syntax, saved-result
summary checks and scans for local paths, email addresses and credential patterns.
Numeric NPZ contents were inspected for nonnumeric/object data. Core imports were
smoke-tested. Full training, native compilation and end-to-end regeneration of
all experiments have NOT been repeated for this package. The original freeze
remains unchanged. No files have been uploaded by the packaging process.

LICENSING
Existing source notices are retained. No new license is assigned by this package.
Ikaros and the MNIST dataset remain subject to their respective upstream terms.
