"""Check supplied files for machine paths, credentials, unsafe archives and object arrays."""
from pathlib import Path
import re,json,zipfile,ast
import numpy as np
ROOT=Path(__file__).resolve().parent
PATTERNS={
'user_home':r'/(?:Users|home)/[A-Za-z0-9_.-]+/',
'macos_private_temp':r'/(?:private/)?var/folders/[A-Za-z0-9_-]+/',
'windows_home':r'[A-Za-z]:\\Users\\[A-Za-z0-9_.-]+',
'email':r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.(?:com|org|net|edu|se|fr|uk|io)\b',
'credential':r'(?i)(?:api[_-]?key|access[_-]?token|password|secret)\s*[:=]\s*[\"\x27][A-Za-z0-9_-]{16,}',
'private_key':r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'}

def run():
 findings=[];arrays=0;texts=0;files=0
 for p in ROOT.rglob('*'):
  rel=p.relative_to(ROOT)
  if any(v in ['__pycache__','results'] for v in rel.parts):continue
  if p.is_symlink():findings.append(dict(file=str(rel),kind='symlink'));continue
  if not p.is_file():continue
  files+=1
  if p.suffix in ['.npz','.npy']:
   if p.suffix=='.npz':
    with np.load(p,allow_pickle=False) as z:
     for name in z.files:
      a=z[name];assert a.dtype.kind in 'biufc',('Non-numeric array',str(rel),name);arrays+=1
   else:assert np.load(p,allow_pickle=False).dtype.kind in 'biufc';arrays+=1
   continue
  try:s=p.read_text()
  except UnicodeDecodeError:continue
  texts+=1
  for kind,pattern in PATTERNS.items():
   if re.search(pattern,s):findings.append(dict(file=str(rel),kind=kind))
  if p.suffix=='.py':ast.parse(s)
 if findings:raise RuntimeError(json.dumps(findings))
 return dict(files_scanned=files,text_files_scanned=texts,numeric_arrays_checked=arrays,findings=0,scope='Pattern-based scan plus explicit inclusion list, metadata scrubbing, numeric-only array validation and symlink rejection. No manuscript drafts, correspondence, logs, credentials or raw dataset downloads included.')
if __name__=='__main__':print(json.dumps(run(),indent=2))
