"""Supported standalone release commands. No machine-specific file locations."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1');os.environ.setdefault('VECLIB_MAXIMUM_THREADS','1')
import argparse,json,time
from pathlib import Path
import numpy as np
import release_runtime as r

def main():
 p=argparse.ArgumentParser();sub=p.add_subparsers(dest='command',required=True)
 for name in ['focal','spatial']:
  a=sub.add_parser(name);a.add_argument('--model',type=int,default=71001);a.add_argument('--output',type=Path,required=True)
  if name=='focal':
   a.add_argument('--start',type=int,default=0);a.add_argument('--count',type=int,default=3);a.add_argument('--mode',choices=['full','none','fixed','direct','pixel','single'],default='full');a.add_argument('--dataset',choices=['qmnist','legacy'],default='qmnist');a.add_argument('--bank',type=int,default=0);a.add_argument('--size',type=int,choices=[1,2,4,8,16,32],default=8);a.add_argument('--random-decoder',choices=['patch','vae']);a.add_argument('--fraction',type=float,default=0);a.add_argument('--realization',type=int,default=0)
  else:
   a.add_argument('--job',type=int,default=1);a.add_argument('--source',choices=['confirmation','extension'],default='confirmation');a.add_argument('--steps',type=int,default=600);a.add_argument('--mode',choices=['full','no_content','no_category_bias','no_spatial_competition','no_gain','no_mismatch','no_gain_no_content'],default='full');a.add_argument('--config',type=Path)
 a=sub.add_parser('verify-inference');a.add_argument('--spatial',action='store_true');a.add_argument('--models',nargs='+',type=int,default=[71001,71002,71003]);a.add_argument('--output',type=Path,default=r.ROOT/'results/inference_verification.json')
 a=sub.add_parser('figures');a.add_argument('--output',type=Path,default=r.ROOT/'results/figures')
 a=sub.add_parser('verify-controls');a.add_argument('--output',type=Path,default=r.ROOT/'results/control_verification.json')
 a=sub.add_parser('statistics');a.add_argument('--output',type=Path,default=r.ROOT/'results/recomputed_statistics.json')
 a=sub.add_parser('rescore-images');a.add_argument('--output',type=Path,default=r.ROOT/'results/rescored_images.json')
 args=p.parse_args();start=time.time()
 if args.command in ['focal','spatial']:
  if args.command=='focal':out=r.focal(args.model,args.start,args.count,args.mode,args.dataset,args.bank,args.size,args.random_decoder,args.fraction,args.realization)
  else:out=r.spatial(args.model,args.job,args.source,args.mode,args.steps,None if args.config is None else r.read(args.config))
  args.output.parent.mkdir(parents=True,exist_ok=True);np.savez_compressed(args.output,**{k:v for k,v in out.items() if isinstance(v,np.ndarray)});print('Inference finished in',round(time.time()-start,2),'seconds');return
 if args.command=='verify-inference':
  out=[]
  for seed in args.models:
   res=r.focal(seed)
   with np.load(r.ROOT/'verification'/f'focal_{seed}.npz',allow_pickle=False) as z:
    ie=float(abs(res['images']-z['images']).max());ae=float(abs(res['acts']-z['activities']).max());np.testing.assert_array_equal(res['chosen'],z['reference_slots']);assert ie<3e-5 and ae<3e-5,(ie,ae);np.testing.assert_array_equal(res['acts'].argmax(2),z['activities'].argmax(2))
   row=dict(model=seed,focal_image_error=ie,focal_activity_error=ae)
   if args.spatial:
    res=r.spatial(seed)
    with np.load(r.ROOT/'verification'/f'spatial_{seed}.npz',allow_pickle=False) as z:
     errors={k:float(abs(res[k]-z[k]).max()) for k in z.files};assert max(errors.values())<3e-5,errors;np.testing.assert_array_equal(res['category_trace'].argmax(1),z['category_trace'].argmax(1));np.testing.assert_array_equal(res['spatial_trace'].argmax(1),z['spatial_trace'].argmax(1));row['spatial_errors']=errors
   out.append(row);print('Verified model',seed,flush=True)
 elif args.command=='figures':
  from release_figures import run
  run(args.output);print('Figures regenerated');return
 elif args.command=='verify-controls':
  out=[]
  for case in r.read(r.ROOT/'verification/control_cases.json'):
   res=r.focal(**case['args'])
   with np.load(r.ROOT/'verification'/(case['name']+'.npz'),allow_pickle=False) as z:error=float(abs(res['images']-z['images']).max())
   assert error<3e-5,(case['name'],error)
   out.append(dict(case=case['name'],maximum_image_error=error))
 elif args.command=='statistics':
  from release_statistics import run
  out=run()
 elif args.command=='rescore-images':
  from run_independent_image_evaluator import predict
  path=r.ROOT/'weights/evaluator_weights.npz';assert r.sha(path)==r.read(r.ROOT/'WEIGHTS_MANIFEST.json')[path.name]['sha256']
  with np.load(path,allow_pickle=False) as z:w={k:z[k] for k in z.files}
  checked=0
  for seed in [71001,71002,71003]:
   for mode in ['none','pixel_retrieval','reference_decoding','single_step','fixed','full']:
    f=r.EVIDENCE/'qmnist_retrieval_controls_20261105'/f'model{seed}_{mode}.npz'
    with np.load(f,allow_pickle=False) as z:pred=predict(w,z['images']).argmax(1)
    expected=[v['mlp_category'] for v in r.read(r.EVIDENCE/'independent_image_evaluation_20261106/focal_results.json') if v['seed']==seed and v['mode']==mode];np.testing.assert_array_equal(pred,expected);checked+=len(pred)
  out=dict(predictions_verified=checked,all_match=True)
 args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(out,indent=2)+'\n');print('Completed',args.command,'in',round(time.time()-start,2),'seconds')
if __name__=='__main__':main()
